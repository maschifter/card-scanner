/** Moonshine wrapper contract, offline: `input_values` goes to the
 *  transcriber as one clip, its ids come back as int64 [1, L]; clips too
 *  short for one encoder frame return BOS+EOS without a GPU call. The
 *  loader's preset pick is checked against tiny/base/other configs. */

import { afterEach, describe, expect, it, vi } from 'vitest';
import { PreTrainedModel, Tensor, type PretrainedConfig } from '@huggingface/transformers';

vi.mock('@tie/core', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@tie/core')>()),
  defaultRoot: () => ({ device: {} }),
  inGpuErrorScopes: (_device: unknown, _label: string, fn: () => Promise<unknown>) => fn(),
}));

const { TieMoonshineForConditionalGeneration } =
  await import('../src/transformers/moonshine/model.ts');
const { MOONSHINE_MODEL_IDS, moonshinePreset } =
  await import('../src/transformers/moonshine/loader.ts');
const { registerTieBackend, unregisterTieBackend } = await import('../src/transformers/index.ts');
const { MIN_SAMPLES } = await import('../src/moonshine/convStem.ts');

const CONFIG = { model_type: 'moonshine' } as unknown as PretrainedConfig;
const TOKENS = { bos: 1, eos: 2 };

/** Returns [BOS, sample count, EOS] so the ids say what audio came in. */
function fakeTranscriber() {
  const calls: Float32Array[] = [];
  const tie = {
    transcribe: async (audio: Float32Array) => {
      calls.push(audio);
      return {
        ids: [TOKENS.bos, audio.length, TOKENS.eos],
        text: '',
        timings: { encodeMs: 0, decodeMs: 0, steps: 2 },
      };
    },
  };
  return { tie, calls };
}

const audio = (samples: number, batch = 1): Tensor =>
  new Tensor('float32', new Float32Array(batch * samples), [batch, samples]);

const ids = (t: Tensor): number[] => Array.from(t.data as BigInt64Array, Number);

/** Hub config.json of moonshine-tiny, trimmed to what the parser reads. */
const TINY_CONFIG = {
  model_type: 'moonshine',
  attention_bias: false,
  bos_token_id: 1,
  eos_token_id: 2,
  decoder_start_token_id: 1,
  hidden_size: 288,
  intermediate_size: 1152,
  encoder_num_hidden_layers: 6,
  decoder_num_hidden_layers: 6,
  encoder_num_attention_heads: 8,
  decoder_num_attention_heads: 8,
  max_position_embeddings: 194,
  partial_rotary_factor: 0.9,
  rope_theta: 10000,
  vocab_size: 32768,
};
const BASE_CONFIG = {
  ...TINY_CONFIG,
  hidden_size: 416,
  intermediate_size: 1664,
  encoder_num_hidden_layers: 8,
  decoder_num_hidden_layers: 8,
  partial_rotary_factor: 0.62,
};

describe('TieMoonshineForConditionalGeneration', () => {
  it('is a transformers.js model', () => {
    const { tie } = fakeTranscriber();
    expect(new TieMoonshineForConditionalGeneration(CONFIG, tie, TOKENS)).toBeInstanceOf(
      PreTrainedModel,
    );
  });

  it('returns the transcriber ids as int64 [1, L]', async () => {
    const { tie, calls } = fakeTranscriber();
    const model = new TieMoonshineForConditionalGeneration(CONFIG, tie, TOKENS);
    const out = await model.generate({ input_values: audio(16_000), max_new_tokens: 18 });
    expect(out.type).toBe('int64');
    expect(out.dims).toEqual([1, 3]);
    expect(ids(out)).toEqual([1, 16_000, 2]);
    expect(calls).toHaveLength(1);
    expect(calls[0]).toBeInstanceOf(Float32Array);
  });

  it('accepts the clip under `inputs` too', async () => {
    const { tie } = fakeTranscriber();
    const model = new TieMoonshineForConditionalGeneration(CONFIG, tie, TOKENS);
    expect(ids(await model.generate({ inputs: audio(2000) }))).toEqual([1, 2000, 2]);
  });

  it('returns BOS+EOS for a clip shorter than one encoder frame', async () => {
    const { tie, calls } = fakeTranscriber();
    const model = new TieMoonshineForConditionalGeneration(CONFIG, tie, TOKENS);
    expect(ids(await model.generate({ input_values: audio(MIN_SAMPLES - 1) }))).toEqual([1, 2]);
    expect(calls).toHaveLength(0);
    expect(ids(await model.generate({ input_values: audio(MIN_SAMPLES) }))).toEqual([
      1,
      MIN_SAMPLES,
      2,
    ]);
  });

  it('rejects a batch of clips and a missing clip', async () => {
    const { tie } = fakeTranscriber();
    const model = new TieMoonshineForConditionalGeneration(CONFIG, tie, TOKENS);
    await expect(model.generate({ input_values: audio(2000, 2) })).rejects.toThrow(/one clip/);
    await expect(model.generate({})).rejects.toThrow(/input_values/);
  });
});

describe('moonshinePreset', () => {
  it('matches the tiny and base hub configs', () => {
    expect(moonshinePreset(TINY_CONFIG as unknown as PretrainedConfig).size).toBe('tiny');
    expect(moonshinePreset(BASE_CONFIG as unknown as PretrainedConfig).size).toBe('base');
  });

  it('keeps the preset position count over the config value', () => {
    const onnxCommunity = { ...TINY_CONFIG, max_position_embeddings: 512 };
    expect(moonshinePreset(onnxCommunity as unknown as PretrainedConfig).cfg.maxPositions).toBe(
      194,
    );
  });

  it('rejects another size and a field the preset does not have', () => {
    const other = { ...TINY_CONFIG, hidden_size: 320 } as unknown as PretrainedConfig;
    expect(() => moonshinePreset(other)).toThrow(/neither tiny nor base/);
    const drift = { ...TINY_CONFIG, intermediate_size: 1000 } as unknown as PretrainedConfig;
    expect(() => moonshinePreset(drift)).toThrow(/ffn/);
  });
});

describe('registerTieBackend', () => {
  afterEach(() => unregisterTieBackend());

  it('registers the moonshine hub ids by default', async () => {
    registerTieBackend();
    await expect(PreTrainedModel.from_pretrained('tie-test/none')).rejects.toThrow(
      new RegExp(MOONSHINE_MODEL_IDS.join('|')),
    );
    expect(MOONSHINE_MODEL_IDS).toContain('onnx-community/moonshine-tiny-ONNX');
  });
});
