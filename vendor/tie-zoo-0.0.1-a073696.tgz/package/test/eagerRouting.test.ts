import { describe, expect, it } from 'vitest';
import { groupByExpert, parseTopk, routeTop4 } from '../src/privacy-filter/routing.ts';

describe('parseTopk', () => {
  it('unpacks the [T,2k] packed topk output into a Selection', () => {
    // one token: ids [2,0,3,1], weights [.4,.3,.2,.1]
    const packed = Float32Array.from([2, 0, 3, 1, 0.4, 0.3, 0.2, 0.1]);
    const sel = parseTopk(packed, 1, 4);
    expect(sel.idx[0]).toEqual([2, 0, 3, 1]);
    // f32 round-trips of .4/.3/.2/.1 (the packed buffer is a Float32Array)
    expect(sel.w[0]).toEqual([
      0.4000000059604645, 0.30000001192092896, 0.20000000298023224, 0.10000000149011612,
    ]);
  });
});

describe('routeTop4 (CPU reference mirror of the GPU topk kernel)', () => {
  it('selects the 4 largest logits in descending order with softmax weights', () => {
    // token 0: experts 2 (5.0), 0 (3.0), 3 (1.0), 1 (0.0) — expert 4 (-1) excluded
    const logits = Float32Array.from([3, 0, 5, 1, -1]);
    const sel = routeTop4(logits, 1, 5);
    expect(sel.idx[0]).toEqual([2, 0, 3, 1]);
    const e = [5, 3, 1, 0].map((v) => Math.exp(v - 5));
    const z = e.reduce((s, v) => s + v);
    sel.w[0]!.forEach((w, i) => expect(w).toBeCloseTo(e[i]! / z, 6));
  });
  it('breaks ties by lowest index (torch.topk semantics)', () => {
    const logits = Float32Array.from([1, 1, 1, 1, 1, 1]);
    const sel = routeTop4(logits, 1, 6);
    expect(sel.idx[0]).toEqual([0, 1, 2, 3]);
  });
});

describe('groupByExpert', () => {
  it('groups (token, slot, weight) triples per expert and records pile positions', () => {
    const sel = {
      idx: [
        [2, 0, 3, 1],
        [2, 1, 0, 3],
      ],
      w: [
        [0.4, 0.3, 0.2, 0.1],
        [0.7, 0.1, 0.1, 0.1],
      ],
    };
    const g = groupByExpert(sel, 4);
    // expert 2 selected by tokens 0 (slot 0) and 1 (slot 0)
    const e2 = g.groups.find((x) => x.expert === 2)!;
    expect(e2.tokens).toEqual([0, 1]);
    expect(e2.weights).toEqual([0.4, 0.7]);
    // slotPos maps (token, slot) -> row in the concatenated pile
    for (let t = 0; t < 2; t++) {
      for (let s = 0; s < 4; s++) {
        const pos = g.slotPos[s]![t]!;
        // reconstruct: walking groups in order, row `pos` must belong to token t at slot s
        let r = pos;
        let found: { expert: number; token: number } | undefined;
        for (const grp of g.groups) {
          if (r < grp.tokens.length) {
            found = { expert: grp.expert, token: grp.tokens[r]! };
            break;
          }
          r -= grp.tokens.length;
        }
        expect(found!.token).toBe(t);
        expect(found!.expert).toBe(sel.idx[t]![s]!);
      }
    }
  });
});
