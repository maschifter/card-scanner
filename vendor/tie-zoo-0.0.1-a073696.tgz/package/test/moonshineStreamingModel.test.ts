import { describe, expect, it } from 'vitest';
import { materialized, matrix, type Value, type ValueMeta } from '@tie/core';
// Reuse the @tie/core test helper via a relative import.
import { fakeGpuBuffer } from '../../core/test/helpers.ts';
import {
  MOONSHINE_STREAMING_SMALL,
  type MoonshineStreamingConfig,
} from '../src/moonshine-streaming/config.ts';
import { MoonshineStreamingModel, decoderView } from '../src/moonshine-streaming/model.ts';
import {
  MINI_STREAMING,
  MINI_STREAMING_PROJ,
  buildHfRecord,
  streamingHfShapes,
} from './moonshineTestData.ts';

const fake = (shape: ValueMeta): Value => materialized(shape, fakeGpuBuffer({ id: 'fake' }));

/** Full-model fake bind: the root transform hook runs, so the fake
 *  checkpoint carries HF names (toy dims — shapes are config-driven). */
async function bindFake(model: MoonshineStreamingModel, cfg: MoonshineStreamingConfig) {
  await model.loadStateDict(buildHfRecord(streamingHfShapes(cfg)), {
    upload: (_data, shape) => fake(shape),
  });
}

describe('moonshine-streaming model', () => {
  it('decoderView projects dec dims into the v1 config shape', () => {
    const v = decoderView(MOONSHINE_STREAMING_SMALL);
    expect(v.dModel).toBe(512);
    expect(v.ffn).toBe(2048);
    expect(v.decLayers).toBe(10);
    expect(v.heads).toBe(8);
    expect(v.headDim).toBe(64);
    expect(v.rotaryDim).toBe(32);
    expect(v.vocab).toBe(32768);
    expect(v.bos).toBe(1);
    expect(v.eos).toBe(2);
  });

  it('frontend → encoder → adapter → decoder chain derives config-driven shapes', async () => {
    const cfg = MINI_STREAMING_PROJ; // enc ≠ dec dims — proj engaged
    const model = new MoonshineStreamingModel(cfg);
    await bindFake(model, cfg);
    const T = 6; // ≤ the mini config's maxPositions (the adapter slices posEmb to T)
    const front = model.frontend.forward(fake(matrix(4 * T, cfg.frameLen)));
    expect(front.shape.dims).toEqual([T, cfg.enc.hidden]);
    const enc = model.encoder.forward(front);
    expect(enc.shape.dims).toEqual([T, cfg.enc.hidden]);
    const adapted = model.adapter.forward(enc);
    expect(adapted.shape.dims).toEqual([T, cfg.dec.hidden]);
    const cross = model.decoder.precomputeCrossKV(adapted);
    expect(cross).toHaveLength(cfg.dec.layers);
    const qw = cfg.dec.heads * cfg.dec.headDim;
    expect(cross[0]!.k.shape.dims).toEqual([T, qw]);
    const t = 3;
    const h = model.decoder.forward(
      model.embed([1, 5, 7]),
      fake(matrix(t, cfg.dec.headDim)),
      fake(matrix(t, cfg.dec.headDim)),
      cross,
    );
    expect(h.shape.dims).toEqual([t, cfg.dec.hidden]);
    expect(model.logitsLast(h).shape.dims).toEqual([cfg.vocab, 1]);
  });

  it('logitsLast rejects a dtype mismatch and forward() stays unimplemented', async () => {
    const model = new MoonshineStreamingModel(MINI_STREAMING);
    await bindFake(model, MINI_STREAMING);
    // An f16 h against the f32 embedding: the matmul binds one element type.
    const h16 = fake({
      elems: MINI_STREAMING.dec.hidden,
      dtype: 'f16',
      dims: [1, MINI_STREAMING.dec.hidden],
    });
    expect(() => model.logitsLast(h16)).toThrow(/f32.*f16|f16.*f32/);
    expect(() => model.forward()).toThrow(/frontend\/encoder\/adapter\/decoder/);
  });
});
