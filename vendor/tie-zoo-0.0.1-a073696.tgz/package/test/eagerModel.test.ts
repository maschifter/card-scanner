import { describe, expect, it } from 'vitest';
import { EagerModel } from '../src/privacy-filter/model.ts';

describe('EagerModel structure', () => {
  it('yields checkpoint-shaped dotted parameter names', () => {
    const m = new EagerModel({ blocks: 2, experts: 4, vocab: 50, logits: 33, weightFormat: 'f32' });
    const names = new Set(Array.from(m.namedParameters()).map(([n]) => n));
    // spot-check the contract, not the full list
    expect(names.has('block.0.attn.qkv.weight')).toBe(true);
    expect(names.has('block.1.attn.norm.scale')).toBe(true);
    expect(names.has('block.0.mlp.gate.bias')).toBe(true);
    // MoE expert tensors stay flat camelCase, split glu/lin (loader maps the
    // checkpoint's fused swiglu.* tensors onto them)
    expect(names.has('block.0.mlp.gluWeight')).toBe(true);
    expect(names.has('block.0.mlp.linBias')).toBe(true);
    expect(names.has('block.1.mlp.outWeight')).toBe(true);
    expect(names.has('norm.scale')).toBe(true);
    expect(names.has('unembedding.weight')).toBe(true);
    expect(names.has('unembedding.bias')).toBe(false); // bias-less classifier
    // rope tables are no longer stored on the model — computed per forward call
    const bufs = Array.from(m.namedBuffers()).map(([n]) => n);
    expect(bufs).toEqual([]);
  });
});
