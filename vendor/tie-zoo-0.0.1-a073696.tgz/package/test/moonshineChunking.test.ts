import { describe, expect, it } from 'vitest';
import { splitIntoChunks, type ChunkOpts } from '../src/moonshine/chunking.ts';

/** Small synthetic rates keep the tests readable: 1 kHz "audio", 4 s chunks. */
const OPTS: ChunkOpts = { maxSeconds: 4, searchSeconds: 2, sampleRate: 1000 };

const sine = (len: number, amp = 0.5) =>
  Float32Array.from({ length: len }, (_, i) => amp * Math.sin(i / 3));

describe('splitIntoChunks', () => {
  it('returns short audio whole, as a full-length view of the same buffer', () => {
    const audio = sine(3000);
    const chunks = splitIntoChunks(audio, OPTS);
    expect(chunks).toHaveLength(1);
    expect(chunks[0]!.buffer).toBe(audio.buffer);
    expect(chunks[0]!.byteOffset).toBe(0);
    expect(chunks[0]!.length).toBe(audio.length);
  });

  it('keeps a clip at the ceiling (and slightly over) in one chunk', () => {
    expect(splitIntoChunks(sine(4000), OPTS)).toHaveLength(1);
    // Up to one tail-merge second over the ceiling still avoids a fragment.
    expect(splitIntoChunks(sine(5000), OPTS)).toHaveLength(1);
    expect(splitIntoChunks(sine(5001), OPTS)).toHaveLength(2);
  });

  it('covers every sample exactly once, in order, within the ceiling', () => {
    const audio = sine(23_456);
    const chunks = splitIntoChunks(audio, OPTS);
    expect(chunks.length).toBeGreaterThan(1);
    let cursor = 0;
    for (const [i, chunk] of chunks.entries()) {
      expect(chunk.buffer).toBe(audio.buffer); // subarray view, no copy
      expect(chunk.byteOffset).toBe(cursor * 4);
      const last = i === chunks.length - 1;
      expect(chunk.length).toBeLessThanOrEqual(last ? 5000 : 4000);
      for (let j = 0; j < chunk.length; j += 997) {
        expect(chunk[j]).toBe(audio[cursor + j]);
      }
      cursor += chunk.length;
    }
    expect(cursor).toBe(audio.length);
  });

  it('cuts inside a silent gap rather than at the fixed offset', () => {
    // Loud throughout except samples [2600, 3000) — inside the search window
    // [2000, 4000) of the first chunk. The cut must land in the gap.
    const audio = sine(9000, 0.8);
    audio.fill(0, 2600, 3000);
    const chunks = splitIntoChunks(audio, OPTS);
    expect(chunks[0]!.length).toBeGreaterThanOrEqual(2600);
    expect(chunks[0]!.length).toBeLessThanOrEqual(3000);
  });

  it('falls back to the quietest stretch when nothing is silent', () => {
    const audio = sine(9000, 0.8);
    const chunks = splitIntoChunks(audio, OPTS);
    // No silence to find — still cuts inside the search window.
    expect(chunks[0]!.length).toBeGreaterThanOrEqual(2000);
    expect(chunks[0]!.length).toBeLessThanOrEqual(4000);
  });

  it('rejects a degenerate config loudly', () => {
    expect(() => splitIntoChunks(sine(10), { ...OPTS, maxSeconds: 0 })).toThrow(/degenerate/);
  });
});
