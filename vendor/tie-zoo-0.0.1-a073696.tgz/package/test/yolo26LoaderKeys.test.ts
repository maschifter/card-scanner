/** Full CPU-side load of the exported yolo26n(-seg) safetensors against the TS
 *  model: strict name matching, BN folds, ConvTranspose permute, shape checks —
 *  everything but the GPU (upload is faked with `materialized`).
 *  Skipped when the export hasn't been run locally (fixture absent). */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { bufferSource, fromSafetensors, materialized } from '@tie/core';
import { Yolo26Model } from '../src/yolo26/model.ts';

const FIXTURE = join(
  import.meta.dirname,
  '../../../apps/yolo-demo/public/yolo26n/model.safetensors',
);
const SEG_FIXTURE = join(
  import.meta.dirname,
  '../../../apps/yolo-demo/public/yolo26n-seg/model.safetensors',
);
const POSE_FIXTURE = join(
  import.meta.dirname,
  '../../../apps/yolo-demo/public/yolo26n-pose/model.safetensors',
);

function tryRead(path: string): Uint8Array | undefined {
  try {
    return readFileSync(path);
  } catch {
    return undefined;
  }
}

describe('yolo26n safetensors export ↔ model contract', () => {
  const file = tryRead(FIXTURE);
  it.skipIf(!file)('loads end-to-end with a fake GPU (strict names, shapes, folds)', async () => {
    const sd = await fromSafetensors(bufferSource(file!));
    expect(sd.metadata['format']).toBe('tie');
    const model = new Yolo26Model('n', { task: 'detect' });
    let uploads = 0;
    await model.loadStateDict(sd, {
      upload: (data, shape) => {
        uploads++;
        // Conv weights upload PACKED (hwc4 mat4 tiles, channel-padded) —
        // larger than the raw meta; everything else uploads exactly.
        if (shape.layout === 'hwc4') expect(data.length).toBeGreaterThanOrEqual(shape.elems);
        else expect(data.length).toBe(shape.elems);
        return materialized(shape, {} as never);
      },
    });
    expect(uploads).toBeGreaterThan(100); // every param + buffer bound
  });
});

describe('yolo26n-pose safetensors export ↔ model contract', () => {
  const file = tryRead(POSE_FIXTURE);
  it.skipIf(!file)(
    'loads end-to-end with a fake GPU (nc=1 towers + cv4 keypoint branch)',
    async () => {
      const sd = await fromSafetensors(bufferSource(file!));
      expect(sd.metadata['format']).toBe('tie');
      const model = new Yolo26Model('n', { task: 'pose' });
      let uploads = 0;
      await model.loadStateDict(sd, {
        upload: (data, shape) => {
          uploads++;
          // Conv weights upload PACKED (hwc4 mat4 tiles, channel-padded) —
          // larger than the raw meta; everything else uploads exactly.
          if (shape.layout === 'hwc4') expect(data.length).toBeGreaterThanOrEqual(shape.elems);
          else expect(data.length).toBe(shape.elems);
          return materialized(shape, {} as never);
        },
      });
      expect(uploads).toBeGreaterThan(100); // every param + buffer bound
    },
  );
});

describe('yolo26n-seg safetensors export ↔ model contract', () => {
  const file = tryRead(SEG_FIXTURE);
  it.skipIf(!file)(
    'loads end-to-end with a fake GPU (exercises Proto26 upsample permute)',
    async () => {
      const sd = await fromSafetensors(bufferSource(file!));
      expect(sd.metadata['format']).toBe('tie');
      const model = new Yolo26Model('n', { task: 'segment' });
      let uploads = 0;
      await model.loadStateDict(sd, {
        upload: (data, shape) => {
          uploads++;
          // Conv weights upload PACKED (hwc4 mat4 tiles, channel-padded) —
          // larger than the raw meta; everything else uploads exactly.
          if (shape.layout === 'hwc4') expect(data.length).toBeGreaterThanOrEqual(shape.elems);
          else expect(data.length).toBe(shape.elems);
          return materialized(shape, {} as never);
        },
      });
      expect(uploads).toBeGreaterThan(100); // every param + buffer bound
    },
  );
});
