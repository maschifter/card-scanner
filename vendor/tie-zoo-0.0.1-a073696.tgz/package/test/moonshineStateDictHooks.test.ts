import { describe, expect, it } from 'vitest';
import { materialized, memoryStateDict, type ValueMeta } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core test helper via a relative import.
import { fakeGpuBuffer } from '../../core/test/helpers.ts';
import { MoonshineModel } from '../src/moonshine/model.ts';
import { transformMoonshineStateDict } from '../src/moonshine/stateDictHooks.ts';
import { MINI, buildHfRecord, hfShapes } from './moonshineTestData.ts';

const D = MINI.dModel;
const QW = MINI.heads * MINI.headDim;

/** A fake root that reports shader-f16 support, for model.half() without a
 *  real GPU device — this file never uploads to an actual buffer. */
const fakeF16Root = { enabledFeatures: new Set(['shader-f16']) } as unknown as TgpuRoot;

/** Collect uploads in namedParameters() order; bind fake Values. */
function collector() {
  const calls: Array<{ data: Float32Array | Uint32Array | Uint16Array; shape: ValueMeta }> = [];
  const upload = (data: Float32Array | Uint32Array | Uint16Array, shape: ValueMeta) => {
    calls.push({ data, shape });
    return materialized(shape, fakeGpuBuffer({}));
  };
  return { calls, upload };
}

/** Load a synthetic HF record into a model; return uploads keyed by name. */
async function loadFake(
  model: MoonshineModel,
): Promise<Map<string, { data: Float32Array | Uint32Array | Uint16Array; shape: ValueMeta }>> {
  const { calls, upload } = collector();
  await model.loadStateDict(buildHfRecord(hfShapes(MINI)), { upload });
  const names = [...model.namedParameters()].map(([n]) => n);
  expect(calls.length).toBe(names.length);
  return new Map(names.map((n, i) => [n, calls[i]!]));
}

describe('transformMoonshineStateDict', () => {
  it('maps the full HF key set onto namedParameters() in torch layouts', () => {
    const sd = memoryStateDict(buildHfRecord(hfShapes(MINI)));
    transformMoonshineStateDict(sd, '', MINI);
    const expected = [...new MoonshineModel(MINI).namedParameters()].map(([n]) => n);
    expect([...sd.tensors.keys()].sort()).toEqual(expected.sort());
    // Torch layouts — the core Linear/Conv1d hooks translate them later.
    expect(sd.tensors.get('encoder.layers.0.attn.qkv.weight')!.shape).toEqual([3 * QW, D]);
    expect(sd.tensors.get('decoder.layers.0.crossAttn.kv.weight')!.shape).toEqual([2 * QW, D]);
    expect(sd.tensors.get('decoder.layers.0.crossAttn.q.weight')!.shape).toEqual([QW, D]);
    expect(sd.tensors.get('stem.conv1.weight')!.shape).toEqual([D, 1, 127]);
  });

  it('drops a tied LM head when the checkpoint still carries one', () => {
    const record = buildHfRecord(hfShapes(MINI));
    record['proj_out.weight'] = record['model.decoder.embed_tokens.weight']!;
    const sd = memoryStateDict(record);
    transformMoonshineStateDict(sd, '', MINI);
    expect(sd.tensors.has('proj_out.weight')).toBe(false);
  });

  it('stacks qkv rows in q|k|v order', async () => {
    const filled = (v: number) => new Float32Array(QW * D).fill(v);
    const sd = memoryStateDict(
      buildHfRecord(hfShapes(MINI), {
        'model.encoder.layers.0.self_attn.q_proj.weight': filled(1),
        'model.encoder.layers.0.self_attn.k_proj.weight': filled(2),
        'model.encoder.layers.0.self_attn.v_proj.weight': filled(3),
      }),
    );
    transformMoonshineStateDict(sd, '', MINI);
    const qkv = await sd.tensors.get('encoder.layers.0.attn.qkv.weight')!.f32();
    expect(qkv.length).toBe(3 * QW * D);
    for (let i = 0; i < QW * D; i++) {
      expect(qkv[i]).toBe(1);
      expect(qkv[QW * D + i]).toBe(2);
      expect(qkv[2 * QW * D + i]).toBe(3);
    }
  });

  it('folds 1/√headDim into crossAttn.q only', async () => {
    const ones = new Float32Array(QW * D).fill(1);
    const sd = memoryStateDict(
      buildHfRecord(hfShapes(MINI), {
        'model.decoder.layers.0.encoder_attn.q_proj.weight': ones,
        'model.decoder.layers.0.encoder_attn.k_proj.weight': new Float32Array(QW * D).fill(1),
      }),
    );
    transformMoonshineStateDict(sd, '', MINI);
    const scale = 1 / Math.sqrt(MINI.headDim);
    expect((await sd.tensors.get('decoder.layers.0.crossAttn.q.weight')!.f32())[0]).toBeCloseTo(
      scale,
      6,
    );
    // k rides unscaled into the kv stack.
    expect((await sd.tensors.get('decoder.layers.0.crossAttn.kv.weight')!.f32())[0]).toBe(1);
  });

  it('carries source byteLengths so progress sums to the checkpoint size', async () => {
    const shapes = hfShapes(MINI);
    const total = Object.values(shapes).reduce((s, sh) => s + sh.reduce((a, b) => a * b, 1) * 4, 0);
    const model = new MoonshineModel(MINI);
    const { upload } = collector();
    let last: [number, number] | undefined;
    await model.loadStateDict(buildHfRecord(shapes), {
      upload,
      onProgress: (_name, done, totalBytes) => (last = [done, totalBytes]),
    });
    expect(last).toEqual([total, total]);
  });

  it('names the tensor when the checkpoint is missing one', async () => {
    const record = buildHfRecord(hfShapes(MINI));
    delete record['model.decoder.norm.weight'];
    await expect(
      new MoonshineModel(MINI).loadStateDict(record, { upload: collector().upload }),
    ).rejects.toThrow(/model\.decoder\.norm\.weight/);
  });
});

/** End-to-end through loadStateDict: what actually lands on the (fake)
 *  device — engine layouts after the core hooks, and the f16 dtype split. */
describe('bound state', () => {
  it('f32: fused weights and convs arrive in engine layouts', async () => {
    const bound = await loadFake(new MoonshineModel(MINI));
    // The Linear hook transposes the stacks: [3·qw, d] → [d, 3·qw].
    expect(bound.get('encoder.layers.0.attn.qkv.weight')!.shape.dims).toEqual([D, 3 * QW]);
    expect(bound.get('decoder.layers.0.crossAttn.kv.weight')!.shape.dims).toEqual([D, 2 * QW]);
    // The Conv1d hook permutes to tap-major: (C_out=d, C_in=1, k=127) → [127·1, d].
    expect(bound.get('stem.conv1.weight')!.shape.dims).toEqual([127, D]);
    expect(bound.get('embedding.weight')!.shape.dims).toEqual([MINI.vocab, D]);
  });

  it('half(): every float parameter goes f16, none packed', async () => {
    const model = new MoonshineModel(MINI);
    model.half(fakeF16Root);
    const bound = await loadFake(model);
    // half() is blanket — matmul weights, conv weights, norms and biases all
    // retype to f16 alike; there is no per-tensor exemption in this model.
    for (const [name, entry] of bound) expect(entry.data, name).toBeInstanceOf(Uint16Array);
    // f16 is one halfword per value — no word packing.
    expect(bound.get('embedding.weight')!.data.length).toBe(MINI.vocab * D);
  });
});
