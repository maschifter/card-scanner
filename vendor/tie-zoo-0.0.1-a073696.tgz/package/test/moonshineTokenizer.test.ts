import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { decodeTokens, type MoonshineTokenizer } from '../src/moonshine/tokenizer.ts';

const DIR = fileURLToPath(new URL('../../../fixtures/moonshine/', import.meta.url));
const ASSET = `${DIR}tokenizer.json`;
const CASES = `${DIR}tokenizer_cases.json`;

/** Synthetic vocab exercising every decode rule without the exported asset. */
const MINI: MoonshineTokenizer = {
  version: 1,
  bosId: 1,
  eosId: 2,
  specialIds: [0, 1, 2],
  vocab: [
    '<unk>', // 0
    '<s>', // 1
    '</s>', // 2
    '▁Hello', // 3
    ',', // 4
    '▁world', // 5
    '!', // 6
    '<0xF0>', // 7 ┐
    '<0x9F>', // 8 │ 🎉 = F0 9F 8E 89, split across
    '<0x8E>', // 9 │ four byte-fallback tokens
    '<0x89>', // 10 ┘
    '▁a▁b', // 11
  ],
};

describe('decodeTokens', () => {
  it('maps ▁ to space and strips the leading space', () => {
    expect(decodeTokens(MINI, [3, 4, 5, 6])).toBe('Hello, world!');
  });

  it('skips special ids anywhere in the stream', () => {
    expect(decodeTokens(MINI, [1, 3, 0, 4, 5, 6, 2])).toBe('Hello, world!');
  });

  it('accumulates byte-fallback runs into one UTF-8 character', () => {
    expect(decodeTokens(MINI, [3, 7, 8, 9, 10])).toBe('Hello🎉');
  });

  it('handles multiple ▁ inside one token', () => {
    expect(decodeTokens(MINI, [11])).toBe('a b');
  });

  it('rejects out-of-vocab ids', () => {
    expect(() => decodeTokens(MINI, [999])).toThrow(/outside vocab/);
  });
});

describe.skipIf(!existsSync(ASSET) || !existsSync(CASES))('decodeTokens vs the HF asset', () => {
  const tok: MoonshineTokenizer = JSON.parse(readFileSync(ASSET, 'utf8'));
  const cases: { ids: number[]; text: string }[] = JSON.parse(readFileSync(CASES, 'utf8'));

  it('asset structure matches the config (vocab 32768, BOS 1, EOS 2)', () => {
    expect(tok.vocab.length).toBe(32768);
    expect(tok.bosId).toBe(1);
    expect(tok.eosId).toBe(2);
  });

  it('reproduces the HF-decoded string for every exported case', () => {
    expect(cases.length).toBeGreaterThan(0);
    for (const c of cases) {
      expect(decodeTokens(tok, c.ids)).toBe(c.text);
    }
  });

  it('BOS/EOS bracketing decodes identically to the bare ids', () => {
    const c = cases[0]!;
    expect(decodeTokens(tok, [tok.bosId, ...c.ids, tok.eosId])).toBe(c.text);
  });
});
