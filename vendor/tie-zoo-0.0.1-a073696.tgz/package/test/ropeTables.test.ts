import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { computeRopeTables } from '../src/privacy-filter/rope.ts';

const FIXTURES = join(import.meta.dirname, '../../../fixtures');

describe('computeRopeTables', () => {
  it('matches the reference YaRN cos/sin table', () => {
    const raw = new Float32Array(readFileSync(join(FIXTURES, 'rope.bin')).buffer);
    const positions = 512;
    const half = 32;
    const { cos, sin } = computeRopeTables({
      positions,
      headDim: 64,
      theta: 150000,
      scalingFactor: 32.0,
      ntkAlpha: 1.0,
      ntkBeta: 32.0,
      initialContextLength: 4096,
    });
    let maxErr = 0;
    for (let i = 0; i < positions * half; i++) {
      maxErr = Math.max(
        maxErr,
        Math.abs(cos[i]! - raw[i]!),
        Math.abs(sin[i]! - raw[positions * half + i]!),
      );
    }
    expect(maxErr).toBeLessThan(1e-4);
  });
});
