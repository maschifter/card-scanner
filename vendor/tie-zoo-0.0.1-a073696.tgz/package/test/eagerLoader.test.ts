/** Node tests for eager-model helpers that don't need real GPU weights:
 *  nn.Embedding's CPU gather, and the state-dict name contract EagerModel
 *  relies on (loadStateDict matches by name and throws on drift — see
 *  pfLoadWeights.test.ts for the real-file load). */

import { describe, expect, it } from 'vitest';
import { nn } from '@tie/core';
import { EagerModel } from '../src/privacy-filter/model.ts';

/** f32 → bf16 bits by truncation — exact for the test values (integers < 256
 *  and dyadic fractions fit bf16's 8 significand bits, so no rounding). */
const scratch = new DataView(new ArrayBuffer(4));
function f32ToBf16Bits(value: number): number {
  scratch.setFloat32(0, value, true);
  return scratch.getUint32(0, true) >>> 16;
}

describe('eager loader helpers', () => {
  it('nn.Embedding.gather expands only the gathered rows', () => {
    const hidden = 4;
    const vocab = 3;
    const embedding = new nn.Embedding(vocab, hidden, { device: 'cpu' });
    // row v, col i = v + i·0.25 — exact in bf16
    (embedding.weight as nn.CpuParameter).bindData(
      Uint16Array.from({ length: vocab * hidden }, (_, i) =>
        f32ToBf16Bits(Math.floor(i / hidden) + (i % hidden) * 0.25),
      ),
    );
    const out = embedding.gather([2, 0]);
    expect(Array.from(out)).toEqual([2, 2.25, 2.5, 2.75, 0, 0.25, 0.5, 0.75]);
    expect(() => embedding.gather([3])).toThrow(/out of range/);
  });

  /** Names EagerModel.loadStateDict expects to find in the pf checkpoint's
   *  state dict — pinned inline so any drift in EagerModel's module tree shows
   *  up as a test diff, not a silent runtime mismatch. */
  function expectedNames(blocks: number, quant: boolean): string[] {
    const names: string[] = ['embedding.weight'];
    for (let n = 0; n < blocks; n++) {
      const b = `block.${n}`;
      names.push(
        `${b}.attn.sinks`,
        `${b}.attn.norm.scale`,
        `${b}.attn.qkv.weight`,
        `${b}.attn.qkv.bias`,
        `${b}.attn.out.weight`,
        `${b}.attn.out.bias`,
        `${b}.mlp.gluWeight`,
        `${b}.mlp.linWeight`,
        `${b}.mlp.outWeight`,
        `${b}.mlp.gluBias`,
        `${b}.mlp.linBias`,
        `${b}.mlp.outBias`,
        `${b}.mlp.norm.scale`,
        `${b}.mlp.gate.weight`,
        `${b}.mlp.gate.bias`,
      );
      if (quant) names.push(`${b}.mlp.gluScales`, `${b}.mlp.linScales`, `${b}.mlp.outScales`);
    }
    names.push('norm.scale', 'unembedding.weight');
    return names;
  }

  it('EagerModel.namedParameters matches the expected name list', () => {
    const model = new EagerModel({
      blocks: 2,
      experts: 128,
      vocab: 200064,
      logits: 33,
      weightFormat: 'f32',
    });
    const got = Array.from(model.namedParameters(), ([n]) => n).sort();
    expect(got).toEqual(expectedNames(2, false).sort());
  });

  it('quantInt8 EagerModel.namedParameters matches the expected name list', () => {
    const model = new EagerModel({
      blocks: 2,
      experts: 128,
      vocab: 200064,
      logits: 33,
      weightFormat: 'quantInt8',
      groupSize: 640,
    });
    const got = Array.from(model.namedParameters(), ([n]) => n).sort();
    expect(got).toEqual(expectedNames(2, true).sort());
  });
});
