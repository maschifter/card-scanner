import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import {
  MOONSHINE_STREAMING_MEDIUM,
  MOONSHINE_STREAMING_SMALL,
  MOONSHINE_STREAMING_TINY,
  assertConfigMatches,
  configFromCheckpoint,
} from '../src/moonshine-streaming/config.ts';
import { frontendFrames } from '../src/moonshine-streaming/frontend.ts';

const FIXTURES = fileURLToPath(new URL('../../../fixtures/moonshine-streaming/', import.meta.url));

/** Minimal v2 checkpoint config layout (tiny's values) for parser tests that
 *  must run without generated fixtures. */
const TINY_JSON = () => ({
  hidden_size: 320,
  intermediate_size: 1280,
  num_hidden_layers: 6,
  num_attention_heads: 8,
  num_key_value_heads: 8,
  head_dim: 40,
  attention_bias: false,
  rope_parameters: { partial_rotary_factor: 0.8, rope_theta: 10000.0, rope_type: 'default' },
  vocab_size: 32768,
  max_position_embeddings: 4096,
  bos_token_id: 1,
  eos_token_id: 2,
  decoder_start_token_id: 1,
  encoder_config: {
    hidden_size: 320,
    intermediate_size: 1280,
    num_hidden_layers: 6,
    num_attention_heads: 8,
    num_key_value_heads: 8,
    head_dim: 40,
    attention_bias: false,
    sample_rate: 16000,
    frame_ms: 5.0,
    sliding_windows: [
      [16, 4],
      [16, 4],
      [16, 0],
      [16, 0],
      [16, 4],
      [16, 4],
    ],
  },
});

describe('moonshine-streaming config', () => {
  it('presets carry the published dims and window patterns', () => {
    expect(MOONSHINE_STREAMING_TINY.enc.hidden).toBe(320);
    expect(MOONSHINE_STREAMING_TINY.dec.rotaryDim).toBe(32);
    expect(MOONSHINE_STREAMING_SMALL.enc.hidden).toBe(620);
    expect(MOONSHINE_STREAMING_SMALL.dec.hidden).toBe(512);
    expect(MOONSHINE_STREAMING_MEDIUM.enc.layers).toBe(14);
    for (const cfg of [
      MOONSHINE_STREAMING_TINY,
      MOONSHINE_STREAMING_SMALL,
      MOONSHINE_STREAMING_MEDIUM,
    ]) {
      const w = cfg.enc.windows;
      expect(w.length).toBe(cfg.enc.layers);
      expect(w[0]).toEqual([16, 4]);
      expect(w[1]).toEqual([16, 4]);
      expect(w[w.length - 1]).toEqual([16, 4]);
      expect(w[w.length - 2]).toEqual([16, 4]);
      for (const mid of w.slice(2, -2)) expect(mid).toEqual([16, 0]);
      expect(cfg.dec.rotaryDim).toBe(32);
      expect(cfg.frameLen).toBe(80);
    }
  });

  it('parses the tiny checkpoint layout to the exact preset', () => {
    const parsed = configFromCheckpoint(TINY_JSON());
    assertConfigMatches(parsed, MOONSHINE_STREAMING_TINY);
  });

  it('rejects structural violations by name', () => {
    const bias = TINY_JSON();
    bias.encoder_config.attention_bias = true as never;
    expect(() => configFromCheckpoint(bias)).toThrow(/attention_bias/);

    const gqa = TINY_JSON();
    gqa.num_key_value_heads = 4;
    expect(() => configFromCheckpoint(gqa)).toThrow(/MHA/);

    const windows = TINY_JSON();
    windows.encoder_config.sliding_windows = [[16, 4]] as never;
    expect(() => configFromCheckpoint(windows)).toThrow(/sliding_windows/);

    const start = TINY_JSON();
    start.decoder_start_token_id = 0;
    expect(() => configFromCheckpoint(start)).toThrow(/decoder_start_token_id/);
  });

  it('assertConfigMatches names the drifted path', () => {
    const drifted = configFromCheckpoint(TINY_JSON());
    expect(() => assertConfigMatches(drifted, MOONSHINE_STREAMING_SMALL)).toThrow(
      /enc.hidden=320 != preset 620/,
    );
  });

  it('frontendFrames chains 80-sample frames through two ceil-halvings', () => {
    // The fixture clip: 48000 samples → 600 frames → 300 → 150 (50 Hz).
    expect(frontendFrames(48000, 80)).toEqual({ input: 600, conv1: 300, conv2: 150 });
    expect(frontendFrames(80, 80)).toEqual({ input: 1, conv1: 1, conv2: 1 });
    expect(frontendFrames(149 * 80, 80).conv2).toBe(38); // odd chain: 149 → 75 → 38
    expect(() => frontendFrames(48001, 80)).toThrow(/multiple/);
    expect(() => frontendFrames(0, 80)).toThrow(/multiple/);
  });
});

describe.skipIf(!existsSync(`${FIXTURES}tiny/config.json`))(
  'moonshine-streaming config vs exported checkpoint',
  () => {
    it('the exported tiny config.json parses to the preset exactly', () => {
      const json = JSON.parse(readFileSync(`${FIXTURES}tiny/config.json`, 'utf8'));
      assertConfigMatches(configFromCheckpoint(json), MOONSHINE_STREAMING_TINY);
    });
  },
);
