import { describe, expect, it } from 'vitest';
import {
  bufferSource,
  f16ToF32,
  fromSafetensors,
  materialized,
  memoryStateDict,
  nn,
  hwc4Meta,
  type Value,
} from '@tie/core';
import { Bottleneck, C3k, C3k2, ConvBlock, SPPF } from '../src/yolo26/blocks.ts';
import { Attention, C2PSA, C3k2Attn, PSABlock } from '../src/yolo26/psa.ts';
import { scaleChannels, scaleRepeats, YOLO26_SCALES } from '../src/yolo26/config.ts';
import { encodeSafetensors, f16Data, f32Data } from './safetensorsHelpers.ts';

/** Fake-load every Parameter with zeros so forward() can build the pending
 *  DAG — node tests only check shape propagation, no GPU. Each entry carries
 *  its Parameter's LOGICAL dims (not the flat word count) so f16 params
 *  pass loadStateDict's shape check. */
async function fakeLoad(model: InstanceType<typeof nn.Module>): Promise<void> {
  model.half(); // hwc4 convs need f16 biases; rootless contexts skip the f16 check
  const sd: Record<string, { data: Float32Array | Uint16Array; shape: number[] }> = {};
  for (const [name, p] of model.namedParameters()) {
    sd[name] = {
      data:
        p.shape.dtype === 'f16'
          ? new Uint16Array(p.shape.elems)
          : new Float32Array(p.shape.elems),
      shape: [...p.shape.dims!],
    };
  }
  await model.loadStateDict(memoryStateDict(sd), {
    upload: (_, shape) => materialized(shape, {} as never),
  });
}

// Blocks run HWC4 storage — feed them hwc4-tagged fakes like the model does.
const t3 = (c: number, h: number, w: number): Value => materialized(hwc4Meta(c, h, w), {} as never);

describe('nano compound scaling', () => {
  it('matches the yolo26n summary channels', () => {
    const n = YOLO26_SCALES.n;
    expect(scaleChannels(64, n)).toBe(16);
    expect(scaleChannels(256, n)).toBe(64);
    expect(scaleChannels(1024, n)).toBe(256);
    expect(scaleRepeats(2, n)).toBe(1);
    expect(scaleRepeats(1, n)).toBe(1);
  });
});

describe('ConvBlock', () => {
  it('3×3 s=2 halves spatial dims (autopad)', async () => {
    const b = new ConvBlock(16, 32, { kernelSize: 3, stride: 2 });
    await fakeLoad(b);
    expect(b.forward(t3(16, 20, 20)).shape.dims).toEqual([32, 10, 10]);
  });

  it('registers checkpoint-shaped names', () => {
    const b = new ConvBlock(4, 8, { kernelSize: 1 });
    const names = Array.from(b.namedParameters()).map(([n]) => n);
    expect(names).toEqual(['conv.weight', 'conv.bias']);
  });
});

describe('ConvBlock.transformStateDict', () => {
  it('folds ultralytics conv+bn checkpoints into the biased conv', async () => {
    const block = new ConvBlock(1, 1, { kernelSize: 1 });
    // conv.weight=[2] (f16), bn: gamma=1, beta=0.5, mean=1, var=3, eps=1e-3
    // scale = 1/sqrt(3.001); w' = 2*scale; b' = 0.5 - 1*scale
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'conv.weight': { dtype: 'F16', shape: [1, 1, 1, 1], data: f16Data([2]) },
          'bn.weight': { dtype: 'F32', shape: [1], data: f32Data([1]) },
          'bn.bias': { dtype: 'F32', shape: [1], data: f32Data([0.5]) },
          'bn.running_mean': { dtype: 'F32', shape: [1], data: f32Data([1]) },
          'bn.running_var': { dtype: 'F32', shape: [1], data: f32Data([3]) },
        }),
      ),
    );
    const uploads: Array<Float32Array | Uint16Array | Uint32Array> = [];
    await block.loadStateDict(sd, {
      upload: (data, shape) => {
        uploads.push(data);
        return materialized(shape, {} as never);
      },
    });
    const scale = 1 / Math.sqrt(3 + 1e-3);
    const w = f16ToF32(new Uint16Array((uploads[0] as Uint32Array).buffer).slice(0, 1));
    expect(w[0]).toBeCloseTo(2 * scale, 3);
    expect((uploads[1] as Float32Array)[0]).toBeCloseTo(0.5 - scale, 5);
  });
});

describe('Bottleneck', () => {
  it('preserves shape and halves hidden width (e=0.5)', async () => {
    const b = new Bottleneck(32, 32, {});
    await fakeLoad(b);
    expect(b.forward(t3(32, 8, 8)).shape.dims).toEqual([32, 8, 8]);
    const params = Object.fromEntries(Array.from(b.namedParameters()));
    expect(params['cv1.conv.weight']!.shape.dims).toEqual([16, 32 * 9]); // 32→16, 3×3
  });
});

describe('C3k', () => {
  it('[32,8,8] → [32,8,8] with two e=1.0 bottlenecks', async () => {
    const b = new C3k(32, 32, {});
    await fakeLoad(b);
    expect(b.forward(t3(32, 8, 8)).shape.dims).toEqual([32, 8, 8]);
    const names = Array.from(b.namedParameters()).map(([n]) => n);
    expect(names).toContain('m.0.cv1.conv.weight');
    expect(names).toContain('m.1.cv2.conv.weight');
  });
});

describe('C3k2', () => {
  it('C2f-style: cv2 consumes (2+n)·c channels', async () => {
    const b = new C3k2(64, 128, { n: 2, c3k: false });
    const params = Object.fromEntries(Array.from(b.namedParameters()));
    // c = 128/2 = 64; cv1: 64→128; cv2: (2+2)·64=256 → 128
    expect(params['cv1.conv.weight']!.shape.dims).toEqual([128, 64]);
    expect(params['cv2.conv.weight']!.shape.dims).toEqual([128, 256]);
    await fakeLoad(b);
    expect(b.forward(t3(64, 8, 8)).shape.dims).toEqual([128, 8, 8]);
  });

  it('e=0.25 variant (early backbone stages)', async () => {
    const b = new C3k2(32, 64, { n: 1, c3k: false, e: 0.25 });
    await fakeLoad(b);
    // c = 64·0.25 = 16; cv2 in = 3·16 = 48
    expect(b.forward(t3(32, 8, 8)).shape.dims).toEqual([64, 8, 8]);
    const params = Object.fromEntries(Array.from(b.namedParameters()));
    expect(params['cv2.conv.weight']!.shape.dims).toEqual([64, 48]);
  });

  it('c3k=true nests C3k blocks under m.*', async () => {
    const b = new C3k2(64, 64, { n: 1, c3k: true });
    const names = Array.from(b.namedParameters()).map(([n]) => n);
    expect(names).toContain('m.0.cv3.conv.weight'); // C3k has cv3, Bottleneck doesn't
    await fakeLoad(b);
    expect(b.forward(t3(64, 8, 8)).shape.dims).toEqual([64, 8, 8]);
  });
});

describe('SPPF', () => {
  it('yolo26 form (k=5, n=3, shortcut) preserves shape', async () => {
    const b = new SPPF(64, 64, { k: 5, n: 3, shortcut: true });
    await fakeLoad(b);
    expect(b.forward(t3(64, 8, 8)).shape.dims).toEqual([64, 8, 8]);
    const params = Object.fromEntries(Array.from(b.namedParameters()));
    // cv1: 64→32; cv2: 32·4=128 → 64
    expect(params['cv1.conv.weight']!.shape.dims).toEqual([32, 64]);
    expect(params['cv2.conv.weight']!.shape.dims).toEqual([64, 128]);
  });
});

describe('Attention', () => {
  it('preserves [C,H,W] and registers qkv/proj/pe', async () => {
    const a = new Attention(128, { numHeads: 2, attnRatio: 0.5 });
    await fakeLoad(a);
    expect(a.forward(t3(128, 4, 4)).shape.dims).toEqual([128, 4, 4]);
    const params = Object.fromEntries(Array.from(a.namedParameters()));
    // headDim=64, keyDim=32 → qkv out = 128 + 2·2·32 = 256
    expect(params['qkv.conv.weight']!.shape.dims).toEqual([256, 128]);
    // pe is depthwise 3×3: [128, 1·9]
    expect(params['pe.conv.weight']!.shape.dims).toEqual([128, 9]);
  });
});

describe('PSABlock / C2PSA', () => {
  it('PSABlock preserves shape (attn + ffn residuals)', async () => {
    const b = new PSABlock(128, { numHeads: 2 });
    await fakeLoad(b);
    expect(b.forward(t3(128, 4, 4)).shape.dims).toEqual([128, 4, 4]);
  });

  it('C2PSA nano form (256, n=1) preserves shape', async () => {
    const b = new C2PSA(256, 256, { n: 1 });
    await fakeLoad(b);
    expect(b.forward(t3(256, 4, 4)).shape.dims).toEqual([256, 4, 4]);
    const names = Array.from(b.namedParameters()).map(([n]) => n);
    expect(names).toContain('m.0.attn.qkv.conv.weight');
    expect(names).toContain('m.0.ffn.1.conv.weight');
  });

  it('C2PSA rejects c1 != c2', () => {
    expect(() => new C2PSA(128, 256, {})).toThrow('c1 must equal c2');
  });
});

describe('C3k2Attn (head P5 layer)', () => {
  it('nano form [256→256, e=0.5] preserves shape, keys m.0.0/m.0.1', async () => {
    const b = new C3k2Attn(256, 256, { n: 1, e: 0.5 });
    const names = Array.from(b.namedParameters()).map(([n]) => n);
    expect(names).toContain('m.0.0.cv1.conv.weight'); // Bottleneck
    expect(names).toContain('m.0.1.attn.qkv.conv.weight'); // PSABlock
    await fakeLoad(b);
    expect(b.forward(t3(256, 4, 4)).shape.dims).toEqual([256, 4, 4]);
  });
});
