import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { createTokenizer } from '../src/privacy-filter/tokenizer.ts';

const FIXTURES = join(import.meta.dirname, '../../../fixtures');
const caseMeta = (name: string) =>
  JSON.parse(readFileSync(join(FIXTURES, 'cases', name, 'meta.json'), 'utf8'));

describe('tokenizer', () => {
  const tok = createTokenizer();

  for (const name of ['email_short', 'unicode', 'mixed_long']) {
    it(`encodes ${name} identically to reference`, () => {
      const meta = caseMeta(name);
      expect(tok.encode(meta.text)).toEqual(meta.token_ids);
    });
  }

  it('roundtrips token bytes to the original text', () => {
    const meta = caseMeta('unicode');
    const ids: number[] = meta.token_ids;
    const merged = new Uint8Array(ids.flatMap((id) => [...tok.tokenBytes(id)]));
    expect(new TextDecoder().decode(merged)).toBe(meta.text);
  });

  it('computes char offsets covering the whole text', () => {
    const meta = caseMeta('unicode');
    const { charStarts, charEnds } = tok.tokenCharOffsets(meta.token_ids);
    expect(charStarts[0]).toBe(0);
    expect(charEnds[charEnds.length - 1]).toBe(meta.text.length); // UTF-16 length
    for (let i = 1; i < charStarts.length; i++) {
      expect(charStarts[i]).toBeGreaterThanOrEqual(charEnds[i - 1]! - 1);
    }
  });
});
