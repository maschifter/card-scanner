/** registerTieBackend patch mechanics, fully offline: a registered hub id
 *  resolves through both the direct PreTrainedModel path and the AutoModel
 *  funnel to the tie loader's instance; unmatched ids and loader failures
 *  throw by default, and fall through to the original loader only with
 *  fallbackToOnnx. Configs are passed inline so nothing touches the network. */

import { afterEach, describe, expect, it, vi } from 'vitest';
import { AutoModel, PreTrainedModel, type PretrainedConfig } from '@huggingface/transformers';
import { registerTieBackend, unregisterTieBackend } from '../src/transformers/index.ts';

// runtime accepts a plain config object and wraps it in PretrainedConfig
const BERT_CONFIG = { model_type: 'bert' } as unknown as PretrainedConfig;

const fakeModel = (): PreTrainedModel => ({ marker: Math.random() }) as unknown as PreTrainedModel;

describe('transformers.js tie backend patch', () => {
  const realOriginal = PreTrainedModel.from_pretrained;

  afterEach(() => {
    unregisterTieBackend();
    PreTrainedModel.from_pretrained = realOriginal;
  });

  it('routes a registered id to the tie loader', async () => {
    const model = fakeModel();
    const load = vi.fn(async () => model);
    registerTieBackend({ models: { 'tie-test/fake': { load } } });

    const out = await PreTrainedModel.from_pretrained('tie-test/fake', { config: BERT_CONFIG });
    expect(out).toBe(model);
    expect(load).toHaveBeenCalledOnce();
    const [id, config] = load.mock.calls[0]! as unknown as [string, { model_type: string }];
    expect(id).toBe('tie-test/fake');
    expect(config.model_type).toBe('bert');
  });

  it('routes AutoModel.from_pretrained through the patch', async () => {
    const model = fakeModel();
    registerTieBackend({ models: { 'tie-test/fake': { load: async () => model } } });

    const out = await AutoModel.from_pretrained('tie-test/fake', { config: BERT_CONFIG });
    expect(out).toBe(model);
  });

  it('throws for unmatched ids by default', async () => {
    registerTieBackend({ models: { 'tie-test/fake': { load: async () => fakeModel() } } });

    await expect(
      PreTrainedModel.from_pretrained('someone/else', { config: BERT_CONFIG }),
    ).rejects.toThrow(/'someone\/else' is not supported/);
  });

  it('throws when the tie loader fails by default', async () => {
    registerTieBackend({
      models: {
        'tie-test/fake': {
          load: async () => {
            throw new Error('no gpu');
          },
        },
      },
    });

    await expect(
      PreTrainedModel.from_pretrained('tie-test/fake', { config: BERT_CONFIG }),
    ).rejects.toThrow(/loading 'tie-test\/fake' failed/);
  });

  it('fallbackToOnnx loads unmatched ids on the original loader', async () => {
    const passthrough = fakeModel();
    const spy = vi.fn(async (..._args: unknown[]) => passthrough);
    PreTrainedModel.from_pretrained = spy as unknown as typeof PreTrainedModel.from_pretrained;
    registerTieBackend({
      models: { 'tie-test/fake': { load: async () => fakeModel() } },
      fallbackToOnnx: true,
    });

    const out = await PreTrainedModel.from_pretrained('someone/else', { config: BERT_CONFIG });
    expect(out).toBe(passthrough);
    expect(spy).toHaveBeenCalledOnce();
    expect(spy.mock.calls[0]![0]).toBe('someone/else');
  });

  it('fallbackToOnnx loads a failing tie id on the original loader with a warn', async () => {
    const passthrough = fakeModel();
    const spy = vi.fn(async () => passthrough);
    PreTrainedModel.from_pretrained = spy as unknown as typeof PreTrainedModel.from_pretrained;
    registerTieBackend({
      models: {
        'tie-test/fake': {
          load: async () => {
            throw new Error('no gpu');
          },
        },
      },
      fallbackToOnnx: true,
    });
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});

    const out = await PreTrainedModel.from_pretrained('tie-test/fake', { config: BERT_CONFIG });
    expect(out).toBe(passthrough);
    expect(spy).toHaveBeenCalledOnce();
    expect(warn).toHaveBeenCalledOnce();
    warn.mockRestore();
  });

  it('unregisterTieBackend restores the original loader', async () => {
    registerTieBackend({ models: { 'tie-test/fake': { load: async () => fakeModel() } } });
    unregisterTieBackend();
    expect(PreTrainedModel.from_pretrained).toBe(realOriginal);
  });

  it('re-registering does not stack patches', async () => {
    registerTieBackend({ models: { 'tie-test/fake': { load: async () => fakeModel() } } });
    registerTieBackend({ models: { 'tie-test/fake': { load: async () => fakeModel() } } });
    unregisterTieBackend();
    expect(PreTrainedModel.from_pretrained).toBe(realOriginal);
  });
});
