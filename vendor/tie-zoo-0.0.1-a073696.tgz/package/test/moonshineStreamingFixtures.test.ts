/** Tooling gate for Moonshine v2 (streaming): the exported safetensors
 *  files, tokenizer asset, and HF golden fixtures are structurally sound —
 *  expected tensor names, config-consistent shapes, on-disk byte sizes,
 *  BOS/EOS bracketing — for every exported size. No GPU, no model code.
 *  Skips (like the gpu e2e suites) when a size's fixtures have not been
 *  generated: tools/export_moonshine_v2.py, tools/export_moonshine_tokenizer.py
 *  --family v2, tools/dump_moonshine_v2_fixtures.py. */

import { existsSync, readFileSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { bufferSource, parseSafetensorsHeader, type SafetensorsIndex } from '@tie/core';

const DIR = fileURLToPath(new URL('../../../fixtures/moonshine-streaming/', import.meta.url));

const readHeader = (path: string): Promise<SafetensorsIndex> =>
  parseSafetensorsHeader(bufferSource(new Uint8Array(readFileSync(path))));

/** Checkpoint-level hyperparameters per exported size (HF config keys).
 *  Encoder and decoder dims diverge above tiny, and the attention inner dim
 *  (heads·headDim) matches hidden_size ONLY for tiny — never assume square. */
const MODELS = [
  {
    name: 'tiny',
    enc: { hidden: 320, ffn: 1280, layers: 6, heads: 8, headDim: 40 },
    dec: { hidden: 320, ffn: 1280, layers: 6, heads: 8, headDim: 40 },
    rotaryFactor: 0.8,
  },
  {
    name: 'small',
    enc: { hidden: 620, ffn: 2480, layers: 10, heads: 8, headDim: 64 },
    dec: { hidden: 512, ffn: 2048, layers: 10, heads: 8, headDim: 64 },
    rotaryFactor: 0.5,
  },
  {
    name: 'medium',
    enc: { hidden: 768, ffn: 3072, layers: 14, heads: 10, headDim: 64 },
    dec: { hidden: 640, ffn: 2560, layers: 14, heads: 10, headDim: 64 },
    rotaryFactor: 0.5,
  },
] as const;

const json = (path: string) => JSON.parse(readFileSync(path, 'utf8'));
/** describe.skipIf still RUNS the suite body at collection time — absent
 *  fixtures must yield an empty object there, not an ENOENT throw. */
const jsonIf = (path: string) => (existsSync(path) ? json(path) : {});
const headerIf = (path: string): Promise<SafetensorsIndex> =>
  existsSync(path)
    ? readHeader(path)
    : Promise.resolve({ metadata: {}, tensors: new Map() } as SafetensorsIndex);

interface TensorEntry {
  dtype?: string;
  shape: number[];
  file: string;
}

/** Expected manifest names for a streaming checkpoint (HF naming). The
 *  encoder norms are MoonshineStreamingLayerNorm (single `gamma` parameter,
 *  applied as gamma+1); decoder norms are plain bias-free LayerNorms. The
 *  adapter projection exists only when encoder and decoder dims differ, and
 *  the LM head — untied in the config but byte-identical in the shipped
 *  checkpoints — is emitted once under the embedding's name. */
function expectedNames(encLayers: number, decLayers: number, hasProj: boolean): string[] {
  const names = [
    'model.encoder.embedder.comp.log_k',
    'model.encoder.embedder.conv1.weight',
    'model.encoder.embedder.conv1.bias',
    'model.encoder.embedder.conv2.weight',
    'model.encoder.embedder.conv2.bias',
    'model.encoder.embedder.linear.weight',
    'model.encoder.final_norm.gamma',
    'model.decoder.embed_tokens.weight',
    'model.decoder.pos_emb.weight',
    'model.decoder.norm.weight',
  ];
  if (hasProj) names.push('model.decoder.proj.weight');
  for (let i = 0; i < encLayers; i++) {
    const L = `model.encoder.layers.${i}`;
    for (const p of ['q', 'k', 'v', 'o']) names.push(`${L}.self_attn.${p}_proj.weight`);
    names.push(
      `${L}.mlp.fc1.weight`,
      `${L}.mlp.fc1.bias`,
      `${L}.mlp.fc2.weight`,
      `${L}.mlp.fc2.bias`,
    );
    names.push(`${L}.input_layernorm.gamma`, `${L}.post_attention_layernorm.gamma`);
  }
  for (let i = 0; i < decLayers; i++) {
    const L = `model.decoder.layers.${i}`;
    for (const p of ['q', 'k', 'v', 'o']) names.push(`${L}.self_attn.${p}_proj.weight`);
    for (const p of ['q', 'k', 'v', 'o']) names.push(`${L}.encoder_attn.${p}_proj.weight`);
    names.push(
      `${L}.mlp.fc1.weight`,
      `${L}.mlp.fc1.bias`,
      `${L}.mlp.fc2.weight`,
      `${L}.mlp.fc2.bias`,
    );
    names.push(
      `${L}.input_layernorm.weight`,
      `${L}.post_attention_layernorm.weight`,
      `${L}.final_layernorm.weight`,
    );
  }
  return names;
}

/** Per-layer [left, right] sliding windows: the first two and last two layers
 *  carry lookahead 4, all middle layers are strictly causal. */
function expectedWindows(layers: number): number[][] {
  return Array.from({ length: layers }, (_, i) => (i < 2 || i >= layers - 2 ? [16, 4] : [16, 0]));
}

for (const M of MODELS) {
  const MODEL = `${DIR}${M.name}/`;
  const CASE = `${MODEL}cases/librispeech_3s/`;

  describe.skipIf(!existsSync(`${MODEL}model.safetensors`))(
    `moonshine streaming weight export (${M.name})`,
    () => {
      const header = headerIf(`${MODEL}model.safetensors`);
      const config = jsonIf(`${MODEL}config.json`);
      const enc = config.encoder_config ?? {};

      it(`checkpoint config carries the expected ${M.name} hyperparameters`, () => {
        expect(config.hidden_size).toBe(M.dec.hidden);
        expect(config.intermediate_size).toBe(M.dec.ffn);
        expect(config.num_hidden_layers).toBe(M.dec.layers);
        expect(config.num_attention_heads).toBe(M.dec.heads);
        expect(config.head_dim).toBe(M.dec.headDim);
        expect(config.vocab_size).toBe(32768);
        expect(config.rope_parameters.partial_rotary_factor).toBe(M.rotaryFactor);
        expect(config.rope_parameters.rope_theta).toBe(10000.0);
        expect(config.max_position_embeddings).toBe(4096);
        expect(config.tie_word_embeddings).toBe(false);
        expect(config.attention_bias).toBe(false);
        expect(config.bos_token_id).toBe(1);
        expect(config.eos_token_id).toBe(2);
        expect(config.decoder_start_token_id).toBe(1);

        expect(enc.hidden_size).toBe(M.enc.hidden);
        expect(enc.intermediate_size).toBe(M.enc.ffn);
        expect(enc.num_hidden_layers).toBe(M.enc.layers);
        expect(enc.num_attention_heads).toBe(M.enc.heads);
        expect(enc.head_dim).toBe(M.enc.headDim);
        expect(enc.sample_rate).toBe(16000);
        expect(enc.frame_ms).toBe(5.0);
        expect(enc.sliding_windows).toEqual(expectedWindows(M.enc.layers));
      });

      it('carries the tie identity metadata', async () => {
        const { metadata } = await header;
        expect(metadata['format']).toBe('tie');
        expect(metadata['model']).toBe('moonshine-streaming');
        expect(metadata['variant']).toBe(M.name);
        expect(metadata['dtype']).toBe('f32');
      });

      it('holds exactly the expected tensor set (head deduped)', async () => {
        const { tensors } = await header;
        const expected = expectedNames(
          enc.num_hidden_layers,
          config.num_hidden_layers,
          enc.hidden_size !== config.hidden_size,
        );
        expect([...tensors.keys()].sort()).toEqual(expected.sort());
        expect(tensors.has('proj_out.weight')).toBe(false);
      });

      it('key shapes match the architecture', async () => {
        const { tensors } = await header;
        const shape = (name: string) => tensors.get(name)!.shape;
        const eh = M.enc.hidden;
        const dh = M.dec.hidden;
        const encAttn = M.enc.heads * M.enc.headDim;
        const decAttn = M.dec.heads * M.dec.headDim;
        expect(shape('model.encoder.embedder.comp.log_k')).toEqual([]);
        expect(shape('model.encoder.embedder.linear.weight')).toEqual([eh, 80]);
        expect(shape('model.encoder.embedder.conv1.weight')).toEqual([2 * eh, eh, 5]);
        expect(shape('model.encoder.embedder.conv2.weight')).toEqual([eh, 2 * eh, 5]);
        expect(shape('model.encoder.layers.0.self_attn.q_proj.weight')).toEqual([encAttn, eh]);
        expect(shape('model.encoder.layers.0.self_attn.o_proj.weight')).toEqual([eh, encAttn]);
        expect(shape('model.encoder.layers.0.mlp.fc1.weight')).toEqual([M.enc.ffn, eh]);
        expect(shape('model.encoder.layers.0.input_layernorm.gamma')).toEqual([eh]);
        expect(shape('model.decoder.embed_tokens.weight')).toEqual([32768, dh]);
        expect(shape('model.decoder.pos_emb.weight')).toEqual([4096, eh]);
        if (eh !== dh) expect(shape('model.decoder.proj.weight')).toEqual([dh, eh]);
        expect(shape('model.decoder.layers.0.self_attn.q_proj.weight')).toEqual([decAttn, dh]);
        // Decoder fc1 is the fused SwiGLU projection: hidden → 2·ffn.
        expect(shape('model.decoder.layers.0.mlp.fc1.weight')).toEqual([2 * M.dec.ffn, dh]);
        expect(shape('model.decoder.layers.0.input_layernorm.weight')).toEqual([dh]);
      });

      it('every tensor is F32 with payload bytes matching its shape', async () => {
        const { tensors } = await header;
        for (const [name, info] of tensors) {
          expect(info.dtype, name).toBe('F32');
          const elems = info.shape.reduce((a, b) => a * b, 1);
          expect(info.end - info.begin, name).toBe(elems * 4);
        }
      });
    },
  );

  describe.skipIf(!existsSync(`${MODEL}model-f16.safetensors`))(
    `moonshine streaming f16 weight export (${M.name})`,
    () => {
      it('every tensor is F16, same name set as the f32 file', async () => {
        const f16 = await headerIf(`${MODEL}model-f16.safetensors`);
        const f32 = await headerIf(`${MODEL}model.safetensors`);
        expect(f16.metadata['dtype']).toBe('f16');
        expect([...f16.tensors.keys()].sort()).toEqual([...f32.tensors.keys()].sort());
        for (const [name, info] of f16.tensors) {
          expect(info.dtype, name).toBe('F16');
          const elems = info.shape.reduce((a, b) => a * b, 1);
          expect(info.end - info.begin, name).toBe(elems * 2);
        }
      });
    },
  );

  describe.skipIf(!existsSync(`${CASE}meta.json`))(
    `moonshine streaming golden fixtures (${M.name}, librispeech_3s)`,
    () => {
      const meta = jsonIf(`${CASE}meta.json`);

      /** Frontend frame count: 80-sample frames, then two stride-2 causal
       *  convs (left-padded, so each is ceil-division: (n−1)/2 + 1). */
      const frames = (samples: number) => {
        let n = Math.floor(samples / 80);
        n = Math.floor((n - 1) / 2) + 1;
        n = Math.floor((n - 1) / 2) + 1;
        return n;
      };

      it('greedy ids are BOS-started, EOS-terminated, in-vocab', () => {
        const ids: number[] = meta.greedyIds;
        expect(ids[0]).toBe(1);
        expect(ids[ids.length - 1]).toBe(2);
        expect(ids.every((i) => Number.isInteger(i) && i >= 0 && i < 32768)).toBe(true);
        expect(meta.transcript.length).toBeGreaterThan(0);
      });

      it('encoder frame count matches the frontend formula (~50 Hz)', () => {
        expect(meta.paddedSamples % 80).toBe(0);
        expect(meta.encoderFrames).toBe(frames(meta.paddedSamples));
      });

      it('stage tensors exist on disk with shape-consistent sizes', () => {
        for (const [name, entry] of Object.entries<TensorEntry>(meta.tensors)) {
          const elems = entry.shape.reduce((a, b) => a * b, 1);
          expect(statSync(`${CASE}${entry.file}`).size, name).toBe(elems * 4);
        }
        expect(meta.tensors.logits_tf.shape).toEqual([meta.greedyIds.length, 32768]);
        expect(meta.tensors.frontend_out.shape).toEqual([meta.encoderFrames, M.enc.hidden]);
        expect(meta.tensors.enc_final.shape).toEqual([meta.encoderFrames, M.enc.hidden]);
        // Adapter output is what the decoder cross-attends to — decoder dims.
        expect(meta.tensors.adapter_out.shape).toEqual([meta.encoderFrames, M.dec.hidden]);
      });

      it('rope table dump covers practical positions at rotary_dim 32', () => {
        const manifest = json(`${MODEL}manifest.json`);
        // All sizes land on rotary_dim 32: int(40·0.8) and int(64·0.5).
        expect(manifest.rope.shape).toEqual([2, 512, 32]);
        const elems = manifest.rope.shape.reduce((a: number, b: number) => a * b, 1);
        expect(statSync(`${MODEL}rope.bin`).size).toBe(elems * 4);
      });

      it('records the reference versions for reproducibility', () => {
        expect(meta.transformers).toMatch(/^\d+\./);
        expect(meta.torch).toMatch(/^\d+\./);
        expect(meta.sampleRate).toBe(16000);
      });
    },
  );
}

describe.skipIf(!existsSync(`${DIR}tokenizer.json`))('moonshine streaming tokenizer asset', () => {
  const asset = jsonIf(`${DIR}tokenizer.json`);

  it('has the full vocab and config-authoritative special ids', () => {
    expect(asset.vocab.length).toBe(32768);
    expect(asset.bosId).toBe(1);
    expect(asset.eosId).toBe(2);
    expect(asset.vocab[1]).toBe('<s>');
    expect(asset.vocab[2]).toBe('</s>');
    expect(asset.specialIds.length).toBe(771); // 0/1/2 + 768 <<ST_N>> placeholders
    expect(asset.specialIds).toContain(asset.bosId);
    expect(asset.specialIds).toContain(asset.eosId);
    // The one token where the v2 vocab differs from v1 — proves this asset
    // was exported from the streaming checkpoint, not copied from v1.
    expect(asset.vocab[31353]).toBe('\u2028');
  });

  it('ships decode parity cases with pure-number id arrays', () => {
    const cases = json(`${DIR}tokenizer_cases.json`);
    expect(cases.length).toBeGreaterThanOrEqual(8);
    for (const c of cases) {
      expect(typeof c.text).toBe('string');
      expect(c.ids.every((i: number) => Number.isInteger(i) && i >= 0 && i < 32768)).toBe(true);
    }
  });
});
