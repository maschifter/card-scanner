/** M0 gate for the Moonshine tooling: the exported safetensors files,
 *  tokenizer asset, and HF golden fixtures are structurally sound — expected
 *  tensor names, config-consistent shapes, on-disk byte sizes, BOS/EOS
 *  bracketing — for every exported model size. No GPU, no model code. Skips
 *  (like the gpu e2e suites) when a model's fixtures have not been generated:
 *  tools/export_moonshine.py, tools/export_moonshine_tokenizer.py,
 *  tools/dump_moonshine_fixtures.py. */

import { existsSync, readFileSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { bufferSource, parseSafetensorsHeader, type SafetensorsIndex } from '@tie/core';

const DIR = fileURLToPath(new URL('../../../fixtures/moonshine/', import.meta.url));

const readHeader = (path: string): Promise<SafetensorsIndex> =>
  parseSafetensorsHeader(bufferSource(new Uint8Array(readFileSync(path))));

/** Checkpoint-level hyperparameters per exported size (HF config keys). */
const MODELS = [
  { name: 'tiny', hidden: 288, ffn: 1152, encLayers: 6, decLayers: 6, rotaryFactor: 0.9 },
  { name: 'base', hidden: 416, ffn: 1664, encLayers: 8, decLayers: 8, rotaryFactor: 0.62 },
] as const;

const json = (path: string) => JSON.parse(readFileSync(path, 'utf8'));
/** describe.skipIf still runs the suite body at collection time — absent
 *  files must read as empty, not throw. */
const jsonIf = (path: string) => (existsSync(path) ? json(path) : {});
const headerIf = (path: string): Promise<SafetensorsIndex> =>
  existsSync(path)
    ? readHeader(path)
    : Promise.resolve({ metadata: {}, tensors: new Map() } as SafetensorsIndex);

interface TensorEntry {
  dtype?: string;
  shape: number[];
  file: string;
}

/** Expected manifest names for a Moonshine checkpoint (HF naming, tied head
 *  emitted once under the embedding's name). */
function expectedNames(encLayers: number, decLayers: number): string[] {
  const names = [
    'model.encoder.conv1.weight',
    'model.encoder.conv2.weight',
    'model.encoder.conv2.bias',
    'model.encoder.conv3.weight',
    'model.encoder.conv3.bias',
    'model.encoder.groupnorm.weight',
    'model.encoder.groupnorm.bias',
    'model.encoder.layer_norm.weight',
    'model.decoder.embed_tokens.weight',
    'model.decoder.norm.weight',
  ];
  for (let i = 0; i < encLayers; i++) {
    const L = `model.encoder.layers.${i}`;
    for (const p of ['q', 'k', 'v', 'o']) names.push(`${L}.self_attn.${p}_proj.weight`);
    names.push(
      `${L}.mlp.fc1.weight`,
      `${L}.mlp.fc1.bias`,
      `${L}.mlp.fc2.weight`,
      `${L}.mlp.fc2.bias`,
    );
    names.push(`${L}.input_layernorm.weight`, `${L}.post_attention_layernorm.weight`);
  }
  for (let i = 0; i < decLayers; i++) {
    const L = `model.decoder.layers.${i}`;
    for (const p of ['q', 'k', 'v', 'o']) names.push(`${L}.self_attn.${p}_proj.weight`);
    for (const p of ['q', 'k', 'v', 'o']) names.push(`${L}.encoder_attn.${p}_proj.weight`);
    names.push(
      `${L}.mlp.fc1.weight`,
      `${L}.mlp.fc1.bias`,
      `${L}.mlp.fc2.weight`,
      `${L}.mlp.fc2.bias`,
    );
    names.push(
      `${L}.input_layernorm.weight`,
      `${L}.post_attention_layernorm.weight`,
      `${L}.final_layernorm.weight`,
    );
  }
  return names;
}

for (const M of MODELS) {
  const MODEL = `${DIR}${M.name}/`;
  const CASE = `${MODEL}cases/librispeech_3s/`;

  describe.skipIf(!existsSync(`${MODEL}model.safetensors`))(
    `moonshine weight export (${M.name})`,
    () => {
      const header = headerIf(`${MODEL}model.safetensors`);
      const config = jsonIf(`${MODEL}config.json`);

      it(`checkpoint config carries the expected ${M.name} hyperparameters`, () => {
        expect(config.hidden_size).toBe(M.hidden);
        expect(config.intermediate_size).toBe(M.ffn);
        expect(config.encoder_num_hidden_layers).toBe(M.encLayers);
        expect(config.decoder_num_hidden_layers).toBe(M.decLayers);
        expect(config.encoder_num_attention_heads).toBe(8);
        expect(config.vocab_size).toBe(32768);
        expect(config.partial_rotary_factor).toBe(M.rotaryFactor);
        expect(config.max_position_embeddings).toBe(194);
        expect(config.bos_token_id).toBe(1);
        expect(config.eos_token_id).toBe(2);
        expect(config.decoder_start_token_id).toBe(1);
      });

      it('carries the tie identity metadata', async () => {
        const { metadata } = await header;
        expect(metadata['format']).toBe('tie');
        expect(metadata['model']).toBe('moonshine');
        expect(metadata['variant']).toBe(M.name);
        expect(metadata['dtype']).toBe('f32');
      });

      it('holds exactly the expected tensor set (tied head deduped)', async () => {
        const { tensors } = await header;
        const expected = expectedNames(
          config.encoder_num_hidden_layers,
          config.decoder_num_hidden_layers,
        );
        expect([...tensors.keys()].sort()).toEqual(expected.sort());
        expect(tensors.has('proj_out.weight')).toBe(false);
      });

      it('key shapes match the architecture', async () => {
        const { tensors } = await header;
        const shape = (name: string) => tensors.get(name)!.shape;
        const d = config.hidden_size;
        const ffn = config.intermediate_size;
        expect(shape('model.decoder.embed_tokens.weight')).toEqual([config.vocab_size, d]);
        expect(shape('model.encoder.conv1.weight')).toEqual([d, 1, 127]);
        expect(shape('model.encoder.conv2.weight')).toEqual([2 * d, d, 7]);
        expect(shape('model.encoder.conv3.weight')).toEqual([d, 2 * d, 3]);
        expect(shape('model.encoder.layers.0.mlp.fc1.weight')).toEqual([ffn, d]);
        // Decoder fc1 is the fused SwiGLU projection: hidden → 2·ffn.
        expect(shape('model.decoder.layers.0.mlp.fc1.weight')).toEqual([2 * ffn, d]);
        expect(shape('model.decoder.layers.0.self_attn.q_proj.weight')).toEqual([d, d]);
        expect(shape('model.encoder.layers.0.input_layernorm.weight')).toEqual([d]);
      });

      it('every tensor is F32 with payload bytes matching its shape', async () => {
        const { tensors } = await header;
        for (const [name, info] of tensors) {
          expect(info.dtype, name).toBe('F32');
          const elems = info.shape.reduce((a, b) => a * b, 1);
          expect(info.end - info.begin, name).toBe(elems * 4);
        }
      });
    },
  );

  describe.skipIf(!existsSync(`${MODEL}model-f16.safetensors`))(
    `moonshine f16 weight export (${M.name})`,
    () => {
      it('every tensor is F16, same name set as the f32 file', async () => {
        const f16 = await headerIf(`${MODEL}model-f16.safetensors`);
        const f32 = await headerIf(`${MODEL}model.safetensors`);
        expect(f16.metadata['dtype']).toBe('f16');
        expect([...f16.tensors.keys()].sort()).toEqual([...f32.tensors.keys()].sort());
        for (const [name, info] of f16.tensors) {
          expect(info.dtype, name).toBe('F16');
          const elems = info.shape.reduce((a, b) => a * b, 1);
          expect(info.end - info.begin, name).toBe(elems * 2);
        }
      });
    },
  );

  describe.skipIf(!existsSync(`${CASE}meta.json`))(
    `moonshine golden fixtures (${M.name}, librispeech_3s)`,
    () => {
      const meta = json(`${CASE}meta.json`);

      /** Chained conv1d output length: floor((L − k)/s) + 1 per stage. */
      const frames = (L: number) =>
        [
          [127, 64],
          [7, 3],
          [3, 2],
        ].reduce((n, [k, s]) => Math.floor((n - k!) / s!) + 1, L);

      it('greedy ids are BOS-started, EOS-terminated, in-vocab', () => {
        const ids: number[] = meta.greedyIds;
        expect(ids[0]).toBe(1);
        expect(ids[ids.length - 1]).toBe(2);
        expect(ids.every((i) => Number.isInteger(i) && i >= 0 && i < 32768)).toBe(true);
        expect(meta.transcript.length).toBeGreaterThan(0);
      });

      it('encoder frame count matches the chained conv formula', () => {
        expect(meta.encoderFrames).toBe(frames(meta.audioSamples));
      });

      it('stage tensors exist on disk with shape-consistent sizes', () => {
        for (const [name, entry] of Object.entries<TensorEntry>(meta.tensors)) {
          const elems = entry.shape.reduce((a, b) => a * b, 1);
          expect(statSync(`${CASE}${entry.file}`).size, name).toBe(elems * 4);
        }
        expect(meta.tensors.logits_tf.shape).toEqual([meta.greedyIds.length, 32768]);
        expect(meta.tensors.stem_out.shape).toEqual([meta.encoderFrames, meta.config.hidden_size]);
      });

      it('rope table dump covers max positions at the empirical rotary_dim', () => {
        const manifest = json(`${MODEL}manifest.json`);
        // Both sizes land on rotary_dim 32: int(36·0.9) and int(52·0.62).
        expect(manifest.rope.shape).toEqual([2, 256, 32]);
        const elems = manifest.rope.shape.reduce((a: number, b: number) => a * b, 1);
        expect(statSync(`${MODEL}rope.bin`).size).toBe(elems * 4);
      });

      it('records the reference versions for reproducibility', () => {
        expect(meta.transformers).toMatch(/^\d+\./);
        expect(meta.torch).toMatch(/^\d+\./);
        expect(meta.sampleRate).toBe(16000);
      });
    },
  );
}

describe.skipIf(!existsSync(`${DIR}tokenizer.json`))('moonshine tokenizer asset', () => {
  const asset = json(`${DIR}tokenizer.json`);

  it('has the full vocab and config-authoritative special ids', () => {
    expect(asset.vocab.length).toBe(32768);
    expect(asset.bosId).toBe(1);
    expect(asset.eosId).toBe(2);
    expect(asset.vocab[1]).toBe('<s>');
    expect(asset.vocab[2]).toBe('</s>');
    expect(asset.specialIds.length).toBe(771); // 0/1/2 + 768 <<ST_N>> placeholders
    expect(asset.specialIds).toContain(asset.bosId);
    expect(asset.specialIds).toContain(asset.eosId);
  });

  it('ships decode parity cases with pure-number id arrays', () => {
    const cases = json(`${DIR}tokenizer_cases.json`);
    expect(cases.length).toBeGreaterThanOrEqual(8);
    for (const c of cases) {
      expect(typeof c.text).toBe('string');
      expect(c.ids.every((i: number) => Number.isInteger(i) && i >= 0 && i < 32768)).toBe(true);
    }
  });
});
