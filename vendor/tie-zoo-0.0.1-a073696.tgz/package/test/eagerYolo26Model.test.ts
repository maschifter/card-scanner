import { describe, expect, it } from 'vitest';
import { materialized, memoryStateDict, nn, tensor3d, type Value } from '@tie/core';
import { Yolo26Model } from '../src/yolo26/model.ts';

/** LOGICAL dims (p.shape.dims), not the flat word count — f16 params
 *  need that for loadStateDict's shape check. */
async function fakeLoad(model: InstanceType<typeof nn.Module>): Promise<void> {
  const sd: Record<string, { data: Float32Array | Uint16Array; shape: number[] }> = {};
  for (const [name, p] of model.namedParameters()) {
    sd[name] = {
      data:
        p.shape.dtype === 'f16'
          ? new Uint16Array(p.shape.elems)
          : new Float32Array(p.shape.elems),
      shape: [...p.shape.dims!],
    };
  }
  await model.loadStateDict(memoryStateDict(sd), {
    upload: (_, shape) => materialized(shape, {} as never),
  });
}

const t3 = (c: number, h: number, w: number): Value => materialized(tensor3d(c, h, w), {} as never);

describe('Yolo26Model (nano)', () => {
  it('registers checkpoint-shaped keys across the 24-layer graph', () => {
    const m = new Yolo26Model('n');
    const names = new Set(Array.from(m.namedParameters()).map(([n]) => n));
    expect(names.has('model.0.conv.weight')).toBe(true); // stem
    expect(names.has('model.2.cv1.conv.weight')).toBe(true); // C3k2
    expect(names.has('model.6.m.0.cv3.conv.weight')).toBe(true); // C3k2 c3k=true → nested C3k
    expect(names.has('model.9.cv1.conv.weight')).toBe(true); // SPPF
    expect(names.has('model.10.m.0.attn.qkv.conv.weight')).toBe(true); // C2PSA
    expect(names.has('model.22.m.0.1.attn.pe.conv.weight')).toBe(true); // C3k2Attn PSABlock
    expect(names.has('model.23.one2one_cv2.0.2.weight')).toBe(true); // Detect box tower final 1×1
    expect(names.has('model.23.one2one_cv3.2.0.0.conv.weight')).toBe(true); // Detect cls DWConv
    // Param-less yaml slots register nothing
    for (const n of names) {
      expect(n.startsWith('model.11.')).toBe(false);
      expect(n.startsWith('model.12.')).toBe(false);
    }
  });

  it('640×640 forward yields [84, 80, 80] / [84, 40, 40] / [84, 20, 20]', async () => {
    const m = new Yolo26Model('n');
    await fakeLoad(m);
    const [p3, p4, p5] = m.forward(t3(3, 640, 640));
    expect(p3.shape.dims).toEqual([84, 80, 80]);
    expect(p4.shape.dims).toEqual([84, 40, 40]);
    expect(p5.shape.dims).toEqual([84, 20, 20]);
  });

  it('nano parameter count is in the yolo26n ballpark (~2.5M)', () => {
    const m = new Yolo26Model('n');
    let total = 0;
    for (const [, p] of m.namedParameters()) {
      total += p.shape.elems;
    }
    // Checkpoint totals 2.57M including the one2many towers we deliberately
    // omit; our inference graph must land between 2M and 2.6M.
    expect(total).toBeGreaterThan(2_000_000);
    expect(total).toBeLessThan(2_600_000);
  });
});
