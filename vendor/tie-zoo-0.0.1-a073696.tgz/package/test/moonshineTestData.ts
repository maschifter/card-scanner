/** Shared moonshine test builders: a toy config, the HF checkpoint shape set
 *  it implies, synthetic checkpoint records, and a fake state dict for
 *  binding module trees without real weights. */

import { nn, type MemoryStateDict } from '@tie/core';
import type { MoonshineConfig } from '../src/moonshine/config.ts';
import type { MoonshineStreamingConfig } from '../src/moonshine-streaming/config.ts';

/** Mini config: same topology as tiny, toy dims — transforms are shape-driven,
 *  so correctness at 4/2/2 is correctness at 288/8/36. */
export const MINI: MoonshineConfig = {
  dModel: 4,
  ffn: 6,
  encLayers: 1,
  decLayers: 1,
  heads: 2,
  headDim: 2,
  rotaryDim: 2,
  ropeTheta: 10000,
  vocab: 10,
  maxPositions: 8,
  bos: 1,
  eos: 2,
};

/** HF checkpoint shapes for a config (mirrors tools/export_moonshine.py). */
export function hfShapes(cfg: MoonshineConfig): Record<string, number[]> {
  const d = cfg.dModel;
  const qw = cfg.heads * cfg.headDim;
  const shapes: Record<string, number[]> = {
    'model.encoder.conv1.weight': [d, 1, 127],
    'model.encoder.conv2.weight': [2 * d, d, 7],
    'model.encoder.conv2.bias': [2 * d],
    'model.encoder.conv3.weight': [d, 2 * d, 3],
    'model.encoder.conv3.bias': [d],
    'model.encoder.groupnorm.weight': [d],
    'model.encoder.groupnorm.bias': [d],
    'model.encoder.layer_norm.weight': [d],
    'model.decoder.embed_tokens.weight': [cfg.vocab, d],
    'model.decoder.norm.weight': [d],
  };
  for (let i = 0; i < cfg.encLayers; i++) {
    const L = `model.encoder.layers.${i}`;
    for (const p of ['q', 'k', 'v']) shapes[`${L}.self_attn.${p}_proj.weight`] = [qw, d];
    shapes[`${L}.self_attn.o_proj.weight`] = [d, qw];
    shapes[`${L}.mlp.fc1.weight`] = [cfg.ffn, d];
    shapes[`${L}.mlp.fc1.bias`] = [cfg.ffn];
    shapes[`${L}.mlp.fc2.weight`] = [d, cfg.ffn];
    shapes[`${L}.mlp.fc2.bias`] = [d];
    shapes[`${L}.input_layernorm.weight`] = [d];
    shapes[`${L}.post_attention_layernorm.weight`] = [d];
  }
  for (let i = 0; i < cfg.decLayers; i++) {
    const L = `model.decoder.layers.${i}`;
    for (const p of ['q', 'k', 'v']) shapes[`${L}.self_attn.${p}_proj.weight`] = [qw, d];
    shapes[`${L}.self_attn.o_proj.weight`] = [d, qw];
    for (const p of ['q', 'k', 'v']) shapes[`${L}.encoder_attn.${p}_proj.weight`] = [qw, d];
    shapes[`${L}.encoder_attn.o_proj.weight`] = [d, qw];
    shapes[`${L}.mlp.fc1.weight`] = [2 * cfg.ffn, d];
    shapes[`${L}.mlp.fc1.bias`] = [2 * cfg.ffn];
    shapes[`${L}.mlp.fc2.weight`] = [d, cfg.ffn];
    shapes[`${L}.mlp.fc2.bias`] = [d];
    shapes[`${L}.input_layernorm.weight`] = [d];
    shapes[`${L}.post_attention_layernorm.weight`] = [d];
    shapes[`${L}.final_layernorm.weight`] = [d];
  }
  return shapes;
}

/** Mini streaming configs: MINI_STREAMING mirrors v2 tiny (enc dim == dec
 *  dim, no adapter proj); MINI_STREAMING_PROJ mirrors small (enc ≠ dec dims,
 *  attention inner dim ≠ hidden, adapter projection present). */
export const MINI_STREAMING: MoonshineStreamingConfig = {
  enc: { hidden: 4, ffn: 6, layers: 1, heads: 2, headDim: 2, windows: [[2, 1]] },
  dec: { hidden: 4, ffn: 6, layers: 1, heads: 2, headDim: 2, rotaryDim: 2, ropeTheta: 10000 },
  frameLen: 4,
  vocab: 10,
  maxPositions: 8,
  bos: 1,
  eos: 2,
};

export const MINI_STREAMING_PROJ: MoonshineStreamingConfig = {
  enc: { hidden: 6, ffn: 8, layers: 1, heads: 2, headDim: 2, windows: [[2, 1]] },
  dec: { hidden: 4, ffn: 6, layers: 1, heads: 2, headDim: 4, rotaryDim: 2, ropeTheta: 10000 },
  frameLen: 4,
  vocab: 10,
  maxPositions: 8,
  bos: 1,
  eos: 2,
};

/** HF v2 checkpoint shapes for a config (mirrors tools/export_moonshine_v2.py). */
export function streamingHfShapes(cfg: MoonshineStreamingConfig): Record<string, number[]> {
  const eh = cfg.enc.hidden;
  const dh = cfg.dec.hidden;
  const encQw = cfg.enc.heads * cfg.enc.headDim;
  const decQw = cfg.dec.heads * cfg.dec.headDim;
  const shapes: Record<string, number[]> = {
    'model.encoder.embedder.comp.log_k': [],
    'model.encoder.embedder.linear.weight': [eh, cfg.frameLen],
    'model.encoder.embedder.conv1.weight': [2 * eh, eh, 5],
    'model.encoder.embedder.conv1.bias': [2 * eh],
    'model.encoder.embedder.conv2.weight': [eh, 2 * eh, 5],
    'model.encoder.embedder.conv2.bias': [eh],
    'model.encoder.final_norm.gamma': [eh],
    'model.decoder.embed_tokens.weight': [cfg.vocab, dh],
    'model.decoder.pos_emb.weight': [cfg.maxPositions, eh],
    'model.decoder.norm.weight': [dh],
  };
  if (eh !== dh) shapes['model.decoder.proj.weight'] = [dh, eh];
  for (let i = 0; i < cfg.enc.layers; i++) {
    const L = `model.encoder.layers.${i}`;
    for (const p of ['q', 'k', 'v']) shapes[`${L}.self_attn.${p}_proj.weight`] = [encQw, eh];
    shapes[`${L}.self_attn.o_proj.weight`] = [eh, encQw];
    shapes[`${L}.mlp.fc1.weight`] = [cfg.enc.ffn, eh];
    shapes[`${L}.mlp.fc1.bias`] = [cfg.enc.ffn];
    shapes[`${L}.mlp.fc2.weight`] = [eh, cfg.enc.ffn];
    shapes[`${L}.mlp.fc2.bias`] = [eh];
    shapes[`${L}.input_layernorm.gamma`] = [eh];
    shapes[`${L}.post_attention_layernorm.gamma`] = [eh];
  }
  for (let i = 0; i < cfg.dec.layers; i++) {
    const L = `model.decoder.layers.${i}`;
    for (const p of ['q', 'k', 'v']) shapes[`${L}.self_attn.${p}_proj.weight`] = [decQw, dh];
    shapes[`${L}.self_attn.o_proj.weight`] = [dh, decQw];
    for (const p of ['q', 'k', 'v']) shapes[`${L}.encoder_attn.${p}_proj.weight`] = [decQw, dh];
    shapes[`${L}.encoder_attn.o_proj.weight`] = [dh, decQw];
    shapes[`${L}.mlp.fc1.weight`] = [2 * cfg.dec.ffn, dh];
    shapes[`${L}.mlp.fc1.bias`] = [2 * cfg.dec.ffn];
    shapes[`${L}.mlp.fc2.weight`] = [dh, cfg.dec.ffn];
    shapes[`${L}.mlp.fc2.bias`] = [dh];
    shapes[`${L}.input_layernorm.weight`] = [dh];
    shapes[`${L}.post_attention_layernorm.weight`] = [dh];
    shapes[`${L}.final_layernorm.weight`] = [dh];
  }
  return shapes;
}

/** Per-index fill — every synthetic checkpoint gets the same values. */
export const fillValue = (i: number): number => ((i * 37) % 101) / 101;

/** Synthetic HF-named checkpoint record for loadStateDict's in-memory path. */
export function buildHfRecord(
  shapes: Record<string, number[]>,
  overrides: Record<string, Float32Array> = {},
): MemoryStateDict {
  const record: MemoryStateDict = {};
  for (const [name, shape] of Object.entries(shapes)) {
    const elems = shape.reduce((a, b) => a * b, 1);
    record[name] = {
      data: overrides[name] ?? Float32Array.from({ length: elems }, (_, i) => fillValue(i)),
      shape,
    };
  }
  return record;
}

/** Engine-named fake state dict for a module tree loaded WITHOUT its root
 *  transform hook: zero data, checkpoint-layout shapes (Linear torch [out,
 *  in], Conv1d torch (C_out, C_in, k)) so the core layer hooks accept it. */
export function fakeStateDict(module: nn.AnyModule): MemoryStateDict {
  const record: MemoryStateDict = {};
  const own = (m: nn.AnyModule) =>
    [...m.namedParameters()].filter(([n]) => !n.includes('.')) as [string, nn.Parameter][];
  for (const [prefix, m] of [['', module] as const, ...module.namedModules()]) {
    const at = (n: string) => (prefix ? `${prefix}.${n}` : n);
    if (m instanceof nn.Linear) {
      const shape = [m.outFeatures, m.inFeatures];
      record[at('weight')] = { data: new Float32Array(m.inFeatures * m.outFeatures), shape };
      if (m.bias)
        record[at('bias')] = { data: new Float32Array(m.outFeatures), shape: [m.outFeatures] };
    } else if (m instanceof nn.Conv1d) {
      const shape = [m.outChannels, m.inChannels, m.kernelSize];
      record[at('weight')] = {
        data: new Float32Array(m.outChannels * m.inChannels * m.kernelSize),
        shape,
      };
      if (m.bias)
        record[at('bias')] = { data: new Float32Array(m.outChannels), shape: [m.outChannels] };
    } else {
      for (const [n, p] of own(m)) {
        record[at(n)] = { data: new Float32Array(p.shape.elems), shape: [...p.shape.dims!] };
      }
    }
  }
  return record;
}
