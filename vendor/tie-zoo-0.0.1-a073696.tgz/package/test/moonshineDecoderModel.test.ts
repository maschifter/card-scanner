import { describe, expect, it } from 'vitest';
import { materialized, matrix, nn, type Value, type ValueMeta } from '@tie/core';
// Reuse the @tie/core test helper via a relative import.
import { fakeGpuBuffer } from '../../core/test/helpers.ts';
import { MOONSHINE_TINY } from '../src/moonshine/config.ts';
import { MoonshineDecoder, type SelfKV } from '../src/moonshine/decoder.ts';
import { MoonshineModel } from '../src/moonshine/model.ts';
import { MINI, buildHfRecord, fakeStateDict, hfShapes } from './moonshineTestData.ts';

const fake = (shape: ValueMeta): Value => materialized(shape, fakeGpuBuffer({ id: 'fake' }));

async function bindFake(model: nn.AnyModule): Promise<void> {
  await model.loadStateDict(fakeStateDict(model), { upload: (_data, shape) => fake(shape) });
}

const CFG = MOONSHINE_TINY;
const QW = CFG.heads * CFG.headDim;

describe('moonshine decoder + model', () => {
  it('decoder forward derives [t, d] through all three sublayers', async () => {
    const dec = new MoonshineDecoder(CFG);
    await bindFake(dec);
    const kvLen = 123;
    const t = 5;
    const cross = dec.precomputeCrossKV(fake(matrix(kvLen, CFG.dModel)));
    expect(cross).toHaveLength(CFG.decLayers);
    for (const { k, v } of cross) {
      expect(k.shape.dims).toEqual([kvLen, QW]);
      expect(v.shape.dims).toEqual([kvLen, QW]);
    }
    const y = dec.forward(
      fake(matrix(t, CFG.dModel)),
      fake(matrix(t, CFG.headDim)),
      fake(matrix(t, CFG.headDim)),
      cross,
    );
    expect(y.shape.dims).toEqual([t, CFG.dModel]);
  });

  it('decoder forward rejects a cross K/V list of the wrong length', async () => {
    const dec = new MoonshineDecoder(CFG);
    await bindFake(dec);
    const cross = dec.precomputeCrossKV(fake(matrix(10, CFG.dModel)));
    expect(() =>
      dec.forward(
        fake(matrix(2, CFG.dModel)),
        fake(matrix(2, CFG.headDim)),
        fake(matrix(2, CFG.headDim)),
        cross.slice(0, 3),
      ),
    ).toThrow(/cross K\/V/);
  });

  it('forwardStep writes preallocated caches in place and keeps [1, d] output', async () => {
    const dec = new MoonshineDecoder(CFG);
    await bindFake(dec);
    const cross = dec.precomputeCrossKV(fake(matrix(123, CFG.dModel)));
    const caches: SelfKV[] = Array.from({ length: CFG.decLayers }, () => ({
      k: fake(matrix(CFG.maxPositions, QW)),
      v: fake(matrix(CFG.maxPositions, QW)),
    }));
    for (let t = 0; t < 3; t++) {
      const h = dec.forwardStep(
        fake(matrix(1, CFG.dModel)),
        fake(matrix(1, CFG.headDim)),
        fake(matrix(1, CFG.headDim)),
        cross,
        caches,
        t,
      );
      expect(h.shape.dims).toEqual([1, CFG.dModel]);
    }
  });

  it('forwardStep rejects a caches list of the wrong length', async () => {
    const dec = new MoonshineDecoder(CFG);
    await bindFake(dec);
    const cross = dec.precomputeCrossKV(fake(matrix(10, CFG.dModel)));
    const short: SelfKV[] = Array.from({ length: 2 }, () => ({
      k: fake(matrix(CFG.maxPositions, QW)),
      v: fake(matrix(CFG.maxPositions, QW)),
    }));
    expect(() =>
      dec.forwardStep(
        fake(matrix(1, CFG.dModel)),
        fake(matrix(1, CFG.headDim)),
        fake(matrix(1, CFG.headDim)),
        cross,
        short,
        0,
      ),
    ).toThrow(/cache entries/);
  });

  it('embed and logitsLast derive the tied-embedding shapes', async () => {
    // The root transform hook runs on a full-model load, so the fake
    // checkpoint carries HF names (toy dims — shapes are config-driven).
    const model = new MoonshineModel(MINI);
    await model.loadStateDict(buildHfRecord(hfShapes(MINI)), {
      upload: (_data, shape) => fake(shape),
    });
    const x = model.embed([1, 7, 8]);
    expect(x.shape.dims).toEqual([3, MINI.dModel]);
    const logits = model.logitsLast(fake(matrix(3, MINI.dModel)));
    expect(logits.shape.dims).toEqual([MINI.vocab, 1]);
  });

  it('MoonshineModel.forward refuses direct use', () => {
    const model = new MoonshineModel(CFG);
    expect(() => model.forward()).toThrow(/logitsLast/);
  });
});
