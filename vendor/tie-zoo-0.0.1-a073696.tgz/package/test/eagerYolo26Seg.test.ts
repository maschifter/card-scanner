import { describe, expect, it } from 'vitest';
import { hwc4Meta, materialized, memoryStateDict, nn, type Value } from '@tie/core';
import { Proto26, Segment26 } from '../src/yolo26/seg.ts';
import { Yolo26Model } from '../src/yolo26/model.ts';

/** Same fakeLoad/t3 helpers as eagerYolo26Blocks.test.ts — shape-only, no GPU.
 *  LOGICAL dims (p.shape.dims), not the flat word count — f16 params
 *  need that for loadStateDict's shape check. */
async function fakeLoad(model: InstanceType<typeof nn.Module>): Promise<void> {
  model.half(); // hwc4 convs need f16 biases; rootless contexts skip the f16 check
  const sd: Record<string, { data: Float32Array | Uint16Array; shape: number[] }> = {};
  for (const [name, p] of model.namedParameters()) {
    sd[name] = {
      data:
        p.shape.dtype === 'f16'
          ? new Uint16Array(p.shape.elems)
          : new Float32Array(p.shape.elems),
      shape: [...p.shape.dims!],
    };
  }
  await model.loadStateDict(memoryStateDict(sd), {
    upload: (_, shape) => materialized(shape, {} as never),
  });
}
// Blocks run HWC4 storage — feed them hwc4-tagged fakes like the model does.
const t3 = (c: number, h: number, w: number): Value => materialized(hwc4Meta(c, h, w), {} as never);
// Model INPUT is row-major (the model converts to hwc4 itself).
const tIn = (c: number, h: number, w: number): Value =>
  materialized({ elems: c * h * w, dtype: 'f32', dims: [c, h, w] }, {} as never);

const CH = [64, 128, 256] as const; // yolo26n P3/P4/P5 channels

describe('Proto26', () => {
  it('fuses P3+P4+P5 → [nm, 4·P3size] and registers checkpoint keys', async () => {
    const p = new Proto26(CH, 64, 32);
    const names = Array.from(p.namedParameters()).map(([n]) => n);
    expect(names).toContain('feat_refine.0.conv.weight'); // 128→64 1×1
    expect(names).toContain('feat_refine.1.conv.weight'); // 256→64 1×1
    expect(names).toContain('feat_fuse.conv.weight');
    expect(names).toContain('upsample.weight'); // ConvTranspose2d
    expect(names).toContain('upsample.bias');
    expect(names).toContain('cv3.conv.weight');
    const params = Object.fromEntries(Array.from(p.namedParameters()));
    expect(params['feat_refine.0.conv.weight']!.shape.dims).toEqual([64, 128]);
    expect(params['upsample.weight']!.shape.dims).toEqual([64 * 4, 64]);
    expect(params['cv3.conv.weight']!.shape.dims).toEqual([32, 64]);
    await fakeLoad(p);
    const out = p.forward([t3(64, 80, 80), t3(128, 40, 40), t3(256, 20, 20)]);
    expect(out.shape.dims).toEqual([32, 160, 160]);
  });
});

describe('Segment26', () => {
  it('per-level output is [4+nc+nm, H, W]; proto is [nm, 160, 160]', async () => {
    const head = new Segment26(80, 1, CH, { npr: 64 });
    await fakeLoad(head);
    const feats = [t3(64, 80, 80), t3(128, 40, 40), t3(256, 20, 20)];
    const [d3, d4, d5] = head.forward(feats);
    expect(d3!.shape.dims).toEqual([116, 80, 80]);
    expect(d4!.shape.dims).toEqual([116, 40, 40]);
    expect(d5!.shape.dims).toEqual([116, 20, 20]);
    expect(head.forwardProto(feats).shape.dims).toEqual([32, 160, 160]);
  });

  it('registers one2one_cv4 + proto checkpoint keys (c4 = max(ch0/4, nm) = 32)', () => {
    const head = new Segment26(80, 1, CH, { npr: 64 });
    const params = Object.fromEntries(Array.from(head.namedParameters()));
    // tower level 0: ConvBlock(64→32 3×3), ConvBlock(32→32 3×3), plain 1×1 32→32
    expect(params['one2one_cv4.0.0.conv.weight']!.shape.dims).toEqual([32, 64 * 9]);
    expect(params['one2one_cv4.0.1.conv.weight']!.shape.dims).toEqual([32, 32 * 9]);
    expect(params['one2one_cv4.0.2.weight']!.shape.dims).toEqual([32, 32]);
    expect(params['one2one_cv4.2.0.conv.weight']!.shape.dims).toEqual([32, 256 * 9]);
    expect(params['proto.feat_fuse.conv.weight']!.shape.dims).toEqual([64, 64 * 9]);
    // Detect towers still present (inherited)
    expect(params['one2one_cv2.0.2.weight']).toBeDefined();
  });
});

describe('Yolo26Model segment task', () => {
  it('registers seg head keys at model.23', () => {
    const m = new Yolo26Model('n', { task: 'segment' });
    const names = new Set(Array.from(m.namedParameters()).map(([n]) => n));
    expect(names.has('model.23.one2one_cv4.0.0.conv.weight')).toBe(true);
    expect(names.has('model.23.proto.upsample.weight')).toBe(true);
    expect(names.has('model.23.proto.cv3.conv.weight')).toBe(true);
    expect(names.has('model.23.one2one_cv2.0.2.weight')).toBe(true); // Detect towers too
  });

  it('640×640 seg forward yields [116,80,80]/[116,40,40]/[116,20,20] + proto [32,160,160]', async () => {
    const m = new Yolo26Model('n', { task: 'segment' });
    await fakeLoad(m);
    const { levels, proto } = m.forward(tIn(3, 640, 640));
    expect(levels[0].shape.dims).toEqual([116, 80, 80]);
    expect(levels[1].shape.dims).toEqual([116, 40, 40]);
    expect(levels[2].shape.dims).toEqual([116, 20, 20]);
    expect(proto.shape.dims).toEqual([32, 160, 160]);
  });

  it('detect task is unchanged', async () => {
    const m = new Yolo26Model('n');
    await fakeLoad(m);
    const [p3] = m.forward(tIn(3, 640, 640));
    expect(p3.shape.dims).toEqual([84, 80, 80]);
  });

  it('seg nano parameter count ≈ detect + ~0.31M (bounds 2.3M–3.0M)', () => {
    const m = new Yolo26Model('n', { task: 'segment' });
    let total = 0;
    for (const [, p] of m.namedParameters()) {
      total += p.shape.elems;
    }
    // Detect graph lands in 2.0–2.6M (see eagerYolo26Model.test.ts); the seg
    // head adds ~313k params (cv4 towers ~160k + Proto26 ~153k).
    expect(total).toBeGreaterThan(2_300_000);
    expect(total).toBeLessThan(3_000_000);
  });
});
