/** transformMinilmStateDict on a tiny synthetic HF checkpoint: the produced
 *  key set must match MinilmModel.namedParameters exactly, and the derived
 *  tensors must compute the right numbers — qkv fusion (row-stacked torch
 *  layout + headDim^(−1/4) scale on q/k) and the token-type-0 fold into the
 *  position table. Linear weights stay torch [out, in] — the layout
 *  transpose is Linear.transformStateDict's job during the load. */

import { describe, expect, it } from 'vitest';
import { eagerTensor, type LazyStateDict, type LazyTensor } from '@tie/core';
import { MinilmModel } from '../src/minilm/model.ts';
import { transformMinilmStateDict } from '../src/minilm/stateDictHooks.ts';
import type { MinilmConfig } from '../src/minilm/config.ts';

const CFG: MinilmConfig = {
  hidden: 4,
  layers: 1,
  heads: 2,
  headDim: 2,
  ffn: 8,
  vocab: 10,
  maxPositions: 6,
  eps: 1e-12,
};

/** Sequential-value tensor so transposes/concats are easy to assert. */
const seq = (shape: number[], offset = 0): LazyTensor => {
  const elems = shape.reduce((a, b) => a * b, 1);
  return eagerTensor(
    Float32Array.from({ length: elems }, (_, i) => offset + i),
    shape,
  );
};

function syntheticDict(cfg: MinilmConfig): LazyStateDict {
  const H = cfg.hidden;
  const tensors = new Map<string, LazyTensor>();
  tensors.set('embeddings.word_embeddings.weight', seq([cfg.vocab, H]));
  tensors.set('embeddings.position_embeddings.weight', seq([cfg.maxPositions, H], 100));
  tensors.set('embeddings.token_type_embeddings.weight', seq([2, H], 1000));
  tensors.set('embeddings.LayerNorm.weight', seq([H]));
  tensors.set('embeddings.LayerNorm.bias', seq([H]));
  tensors.set('embeddings.position_ids', seq([1, cfg.maxPositions]));
  tensors.set('pooler.dense.weight', seq([H, H]));
  tensors.set('pooler.dense.bias', seq([H]));
  for (let i = 0; i < cfg.layers; i++) {
    const L = `encoder.layer.${i}`;
    for (const p of ['query', 'key', 'value']) {
      tensors.set(
        `${L}.attention.self.${p}.weight`,
        seq([H, H], p === 'query' ? 0 : p === 'key' ? 16 : 32),
      );
      tensors.set(
        `${L}.attention.self.${p}.bias`,
        seq([H], p === 'query' ? 0 : p === 'key' ? 4 : 8),
      );
    }
    tensors.set(`${L}.attention.output.dense.weight`, seq([H, H]));
    tensors.set(`${L}.attention.output.dense.bias`, seq([H]));
    tensors.set(`${L}.attention.output.LayerNorm.weight`, seq([H]));
    tensors.set(`${L}.attention.output.LayerNorm.bias`, seq([H]));
    tensors.set(`${L}.intermediate.dense.weight`, seq([cfg.ffn, H]));
    tensors.set(`${L}.intermediate.dense.bias`, seq([cfg.ffn]));
    tensors.set(`${L}.output.dense.weight`, seq([H, cfg.ffn]));
    tensors.set(`${L}.output.dense.bias`, seq([H]));
    tensors.set(`${L}.output.LayerNorm.weight`, seq([H]));
    tensors.set(`${L}.output.LayerNorm.bias`, seq([H]));
  }
  return {
    metadata: {},
    tensors,
    totalBytes: () => [...tensors.values()].reduce((s, t) => s + t.byteLength, 0),
  };
}

describe('transformMinilmStateDict', () => {
  it('produces exactly the model parameter names', () => {
    const sd = syntheticDict(CFG);
    transformMinilmStateDict(sd, '', CFG);
    const model = new MinilmModel(CFG);
    const expected = new Set([...model.namedParameters()].map(([n]) => n));
    expect(new Set(sd.tensors.keys())).toEqual(expected);
  });

  it('fuses qkv row-stacked in torch layout with q/k scaling', async () => {
    const sd = syntheticDict(CFG);
    transformMinilmStateDict(sd, '', CFG);
    const H = CFG.hidden;
    const s = CFG.headDim ** -0.25;
    const w = await sd.tensors.get('layers.0.qkv.weight')!.f32();
    expect(sd.tensors.get('layers.0.qkv.weight')!.shape).toEqual([3 * H, H]);
    // Row part·H + r holds the part's torch row r, scaled.
    // Source weight[r][c] = offset + r·H + c; k offset 16, v offset 32.
    for (const [part, offset, scale] of [
      [0, 0, s],
      [1, 16, s],
      [2, 32, 1],
    ] as const) {
      for (let r = 0; r < H; r++) {
        for (let c = 0; c < H; c++) {
          expect(w[(part * H + r) * H + c]).toBeCloseTo((offset + r * H + c) * scale, 5);
        }
      }
    }
    const b = await sd.tensors.get('layers.0.qkv.bias')!.f32();
    expect(b).toHaveLength(3 * H);
    for (let c = 0; c < H; c++) {
      expect(b[c]).toBeCloseTo(c * s, 5); // q bias scaled
      expect(b[H + c]).toBeCloseTo((4 + c) * s, 5); // k bias scaled
      expect(b[2 * H + c]).toBe(8 + c); // v bias untouched
    }
  });

  it('folds token-type row 0 into every position row', async () => {
    const sd = syntheticDict(CFG);
    transformMinilmStateDict(sd, '', CFG);
    const pos = await sd.tensors.get('embeddings.position.weight')!.f32();
    // position[i][j] = (100 + i·H + j) + tokenType[0][j] = … + (1000 + j).
    for (let i = 0; i < CFG.maxPositions; i++) {
      for (let j = 0; j < CFG.hidden; j++) {
        expect(pos[i * CFG.hidden + j]).toBe(100 + i * CFG.hidden + j + 1000 + j);
      }
    }
  });

  it('keeps the plain Linear weights in torch layout', async () => {
    const sd = syntheticDict(CFG);
    transformMinilmStateDict(sd, '', CFG);
    const up = sd.tensors.get('layers.0.up.weight')!;
    expect(up.shape).toEqual([CFG.ffn, CFG.hidden]); // torch [out, in]
    const data = await up.f32();
    // Moved untouched: weight[o][i] = o·H + i.
    expect(data[3 * CFG.hidden + 0]).toBe(3 * CFG.hidden + 0);
    expect(data[5 * CFG.hidden + 2]).toBe(5 * CFG.hidden + 2);
  });
});
