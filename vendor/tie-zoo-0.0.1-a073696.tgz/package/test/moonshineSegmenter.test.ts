import { describe, expect, it } from 'vitest';
import { analyzeSegment } from '../src/moonshine/segmenter.ts';

const RATE = 16_000;

/** Synth audio: sequence of (seconds, amplitude) spans — sine bursts for
 *  speech-like energy, zeros (or a low hum) for silence. */
function synth(spans: readonly (readonly [number, number])[]): Float32Array {
  const total = Math.round(spans.reduce((s, [sec]) => s + sec, 0) * RATE);
  const out = new Float32Array(total);
  let at = 0;
  for (const [sec, amp] of spans) {
    const n = Math.round(sec * RATE);
    for (let i = 0; i < n; i++) out[at + i] = amp * Math.sin((2 * Math.PI * 220 * i) / RATE);
    at += n;
  }
  return out;
}

const opts = { sampleRate: RATE };

describe('live segmenter', () => {
  it('pure silence: no speech, no finalize, trailing silence = duration', () => {
    const a = analyzeSegment(synth([[2, 0]]), opts);
    expect(a.hasSpeech).toBe(false);
    expect(a.shouldFinalize).toBe(false);
    expect(a.trailingSilenceSeconds).toBeCloseTo(2, 1);
    expect(a.seconds).toBeCloseTo(2, 5);
  });

  it('a sub-threshold hum is not speech', () => {
    const a = analyzeSegment(synth([[2, 0.01]]), opts);
    expect(a.hasSpeech).toBe(false);
  });

  it('speech followed by a long pause finalizes with the measured tail', () => {
    const a = analyzeSegment(
      synth([
        [1.5, 0.3],
        [1.0, 0],
      ]),
      opts,
    );
    expect(a.hasSpeech).toBe(true);
    expect(a.shouldFinalize).toBe(true);
    // The smoothing window drags the envelope past the burst end slightly.
    expect(a.trailingSilenceSeconds).toBeGreaterThan(0.6);
    expect(a.trailingSilenceSeconds).toBeLessThan(1.05);
  });

  it('mid-sentence gaps shorter than the silence bound do not finalize', () => {
    const a = analyzeSegment(
      synth([
        [1, 0.3],
        [0.4, 0],
        [1, 0.3],
        [0.3, 0],
      ]),
      opts,
    );
    expect(a.hasSpeech).toBe(true);
    expect(a.shouldFinalize).toBe(false);
    expect(a.trailingSilenceSeconds).toBeLessThan(0.8);
  });

  it('an unbroken monologue finalizes only at the segment cap', () => {
    const short = analyzeSegment(synth([[5, 0.3]]), opts);
    expect(short.shouldFinalize).toBe(false);
    const capped = analyzeSegment(synth([[15.5, 0.3]]), opts);
    expect(capped.shouldFinalize).toBe(true);
    expect(capped.trailingSilenceSeconds).toBeLessThan(0.2);
  });

  it('a custom threshold reclassifies the same audio', () => {
    const hum = synth([[2, 0.05]]);
    expect(analyzeSegment(hum, opts).hasSpeech).toBe(true);
    expect(analyzeSegment(hum, { ...opts, threshold: 0.2 }).hasSpeech).toBe(false);
  });

  it('handles empty and sub-hop buffers', () => {
    const empty = analyzeSegment(new Float32Array(0), opts);
    expect(empty.hasSpeech).toBe(false);
    expect(empty.seconds).toBe(0);
    const tiny = analyzeSegment(synth([[0.005, 0.3]]), opts);
    expect(tiny.hasSpeech).toBe(true);
  });

  it('rejects bad options', () => {
    expect(() => analyzeSegment(new Float32Array(8), { sampleRate: 0 })).toThrow(/sampleRate/);
    expect(() => analyzeSegment(new Float32Array(8), { sampleRate: RATE, threshold: 0 })).toThrow(
      /threshold/,
    );
  });
});
