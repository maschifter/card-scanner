/** pf safetensors keep dense weights torch-layout [out, in]; core
 *  nn.Linear transposes them at load (layers.ts). This test pins that a pf
 *  block loads a torch-layout checkpoint end-to-end with no model-side hooks.
 *  The transpose math itself is covered in packages/core/test/loadStateDict. */
import { describe, expect, it } from 'vitest';
import { bufferSource, fromSafetensors, materialized, type ValueMeta } from '@tie/core';
import { EagerAttnBlock } from '../src/privacy-filter/attnBlock.ts';
import { bf16Data, encodeSafetensors, f32Data } from './safetensorsHelpers.ts';

/** A flat array of `length` copies of `fillValue`, with a few positions
 *  overridden — used to build synthetic checkpoint payloads without typing
 *  thousands of literals. All values here are powers of two so bf16
 *  truncation round-trips exactly (see bf16Data's doc comment). */
function fillWith(length: number, fillValue: number, overrides: Record<number, number> = {}) {
  const arr = new Array<number>(length).fill(fillValue);
  for (const [idx, val] of Object.entries(overrides)) arr[Number(idx)] = val;
  return arr;
}

/** Collect uploads in call order; returns fake Values so bind() succeeds
 *  (mirrors packages/core/test/loadStateDict.test.ts's collector — zoo tests
 *  can't import core's test helpers directly). EagerAttnBlock.namedParameters()
 *  walks its own direct Parameter (sinks) before its submodules in
 *  declaration order (norm, qkv, out), so the upload order is fixed:
 *  sinks, norm.scale, qkv.weight, qkv.bias, out.weight, out.bias. */
function collector() {
  const calls: Array<{ data: Float32Array | Uint16Array | Uint32Array; shape: ValueMeta }> = [];
  const upload = (data: Float32Array | Uint16Array | Uint32Array, shape: ValueMeta) => {
    calls.push({ data, shape });
    return materialized(shape, {} as never);
  };
  return { calls, upload };
}

describe('EagerAttnBlock checkpoint load', () => {
  const QKV_WIDTH = 1152;
  const HIDDEN = 640;
  const ATTN_OUT = 896;

  it('loads torch-layout qkv.weight/out.weight transposed, leaves everything else untouched', async () => {
    // Checkpoint values: qkv.weight[o=2, i=1] = 8 (2^3), everything else = 1
    // (2^0) — both exact in bf16. Row-major [out, in]: index = o*HIDDEN + i.
    const qkvOverrideIndex = 2 * HIDDEN + 1;
    const qkvData = fillWith(QKV_WIDTH * HIDDEN, 1, { [qkvOverrideIndex]: 8 });
    const outData = fillWith(HIDDEN * ATTN_OUT, 1);
    const sinksData = fillWith(14, 4); // [1,14] sink logits
    const normData = fillWith(HIDDEN, 3);
    const qkvBiasData = fillWith(QKV_WIDTH, 2);
    const outBiasData = fillWith(HIDDEN, 5);

    const raw = encodeSafetensors({
      sinks: { dtype: 'F32', shape: [1, 14], data: f32Data(sinksData) },
      'norm.scale': { dtype: 'F32', shape: [HIDDEN], data: f32Data(normData) },
      'qkv.weight': { dtype: 'BF16', shape: [QKV_WIDTH, HIDDEN], data: bf16Data(qkvData) },
      'qkv.bias': { dtype: 'F32', shape: [QKV_WIDTH], data: f32Data(qkvBiasData) },
      'out.weight': { dtype: 'BF16', shape: [HIDDEN, ATTN_OUT], data: bf16Data(outData) },
      'out.bias': { dtype: 'F32', shape: [HIDDEN], data: f32Data(outBiasData) },
    });
    const sd = await fromSafetensors(bufferSource(raw));
    const totalBefore = sd.totalBytes();

    const block = new EagerAttnBlock();
    const { upload, calls } = collector();
    await block.loadStateDict(sd, { upload });

    // progress accounting: the transpose must preserve byteLength, so the
    // file's total bytes are unchanged after the transform runs.
    expect(sd.totalBytes()).toBe(totalBefore);

    // upload order per namedParameters(): sinks, norm.scale, qkv.weight,
    // qkv.bias, out.weight, out.bias (see the collector's doc comment).
    expect(calls.length).toBe(6);
    const [sinksCall, normCall, qkvCall, qkvBiasCall, outCall, outBiasCall] = calls;

    // qkv.weight bound to the model as [in, out] = [640, 1152]; logical
    // index [i=1, o=2] must equal the checkpoint's [o=2, i=1] = 8.
    expect(qkvCall!.shape.dims).toEqual([HIDDEN, QKV_WIDTH]);
    expect(qkvCall!.data[1 * QKV_WIDTH + 2]).toBe(8);
    // spot-check an untransposed position stays 1
    expect(qkvCall!.data[0]).toBe(1);

    // out.weight bound as [in, out] = [896, 640].
    expect(outCall!.shape.dims).toEqual([ATTN_OUT, HIDDEN]);

    // sinks, norm.scale, biases bind unchanged.
    expect(Array.from(sinksCall!.data)).toEqual(sinksData);
    expect(Array.from(normCall!.data)).toEqual(normData);
    expect(Array.from(qkvBiasCall!.data)).toEqual(qkvBiasData);
    expect(Array.from(outBiasCall!.data)).toEqual(outBiasData);
  });
});
