import { describe, expect, it } from 'vitest';
import { decodeSegmentations, type RawLevel } from '../src/yolo26/pipeline.ts';

/** Hand-built fixture: 1 level (2×2 cells, stride 8), nc=2, nm=2, 4×4 proto
 *  grid on a 16×16 input (protoStride = 16/4 = 4). Cell 0 fires class 1 with
 *  a box covering the whole image; coeffs [1, -1] against proto0 = +1 in the
 *  left half / proto1 = +0.5 everywhere ⇒ mask logit = p0 − p1 > 0 exactly in
 *  the left half. */
function level(): RawLevel {
  const [h, w, nc, nm] = [2, 2, 2, 2];
  const hw = h * w;
  const data = new Float32Array((4 + nc + nm) * hw).fill(-10); // all cls logits low
  // cell 0 box ltrb: l=0.5,t=0.5,r=1.5,b=1.5 grid units → xyxy (0,0,16,16) at stride 8
  data[0 * hw + 0] = 0.5;
  data[1 * hw + 0] = 0.5;
  data[2 * hw + 0] = 1.5;
  data[3 * hw + 0] = 1.5;
  data[(4 + 1) * hw + 0] = 2; // class 1 logit → score σ(2) ≈ 0.88
  data[(4 + 2 + 0) * hw + 0] = 1; // coeff 0
  data[(4 + 2 + 1) * hw + 0] = -1; // coeff 1
  return { data, h, w, stride: 8 };
}

function proto(): { data: Float32Array; h: number; w: number } {
  const [h, w] = [4, 4];
  const data = new Float32Array(2 * h * w);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      data[0 * h * w + y * w + x] = x < 2 ? 1 : 0; // proto0: left half
      data[1 * h * w + y * w + x] = 0.5; // proto1: everywhere
    }
  return { data, h, w };
}

describe('decodeSegmentations', () => {
  it('gathers coeffs, assembles soft mask (255·σ(logit)), crops to box', () => {
    const dets = decodeSegmentations([level()], proto(), {
      numClasses: 2,
      numMasks: 2,
      confThreshold: 0.5,
      inputSize: 16,
    });
    expect(dets.length).toBe(1);
    const d = dets[0]!;
    expect(d.classId).toBe(1);
    expect(d.score).toBeCloseTo(1 / (1 + Math.exp(-2)), 5);
    expect([d.x1, d.y1, d.x2, d.y2]).toEqual([0, 0, 16, 16]);
    // crop = whole 4×4 proto grid
    expect([d.maskX, d.maskY, d.maskW, d.maskH]).toEqual([0, 0, 4, 4]);
    // logit = 1·p0 − 1·p1 = +0.5 left half, −0.5 right half; the soft mask
    // stores 255·σ(logit), so ≥128 ⇔ the old binary 1 (logit > 0).
    const IN = Math.round(255 / (1 + Math.exp(-0.5))); // 159
    const OUT = Math.round(255 / (1 + Math.exp(0.5))); // 96
    expect(IN).toBeGreaterThanOrEqual(128);
    expect(OUT).toBeLessThan(128);
    expect(Array.from(d.mask)).toEqual([
      IN,
      IN,
      OUT,
      OUT,
      IN,
      IN,
      OUT,
      OUT,
      IN,
      IN,
      OUT,
      OUT,
      IN,
      IN,
      OUT,
      OUT,
    ]);
  });

  it('clamps the crop to the proto grid and respects confThreshold', () => {
    const lv = level();
    lv.data[0] = -0.5; // l → x1 = (0.5 − (−0.5))·8 = 8 → right half box
    const dets = decodeSegmentations([lv], proto(), {
      numClasses: 2,
      numMasks: 2,
      confThreshold: 0.5,
      inputSize: 16,
    });
    expect(dets[0]!.maskX).toBe(2); // 8 / protoStride(4)
    expect(dets[0]!.maskW).toBe(2);
    // everything below threshold → empty
    expect(
      decodeSegmentations([level()], proto(), {
        numClasses: 2,
        numMasks: 2,
        confThreshold: 0.95,
        inputSize: 16,
      }),
    ).toEqual([]);
  });
});
