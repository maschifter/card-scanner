import { describe, expect, it } from 'vitest';
import { materialized, matrix, nn, type Value, type ValueMeta } from '@tie/core';
// Reuse the @tie/core test helper via a relative import.
import { fakeGpuBuffer } from '../../core/test/helpers.ts';
import { MOONSHINE_TINY } from '../src/moonshine/config.ts';
import { ConvStem, stemFrames } from '../src/moonshine/convStem.ts';
import { MoonshineEncoder } from '../src/moonshine/encoder.ts';
import { MoonshineModel } from '../src/moonshine/model.ts';
import { fakeStateDict } from './moonshineTestData.ts';

const fake = (shape: ValueMeta): Value => materialized(shape, fakeGpuBuffer({ id: 'fake' }));

/** Bind every parameter to a fake Value so forward() can build the graph. */
async function bindFake(model: nn.AnyModule): Promise<void> {
  await model.loadStateDict(fakeStateDict(model), { upload: (_data, shape) => fake(shape) });
}

/** Full-model parameter names under `prefix`, prefix stripped — a standalone
 *  sub-module must register exactly the params the model tree holds there. */
const contractNames = (prefix: string) =>
  [...new MoonshineModel(MOONSHINE_TINY).namedParameters()]
    .map(([n]) => n)
    .filter((n) => n.startsWith(prefix))
    .map((n) => n.slice(prefix.length))
    .sort();

describe('moonshine encoder modules', () => {
  it('ConvStem parameter names equal the model tree (stem.*)', () => {
    const stem = new ConvStem(MOONSHINE_TINY);
    const names = [...stem.namedParameters()].map(([n]) => n).sort();
    expect(names).toEqual(contractNames('stem.'));
  });

  it('MoonshineEncoder parameter names equal the model tree (encoder.*)', () => {
    const enc = new MoonshineEncoder(MOONSHINE_TINY);
    const names = [...enc.namedParameters()].map(([n]) => n).sort();
    expect(names).toEqual(contractNames('encoder.'));
  });

  it('stemFrames matches the fixture geometry (48000 samples → 123 frames)', () => {
    expect(stemFrames(48000)).toEqual({ conv1: 749, conv2: 248, conv3: 123 });
  });

  it('stemFrames rejects clips too short for one encoder frame', () => {
    expect(stemFrames(895).conv3).toBe(1);
    expect(() => stemFrames(894)).toThrow(/895/);
    expect(() => stemFrames(895.5)).toThrow(/895/);
  });

  it('ConvStem forward derives [L,1] → [frames, d]', async () => {
    const stem = new ConvStem(MOONSHINE_TINY);
    await bindFake(stem);
    const y = stem.forward(fake(matrix(48000, 1)));
    expect(y.shape.dims).toEqual([123, MOONSHINE_TINY.dModel]);
  });

  it('MoonshineEncoder forward preserves [T, d]', async () => {
    const enc = new MoonshineEncoder(MOONSHINE_TINY);
    await bindFake(enc);
    const T = 123;
    const hd = MOONSHINE_TINY.headDim;
    const y = enc.forward(
      fake(matrix(T, MOONSHINE_TINY.dModel)),
      fake(matrix(T, hd)),
      fake(matrix(T, hd)),
    );
    expect(y.shape.dims).toEqual([T, MOONSHINE_TINY.dModel]);
  });
});
