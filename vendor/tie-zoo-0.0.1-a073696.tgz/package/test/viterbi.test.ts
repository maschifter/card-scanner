import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { buildLabelInfo, V2_NER_CLASS_NAMES } from '../src/privacy-filter/config.ts';
import { logSoftmaxRows, ViterbiDecoder } from '../src/privacy-filter/viterbi.ts';

const FIXTURES = join(import.meta.dirname, '../../../fixtures');

describe('label space', () => {
  it('matches the reference class-name expansion', () => {
    const reference = JSON.parse(readFileSync(join(FIXTURES, 'labels.json'), 'utf8'));
    expect([...V2_NER_CLASS_NAMES]).toEqual(reference);
  });
  it('builds lookup tables', () => {
    const info = buildLabelInfo(V2_NER_CLASS_NAMES);
    expect(info.backgroundTokenLabel).toBe(0);
    expect(info.tokenToSpanLabel.get(1)).toBe(1); // B-account_number → account_number
    expect(info.tokenBoundaryTags.get(32)).toBe('S'); // S-secret
    expect(info.spanClassNames[8]).toBe('secret');
  });
});

describe('ViterbiDecoder', () => {
  const decoder = new ViterbiDecoder(buildLabelInfo(V2_NER_CLASS_NAMES));

  for (const name of ['email_short', 'mixed_long', 'negatives']) {
    it(`reproduces reference labels for ${name}`, () => {
      const meta = JSON.parse(readFileSync(join(FIXTURES, 'cases', name, 'meta.json'), 'utf8'));
      const t = meta.tensors.logits;
      const raw = readFileSync(join(FIXTURES, 'cases', name, t.file));
      const logits = new Float32Array(raw.buffer, raw.byteOffset, raw.byteLength / 4);
      const logProbs = logSoftmaxRows(logits, t.shape[1]);
      expect(decoder.decode(logProbs, t.shape[1])).toEqual(meta.viterbi_labels);
    });
  }

  it('forbids invalid transitions', () => {
    // Emissions strongly favor I-account_number at t=0, which cannot start a span.
    const n = 33;
    const em = new Float32Array(2 * n).fill(-20);
    em[2] = 0; // t0: I-account_number (invalid start)
    em[0] = -1; // t0: O (valid)
    em[n + 0] = 0; // t1: O
    const labels = decoder.decode(em, n);
    expect(labels[0]).toBe(0);
  });
});
