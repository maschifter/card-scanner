/** Bucket selection and replay-input packing (pure CPU helpers). */

import { describe, expect, it } from 'vitest';
import { fillBucketInputs, MINILM_BUCKETS, pickBucket } from '../src/minilm/embedder.ts';

const scratch = (T: number) => ({
  ids: new Float32Array(T),
  positions: new Float32Array(T),
  segments: new Float32Array(T * 2),
  selector: new Float32Array(T),
});

describe('pickBucket', () => {
  it('returns the smallest bucket that fits', () => {
    expect(pickBucket(1)).toBe(16);
    expect(pickBucket(16)).toBe(16);
    expect(pickBucket(17)).toBe(32);
    expect(pickBucket(256)).toBe(256);
  });
  it('returns undefined past the largest bucket', () => {
    expect(pickBucket(257)).toBeUndefined();
  });
  it('buckets are ascending', () => {
    for (let i = 1; i < MINILM_BUCKETS.length; i++) {
      expect(MINILM_BUCKETS[i]!).toBeGreaterThan(MINILM_BUCKETS[i - 1]!);
    }
  });
});

describe('fillBucketInputs', () => {
  it('pads into an isolated segment with restarted positions', () => {
    const T = 8;
    const out = scratch(T);
    fillBucketInputs(T, [101, 7, 9, 102], out);
    expect([...out.ids]).toEqual([101, 7, 9, 102, 0, 0, 0, 0]);
    expect([...out.positions]).toEqual([0, 1, 2, 3, 0, 1, 2, 3]);
    // Real rows attend [0, 4), pad rows attend [4, 8) — never each other.
    for (let i = 0; i < 4; i++) {
      expect(out.segments[2 * i]).toBe(0);
      expect(out.segments[2 * i + 1]).toBe(4);
    }
    for (let i = 4; i < 8; i++) {
      expect(out.segments[2 * i]).toBe(4);
      expect(out.segments[2 * i + 1]).toBe(8);
    }
    // Mean over the 4 real tokens only.
    expect([...out.selector]).toEqual([0.25, 0.25, 0.25, 0.25, 0, 0, 0, 0]);
  });

  it('exact-fit sentence leaves no pad segment', () => {
    const T = 4;
    const out = scratch(T);
    fillBucketInputs(T, [1, 2, 3, 4], out);
    expect([...out.positions]).toEqual([0, 1, 2, 3]);
    for (let i = 0; i < 4; i++) {
      expect(out.segments[2 * i]).toBe(0);
      expect(out.segments[2 * i + 1]).toBe(4);
    }
    expect([...out.selector]).toEqual([0.25, 0.25, 0.25, 0.25]);
  });

  it('rejects sentences that do not fit', () => {
    const out = scratch(4);
    expect(() => fillBucketInputs(4, [1, 2, 3, 4, 5], out)).toThrow(/do not fit/);
    expect(() => fillBucketInputs(4, [], out)).toThrow(/do not fit/);
  });
});
