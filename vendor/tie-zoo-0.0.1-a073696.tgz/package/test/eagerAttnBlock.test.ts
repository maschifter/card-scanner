import { describe, expect, it } from 'vitest';
import { EagerAttnBlock } from '../src/privacy-filter/attnBlock.ts';

describe('EagerAttnBlock structure', () => {
  it('registers the weight tensors under legacy-compatible names', () => {
    const block = new EagerAttnBlock();
    const names = Array.from(block.namedParameters()).map(([n]) => n);
    expect(names.sort()).toEqual(
      ['norm.scale', 'out.bias', 'out.weight', 'qkv.bias', 'qkv.weight', 'sinks'].sort(),
    );
    // rope tables are no longer stored as Buffers — computed per forward call
    const bufs = Array.from(block.namedBuffers()).map(([n]) => n);
    expect(bufs).toEqual([]);
  });
});
