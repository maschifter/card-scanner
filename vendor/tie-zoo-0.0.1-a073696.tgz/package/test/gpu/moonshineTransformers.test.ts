/** Moonshine through the plugin on the GPU: the tie-backed model's
 *  generate() returns the fixture's greedy ids for the stock feature
 *  extractor's input_values, and the ids decode to the fixture transcript.
 *  Needs fixtures/moonshine/tiny (weights, config, the librispeech_3s case)
 *  and fixtures/moonshine/tokenizer.json; a missing file skips. */

import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  AutoModelForSpeechSeq2Seq,
  MoonshineFeatureExtractor,
  type PretrainedConfig,
  type Tensor,
} from '@huggingface/transformers';
import { initTie } from '@tie/core';
import { getRoot } from '../../../core/test/gpu/harness.ts';
import {
  moonshineLoader,
  registerTieBackend,
  unregisterTieBackend,
} from '../../src/transformers/index.ts';
import { decodeTokens, type MoonshineTokenizer } from '../../src/moonshine/tokenizer.ts';

const MODEL = '/fixtures/moonshine/tiny';
const CASE = `${MODEL}/cases/librispeech_3s`;

describe('moonshine through the transformers.js plugin', () => {
  let ready = false;
  let model: Awaited<ReturnType<typeof AutoModelForSpeechSeq2Seq.from_pretrained>>;
  let tokenizer: MoonshineTokenizer;
  let audio: Float32Array;
  let meta: { greedyIds: number[]; transcript: string; tensors: { audio: { file: string } } };

  beforeAll(async () => {
    const probes = await Promise.all(
      [`${CASE}/meta.json`, `${MODEL}/config.json`, '/fixtures/moonshine/tokenizer.json'].map(
        (url) => fetch(url),
      ),
    );
    if (probes.some((r) => !r.ok)) return;
    const weights = await fetch(`${MODEL}/model.safetensors`, { method: 'HEAD' });
    if (!weights.ok) return;
    const [metaRes, configRes, tokRes] = probes as [Response, Response, Response];
    meta = await metaRes.json();
    const config = (await configRes.json()) as PretrainedConfig;
    tokenizer = await tokRes.json();
    audio = new Float32Array(
      await (await fetch(`${CASE}/${meta.tensors.audio.file}`)).arrayBuffer(),
    );

    initTie(await getRoot());
    registerTieBackend({
      models: { 'tie-test/moonshine': moonshineLoader(`${MODEL}/model.safetensors`) },
    });
    model = await AutoModelForSpeechSeq2Seq.from_pretrained('tie-test/moonshine', { config });
    ready = true;
  }, 300_000);

  afterAll(() => unregisterTieBackend());

  it('generates the fixture ids from the stock feature extractor input', async (ctx) => {
    if (!ready) return ctx.skip();
    const extractor = new MoonshineFeatureExtractor({ sampling_rate: 16_000 });
    const { input_values } = await extractor(audio);
    expect(input_values.dims).toEqual([1, audio.length]);
    const out = (await model.generate({ input_values, max_new_tokens: 18 })) as Tensor;
    expect(out.type).toBe('int64');
    const ids = Array.from(out.data as BigInt64Array, Number);
    expect(out.dims).toEqual([1, ids.length]);
    expect(ids).toEqual(meta.greedyIds);
    expect(decodeTokens(tokenizer, ids)).toBe(meta.transcript);
  }, 120_000);

  it('runs the same clip twice to the same ids', async (ctx) => {
    if (!ready) return ctx.skip();
    const extractor = new MoonshineFeatureExtractor({ sampling_rate: 16_000 });
    const { input_values } = await extractor(audio);
    const run = async () =>
      Array.from(
        ((await model.generate({ input_values })) as Tensor).data as BigInt64Array,
        Number,
      );
    const a = await run();
    const b = await run();
    expect(a).toEqual(b);
  }, 120_000);
});
