import { beforeAll, describe, expect, it } from 'vitest';
import { initTie } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core GPU harness via a relative import.
import { getRoot } from '../../../core/test/gpu/harness.ts';
import { createTranscriber } from '../../src/moonshine/transcriber.ts';
import type { MoonshineTokenizer } from '../../src/moonshine/tokenizer.ts';

/** Long-audio chunking e2e (tiny): the fixture clip twice with a second of
 *  silence between, forced through the chunked path by a small per-chunk
 *  ceiling. The splitter must cut inside the silent gap, so each chunk is the
 *  original utterance (plus a sliver of silence — enough to shift a final
 *  token, e.g. "turnip" → "turnips", so the gate matches each utterance by
 *  prefix rather than byte equality). Skips when the fixtures have not been
 *  generated. */

const TINY = '/fixtures/moonshine/tiny';
const CASE = `${TINY}/cases/librispeech_3s`;
const SAMPLE_RATE = 16_000;

interface CaseMeta {
  greedyIds: number[];
  transcript: string;
  tensors: Record<string, { shape: number[]; file: string }>;
}

let ready = false;
let root: TgpuRoot;
let meta: CaseMeta;
let clip: Float32Array;
let tokenizer: MoonshineTokenizer;

beforeAll(async () => {
  const probe = await fetch(`${CASE}/meta.json`);
  if (!probe.ok) return;
  const tokRes = await fetch(`/fixtures/moonshine/tokenizer.json`);
  if (!tokRes.ok) return;
  meta = await probe.json();
  tokenizer = await tokRes.json();
  const audioRes = await fetch(`${CASE}/${meta.tensors.audio!.file}`);
  clip = new Float32Array(await audioRes.arrayBuffer());
  const weights = await fetch(`${TINY}/model.safetensors`, { method: 'HEAD' });
  if (!weights.ok) return;
  root = await getRoot();
  initTie(root);
  ready = true;
}, 300_000);

describe('moonshine chunked transcription', () => {
  it('splits on the silent gap and transcribes both utterances', async (ctx) => {
    if (!ready) return ctx.skip();
    // clip (3 s) + silence (1 s) + clip (3 s); ceiling 4 s with a 2 s search
    // window puts the only admissible quiet cut inside the silence.
    const audio = new Float32Array(clip.length * 2 + SAMPLE_RATE);
    audio.set(clip, 0);
    audio.set(clip, clip.length + SAMPLE_RATE);

    const transcriber = await createTranscriber(`${TINY}/model.safetensors`, tokenizer, {
      chunking: { maxSeconds: 4, searchSeconds: 2 },
    });
    const result = await transcriber.transcribe(audio);
    console.log(`chunked e2e (${result.timings.steps} steps) → "${result.text}"`);
    // Both utterances present: the transcript up to its final word, twice.
    const head = meta.transcript.slice(0, meta.transcript.lastIndexOf(','));
    expect(head.length).toBeGreaterThan(20);
    expect(result.text.split(head)).toHaveLength(3);
    // Two independent utterances: BOS opens each chunk's id sequence.
    expect(result.ids.filter((id) => id === 1)).toHaveLength(2);
    expect(result.ids[0]).toBe(1);
  }, 120_000);

  it('single-chunk clips keep the exact single-utterance result', async (ctx) => {
    if (!ready) return ctx.skip();
    const transcriber = await createTranscriber(`${TINY}/model.safetensors`, tokenizer);
    const result = await transcriber.transcribe(clip);
    expect(result.ids).toEqual(meta.greedyIds);
    expect(result.text).toBe(meta.transcript);
  }, 120_000);
});
