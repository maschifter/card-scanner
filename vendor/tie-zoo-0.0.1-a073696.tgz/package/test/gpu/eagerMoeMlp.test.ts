import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  initTie,
  materialized,
  memoryStateDict,
  tensor,
  toArray,
  transposeF32,
  uploadF32,
} from '@tie/core';
import { EagerMoeMlp, gateColumnShape } from '../../src/privacy-filter/moeMlp.ts';
import { groupByExpert, parseTopk } from '../../src/privacy-filter/routing.ts';
import { cpuMoe, cpuRms, mulberry32, randArr, splitGluLin } from './cpuRefs.ts';

const E = 8;
const H = 64;
const T = 24;

describe('eager MoE MLP parity', () => {
  it('matches the f64 CPU reference with random weights (E=8, H=64, T=24)', async () => {
    const root = await tgpu.init();
    const ex = initTie(root);
    const rng = mulberry32(1234);

    const normScale = Float32Array.from({ length: H }, () => 0.9 + rng() * 0.2);
    const gateW = randArr(rng, H * E, 1 / Math.sqrt(H));
    const gateB = randArr(rng, E, 0.05);
    const w1 = randArr(rng, E * H * 2 * H, 1 / Math.sqrt(H));
    const b1 = randArr(rng, E * 2 * H, 0.05);
    const w2 = randArr(rng, E * H * H, 1 / Math.sqrt(H));
    const b2 = randArr(rng, E * H, 0.05);
    const xData = randArr(rng, T * H, 1);

    // The eager module takes SPLIT glu/lin expert tensors; cpuMoe below keeps
    // consuming the fused w1/b1 — the split is algebraically identical.
    const w1Split = splitGluLin(w1, E * H, H);
    const b1Split = splitGluLin(b1, E, H);
    const block = new EagerMoeMlp({ experts: E, hidden: H, weightFormat: 'f32' });
    // EagerMoeMlp's transformStateDict transposes gate.weight from checkpoint
    // torch-layout [out,in] to nn.Linear's [in,out] — pre-transpose here so
    // the round trip lands back on gateW exactly.
    await block.loadStateDict(
      memoryStateDict({
        'norm.scale': normScale,
        'gate.weight': { data: transposeF32(gateW, H, E), shape: [E, H] },
        'gate.bias': gateB,
        gluWeight: w1Split.glu,
        linWeight: w1Split.lin,
        gluBias: b1Split.glu,
        linBias: b1Split.lin,
        outWeight: w2,
        outBias: b2,
      }),
    );

    // Phase A: routing math on GPU (topk primitive); only the packed [T,8]
    // ids+weights are read back to shape phase B's DAG.
    const x = tensor(xData, [T, H]);
    const packed = await toArray(block.selection(x), ex);
    const sel = parseTopk(packed, T, 4);
    const grouping = groupByExpert(sel, E);

    // Phase B: expert compute with CPU-known indices.
    const gateColumns = grouping.groups.map((g) =>
      materialized(gateColumnShape(g.tokens.length), uploadF32(root, Float32Array.from(g.weights))),
    );
    const got = await toArray(block.forward(x, grouping, gateColumns), ex);

    // CPU reference: routing decisions REUSED from the GPU-derived selection
    // (routing parity is tested separately in eagerRouting.test.ts; here we
    // verify the expert compute given a selection).
    const xn = cpuRms(xData, normScale, T, H);
    const delta = cpuMoe(xn, sel.idx, sel.w, { w1, b1, w2, b2 }, { hidden: H, tokens: T });
    let maxDiff = 0;
    let sumDiff = 0;
    for (let i = 0; i < T * H; i++) {
      const dAbs = Math.abs(got[i]! - (xData[i]! + delta[i]!));
      maxDiff = Math.max(maxDiff, dAbs);
      sumDiff += dAbs;
    }
    const meanDiff = sumDiff / (T * H);
    console.log('maxDiff', maxDiff, 'meanDiff', meanDiff);
    // f32 GPU vs f64 CPU through two H=64 matmuls + swiglu. Observed on first
    // run: maxDiff ~1.8e-7, meanDiff ~2.9e-8 (near f32 eps); bounds keep ~50x
    // headroom for other GPUs.
    expect(maxDiff).toBeLessThan(1e-5);
    expect(meanDiff).toBeLessThan(1e-6);
    expect(got.every(Number.isFinite)).toBe(true);

    // Routing sanity on real GPU logits: every token got 4 distinct experts.
    for (let t = 0; t < T; t++) expect(new Set(sel.idx[t]).size).toBe(4);
  });
});
