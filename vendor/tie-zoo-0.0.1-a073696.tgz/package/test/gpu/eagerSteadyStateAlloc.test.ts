/** Steady-state allocation audit for the demo's per-frame loop. Counts raw
 *  device.createBuffer calls (count + bytes) per frame of a demo-shaped loop:
 *  upload input → forward → evalValues → batched readback. A camera loop runs
 *  this ~30×/s for minutes, so EVERY steady-state allocation is a leak — GC
 *  collects the JS wrappers eventually, but on iOS WebKit the GPU-side
 *  allocations outrun collection and memory pressure tanks performance after
 *  ~30s (observed on-device 2026-07-23; onnxruntime-web on the same phone
 *  stays flat because it reuses its buffers). */

import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  evalValues,
  gpuExecutor,
  materialized,
  f32ArrayToF16Bits,
  tensor3d,
  uploadF32,
  uploadF16,
  writeF32,
} from '@tie/core';
import { Yolo26Model } from '../../src/yolo26/model.ts';
import { mulberry32 } from './cpuRefs.ts';

describe('yolo26 demo-loop steady-state allocations', () => {
  it(
    'allocates ZERO new GPU buffers per steady-state frame',
    async () => {
      const root = await tgpu.init();
      const device = root.device;
      let allocCount = 0;
      let allocBytes = 0;
      const origCreate = device.createBuffer.bind(device);
      device.createBuffer = ((desc: GPUBufferDescriptor) => {
        allocCount += 1;
        allocBytes += desc.size;
        return origCreate(desc);
      }) as typeof device.createBuffer;

      const exec = gpuExecutor(root);
      const rng = mulberry32(42);
      const model = new Yolo26Model('n', { task: 'segment' });
      for (const [, p] of model.namedParameters()) {
        const data = new Float32Array(p.shape.elems).map(() => (rng() - 0.5) * 0.2);
        p.bind(
          materialized(
            p.shape,
            p.shape.dtype === 'f16'
              ? uploadF16(root, f32ArrayToF16Bits(data).data)
              : uploadF32(root, data),
          ),
        );
      }
      const chw = new Float32Array(3 * 640 * 640).map(() => rng());
      // Persistent input, overwritten per frame — mirrors the fixed demo.
      const inputBuf = uploadF32(root, chw);
      const input = materialized(tensor3d(3, 640, 640), inputBuf);

      // One demo frame: input rewrite, seg forward, batched readback, release.
      const frame = async () => {
        writeF32(root, inputBuf, chw);
        const { levels, proto } = model.forward(input);
        const targets = [...levels, proto];
        evalValues(targets, exec);
        const outs = await exec.readbackMany!(
          targets.map((p) => ({ buffer: p.buffer, shape: p.shape })),
        );
        exec.releaseValues(targets);
        return outs;
      };

      await frame(); // warmup: pipeline compiles + pool fill
      await frame(); // second pass: pool buckets settle

      const perFrame: { count: number; bytes: number }[] = [];
      for (let i = 0; i < 5; i++) {
        allocCount = 0;
        allocBytes = 0;
        const outs = await frame();
        expect(outs.length).toBe(4);
        perFrame.push({ count: allocCount, bytes: allocBytes });
      }

      console.log(
        '\n=== per-frame GPU buffer allocations (seg demo loop, post-warmup) ===\n' +
          perFrame
            .map((f, i) => `frame ${i}: ${f.count} buffers, ${(f.bytes / 1e6).toFixed(2)} MB`)
            .join('\n'),
      );

      // Steady state must be allocation-FREE: pooled outputs, cached uniforms
      // and bind groups, persistent input + readback staging.
      for (const f of perFrame) {
        expect(f.count).toBe(0);
        expect(f.bytes).toBe(0);
      }

      // --- Sustained run: the on-device failure mode was ~2× degradation
      // after ~30 s. Desktop absorbs allocation churn better than iOS WebKit,
      // so the pin here is the MECHANISM: timing flat AND zero allocations
      // across a long loop.
      const FRAMES = 1000;
      allocCount = 0;
      allocBytes = 0;
      const times: number[] = [];
      for (let i = 0; i < FRAMES; i++) {
        const t0 = performance.now();
        await frame();
        times.push(performance.now() - t0);
      }
      const median = (xs: number[]) => {
        const s = [...xs].sort((a, b) => a - b);
        return s[Math.floor(s.length / 2)]!;
      };
      const first = median(times.slice(0, 200));
      const last = median(times.slice(-200));
      console.log(
        `\n=== sustained seg loop (${FRAMES} frames) ===\n` +
          `first-200 median ${first.toFixed(1)}ms  last-200 median ${last.toFixed(1)}ms  ` +
          `ratio ${(last / first).toFixed(2)}  allocations ${allocCount} (${(allocBytes / 1e6).toFixed(2)} MB)`,
      );
      expect(allocCount).toBe(0);
      expect(last / first).toBeLessThan(1.25);
    },
    { timeout: 300_000 },
  );
});
