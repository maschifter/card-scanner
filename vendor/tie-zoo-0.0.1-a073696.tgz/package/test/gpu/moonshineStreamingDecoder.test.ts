import { beforeAll, describe, expect, it } from 'vitest';
import {
  evalValues,
  gpuExecutor,
  initTie,
  matmul,
  slice,
  tensor,
  toArray,
  transpose,
  type Value,
} from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core GPU harness via a relative import.
import { getRoot, maxAbsDiff } from '../../../core/test/gpu/harness.ts';
import { MOONSHINE_STREAMING_TINY } from '../../src/moonshine-streaming/config.ts';
import { MoonshineStreamingModel, decoderView } from '../../src/moonshine-streaming/model.ts';
import { createTranscriber } from '../../src/moonshine-streaming/transcriber.ts';
import { buildRopeTables } from '../../src/moonshine/rope.ts';
import type { MoonshineTokenizer } from '../../src/moonshine/tokenizer.ts';
import type { CrossKV, SelfKV } from '../../src/moonshine/decoder.ts';

/** Decoder parity vs the HF golden fixtures (librispeech_3s) for
 *  moonshine-streaming tiny: teacher-forced layer-0 output and full logits
 *  over the greedy sequence (cross K/V built from the fixture adapter_out,
 *  isolating the decoder from encoder drift), the cached forwardStep chain
 *  against the batch forward, then the whole pipeline — greedy ids and
 *  transcript must match HF EXACTLY. Skips when fixtures are absent. */

const cfg = MOONSHINE_STREAMING_TINY;
const dec = decoderView(cfg);
const BASE_DIR = '/fixtures/moonshine-streaming';
const MODEL = `${BASE_DIR}/tiny`;
const CASE = `${MODEL}/cases/librispeech_3s`;
const ROPE_ROWS = 256; // covers the 18-id fixture with the transcriber's cap

interface CaseMeta {
  paddedSamples: number;
  encoderFrames: number;
  greedyIds: number[];
  transcript: string;
  tensors: Record<string, { shape: number[]; file: string }>;
}

describe('moonshine-streaming decoder parity vs HF fixtures (tiny)', () => {
  let ready = false;
  let root: TgpuRoot;
  let meta: CaseMeta;
  let model: MoonshineStreamingModel;
  let cross: CrossKV[];

  const loadTensor = async (tensorName: string): Promise<Float32Array> => {
    const entry = meta.tensors[tensorName];
    if (!entry) throw new Error(`fixture tensor missing from meta: ${tensorName}`);
    const res = await fetch(`${CASE}/${entry.file}`);
    if (!res.ok) throw new Error(`fixture ${tensorName}: ${res.status}`);
    return new Float32Array(await res.arrayBuffer());
  };

  /** Decoder rope tables sliced to the teacher-forced length. */
  const decTables = (t: number): { cos: Value; sin: Value } => {
    const tables = buildRopeTables(ROPE_ROWS, dec);
    const cos = tensor(root, tables.cos, [ROPE_ROWS, dec.headDim]);
    const sin = tensor(root, tables.sin, [ROPE_ROWS, dec.headDim]);
    return { cos: slice(cos, 0, 0, t), sin: slice(sin, 0, 0, t) };
  };

  beforeAll(async () => {
    const probe = await fetch(`${CASE}/meta.json`);
    const weights = await fetch(`${MODEL}/model.safetensors`, { method: 'HEAD' });
    if (!probe.ok || !weights.ok) return; // fixtures not generated → every test skips
    meta = await probe.json();
    root = await getRoot();

    model = new MoonshineStreamingModel(cfg);
    await model.loadStateDict(`${MODEL}/model.safetensors`, { root });

    // Cross K/V from the FIXTURE adapter output — decoder-only parity.
    const adapterOut = tensor(root, await loadTensor('adapter_out'), [
      meta.encoderFrames,
      cfg.dec.hidden,
    ]);
    cross = model.decoder.precomputeCrossKV(adapterOut);
    evalValues([adapterOut, ...cross.flatMap((c) => [c.k, c.v])], gpuExecutor(root));
    ready = true;
  }, 300_000);

  it('teacher-forced layer 0 matches dec_layer0_tf', async (ctx) => {
    if (!ready) return ctx.skip();
    const ref = await loadTensor('dec_layer0_tf'); // [N, d]
    const t = meta.greedyIds.length;
    const { cos, sin } = decTables(t);
    const out = await toArray(
      model.decoder.layers.items[0]!.forward(model.embed(meta.greedyIds), cos, sin, cross[0]!),
      gpuExecutor(root),
    );
    console.log(`dec_layer0_tf maxAbsDiff ${maxAbsDiff(out, ref).toExponential(2)}`);
    expect(out.length).toBe(ref.length);
    expect(maxAbsDiff(out, ref)).toBeLessThan(2e-4);
  });

  it('teacher-forced logits match logits_tf and re-derive the greedy ids', async (ctx) => {
    if (!ready) return ctx.skip();
    const ref = await loadTensor('logits_tf'); // [N, V]
    const t = meta.greedyIds.length;
    const { cos, sin } = decTables(t);
    const h = model.decoder.forward(model.embed(meta.greedyIds), cos, sin, cross);
    // Full teacher-forced logits, [V, N] to keep the embedding un-transposed.
    const logits = await toArray(
      matmul(model.embedding.weight.value, transpose(h)),
      gpuExecutor(root),
    );
    let diff = 0;
    for (let row = 0; row < t; row++) {
      for (let v = 0; v < cfg.vocab; v++) {
        diff = Math.max(diff, Math.abs(logits[v * t + row]! - ref[row * cfg.vocab + v]!));
      }
    }
    console.log(`logits_tf maxAbsDiff ${diff.toExponential(2)}`);
    expect(diff).toBeLessThan(1e-3);
    // Argmax of row t must reproduce greedy id t+1 — exactness the transcript gate needs.
    for (let row = 0; row < t - 1; row++) {
      let best = 0;
      for (let v = 1; v < cfg.vocab; v++) {
        if (logits[v * t + row]! > logits[best * t + row]!) best = v;
      }
      expect(best).toBe(meta.greedyIds[row + 1]);
    }
  });

  it('cached forwardStep chain matches full-recompute hidden states row by row', async (ctx) => {
    if (!ready) return ctx.skip();
    const ex = gpuExecutor(root);
    const t = meta.greedyIds.length;
    const { cos, sin } = decTables(t);
    const hFull = await toArray(
      model.decoder.forward(model.embed(meta.greedyIds), cos, sin, cross),
      ex,
    );
    const tables = buildRopeTables(ROPE_ROWS, dec);
    const fullCos = tensor(root, tables.cos, [ROPE_ROWS, dec.headDim]);
    const fullSin = tensor(root, tables.sin, [ROPE_ROWS, dec.headDim]);
    // Preallocated caches, written in place by forwardStep (the production
    // decode-loop shape).
    const qw = dec.heads * dec.headDim;
    const kvInit = new Float32Array(ROPE_ROWS * qw);
    const caches: SelfKV[] = Array.from({ length: dec.decLayers }, () => ({
      k: tensor(root, kvInit, [ROPE_ROWS, qw]),
      v: tensor(root, kvInit, [ROPE_ROWS, qw]),
    }));
    let diff = 0;
    for (let step = 0; step < t; step++) {
      const h = model.decoder.forwardStep(
        model.embed([meta.greedyIds[step]!]),
        slice(fullCos, 0, step, step + 1),
        slice(fullSin, 0, step, step + 1),
        cross,
        caches,
        step,
      );
      evalValues([h], ex);
      const hData = await ex.readback(h.buffer, h.shape);
      for (let c = 0; c < dec.dModel; c++) {
        diff = Math.max(diff, Math.abs(hData[c]! - hFull[step * dec.dModel + c]!));
      }
    }
    console.log(`cached vs full hidden maxAbsDiff ${diff.toExponential(2)}`);
    // forwardStep's m = 1 matmuls run the split-K GEMV route while the full
    // pass runs the batch kernel — different f32 summation orders, so the
    // chains agree to a few ulps at hidden-state magnitude, not bitwise.
    // The exact-ids/transcript test below holds the hard line.
    expect(diff).toBeLessThan(5e-5);
  });

  it('end-to-end transcribe matches the HF greedy ids and transcript exactly', async (ctx) => {
    if (!ready) return ctx.skip();
    const audioRes = await fetch(`${CASE}/${meta.tensors.audio!.file}`);
    const audio = new Float32Array(await audioRes.arrayBuffer());
    const tokRes = await fetch(`${BASE_DIR}/tokenizer.json`);
    if (!tokRes.ok) return ctx.skip();
    const tokenizer: MoonshineTokenizer = await tokRes.json();

    initTie(root);
    const transcriber = await createTranscriber(`${MODEL}/model.safetensors`, tokenizer, { cfg });
    const result = await transcriber.transcribe(audio);
    console.log(
      `e2e: encode ${result.timings.encodeMs.toFixed(1)}ms, ` +
        `decode ${result.timings.decodeMs.toFixed(1)}ms / ${result.timings.steps} steps ` +
        `(${(result.timings.decodeMs / result.timings.steps).toFixed(1)}ms/step) → "${result.text}"`,
    );
    expect(result.ids).toEqual(meta.greedyIds);
    expect(result.text).toBe(meta.transcript);
  }, 120_000);

  it('f16 weights reproduce the exact ids and transcript (the demo default)', async (ctx) => {
    if (!ready) return ctx.skip();
    const audioRes = await fetch(`${CASE}/${meta.tensors.audio!.file}`);
    const audio = new Float32Array(await audioRes.arrayBuffer());
    const tokRes = await fetch(`${BASE_DIR}/tokenizer.json`);
    if (!tokRes.ok) return ctx.skip();
    const tokenizer: MoonshineTokenizer = await tokRes.json();

    // Prefer the exported f16 file (the demo's artifact) when present; the
    // f32 file exercises the same pack path at load.
    const f16Probe = await fetch(`${MODEL}/model-f16.safetensors`, { method: 'HEAD' });
    const weightsFile = f16Probe.ok ? 'model-f16.safetensors' : 'model.safetensors';
    console.log(`f16 e2e source: ${weightsFile}`);
    initTie(root);
    const transcriber = await createTranscriber(`${MODEL}/${weightsFile}`, tokenizer, {
      cfg,
      weightDtype: 'f16',
    });
    const result = await transcriber.transcribe(audio);
    console.log(
      `f16 e2e: decode ${result.timings.decodeMs.toFixed(1)}ms / ${result.timings.steps} steps ` +
        `→ "${result.text}"`,
    );
    expect(result.ids).toEqual(meta.greedyIds);
    expect(result.text).toBe(meta.transcript);
  }, 120_000);
});
