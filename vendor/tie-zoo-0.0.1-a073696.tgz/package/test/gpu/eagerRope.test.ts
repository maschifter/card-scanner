import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { matrix, materialized, gpuExecutor, toArray, uploadF32 } from '@tie/core';
import { applyRope, ropeConstants, QK_SCALE } from '../../src/privacy-filter/rope.ts';

/** f64 reference: the legacy interleaved rotation on the raw [T×32] tables. */
function cpuRope(x: Float32Array, cos: Float32Array, sin: Float32Array, T: number): Float32Array {
  const out = new Float32Array(T * 64);
  for (let t = 0; t < T; t++) {
    for (let p = 0; p < 32; p++) {
      const c = cos[t * 32 + p]!;
      const s = sin[t * 32 + p]!;
      const x1 = x[t * 64 + 2 * p]!;
      const x2 = x[t * 64 + 2 * p + 1]!;
      out[t * 64 + 2 * p] = (x1 * c - x2 * s) * QK_SCALE;
      out[t * 64 + 2 * p + 1] = (x2 * c + x1 * s) * QK_SCALE;
    }
  }
  return out;
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

describe('eager rope primitive', () => {
  it('matches the legacy interleaved rotation (f64 ref) on a [40,64] head', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const T = 40;
    const rng = mulberry32(7);
    const xData = Float32Array.from({ length: T * 64 }, () => (rng() - 0.5) * 2);

    const { cosE, sinE, rawCos, rawSin } = ropeConstants(T);
    const x = materialized(matrix(T, 64), uploadF32(root, xData));
    const cos = materialized(matrix(T, 64), uploadF32(root, cosE));
    const sin = materialized(matrix(T, 64), uploadF32(root, sinE));

    const out = await toArray(applyRope(x, cos, sin), ex);
    const ref = cpuRope(xData, rawCos, rawSin, T);
    let maxDiff = 0;
    for (let i = 0; i < T * 64; i++) maxDiff = Math.max(maxDiff, Math.abs(out[i]! - ref[i]!));
    expect(maxDiff).toBeLessThan(1e-4);
  });

  it('ropes a multi-head [T, 3·64] slab section-by-section (one dispatch)', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const T = 17;
    const HEADS = 3;
    const rng = mulberry32(23);
    const xData = Float32Array.from({ length: T * HEADS * 64 }, () => (rng() - 0.5) * 2);

    const { cosE, sinE, rawCos, rawSin } = ropeConstants(T);
    const x = materialized(matrix(T, HEADS * 64), uploadF32(root, xData));
    const cos = materialized(matrix(T, 64), uploadF32(root, cosE));
    const sin = materialized(matrix(T, 64), uploadF32(root, sinE));
    const out = await toArray(applyRope(x, cos, sin), ex);

    // Reference: rope each 64-wide section independently.
    let maxDiff = 0;
    for (let h = 0; h < HEADS; h++) {
      const sect = new Float32Array(T * 64);
      for (let t = 0; t < T; t++)
        sect.set(xData.subarray(t * HEADS * 64 + h * 64, t * HEADS * 64 + h * 64 + 64), t * 64);
      const ref = cpuRope(sect, rawCos, rawSin, T);
      for (let t = 0; t < T; t++) {
        for (let d = 0; d < 64; d++) {
          maxDiff = Math.max(
            maxDiff,
            Math.abs(out[t * HEADS * 64 + h * 64 + d]! - ref[t * 64 + d]!),
          );
        }
      }
    }
    expect(maxDiff).toBeLessThan(1e-4);
  });
});
