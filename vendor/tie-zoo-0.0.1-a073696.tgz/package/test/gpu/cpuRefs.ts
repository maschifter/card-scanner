/** Shared f64 CPU reference helpers for the eager GPU parity tests, extracted
 *  verbatim from eagerAttnBlock.test.ts and eagerMoeMlp.test.ts. Attention
 *  dims are the real privacy-filter ones (fixed, like the block); the MoE
 *  reference is dimension-parameterized like EagerMoeMlp. */

import { QK_SCALE } from '../../src/privacy-filter/rope.ts';

// Real attention dims (baked into EagerAttnBlock — not parameterized).
const QKV = 1152;
const ATTN_OUT = 896;
const Q_HEADS = 14;
const HEAD = 64;
const WINDOW = 128;

// Clamped-SwiGLU constants (kernels/moeCommon.ts).
const ALPHA = 1.702;
const LIMIT = 7.0;

export function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const randArr = (rng: () => number, n: number, scale: number) =>
  Float32Array.from({ length: n }, () => (rng() - 0.5) * 2 * scale);

/** Split a fused [rows, 2H] matrix into its glu (cols 0..H) / lin (cols
 *  H..2H) halves. The eager module wants split expert tensors (gluWeight /
 *  linWeight, gluBias / linBias) while cpuMoe keeps consuming the fused
 *  layout — the split is algebraically identical. */
export function splitGluLin(
  fused: Float32Array,
  rows: number,
  h: number,
): { glu: Float32Array; lin: Float32Array } {
  const glu = new Float32Array(rows * h);
  const lin = new Float32Array(rows * h);
  for (let r = 0; r < rows; r++) {
    glu.set(fused.subarray(r * 2 * h, r * 2 * h + h), r * h);
    lin.set(fused.subarray(r * 2 * h + h, (r + 1) * 2 * h), r * h);
  }
  return { glu, lin };
}

/** RMSNorm; eps defaults to the legacy kernel's 1e-5. x may be an f64
 *  intermediate (full-model reference chains blocks in f64). */
export function cpuRms(
  x: Float32Array | Float64Array,
  scale: Float32Array,
  T: number,
  N: number,
  eps = 1e-5,
): Float64Array {
  const o = new Float64Array(T * N);
  for (let t = 0; t < T; t++) {
    let ms = 0;
    for (let j = 0; j < N; j++) ms += x[t * N + j]! ** 2;
    const inv = 1 / Math.sqrt(ms / N + eps);
    for (let j = 0; j < N; j++) o[t * N + j] = x[t * N + j]! * inv * scale[j]!;
  }
  return o;
}

export function cpuLinear(
  x: Float64Array,
  w: Float32Array,
  b: Float32Array | undefined,
  T: number,
  K: number,
  N: number,
): Float64Array {
  const o = new Float64Array(T * N);
  for (let t = 0; t < T; t++) {
    for (let n = 0; n < N; n++) {
      let acc = b ? b[n]! : 0;
      for (let k = 0; k < K; k++) acc += x[t * K + k]! * w[k * N + n]!;
      o[t * N + n] = acc;
    }
  }
  return o;
}

/** In-place interleaved rotation (+ QK_SCALE) of one 64-wide section at `off`. */
export function cpuRopeSection(
  qkv: Float64Array,
  off: number,
  cos: Float32Array,
  sin: Float32Array,
  T: number,
): void {
  for (let t = 0; t < T; t++) {
    for (let p = 0; p < 32; p++) {
      const c = cos[t * 32 + p]!;
      const s = sin[t * 32 + p]!;
      const i1 = t * QKV + off + 2 * p;
      const x1 = qkv[i1]!;
      const x2 = qkv[i1 + 1]!;
      qkv[i1] = (x1 * c - x2 * s) * QK_SCALE;
      qkv[i1 + 1] = (x2 * c + x1 * s) * QK_SCALE;
    }
  }
}

/** Banded bidirectional GQA with sinks — sink joins the denominator only. */
export function cpuAttention(qkv: Float64Array, sinks: Float32Array, T: number): Float64Array {
  const out = new Float64Array(T * ATTN_OUT);
  for (let t = 0; t < T; t++) {
    for (let h = 0; h < Q_HEADS; h++) {
      const kvh = Math.floor(h / 7);
      const lo = Math.max(0, t - WINDOW);
      const hi = Math.min(T - 1, t + WINDOW);
      const sink = sinks[h]! * Math.LN2;
      const scores: number[] = [];
      for (let j = lo; j <= hi; j++) {
        let s = 0;
        for (let dd = 0; dd < HEAD; dd++) {
          s += qkv[t * QKV + h * HEAD + dd]! * qkv[j * QKV + 896 + kvh * HEAD + dd]!;
        }
        scores.push(s);
      }
      const m = Math.max(sink, ...scores);
      let denom = Math.exp(sink - m);
      const p = scores.map((s) => {
        const e = Math.exp(s - m);
        denom += e;
        return e;
      });
      for (let dd = 0; dd < HEAD; dd++) {
        let acc = 0;
        for (let jj = 0; jj < p.length; jj++) {
          acc += (p[jj]! / denom) * qkv[(lo + jj) * QKV + 1024 + kvh * HEAD + dd]!;
        }
        out[t * ATTN_OUT + h * HEAD + dd] = acc;
      }
    }
  }
  return out;
}

export interface CpuMoeWeights {
  w1: Float32Array; // [E·H, 2H]
  b1: Float32Array; // [E, 2H]
  w2: Float32Array; // [E·H, H]
  b2: Float32Array; // [E, H]
}

/** MoE expert compute (no residual) for a routing decided elsewhere:
 *  idx/w are the [T][4] selection, xn the already-normed [T, H] input. */
export function cpuMoe(
  xn: Float64Array,
  idx: number[][],
  w: number[][],
  weights: CpuMoeWeights,
  dims: { hidden: number; tokens: number },
): Float64Array {
  const { w1, b1, w2, b2 } = weights;
  const { hidden: H, tokens: T } = dims;
  const out = new Float64Array(T * H);
  for (let t = 0; t < T; t++) {
    const acc = new Float64Array(H);
    for (let s = 0; s < 4; s++) {
      const e = idx[t]![s]!;
      const gw = w[t]![s]!;
      const u = new Float64Array(2 * H);
      for (let c = 0; c < 2 * H; c++) u[c] = b1[e * 2 * H + c]!;
      for (let k = 0; k < H; k++) {
        const xv = xn[t * H + k]!;
        const row = e * H * 2 * H + k * 2 * H;
        for (let c = 0; c < 2 * H; c++) u[c] = u[c]! + xv * w1[row + c]!;
      }
      const h = new Float64Array(H);
      for (let i = 0; i < H; i++) {
        const glu = Math.min(u[i]!, LIMIT);
        const lin = Math.min(Math.max(u[i + H]!, -LIMIT), LIMIT);
        h[i] = glu * (1 / (1 + Math.exp(-ALPHA * glu))) * (lin + 1);
      }
      const o = new Float64Array(H);
      for (let c = 0; c < H; c++) o[c] = b2[e * H + c]!;
      for (let i = 0; i < H; i++) {
        const hv = h[i]!;
        const row = e * H * H + i * H;
        for (let c = 0; c < H; c++) o[c] = o[c]! + hv * w2[row + c]!;
      }
      for (let c = 0; c < H; c++) acc[c] = acc[c]! + gw * o[c]!;
    }
    for (let c = 0; c < H; c++) out[t * H + c] = acc[c]!;
  }
  return out;
}
