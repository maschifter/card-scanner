/** Replay-path latency micro-bench (random weights): what one bucketed
 *  single-sentence embed costs wall-clock, tight-loop vs paced — the paced
 *  variant exposes scheduler-wake/clock-ramp cost that tight loops hide.
 *  Reported, not asserted; compare medians within one session only. */

import { beforeAll, describe, expect, it } from 'vitest';
import { initTie, materialized, uploadF32 } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
import { getRoot } from '../../../core/test/gpu/harness.ts';
import { createMinilmEmbedCore } from '../../src/minilm/embedder.ts';
import { MinilmModel } from '../../src/minilm/model.ts';

function randomStateDict(model: MinilmModel): Record<string, Float32Array> {
  const sd: Record<string, Float32Array> = {};
  let seed = 1;
  const next = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return (seed / 0x7fffffff - 0.5) * 0.04;
  };
  for (const [name, p] of model.namedParameters()) {
    sd[name] = Float32Array.from({ length: p.shape.elems }, next);
  }
  return sd;
}

/** Binds every Parameter straight from `sd` by name, bypassing
 *  transformStateDict — this model has no checkpoint to remap, just random
 *  f32 weights keyed by the model's own dotted parameter paths. */
function loadDirect(model: MinilmModel, sd: Record<string, Float32Array>, root: TgpuRoot): void {
  for (const [name, p] of model.namedParameters()) {
    p.bind(materialized(p.shape, uploadF32(root, sd[name]!)));
  }
}

const median = (xs: number[]): number => {
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)]!;
};

describe('minilm replay latency (random weights)', () => {
  let root: TgpuRoot;
  let core: ReturnType<typeof createMinilmEmbedCore>;

  beforeAll(async () => {
    root = await getRoot();
    initTie(root);
    const model = new MinilmModel();
    loadDirect(model, randomStateDict(model), root);
    core = createMinilmEmbedCore(model);
  }, 300_000);

  it('reports tight vs paced single-sentence latency', async () => {
    const ids = Array.from({ length: 14 }, (_, i) => (i * 37) % 30522);
    const REPS = 40;
    await core.embedPooled(ids); // bucket capture outside timing
    for (const pacedMs of [0, 10]) {
      const times: number[] = [];
      for (let i = 0; i < REPS; i++) {
        if (pacedMs > 0) await new Promise((r) => setTimeout(r, pacedMs));
        const t0 = performance.now();
        const out = await core.embedPooled(ids);
        times.push(performance.now() - t0);
        expect(out.every(Number.isFinite)).toBe(true);
      }
      console.log(
        `paced=${pacedMs}ms: median ${median(times).toFixed(2)}ms  min ${Math.min(...times).toFixed(2)}ms  max ${Math.max(...times).toFixed(2)}ms`,
      );
    }
  }, 120_000);
});
