import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  evalValues,
  gpuExecutor,
  materialized,
  matrix,
  nn,
  tensor,
  toArray,
  transposeF32,
  uploadF32,
  type Value,
} from '@tie/core';
import { EagerModel } from '../../src/privacy-filter/model.ts';
import { ropeConstants } from '../../src/privacy-filter/rope.ts';
import { groupByExpert, parseTopk, type Selection } from '../../src/privacy-filter/routing.ts';
import { gateColumnShape } from '../../src/privacy-filter/moeMlp.ts';
import {
  cpuAttention,
  cpuLinear,
  cpuMoe,
  cpuRms,
  cpuRopeSection,
  mulberry32,
  randArr,
  splitGluLin,
} from './cpuRefs.ts';

const HIDDEN = 640;
const QKV = 1152;
const ATTN_OUT = 896;
const Q_HEADS = 14;
const HEAD = 64;
const BLOCKS = 2;
const E = 8;
const T = 64;
const LOGITS = 33;
const VOCAB = 50;

describe('eager full model GPU parity', () => {
  it('matches an f64 CPU reference through 2 blocks + head (real attn dims, E=8, T=64)', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const rng = mulberry32(2026);

    // Seeded weights, per block (same scales as the two block parity tests).
    const blockWeights = Array.from({ length: BLOCKS }, () => ({
      attn: {
        normScale: Float32Array.from({ length: HIDDEN }, () => 0.9 + rng() * 0.2),
        wQkv: randArr(rng, HIDDEN * QKV, 1 / Math.sqrt(HIDDEN)),
        bQkv: randArr(rng, QKV, 0.05),
        wOut: randArr(rng, ATTN_OUT * HIDDEN, 1 / Math.sqrt(ATTN_OUT)),
        bOut: randArr(rng, HIDDEN, 0.05),
        sinks: randArr(rng, Q_HEADS, 1),
      },
      moe: {
        normScale: Float32Array.from({ length: HIDDEN }, () => 0.9 + rng() * 0.2),
        gateW: randArr(rng, HIDDEN * E, 1 / Math.sqrt(HIDDEN)),
        gateB: randArr(rng, E, 0.05),
        w1: randArr(rng, E * HIDDEN * 2 * HIDDEN, 1 / Math.sqrt(HIDDEN)),
        b1: randArr(rng, E * 2 * HIDDEN, 0.05),
        w2: randArr(rng, E * HIDDEN * HIDDEN, 1 / Math.sqrt(HIDDEN)),
        b2: randArr(rng, E * HIDDEN, 0.05),
      },
    }));
    const finalNormScale = Float32Array.from({ length: HIDDEN }, () => 0.9 + rng() * 0.2);
    const unembW = randArr(rng, HIDDEN * LOGITS, 1 / Math.sqrt(HIDDEN)); // NO bias
    // Embedding table as bf16 bits (truncated f32) — the checkpoint format
    // nn.Embedding loads. The CPU reference starts from the gathered x0, so
    // truncation cancels out of the parity comparison.
    const tableBits = Uint16Array.from(randArr(rng, VOCAB * HIDDEN, 1), (v) => {
      const scratch = new DataView(new ArrayBuffer(4));
      scratch.setFloat32(0, v, true);
      return scratch.getUint32(0, true) >>> 16;
    });
    const tokenIds = Array.from({ length: T }, () => Math.floor(rng() * VOCAB));

    // EagerAttnBlock/EagerMoeMlp/EagerModel's transformStateDict hooks
    // transpose qkv/out/gate/unembedding weights from checkpoint torch-layout
    // [out,in] to nn.Linear's [in,out] — pre-transpose here so the round trip
    // lands back on the raw wQkv/wOut/gateW/unembW arrays the CPU reference
    // below computes on directly.
    const stateDict: Record<
      string,
      Float32Array | { data: Float32Array | Uint16Array; shape: number[] }
    > = {
      'norm.scale': finalNormScale,
      'unembedding.weight': { data: transposeF32(unembW, HIDDEN, LOGITS), shape: [LOGITS, HIDDEN] },
      'embedding.weight': { data: tableBits, shape: [VOCAB, HIDDEN] },
    };
    blockWeights.forEach(({ attn, moe }, i) => {
      stateDict[`block.${i}.attn.norm.scale`] = attn.normScale;
      stateDict[`block.${i}.attn.qkv.weight`] = attn.wQkv;
      stateDict[`block.${i}.attn.qkv.bias`] = attn.bQkv;
      stateDict[`block.${i}.attn.out.weight`] = attn.wOut;
      stateDict[`block.${i}.attn.out.bias`] = attn.bOut;
      stateDict[`block.${i}.attn.sinks`] = attn.sinks;
      stateDict[`block.${i}.mlp.norm.scale`] = moe.normScale;
      stateDict[`block.${i}.mlp.gate.weight`] = moe.gateW;
      stateDict[`block.${i}.mlp.gate.bias`] = moe.gateB;
      // MoE expert tensors are flat camelCase, split glu/lin for the eager
      // module; the CPU reference keeps the fused w1/b1 (identical math).
      const w1Split = splitGluLin(moe.w1, E * HIDDEN, HIDDEN);
      const b1Split = splitGluLin(moe.b1, E, HIDDEN);
      stateDict[`block.${i}.mlp.gluWeight`] = w1Split.glu;
      stateDict[`block.${i}.mlp.linWeight`] = w1Split.lin;
      stateDict[`block.${i}.mlp.gluBias`] = b1Split.glu;
      stateDict[`block.${i}.mlp.linBias`] = b1Split.lin;
      stateDict[`block.${i}.mlp.outWeight`] = moe.w2;
      stateDict[`block.${i}.mlp.outBias`] = moe.b2;
    });

    // GPU path: build → load → run, capturing each block's routing decision.
    const model = new EagerModel({
      blocks: BLOCKS,
      experts: E,
      vocab: VOCAB,
      logits: LOGITS,
      weightFormat: 'f32',
    });
    expect(Array.from(model.namedParameters())).toHaveLength(Object.keys(stateDict).length);
    await model.loadStateDict(stateDict);
    const x0 = model.embedding.gather(tokenIds);
    const { cosE, sinE, rawCos, rawSin } = ropeConstants(T);
    const HEAD = 64;
    const cos = tensor(root, cosE, [T, HEAD]);
    const sin = tensor(root, sinE, [T, HEAD]);

    // Two-phase f32 forward: per-block attn → selection readback → expert compute.
    // Readback is needed so the CPU reference uses the same routing as the GPU
    // (f32 near-ties can go either way; routing parity is covered by topk tests).
    const selections: Selection[] = [];
    const blockOutPromises: Promise<Float32Array>[] = [];
    let xGpu: Value = materialized(matrix(T, HIDDEN), uploadF32(root, x0));
    for (const [i, b] of model.block.items.entries()) {
      xGpu = b.attn.forward(xGpu, cos, sin);
      const selVal = b.mlp.selection(xGpu);
      evalValues([selVal, xGpu], ex);
      const packed = await toArray(selVal, ex);
      const sel = parseTopk(packed, T, 4);
      selections[i] = sel;
      const grouping = groupByExpert(sel, E);
      const gateColumns = grouping.groups.map((g) =>
        materialized(
          gateColumnShape(g.tokens.length),
          uploadF32(root, Float32Array.from(g.weights)),
        ),
      );
      xGpu = b.mlp.forward(xGpu, grouping, gateColumns);
      // toArray IMMEDIATELY — the Value becomes a target of its own eval (never
      // pool-released), so the next block's selection eval re-walks it materialized.
      blockOutPromises[i] = toArray(xGpu, ex);
    }
    const got = await toArray(model.unembedding.forward(model.norm.forward(xGpu)), ex);
    const blockOuts = await Promise.all(blockOutPromises);

    // CPU reference: sequential f64 over the same f32 arrays, reusing the
    // GPU-decided routing per block (routing parity is covered by the topk
    // kernel tests; f32 near-ties could route differently otherwise).
    const x = Float64Array.from(x0);
    const cpuBlockX: Float64Array[] = [];
    for (let i = 0; i < BLOCKS; i++) {
      const { attn, moe } = blockWeights[i]!;
      const normed = cpuRms(x, attn.normScale, T, HIDDEN);
      const qkv = cpuLinear(normed, attn.wQkv, attn.bQkv, T, HIDDEN, QKV);
      for (let h = 0; h < Q_HEADS; h++) cpuRopeSection(qkv, h * HEAD, rawCos, rawSin, T);
      for (let kh = 0; kh < 2; kh++) cpuRopeSection(qkv, 896 + kh * HEAD, rawCos, rawSin, T);
      const attnOut = cpuAttention(qkv, attn.sinks, T);
      const proj = cpuLinear(attnOut, attn.wOut, attn.bOut, T, ATTN_OUT, HIDDEN);
      for (let j = 0; j < T * HIDDEN; j++) x[j] = x[j]! + proj[j]!; // attn residual

      const sel = selections[i]!;
      const xn = cpuRms(x, moe.normScale, T, HIDDEN);
      const delta = cpuMoe(xn, sel.idx, sel.w, moe, { hidden: HIDDEN, tokens: T });
      for (let j = 0; j < T * HIDDEN; j++) x[j] = x[j]! + delta[j]!; // mlp residual
      cpuBlockX.push(x.slice());
    }
    const finalNormed = cpuRms(x, finalNormScale, T, HIDDEN);
    const ref = cpuLinear(finalNormed, unembW, undefined, T, HIDDEN, LOGITS);

    let maxDiff = 0;
    let sumDiff = 0;
    for (let i = 0; i < T * LOGITS; i++) {
      expect(Number.isFinite(got[i]!)).toBe(true);
      const d = Math.abs(got[i]! - ref[i]!);
      maxDiff = Math.max(maxDiff, d);
      sumDiff += d;
    }
    const meanDiff = sumDiff / (T * LOGITS);
    console.log('maxDiff', maxDiff, 'meanDiff', meanDiff);
    // f32 GPU vs f64 CPU through two full blocks + head. Observed on first
    // run: maxDiff ~2.2e-6, meanDiff ~2.4e-7; bounds keep ~45x headroom for
    // other GPUs.
    expect(maxDiff).toBeLessThan(1e-4);
    expect(meanDiff).toBeLessThan(1e-5);

    // Per-block residual snapshots (onBlockOutput, toArray-ed immediately mid
    // orchestration) match the CPU residual stream — pins the capture path the
    // real-weights parity test drives.
    expect(blockOuts).toHaveLength(BLOCKS);
    blockOuts.forEach((bo, i) => {
      const refX = cpuBlockX[i]!;
      let bMax = 0;
      for (let j = 0; j < T * HIDDEN; j++) bMax = Math.max(bMax, Math.abs(bo[j]! - refX[j]!));
      console.log(`block ${i} residual maxDiff`, bMax);
      expect(bMax).toBeLessThan(1e-4);
    });

    // Routing sanity: every token got 4 distinct experts in every block.
    expect(selections).toHaveLength(BLOCKS);
    for (const sel of selections) {
      for (let t = 0; t < T; t++) expect(new Set(sel.idx[t]).size).toBe(4);
    }
  });
});
