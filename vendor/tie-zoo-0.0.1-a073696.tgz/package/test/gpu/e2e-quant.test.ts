import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { fromSafetensors, gpuExecutor, initTie, tensor, toArray } from '@tie/core';
import type { Detector } from '../../src/privacy-filter/pipeline.ts';
import { createEagerDetector } from '../../src/privacy-filter/detector.ts';
import { EagerModel } from '../../src/privacy-filter/model.ts';
import { HEAD } from '../../src/privacy-filter/attnBlock.ts';
import { ropeConstants } from '../../src/privacy-filter/rope.ts';
import {
  getRoot,
  loadCaseMeta,
  loadCaseTensor,
  maxAbsDiff,
} from '../../../core/test/gpu/harness.ts';

const CASES = [
  'email_short',
  'address',
  'account',
  'secret_url',
  'person_date',
  'negatives',
  'unicode',
  'mixed_long',
];

/** Same mechanism as e2e.test.ts: pin investigated label flips exactly.
 *  Entries are added only after running the milestone-1 investigation
 *  protocol; each comment records the measured numbers.
 *
 * int8/g640, mixed_long (measured 2026-06-11): span "alice@corp.example"
 * decodes as private_person instead of the reference private_email — the
 * SAME flip as the f16 baseline (e2e.test.ts), landing on the same side of
 * the same near-tie. Investigation:
 *
 * 1. Router near-tie at block1/token26 re-verified on CPU from the REFERENCE
 *    attn1 fixture: top-4 {79,69,17,93}, 4th-vs-5th margin 0.0017 logits
 *    (e93=1.0951 vs e51=1.0934) — identical to the f16 investigation.
 * 2. int8 block0 maxAbsDiff on mixed_long is 2.29 (f16 baseline ~1.1),
 *    ~1300x the 0.0017 router margin, so the 4th expert pick is genuinely
 *    undetermined at this precision. block1 drift is 47.46 — matching the
 *    ~46 activation signature the f16 investigation measured for taking
 *    the e51 routing instead of the bf16 reference's e93.
 * 3. Per-token argmax still agrees 81/81 with the reference log_probs
 *    (max |dlogprob| 3.04). The email-vs-person Viterbi path margin over
 *    tokens 6-9 lands at 0.0347 nats in favor of person (sums: person
 *    -5.0118 vs email -5.0465; reference margin was 0.0625 nats the email
 *    way, f16 landed 0.0708 the person way) — ~0.009 nats/token, far below
 *    the quantization noise floor. Genuine knife edge; pinned exactly.
 */
const KNOWN_DEVIATIONS: Record<
  string,
  Record<string, (spans: { label: string; text: string }[]) => void>
> = {
  'pf-int8g640.safetensors': {
    mixed_long: (spans) => {
      const s = spans[1]!;
      if (s.label !== 'private_email' || s.text !== 'alice@corp.example') {
        throw new Error('mixed_long fixture changed; re-evaluate the known deviation');
      }
      s.label = 'private_person';
    },
  },
  'pf-int4g64.safetensors': {},
  'pf-int4g32.safetensors': {},
};

// label must equal the loader-derived Detector.weightFormat — the beforeAll asserts it.
// The milestone-3 candidates (mixed-precision sw4/out8 pairs + int8 embeddings)
// were measured, FAILED the ladder, and were rejected — the numbers live in the
// EXPECTED_FAILURES comment below as the historical record (measured on the
// legacy engine, 2026-06-12). They are dropped from the executable list: the
// eager engine deliberately supports only uniform expert precision + bf16
// embeddings (the shipped config), so there is nothing left to run them on.
const CONFIGS = [
  { file: 'pf-int8g640.safetensors', label: 'int8/g640' },
  { file: 'pf-int4g64.safetensors', label: 'int4/g64' },
  { file: 'pf-int4g32.safetensors', label: 'int4/g32' },
];

/** Cases a config FAILS outright — measured, investigated, and recorded in
 *  docs/superpowers/specs/2026-06-11-quantization-design.md and
 *  2026-06-12-mixed-precision-quantization-design.md (Results).
 *  Boundary/count mismatches are never pinned as deviations; `it.fails`
 *  keeps the empirical record executable: if the artifact ever starts
 *  passing (e.g. a re-export), the suite flags it for re-evaluation.
 *
 * int4/g64, mixed_long (measured 2026-06-11): the "alice@corp.example" span
 * VANISHES (9 spans vs 10) — tokens 6-9 decode as O. This is NOT a near-tie:
 * the O path beats private_person by 0.61 nats and private_email by 1.72
 * nats over tokens 6-9 (sums: O -4.8291, person -5.4389, email -6.5475),
 * ~27x the 0.0625-nat reference margin. Per-token argmax agreement drops to
 * 80/81 (max |dlogprob| 3.74). Drift grows monotonically through depth
 * (block0 15.96 -> block7 1009.94 on mixed_long) with no output-column
 * concentration, and the other 7 cases pass, so this is accumulated int4
 * round-to-nearest quantization error (qerrRel ~0.13), not a kernel or
 * packing bug. int4/g64 fails the span bar; see the spec's config ladder.
 *
 * int4/g32, mixed_long (measured 2026-06-11): boundaries and count match and
 * the label flip superficially reproduces the f16/int8 one (private_person
 * for "alice@corp.example"), but it does NOT qualify as a near-tie deviation:
 * the person path beats the email path by 1.5703 nats over tokens 6-9
 * (sums: person -4.4976 vs email -6.0679) — ~25x the 0.0625-nat reference
 * margin and ~45x int8's 0.0347. Max |dlogprob| vs the reference is 8.22
 * (int8: 3.04). The decision is no longer borderline; g32 quantization
 * error (qerrRel ~0.11) moved it decisively, and the agreeing label is
 * luck of the noise, not the documented knife edge. Per the milestone-1
 * protocol (pin only when BOTH margins are razor-thin) int4/g32 fails the
 * span bar. int8/g640 ships; see the spec's Results section.
 *
 * --- Milestone 3 (spec 2026-06-12, measured 2026-06-12) ---
 *
 * int4/g64|int8/g640 (C1, mixed_long): boundaries and count match (10 spans)
 * and the "alice@corp.example" label flip superficially reproduces the
 * f16/int8 one (private_person), but it is NOT a near-tie. The person path
 * beats the email path by 2.5055 nats over tokens 6-9 (sums: O -6.0022,
 * person -4.3526, email -6.8581; reference person -5.1752 vs email -5.1127,
 * i.e. 0.0625 nats the email way) — ~40x the reference margin, ~72x int8's
 * 0.0347, and larger even than the rejected uniform int4/g32 (1.5703). Keeping
 * w2 at int8 was not enough: the w1 int4 error (qerrRel ~0.12) moved the
 * decision decisively, and the agreeing label is noise luck. Argmax agreement
 * 80/81, max |dlogprob| 8.3191. Drift grows monotonically (email_short block0
 * 4.54 -> block7 627.97). Per the protocol C1 fails the span bar; not pinnable.
 *
 * int4/g32|int8/g640 (C2 fallback, mixed_long): same shape — 10 spans, same
 * surface flip — and even further from a tie. The person path beats email by
 * 3.3379 nats over tokens 6-9 (sums: O -7.6008, person -3.6219, email
 * -6.9598) — ~53x the reference margin and larger than C1. Argmax agreement
 * 80/81, max |dlogprob| 5.8676. Drift email_short block0 3.50 -> block6 853.78
 * (peaks at block6, block7 616.61). Halving the swiglu group size did not
 * recover the email decision; C2 fails. Both expert candidates fail, so
 * int8/g640 stays the shipped expert config (spec Results 2026-06-12).
 *
 * int8/g640+emb8 (mixed_long): the "alice@corp.example" span VANISHES (9 spans
 * vs 10) — tokens 6-9 decode as O. NOT pinnable (boundary/count mismatch) and
 * not borderline: the O path beats person by 1.9348 nats and email by 4.1661
 * nats over tokens 6-9 (sums: O -3.7481, person -5.6828, email -7.9141).
 * Argmax agreement 78/81, max |dlogprob| 3.7755. Drift email_short block0
 * 28.43 -> block7 218.77. Sanity check ruling out a dequant-path bug: gathering
 * the mixed_long token ids through both gatherEmbeddings paths (int8 emb
 * manifest-int8g640-emb8.json vs bf16 manifest-int8g640.json) gives max abs
 * diff 0.28334, mean 0.08453 — within qerrMax 0.3517 and unpatterned, so the
 * failure is genuine quantization quality, not implementation. Per protocol
 * rule 2 a vanished span is never pinnable: emb8 fails the gate, embeddings
 * stay bf16 (spec Results 2026-06-12).
 */
const EXPECTED_FAILURES: Record<string, Set<string>> = {
  'pf-int4g64.safetensors': new Set(['mixed_long']),
  'pf-int4g32.safetensors': new Set(['mixed_long']),
};

for (const config of CONFIGS) {
  describe(`quantized e2e (${config.label})`, () => {
    let detector: Detector | undefined;
    beforeAll(async () => {
      // Skip the whole config when its artifact has not been exported.
      const probe = await fetch(`/fixtures/weights/${config.file}`, { method: 'HEAD' });
      if (!probe.ok) return;
      const root = await getRoot();
      // The EAGER detector is the system under test — the fixture spans are
      // engine-independent ground truth, so this suite outlives legacy deletion.
      initTie(root);
      detector = await createEagerDetector(`/fixtures/weights/${config.file}`);
      expect(detector.weightFormat).toBe(config.label);
    }, 300_000);

    // Release the detector so this config's ~1-1.4 GiB of GPU weights
    // becomes GC-eligible before the next config loads.
    afterAll(() => {
      detector = undefined;
    });

    for (const name of CASES) {
      const expectFail = EXPECTED_FAILURES[config.file]?.has(name) ?? false;
      const itFn = expectFail ? it.fails : it;
      itFn(
        `matches reference spans for ${name}`,
        async (ctx) => {
          if (!detector) return ctx.skip();
          const meta = await loadCaseMeta(name);
          const result = await detector.detect(meta.text);
          console.log(
            `${config.label} ${name}: ${result.spans.length} spans, gpu=${result.timings.gpuMs.toFixed(1)}ms`,
          );
          const expected = meta.spans.map((s) => ({ label: s.label, text: s.text }));
          KNOWN_DEVIATIONS[config.file]?.[name]?.(expected);
          expect(result.spans.map((s) => ({ label: s.label, text: s.text }))).toEqual(expected);
        },
        120_000,
      );
    }

    it('reports per-block activation drift on email_short (not gated)', async (ctx) => {
      if (!detector) return ctx.skip();
      const root = await getRoot();
      initTie(root);
      const ex = gpuExecutor(root);
      const sd = await fromSafetensors(`/fixtures/weights/${config.file}`);
      const quantization = JSON.parse(sd.metadata['quantization']!) as {
        bits: 4 | 8;
        groupSize: number;
      };
      const meta = await loadCaseMeta('email_short');
      const T = meta.token_ids.length;
      const model = new EagerModel({
        blocks: 8,
        experts: 128,
        vocab: 200064,
        logits: 33,
        weightFormat: quantization.bits === 4 ? 'quantInt4' : 'quantInt8',
        groupSize: quantization.groupSize,
      });
      await model.loadStateDict(sd, {});
      // Walk the residual stream block by block, materializing each block's
      // output (attn + MoE, residuals folded — the same stream the legacy
      // captureBlocks hook recorded into the fixtures).
      const { cosE, sinE } = ropeConstants(T);
      const cos = tensor(root, cosE, [T, HEAD]);
      const sin = tensor(root, sinE, [T, HEAD]);
      let x = tensor(root, model.embedding.gather(meta.token_ids), [T, 640]);
      for (let i = 0; i < 8; i++) {
        const b = model.block.items[i]!;
        x = b.mlp.forwardGather(b.attn.forward(x, cos, sin));
        const got = await toArray(x, ex);
        const fixture = await loadCaseTensor('email_short', meta, `block${i}`);
        const diff = maxAbsDiff(got, fixture.data);
        console.log(`${config.label} block${i} maxAbsDiff vs fixture: ${diff.toFixed(4)}`);
        expect(Number.isFinite(diff)).toBe(true);
      }
    }, 300_000);
  });
}
