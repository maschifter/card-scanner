/** Privacy filter through the plugin on the GPU: the tie-backed model's
 *  per-token argmax matches the fixture reference logits, and a padded
 *  batch (left and right) reproduces the single-row logits. Runs once per
 *  weights file: the official checkpoint (fixtures/weights/pf-hf.safetensors,
 *  a copy of the hub file) and the exported f16 file. A missing file skips
 *  its run. */

import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  AutoModelForTokenClassification,
  Tensor,
  type PretrainedConfig,
} from '@huggingface/transformers';
import { initTie } from '@tie/core';
import { getRoot, loadCaseMeta, loadCaseTensor } from '../../../core/test/gpu/harness.ts';
import {
  privacyFilterLoader,
  registerTieBackend,
  unregisterTieBackend,
} from '../../src/transformers/index.ts';
import { PRIVACY_FILTER_LABELS } from '../../src/transformers/privacy-filter/model.ts';
import { V2_NER_CLASS_NAMES } from '../../src/privacy-filter/config.ts';

const WEIGHTS_FILES = [
  '/fixtures/weights/pf-hf.safetensors',
  '/fixtures/weights/pf-f16.safetensors',
];
const CASES = ['email_short', 'address', 'person_date', 'negatives'];
const L = PRIVACY_FILTER_LABELS;

/** The hub config fields the loader checks, passed inline so nothing
 *  touches the network. */
const PF_CONFIG = {
  model_type: 'openai_privacy_filter',
  hidden_size: 640,
  num_hidden_layers: 8,
  num_local_experts: 128,
  num_experts_per_tok: 4,
  id2label: Object.fromEntries(V2_NER_CLASS_NAMES.map((n, i) => [String(i), n])),
} as unknown as PretrainedConfig;

const int64 = (values: number[], dims: number[]): Tensor =>
  new Tensor('int64', BigInt64Array.from(values.map(BigInt)), dims);

const argmaxRows = (data: Float32Array, rows: number): number[] =>
  Array.from({ length: rows }, (_, t) => {
    let best = 0;
    for (let k = 1; k < L; k++) if (data[t * L + k]! > data[t * L + best]!) best = k;
    return best;
  });

const maxAbsDiff = (a: Float32Array, b: Float32Array): number => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

describe.each(WEIGHTS_FILES)(
  'privacy filter through the transformers.js plugin (%s)',
  (WEIGHTS) => {
    let ready = false;
    let model: Awaited<ReturnType<typeof AutoModelForTokenClassification.from_pretrained>>;

    beforeAll(async () => {
      const probe = await fetch(WEIGHTS, { method: 'HEAD' });
      if (!probe.ok) return;
      initTie(await getRoot());
      registerTieBackend({ models: { 'tie-test/pf': privacyFilterLoader(WEIGHTS) } });
      model = await AutoModelForTokenClassification.from_pretrained('tie-test/pf', {
        config: PF_CONFIG,
      });
      ready = true;
    }, 300_000);

    afterAll(() => unregisterTieBackend());

    /** Runs one row without padding, returns its [T, L] logits. */
    const runRow = async (ids: number[]): Promise<Float32Array> => {
      const out = await model({ input_ids: int64(ids, [1, ids.length]) });
      const logits = out['logits']!;
      expect(logits.dims).toEqual([1, ids.length, L]);
      return logits.data as Float32Array;
    };

    it('picks the reference label for every token', async (ctx) => {
      if (!ready) return ctx.skip();
      for (const name of CASES) {
        const meta = await loadCaseMeta(name);
        const ref = await loadCaseTensor(name, meta, 'logits');
        const got = await runRow(meta.token_ids);
        expect(got.every(Number.isFinite)).toBe(true);
        expect(argmaxRows(got, meta.token_ids.length)).toEqual(
          argmaxRows(ref.data, meta.token_ids.length),
        );
      }
    }, 120_000);

    it('matches the single-row logits in a padded batch', async (ctx) => {
      if (!ready) return ctx.skip();
      const a = (await loadCaseMeta('email_short')).token_ids;
      const b = (await loadCaseMeta('negatives')).token_ids;
      const [soloA, soloB] = [await runRow(a), await runRow(b)];

      const seqLen = Math.max(a.length, b.length) + 2;
      const pad = (ids: number[], left: boolean) => {
        const fill = new Array<number>(seqLen - ids.length).fill(0);
        return {
          ids: left ? [...fill, ...ids] : [...ids, ...fill],
          mask: left ? [...fill, ...ids.map(() => 1)] : [...ids.map(() => 1), ...fill],
          start: left ? seqLen - ids.length : 0,
        };
      };
      const rowA = pad(a, false);
      const rowB = pad(b, true);
      const out = await model({
        input_ids: int64([...rowA.ids, ...rowB.ids], [2, seqLen]),
        attention_mask: int64([...rowA.mask, ...rowB.mask], [2, seqLen]),
      });
      const logits = out['logits']!;
      expect(logits.dims).toEqual([2, seqLen, L]);
      const data = logits.data as Float32Array;

      const rowSlice = (row: number, start: number, len: number) =>
        data.subarray((row * seqLen + start) * L, (row * seqLen + start + len) * L);
      expect(maxAbsDiff(rowSlice(0, rowA.start, a.length), soloA)).toBeLessThan(1e-5);
      expect(maxAbsDiff(rowSlice(1, rowB.start, b.length), soloB)).toBeLessThan(1e-5);
      // pad slots: after row A's tokens, before row B's tokens
      expect(rowSlice(0, a.length, seqLen - a.length).every((v) => v === 0)).toBe(true);
      expect(rowSlice(1, 0, rowB.start).every((v) => v === 0)).toBe(true);
    }, 120_000);
  },
);
