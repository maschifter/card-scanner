import { beforeAll, describe, expect, it } from 'vitest';
import { initTie } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core GPU harness via a relative import.
import { getRoot } from '../../../core/test/gpu/harness.ts';
import {
  MOONSHINE_BASE,
  MOONSHINE_TINY,
  type MoonshineConfig,
} from '../../src/moonshine/config.ts';
import { createTranscriber } from '../../src/moonshine/transcriber.ts';
import type { Transcriber } from '../../src/moonshine/transcriber.ts';
import type { MoonshineTokenizer } from '../../src/moonshine/tokenizer.ts';

/** Perf baseline for the transcriber on the fixture clip, per model size —
 *  numbers recorded, not tightly asserted, since machines differ. A cold run
 *  includes every pipeline compile; the warm run is the steady state a demo
 *  user feels. Bounds are deliberately loose sanity rails, an order of
 *  magnitude above the measured tiny baseline (encode ~50 ms, ~30 ms/step
 *  warm on an M-class laptop). A size whose fixtures have not been generated
 *  skips. */

const FIXTURES = '/fixtures/moonshine';

const MODELS: readonly { name: string; cfg: MoonshineConfig }[] = [
  { name: 'tiny', cfg: MOONSHINE_TINY },
  { name: 'base', cfg: MOONSHINE_BASE },
];

interface CaseMeta {
  audioSamples: number;
  transcript: string;
  tensors: Record<string, { shape: number[]; file: string }>;
}

for (const { name, cfg } of MODELS) {
  const MODEL = `${FIXTURES}/${name}`;
  const CASE = `${MODEL}/cases/librispeech_3s`;

  describe(`moonshine transcriber perf baseline (${name})`, () => {
    let ready = false;
    let root: TgpuRoot;
    let meta: CaseMeta;
    let audio: Float32Array;
    let transcriber: Transcriber;

    beforeAll(async () => {
      const probe = await fetch(`${CASE}/meta.json`);
      if (!probe.ok) return; // fixtures not generated → every test skips
      meta = await probe.json();
      const tokRes = await fetch(`${FIXTURES}/tokenizer.json`);
      if (!tokRes.ok) return;
      const tokenizer: MoonshineTokenizer = await tokRes.json();
      const audioRes = await fetch(`${CASE}/${meta.tensors.audio!.file}`);
      audio = new Float32Array(await audioRes.arrayBuffer());

      const weights = await fetch(`${MODEL}/model.safetensors`, { method: 'HEAD' });
      if (!weights.ok) return;
      root = await getRoot();
      initTie(root);
      transcriber = await createTranscriber(`${MODEL}/model.safetensors`, tokenizer, { cfg });
      ready = true;
    }, 300_000);

    it('records cold and warm timings for the fixture clip', async (ctx) => {
      if (!ready) return ctx.skip();
      const audioS = meta.audioSamples / 16_000;

      const cold = await transcriber.transcribe(audio);
      const warm = await transcriber.transcribe(audio);
      for (const [label, r] of [
        ['cold', cold],
        ['warm', warm],
      ] as const) {
        const total = r.timings.encodeMs + r.timings.decodeMs;
        console.log(
          `perf ${name} ${label}: encode ${r.timings.encodeMs.toFixed(1)}ms · ` +
            `decode ${r.timings.decodeMs.toFixed(1)}ms / ${r.timings.steps} steps ` +
            `(${(r.timings.decodeMs / r.timings.steps).toFixed(1)}ms/step) · ` +
            `${((r.timings.steps / r.timings.decodeMs) * 1000).toFixed(1)} tokens/s · ` +
            `${(audioS / (total / 1000)).toFixed(1)}x real-time`,
        );
      }

      // Correctness rail: perf numbers only count for output that is right.
      expect(warm.text).toBe(meta.transcript);
      // Sanity rails, ~10x above the measured baseline.
      expect(warm.timings.encodeMs).toBeLessThan(2000);
      expect(warm.timings.decodeMs / warm.timings.steps).toBeLessThan(300);
    }, 120_000);
  });
}
