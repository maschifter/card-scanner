/** transformers.js plugin end-to-end on the GPU: AutoModel.from_pretrained
 *  through the patched loader returns the tie-backed model, whose
 *  last_hidden_state — mean-pooled and normalized exactly like the
 *  feature-extraction pipeline does — matches the HF normalized goldens: one
 *  sequence at a time, one right-padded batch and one left-padded batch
 *  (each result written back to its token's slot). Skips when the
 *  minilm fixtures are missing (tools/dump_minilm_fixtures.py). */

import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { AutoModel, Tensor, type PretrainedConfig } from '@huggingface/transformers';
import { initTie } from '@tie/core';
import { getRoot, maxAbsDiff } from '../../../core/test/gpu/harness.ts';
import {
  minilmLoader,
  registerTieBackend,
  unregisterTieBackend,
} from '../../src/transformers/index.ts';
import { EMBEDDING_DIM } from '../../src/minilm/config.ts';

const DIR = '/fixtures/minilm';

interface Meta {
  cases: {
    name: string;
    text: string;
    ids: number[];
    tensors: Record<string, { shape: number[]; file: string }>;
  }[];
}

/** Mask-aware mean over tokens + L2 normalize — what the feature-extraction
 *  pipeline does with `{ pooling: 'mean', normalize: true }`. */
function poolNormalize(hidden: Float32Array, seqLen: number, realLen: number): Float32Array {
  const out = new Float32Array(EMBEDDING_DIM);
  for (let t = 0; t < realLen; t++) {
    for (let h = 0; h < EMBEDDING_DIM; h++) out[h]! += hidden[t * EMBEDDING_DIM + h]!;
  }
  let sumSq = 0;
  for (let h = 0; h < EMBEDDING_DIM; h++) {
    out[h]! /= realLen;
    sumSq += out[h]! * out[h]!;
  }
  const inv = 1 / Math.sqrt(sumSq);
  for (let h = 0; h < EMBEDDING_DIM; h++) out[h]! *= inv;
  return out;
}

const int64 = (values: number[], dims: number[]): Tensor =>
  new Tensor('int64', BigInt64Array.from(values.map(BigInt)), dims);

describe('minilm through the transformers.js plugin', () => {
  let ready = false;
  let meta: Meta;
  let model: Awaited<ReturnType<typeof AutoModel.from_pretrained>>;
  const goldens: Float32Array[] = [];

  beforeAll(async () => {
    const probe = await fetch(`${DIR}/meta.json`);
    if (!probe.ok) return;
    meta = await probe.json();
    for (const c of meta.cases) {
      const entry = c.tensors['normalized']!;
      goldens.push(new Float32Array(await (await fetch(`${DIR}/${entry.file}`)).arrayBuffer()));
    }
    initTie(await getRoot());
    registerTieBackend({ models: { 'tie-test/minilm': minilmLoader(`${DIR}/model.safetensors`) } });
    model = await AutoModel.from_pretrained('tie-test/minilm', {
      config: { model_type: 'bert' } as unknown as PretrainedConfig,
    });
    ready = true;
  }, 300_000);

  afterAll(() => unregisterTieBackend());

  it('matches the HF normalized goldens one sequence at a time', async (ctx) => {
    if (!ready) return ctx.skip();
    for (const [i, c] of meta.cases.entries()) {
      const T = c.ids.length;
      const outputs = await model({
        input_ids: int64(c.ids, [1, T]),
        attention_mask: int64(Array(T).fill(1), [1, T]),
      });
      const hidden = outputs['last_hidden_state'] as Tensor;
      expect(hidden.dims).toEqual([1, T, EMBEDDING_DIM]);
      const pooled = poolNormalize(hidden.data as Float32Array, T, T);
      const diff = maxAbsDiff(pooled, goldens[i]!);
      console.log(`${c.name} plugin maxAbsDiff ${diff.toExponential(2)}`);
      expect(diff).toBeLessThan(1e-5);
    }
  });

  it('matches the goldens as one right-padded batch', async (ctx) => {
    if (!ready) return ctx.skip();
    const lengths = meta.cases.map((c) => c.ids.length);
    const seqLen = Math.max(...lengths);
    const batch = meta.cases.length;
    const ids: number[] = [];
    const mask: number[] = [];
    for (const c of meta.cases) {
      ids.push(...c.ids, ...Array(seqLen - c.ids.length).fill(0));
      mask.push(...Array(c.ids.length).fill(1), ...Array(seqLen - c.ids.length).fill(0));
    }
    const outputs = await model({
      input_ids: int64(ids, [batch, seqLen]),
      attention_mask: int64(mask, [batch, seqLen]),
    });
    const hidden = outputs['last_hidden_state'] as Tensor;
    expect(hidden.dims).toEqual([batch, seqLen, EMBEDDING_DIM]);
    const data = hidden.data as Float32Array;
    let worst = 0;
    meta.cases.forEach((c, b) => {
      const row = data.subarray(b * seqLen * EMBEDDING_DIM, (b + 1) * seqLen * EMBEDDING_DIM);
      const pooled = poolNormalize(row, seqLen, c.ids.length);
      worst = Math.max(worst, maxAbsDiff(pooled, goldens[b]!));
      // pad rows must stay zero so mask-aware pooling downstream is exact
      for (let t = c.ids.length; t < seqLen; t++) {
        expect(row[t * EMBEDDING_DIM]).toBe(0);
      }
    });
    console.log(`padded batch maxAbsDiff ${worst.toExponential(2)}`);
    expect(worst).toBeLessThan(1e-5);
  });

  it('matches the goldens as one left-padded batch', async (ctx) => {
    if (!ready) return ctx.skip();
    const seqLen = Math.max(...meta.cases.map((c) => c.ids.length));
    const batch = meta.cases.length;
    const ids: number[] = [];
    const mask: number[] = [];
    for (const c of meta.cases) {
      const pad = seqLen - c.ids.length;
      ids.push(...Array(pad).fill(0), ...c.ids);
      mask.push(...Array(pad).fill(0), ...Array(c.ids.length).fill(1));
    }
    const outputs = await model({
      input_ids: int64(ids, [batch, seqLen]),
      attention_mask: int64(mask, [batch, seqLen]),
    });
    const hidden = outputs['last_hidden_state'] as Tensor;
    expect(hidden.dims).toEqual([batch, seqLen, EMBEDDING_DIM]);
    const data = hidden.data as Float32Array;
    let worst = 0;
    meta.cases.forEach((c, b) => {
      const pad = seqLen - c.ids.length;
      const row = data.subarray(b * seqLen * EMBEDDING_DIM, (b + 1) * seqLen * EMBEDDING_DIM);
      // real tokens sit at the end of the row; pad slots before them stay zero
      const pooled = poolNormalize(row.subarray(pad * EMBEDDING_DIM), c.ids.length, c.ids.length);
      worst = Math.max(worst, maxAbsDiff(pooled, goldens[b]!));
      for (let t = 0; t < pad; t++) {
        expect(row[t * EMBEDDING_DIM]).toBe(0);
      }
    });
    console.log(`left-padded batch maxAbsDiff ${worst.toExponential(2)}`);
    expect(worst).toBeLessThan(1e-5);
  });
});
