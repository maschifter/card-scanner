/** yolo26 HWC4 regression pins. The model runs HWC4+f16 end to end (there is
 *  no row-major conv path to compare against anymore), so correctness rests
 *  on two layers: core's eagerHwc4 CPU-reference parity per kernel, and
 *  these whole-graph pins — sampled head outputs for seeded weights/input,
 *  captured 2026-09-01 from an hwc4 forward that was parity-checked against
 *  the then-live f32 CHW graph (cosine > 0.999, max |diff| < 5% of range,
 *  all three tasks; see the deleted yolo26F16.test.ts for that A/B test —
 *  this file replaced it and has no history of its own).
 *
 *  Tolerances are loose (2.5% of each head's range): f16 accumulation
 *  varies a little across GPUs/drivers, while a packing or layout
 *  regression produces garbage, not percent-level drift. */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  evalValues,
  f16BitsToF32,
  f32ArrayToF16Bits,
  gpuExecutor,
  materialized,
  tensor3d,
  toArray,
  uploadF16,
  uploadF32,
  type Value,
} from '@tie/core';
import { Yolo26Model } from '../../src/yolo26/model.ts';
import { mulberry32 } from './cpuRefs.ts';

const SIZE = 320;
const N_SAMPLES = 24;

/** Captured reference: per task, per head — element count, |max|, and
 *  N_SAMPLES values at stride floor(len/N_SAMPLES). */
// prettier-ignore
const PINS: Record<'detect' | 'segment' | 'pose', { len: number; absMax: number; samples: number[] }[]> = {
  detect: [
    { len: 134400, absMax: 0.12683, samples: [-0.037537, 0.027802, -0.083008, -0.072144, 0.063232, 0.036072, 0.075623, -0.012756, -0.056305, -0.025894, -0.019104, 0.066711, 0.023193, -0.085999, 0.051514, 0.0896, -0.10461, -0.010818, -0.070313, -0.026199, 0.055237, -0.089355, -0.095764, -0.016174] },
    { len: 33600, absMax: 0.12262, samples: [0.039001, -0.092407, -0.010658, -0.010788, 0.046082, 0.088318, -0.067749, 0.077332, -0.027954, 0.044952, -0.086304, 0.038055, -0.097168, -0.043549, -0.03009, -0.018661, -0.0037689, 0.056396, 0.033905, 0.016296, 0.076355, 0.041321, -0.050903, 0.011703] },
    { len: 8400, absMax: 0.11792, samples: [0.046997, -0.035675, 0.043976, 0.10626, -0.0021362, -0.060913, -0.01265, -0.039398, -0.066162, 0.04364, -0.026688, -0.04187, 0.11792, -0.024017, 0.020966, 0.049561, 0.019836, 0.041382, -0.086487, -0.1106, 0.023148, -0.09668, -0.038635, -0.072632] },
  ],
  segment: [
    { len: 185600, absMax: 0.12683, samples: [-0.037537, 0.072876, -0.030273, 0.063477, -0.07019, -0.013306, -0.056396, -0.050049, 0.066833, 0.079956, 0.055359, 0.088196, -0.06131, 0.083374, 0.068604, 0.075989, -0.09613, 0.023972, -0.035431, -0.078735, 0.079224, 0.032104, 0.0186, -0.057983] },
    { len: 46400, absMax: 0.12262, samples: [0.039001, -0.028976, 0.020126, 0.046082, -0.0088348, 0.077271, -0.02803, -0.097412, 0.038208, 0.033142, 0.034851, 0.091125, -0.053101, 0.045502, 0.05777, -0.096008, -0.051178, -0.049347, 0.014122, 0.034454, 0.097107, -0.075806, 0.044861, 0.077209] },
    { len: 11600, absMax: 0.11841, samples: [0.046997, -0.029251, -0.034485, -0.0026245, -0.0080414, -0.039337, -0.066223, 0.039429, -0.04187, 0.089111, 0.078369, 0.090637, -0.11041, 0.024353, 0.024948, -0.01944, -0.038452, 0.069153, 0.044678, 0.094116, -0.031677, -0.023392, 0.016937, 0.079773] },
    { len: 204800, absMax: 0.070984, samples: [0.035248, -0.018524, -0.019775, 0.017136, 0.025528, 0.009285, 0.0013657, 0.0016966, 0.015419, 0.020172, 0.04718, -0.0098114, 0.031372, -0.0077286, 0.02742, -0.021118, -0.0038528, -0.018173, -0.016357, 0.0033989, 0.02655, 0.045288, -0.007843, -0.048004] },
  ],
  pose: [
    { len: 89600, absMax: 0.14343, samples: [-0.037537, -0.07074, 0.0015106, -0.059204, -0.087402, 0.027466, 0.077271, -0.065247, 0.0063934, 0.00085449, -0.015823, 0.0020752, 0.046661, -0.086731, 0.051758, 0.12286, -0.075012, -0.046143, -0.012665, -0.0080261, 0.055176, -0.0046692, -0.074829, 0.054474] },
    { len: 22400, absMax: 0.14441, samples: [0.039001, 0.039734, 0.088074, 0.0513, -0.064819, 0.049042, 0.12878, 0.0080261, 0.037354, 0.079285, 0.034149, -0.014877, -0.021118, -0.0020828, -0.031738, -0.060699, 0.024368, 0.073425, -0.090515, 0.10278, 0.06958, 0.082581, 0.018524, -0.052673] },
    { len: 5600, absMax: 0.17542, samples: [0.046997, -0.00099373, -0.0040512, 0.072571, 0.10388, -0.077515, -0.046814, 0.10547, -0.08783, 0.086609, 0.005127, -0.017883, -0.010834, 0.022766, 0.066956, 0.00057983, -0.072998, 0.10071, 0.076599, -0.087769, 0.1626, 0.061523, 0.065674, 0.01619] },
  ],
};

/** f16-rounded random weights — the exact draw the pins were captured with. */
function roundedRandom(n: number, rng: () => number): Float32Array {
  const raw = new Float32Array(n).map(() => (rng() - 0.5) * 0.2);
  const bits = f32ArrayToF16Bits(raw).data;
  return Float32Array.from(bits, (b) => f16BitsToF32(b));
}

describe('yolo26 hwc4 pins', () => {
  const runTask = async (task: 'detect' | 'segment' | 'pose') => {
    const root = await tgpu.init({ device: { optionalFeatures: ['shader-f16'] } });
    const exec = gpuExecutor(root);
    const rng = mulberry32(7);
    const model = new Yolo26Model('n', { root, task });
    for (const [, p] of model.namedParameters()) {
      const data = roundedRandom(p.shape.elems, rng);
      if (p.shape.dtype === 'f16') {
        // The loader applies preprocess (the hwc4 tile repack); manual binds
        // must do the same or the kernels read garbage.
        let bits: Uint16Array = f32ArrayToF16Bits(data).data;
        if (p.preprocess) bits = p.preprocess(bits) as Uint16Array;
        p.bind(materialized(p.shape, uploadF16(root, bits)));
      } else {
        p.bind(materialized(p.shape, uploadF32(root, data)));
      }
    }
    // Every conv weight carries the packed tag.
    const tagged = [...model.namedParameters()].filter(
      ([name, p]) => name.endsWith('conv.weight') && p.shape.layout === 'hwc4',
    );
    expect(tagged.length).toBeGreaterThan(50);

    const raw = new Float32Array(3 * SIZE * SIZE).map((_, i) => Math.abs(Math.sin(i * 0.013)));
    const rounded = Float32Array.from(f32ArrayToF16Bits(raw).data, (b) => f16BitsToF32(b));
    const x = materialized(tensor3d(3, SIZE, SIZE), uploadF32(root, rounded));

    const o = model.forward(x);
    const heads: Value[] = Array.isArray(o)
      ? o
      : [...(o as unknown as { levels: Value[] }).levels, (o as unknown as { proto: Value }).proto];
    evalValues(heads, exec);

    const pins = PINS[task];
    expect(heads.length).toBe(pins.length);
    for (let i = 0; i < heads.length; i++) {
      const got = await toArray(heads[i]!, exec);
      const pin = pins[i]!;
      expect(got.length, `head ${i} length`).toBe(pin.len);
      const tol = Math.max(0.025 * pin.absMax, 0.005);
      let absMax = 0;
      for (const v of got) {
        if (!Number.isFinite(v)) expect.fail(`head ${i}: non-finite value`);
        absMax = Math.max(absMax, Math.abs(v));
      }
      expect(Math.abs(absMax - pin.absMax), `head ${i} |max|`).toBeLessThan(tol * 4);
      const stride = Math.floor(pin.len / N_SAMPLES);
      for (let j = 0; j < N_SAMPLES; j++) {
        const diff = Math.abs(got[j * stride]! - pin.samples[j]!);
        if (diff >= tol) {
          expect.fail(`head ${i} sample ${j}: got ${got[j * stride]} pin ${pin.samples[j]}`);
        }
      }
    }
  };

  it('detect matches the pinned heads', () => runTask('detect'), 120_000);
  it('segment matches the pinned heads (levels + proto)', () => runTask('segment'), 120_000);
  it('pose matches the pinned heads', () => runTask('pose'), 120_000);
});
