import { beforeAll, describe, expect, it } from 'vitest';
import { initTie } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core GPU harness via a relative import.
import { getRoot } from '../../../core/test/gpu/harness.ts';
import {
  MOONSHINE_BASE,
  MOONSHINE_TINY,
  type MoonshineConfig,
} from '../../src/moonshine/config.ts';
import { createTranscriber } from '../../src/moonshine/transcriber.ts';
import type { MoonshineTokenizer } from '../../src/moonshine/tokenizer.ts';

/** f16-weight e2e gate per model size: the transcriber with weightDtype 'f16'
 *  (packed matmul/embedding weights, f32 activations) must reproduce the HF
 *  greedy ids and transcript EXACTLY — the accuracy verdict for shipping f16
 *  as the demo default. Prefers the exported f16 file (the demo's artifact);
 *  the f32 file exercises the same pack path at load. */

const FIXTURES = '/fixtures/moonshine';

const MODELS: readonly { name: string; cfg: MoonshineConfig }[] = [
  { name: 'tiny', cfg: MOONSHINE_TINY },
  { name: 'base', cfg: MOONSHINE_BASE },
];

interface CaseMeta {
  greedyIds: number[];
  transcript: string;
  tensors: Record<string, { shape: number[]; file: string }>;
}

for (const { name, cfg } of MODELS) {
  const MODEL = `${FIXTURES}/${name}`;
  const CASE = `${MODEL}/cases/librispeech_3s`;

  describe(`moonshine f16 weights e2e (${name})`, () => {
    let ready = false;
    let root: TgpuRoot;
    let meta: CaseMeta;
    let audio: Float32Array;
    let tokenizer: MoonshineTokenizer;
    let weightsFile = 'model.safetensors';

    beforeAll(async () => {
      const probe = await fetch(`${CASE}/meta.json`);
      if (!probe.ok) return; // fixtures not generated → every test skips
      const tokRes = await fetch(`${FIXTURES}/tokenizer.json`);
      if (!tokRes.ok) return;
      const weights = await fetch(`${MODEL}/model.safetensors`, { method: 'HEAD' });
      if (!weights.ok) return;
      meta = await probe.json();
      tokenizer = await tokRes.json();
      const audioRes = await fetch(`${CASE}/${meta.tensors.audio!.file}`);
      audio = new Float32Array(await audioRes.arrayBuffer());
      const f16Probe = await fetch(`${MODEL}/model-f16.safetensors`, { method: 'HEAD' });
      if (f16Probe.ok) weightsFile = 'model-f16.safetensors';
      root = await getRoot();
      ready = true;
    }, 300_000);

    it('transcribes with f16 weights to the exact HF ids and transcript', async (ctx) => {
      if (!ready) return ctx.skip();
      console.log(`f16 e2e source: ${weightsFile}`);
      initTie(root);
      const transcriber = await createTranscriber(`${MODEL}/${weightsFile}`, tokenizer, {
        cfg,
        weightDtype: 'f16',
      });
      const cold = await transcriber.transcribe(audio);
      const result = await transcriber.transcribe(audio); // warm — the steady state
      for (const [label, r] of [
        ['cold', cold],
        ['warm', result],
      ] as const) {
        console.log(
          `f16 e2e ${label}: decode ${r.timings.decodeMs.toFixed(1)}ms / ${r.timings.steps} steps ` +
            `(${(r.timings.decodeMs / r.timings.steps).toFixed(1)}ms/step) → "${r.text}"`,
        );
      }
      expect(cold.ids).toEqual(meta.greedyIds);
      expect(result.ids).toEqual(meta.greedyIds);
      expect(result.text).toBe(meta.transcript);
    }, 120_000);
  });
}
