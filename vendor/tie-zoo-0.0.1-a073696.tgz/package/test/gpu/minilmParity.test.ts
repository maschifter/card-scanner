/** MiniLM parity vs the HF golden fixtures, on the real checkpoint: per stage
 *  (embeddings LN, encoder layer 0, final hidden), then the pooled +
 *  L2-normalized sentence embedding and the full cosine-similarity matrix
 *  across all fixture cases. Skips when the fixtures have not been generated
 *  (tools/dump_minilm_fixtures.py). */

import { beforeAll, describe, expect, it } from 'vitest';
import { gpuExecutor, mean, toArray, transpose, type Value } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core GPU harness via a relative import.
import { getRoot, maxAbsDiff } from '../../../core/test/gpu/harness.ts';
import { MinilmModel } from '../../src/minilm/model.ts';

const DIR = '/fixtures/minilm';

interface CaseEntry {
  name: string;
  text: string;
  ids: number[];
  tensors: Record<string, { shape: number[]; file: string }>;
}

interface Meta {
  cases: CaseEntry[];
  similarity: number[][];
}

describe('minilm parity vs HF fixtures', () => {
  let ready = false;
  let root: TgpuRoot;
  let meta: Meta;
  let model: MinilmModel;

  const loadTensor = async (c: CaseEntry, name: string): Promise<Float32Array> => {
    const entry = c.tensors[name];
    if (!entry) throw new Error(`fixture tensor missing from meta: ${c.name}/${name}`);
    const res = await fetch(`${DIR}/${entry.file}`);
    if (!res.ok) throw new Error(`fixture ${c.name}/${name}: ${res.status}`);
    return new Float32Array(await res.arrayBuffer());
  };

  beforeAll(async () => {
    const probe = await fetch(`${DIR}/meta.json`);
    if (!probe.ok) return; // fixtures not generated → every test skips
    meta = await probe.json();
    root = await getRoot();
    model = new MinilmModel();
    await model.loadStateDict(`${DIR}/model.safetensors`, { root });
    ready = true;
  }, 300_000);

  const run = (v: Value): Promise<Float32Array> => toArray(v, gpuExecutor(root));

  it('embeddings stage matches emb_ln', async (ctx) => {
    if (!ready) return ctx.skip();
    for (const c of meta.cases) {
      const out = await run(model.embeddings.forward(c.ids));
      const diff = maxAbsDiff(out, await loadTensor(c, 'emb_ln'));
      console.log(`${c.name} emb_ln maxAbsDiff ${diff.toExponential(2)}`);
      expect(diff).toBeLessThan(1e-5);
    }
  });

  it('encoder layer 0 matches enc_layer0', async (ctx) => {
    if (!ready) return ctx.skip();
    for (const c of meta.cases) {
      const out = await run(model.layers.items[0]!.forward(model.embeddings.forward(c.ids)));
      const diff = maxAbsDiff(out, await loadTensor(c, 'enc_layer0'));
      console.log(`${c.name} enc_layer0 maxAbsDiff ${diff.toExponential(2)}`);
      expect(diff).toBeLessThan(1e-5);
    }
  });

  it('final hidden state matches last_hidden', async (ctx) => {
    if (!ready) return ctx.skip();
    for (const c of meta.cases) {
      const out = await run(model.forward(c.ids));
      const diff = maxAbsDiff(out, await loadTensor(c, 'last_hidden'));
      console.log(`${c.name} last_hidden maxAbsDiff ${diff.toExponential(2)}`);
      expect(diff).toBeLessThan(2e-5);
    }
  });

  it('pooled + normalized embeddings and the similarity matrix match', async (ctx) => {
    if (!ready) return ctx.skip();
    const embeddings: Float32Array[] = [];
    for (const c of meta.cases) {
      const pooled = await run(mean(transpose(model.forward(c.ids))));
      const poolDiff = maxAbsDiff(pooled, await loadTensor(c, 'pooled'));
      let sumSq = 0;
      for (const v of pooled) sumSq += v * v;
      const inv = 1 / Math.sqrt(sumSq);
      for (let i = 0; i < pooled.length; i++) pooled[i]! *= inv;
      const normDiff = maxAbsDiff(pooled, await loadTensor(c, 'normalized'));
      console.log(
        `${c.name} pooled ${poolDiff.toExponential(2)} normalized ${normDiff.toExponential(2)}`,
      );
      expect(poolDiff).toBeLessThan(1e-5);
      expect(normDiff).toBeLessThan(1e-5);
      embeddings.push(pooled);
    }
    let simDiff = 0;
    for (let a = 0; a < embeddings.length; a++) {
      for (let b = 0; b < embeddings.length; b++) {
        let dot = 0;
        for (let i = 0; i < embeddings[a]!.length; i++)
          dot += embeddings[a]![i]! * embeddings[b]![i]!;
        simDiff = Math.max(simDiff, Math.abs(dot - meta.similarity[a]![b]!));
      }
    }
    console.log(`similarity matrix maxAbsDiff ${simDiff.toExponential(2)}`);
    expect(simDiff).toBeLessThan(1e-4);
  });
});
