/** Bucketed capture/replay parity for the MiniLM embed core (random f32
 *  weights, no fixtures needed): the replay path — padded bucket, rewritten
 *  input buffers, fused single-submit readback — must match the eager
 *  forward on the same tokens. Padding changes reduction split points, so
 *  the comparison allows small float noise, not exact bytes. */

import { beforeAll, describe, expect, it } from 'vitest';
import { initTie, materialized, matmul, matrix, toArray, uploadF32 } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
import { getRoot } from '../../../core/test/gpu/harness.ts';
import { createMinilmEmbedCore, pickBucket } from '../../src/minilm/embedder.ts';
import { MinilmModel } from '../../src/minilm/model.ts';

/** Small deterministic values keep every activation finite through 6 layers. */
function randomStateDict(model: MinilmModel): Record<string, Float32Array> {
  const sd: Record<string, Float32Array> = {};
  let seed = 1;
  const next = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return (seed / 0x7fffffff - 0.5) * 0.04;
  };
  for (const [name, p] of model.namedParameters()) {
    sd[name] = Float32Array.from({ length: p.shape.elems }, next);
  }
  return sd;
}

/** Binds every Parameter straight from `sd` by name, bypassing
 *  transformStateDict — this model has no checkpoint to remap, just random
 *  f32 weights keyed by the model's own dotted parameter paths. */
function loadDirect(model: MinilmModel, sd: Record<string, Float32Array>, root: TgpuRoot): void {
  for (const [name, p] of model.namedParameters()) {
    p.bind(materialized(p.shape, uploadF32(root, sd[name]!)));
  }
}

const idsOfLength = (len: number, salt = 0): number[] =>
  Array.from({ length: len }, (_, i) => ((i + salt) * 37 + salt) % 30522);

/** Eager reference: same pooling matmul, no padding, default executor. */
async function eagerPooled(model: MinilmModel, ids: readonly number[]): Promise<Float32Array> {
  const s = materialized(
    matrix(1, ids.length),
    uploadF32(new Float32Array(ids.length).fill(1 / ids.length)),
  );
  return toArray(matmul(s, model.forward(ids)));
}

function compare(got: Float32Array, want: Float32Array): { cosine: number; maxAbs: number } {
  let dot = 0;
  let ng = 0;
  let nw = 0;
  let maxAbs = 0;
  for (let i = 0; i < want.length; i++) {
    dot += got[i]! * want[i]!;
    ng += got[i]! * got[i]!;
    nw += want[i]! * want[i]!;
    maxAbs = Math.max(maxAbs, Math.abs(got[i]! - want[i]!));
  }
  return { cosine: dot / Math.sqrt(ng * nw), maxAbs };
}

describe('minilm bucketed replay (random weights)', () => {
  let root: TgpuRoot;
  let model: MinilmModel;
  let core: ReturnType<typeof createMinilmEmbedCore>;

  beforeAll(async () => {
    root = await getRoot();
    initTie(root);
    model = new MinilmModel();
    loadDirect(model, randomStateDict(model), root);
    core = createMinilmEmbedCore(model);
  }, 300_000);

  it('matches the eager forward across lengths and buckets', async () => {
    for (const len of [2, 5, 16, 17, 40, 64, 100, 200, 256]) {
      const ids = idsOfLength(len);
      const got = await core.embedPooled(ids);
      const want = await eagerPooled(model, ids);
      const { cosine, maxAbs } = compare(got, want);
      expect(cosine, `len ${len} cosine`).toBeGreaterThan(1 - 1e-6);
      expect(maxAbs, `len ${len} maxAbs`).toBeLessThan(1e-4);
    }
  }, 120_000);

  it('repeated replays on one bucket do not leak previous inputs', async () => {
    // Same bucket (16), three different sentences round-robin, twice — a
    // stale ids/segments/selector buffer would corrupt the later results.
    const sentences = [idsOfLength(4, 1), idsOfLength(9, 2), idsOfLength(16, 3)];
    const wants = [];
    for (const ids of sentences) wants.push(await eagerPooled(model, ids));
    for (let round = 0; round < 2; round++) {
      for (let i = 0; i < sentences.length; i++) {
        const got = await core.embedPooled(sentences[i]!);
        const { cosine, maxAbs } = compare(got, wants[i]!);
        expect(cosine, `round ${round} sentence ${i}`).toBeGreaterThan(1 - 1e-6);
        expect(maxAbs).toBeLessThan(1e-4);
      }
    }
  }, 120_000);

  it('falls back to eager past the largest bucket', async () => {
    expect(pickBucket(300)).toBeUndefined();
    const ids = idsOfLength(300);
    const got = await core.embedPooled(ids);
    const want = await eagerPooled(model, ids);
    const { cosine } = compare(got, want);
    expect(cosine).toBeGreaterThan(1 - 1e-6);
  }, 120_000);

  it('packed batch path is unchanged and consistent with singles', async () => {
    const list = [idsOfLength(6, 5), idsOfLength(30, 6)];
    const pooled = await core.embedPooledBatch(list);
    for (let b = 0; b < list.length; b++) {
      const want = await eagerPooled(model, list[b]!);
      const { cosine, maxAbs } = compare(pooled.slice(b * 384, (b + 1) * 384), want);
      expect(cosine, `batch row ${b}`).toBeGreaterThan(1 - 1e-6);
      expect(maxAbs).toBeLessThan(1e-4);
    }
  }, 120_000);
});
