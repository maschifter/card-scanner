/** MiniLM forward+pool micro-benchmark on random f32 weights (no fixtures
 *  needed). Reports warm-up and steady-state median wall ms per sequence
 *  length; compare medians within one session only. */

import { beforeAll, describe, expect, it } from 'vitest';
import {
  gpuExecutor,
  initTie,
  matmul,
  matrix,
  mean,
  toArray,
  transpose,
  uploadF32,
  materialized,
  type MemoryStateDict,
} from '@tie/core';
import type { GpuSubmitTiming } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
import { getRoot } from '../../../core/test/gpu/harness.ts';
import { MINILM_L6 } from '../../src/minilm/config.ts';
import { MinilmModel } from '../../src/minilm/model.ts';

const LENGTHS = [16, 64, 256];
const REPS = 30;

/** Random HF-named checkpoint record — the model's transform hook consumes
 *  HF names, so the fake carries them (layouts are torch-style; the values
 *  are random anyway). Small repeatable values keep every activation finite
 *  through 6 layers. */
function randomHfStateDict(): MemoryStateDict {
  const { hidden: H, ffn, layers, vocab, maxPositions } = MINILM_L6;
  let seed = 1;
  const next = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return (seed / 0x7fffffff - 0.5) * 0.04;
  };
  const sd: MemoryStateDict = {};
  const put = (name: string, shape: number[]) => {
    const elems = shape.reduce((a, b) => a * b, 1);
    sd[name] = { data: Float32Array.from({ length: elems }, next), shape };
  };
  put('embeddings.word_embeddings.weight', [vocab, H]);
  put('embeddings.position_embeddings.weight', [maxPositions, H]);
  put('embeddings.token_type_embeddings.weight', [2, H]);
  put('embeddings.LayerNorm.weight', [H]);
  put('embeddings.LayerNorm.bias', [H]);
  for (let i = 0; i < layers; i++) {
    const L = `encoder.layer.${i}`;
    for (const p of ['query', 'key', 'value']) {
      put(`${L}.attention.self.${p}.weight`, [H, H]);
      put(`${L}.attention.self.${p}.bias`, [H]);
    }
    put(`${L}.attention.output.dense.weight`, [H, H]);
    put(`${L}.attention.output.dense.bias`, [H]);
    put(`${L}.attention.output.LayerNorm.weight`, [H]);
    put(`${L}.attention.output.LayerNorm.bias`, [H]);
    put(`${L}.intermediate.dense.weight`, [ffn, H]);
    put(`${L}.intermediate.dense.bias`, [ffn]);
    put(`${L}.output.dense.weight`, [H, ffn]);
    put(`${L}.output.dense.bias`, [H]);
    put(`${L}.output.LayerNorm.weight`, [H]);
    put(`${L}.output.LayerNorm.bias`, [H]);
  }
  return sd;
}

describe('minilm bench (random weights)', () => {
  let root: TgpuRoot;
  let model: MinilmModel;

  beforeAll(async () => {
    root = await getRoot();
    initTie(root); // the batched forward uploads its segment table to the default device
    model = new MinilmModel();
    await model.loadStateDict(randomHfStateDict(), { root });
  }, 300_000);

  it('reports steady-state median per sequence length', async () => {
    const ex = gpuExecutor(root);
    for (const T of LENGTHS) {
      const ids = Array.from({ length: T }, (_, i) => (i * 37) % 30522);
      const run = () => toArray(mean(transpose(model.forward(ids))), ex);
      const t0 = performance.now();
      const first = await run();
      const warmup = performance.now() - t0;
      expect(first.every(Number.isFinite)).toBe(true);
      const times: number[] = [];
      for (let i = 0; i < REPS; i++) {
        const s = performance.now();
        await run();
        times.push(performance.now() - s);
      }
      times.sort((a, b) => a - b);
      const median = times[Math.floor(times.length / 2)]!;
      console.log(
        `T=${T}: warmup ${warmup.toFixed(1)}ms  steady median ${median.toFixed(2)}ms  min ${times[0]!.toFixed(2)}ms`,
      );
    }
  }, 120_000);

  it('batched throughput: ms per sentence at B=1/4/8/16/32 (T=16)', async () => {
    const ex = gpuExecutor(root);
    const T = 16;
    const ids = Array.from({ length: T }, (_, i) => (i * 37) % 30522);
    for (const B of [1, 4, 8, 16, 32]) {
      const packed = Array.from({ length: B }, () => ids).flat();
      const lengths = Array.from({ length: B }, () => T);
      const total = B * T;
      const selector = new Float32Array(B * total);
      for (let b = 0; b < B; b++) {
        for (let i = 0; i < T; i++) selector[b * total + b * T + i] = 1 / T;
      }
      const run = () =>
        toArray(
          matmul(
            materialized(matrix(B, total), uploadF32(selector)),
            model.forward(packed, lengths),
          ),
          ex,
        );
      const first = await run(); // warm-up
      expect(first.every(Number.isFinite)).toBe(true);
      const times: number[] = [];
      for (let i = 0; i < REPS; i++) {
        const s = performance.now();
        await run();
        times.push(performance.now() - s);
      }
      times.sort((a, b) => a - b);
      const median = times[Math.floor(times.length / 2)]!;
      console.log(
        `B=${B} T=${T}: batch median ${median.toFixed(2)}ms  =${(median / B).toFixed(2)}ms/sentence  min ${(times[0]! / B).toFixed(2)}ms/sentence`,
      );
    }
  }, 300_000);

  it('per-kernel GPU histogram (perOp timestamps)', async (ctx) => {
    if (!root.device.features.has('timestamp-query')) return ctx.skip();
    for (const T of LENGTHS) {
      const timings: Promise<GpuSubmitTiming>[] = [];
      let dispatches = 0;
      const ex = gpuExecutor(root, {
        perf: {
          perOp: true,
          onSubmit(n, timing) {
            dispatches += n;
            if (timing) timings.push(timing);
          },
        },
      });
      const ids = Array.from({ length: T }, (_, i) => (i * 37) % 30522);
      const run = () => toArray(mean(transpose(model.forward(ids))), ex);
      await run(); // warm-up: pipeline compiles land outside the histogram
      const warmupSubmits = timings.length;
      const warmupDispatches = dispatches;
      for (let i = 0; i < REPS; i++) await run();
      const settled = await Promise.all(timings.slice(warmupSubmits));
      const perKernel = new Map<string, { ns: number; count: number }>();
      let totalNs = 0;
      for (const t of settled) {
        totalNs += t.gpuNs;
        for (const [name, op] of t.opNs ?? []) {
          const agg = perKernel.get(name) ?? { ns: 0, count: 0 };
          agg.ns += op.ns;
          agg.count += op.count;
          perKernel.set(name, agg);
        }
      }
      // Timestamps must actually resolve — otherwise the table is silent noise.
      expect(settled.length).toBeGreaterThan(0);
      expect(totalNs).toBeGreaterThan(0);
      const perForward = (dispatches - warmupDispatches) / REPS;
      const rows = [...perKernel.entries()].sort((a, b) => b[1].ns - a[1].ns);
      console.log(
        `T=${T}: ${perForward} dispatches/forward, GPU ${(totalNs / REPS / 1e6).toFixed(2)}ms/forward (perOp mode — pass-per-dispatch inflates totals)`,
      );
      for (const [name, { ns, count }] of rows) {
        const share = ((ns / totalNs) * 100).toFixed(1).padStart(5);
        const us = (ns / REPS / 1e3).toFixed(0).padStart(6);
        console.log(`  ${share}%  ${us}µs/fwd  ×${(count / REPS).toFixed(0).padStart(2)}  ${name}`);
      }
    }
  }, 300_000);
});
