import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  gpuExecutor,
  materialized,
  matrix,
  matmul,
  packQuantColSlice,
  toArray,
  uploadF32,
  uploadU32,
} from '@tie/core';

/** Weights go through core's packQuantColSlice (E=1 full-width slice), pinning
 *  the packer→kernel blocked-unit layout contract at the op level. */
const packInt8 = (vals: Int8Array, K: number, N: number, groupSize: number, scales: Float32Array) =>
  packQuantColSlice(
    new Uint8Array(vals.buffer, vals.byteOffset, vals.length),
    scales,
    8,
    groupSize,
    1,
    K,
    N,
    0,
    N,
  );
const packInt4 = (
  vals: Int8Array,
  K: number,
  N: number,
  groupSize: number,
  scales: Float32Array,
) => {
  const qbytes = new Uint8Array((K * N) / 2);
  for (let i = 0; i < vals.length; i++) {
    qbytes[i >> 1] = (qbytes[i >> 1]! | ((vals[i]! & 0xf) << ((i & 1) * 4))) & 0xff;
  }
  return packQuantColSlice(qbytes, scales, 4, groupSize, 1, K, N, 0, N);
};

describe('quantW matmul GPU', () => {
  it('int8 matmul matches CPU dequant', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const a = new Float32Array([1, 2, 3, 4]); // [1,4]
    const wq = new Int8Array([1, -2, 3, -4, 5, 6, -7, 8, 2, 2, 2, 2, -1, -1, -1, -1]); // [K=4,N=4]
    const scaleArr = new Float32Array([0.5, 0.25, 0.5, 1.0]); // [KG=1,N=4]
    const { qdata } = packInt8(wq, 4, 4, 4, scaleArr);
    const w = materialized({ elems: 4, dtype: 'quantW', dims: [4, 4] }, uploadU32(root, qdata));
    const s = materialized({ elems: 4, dtype: 'f32', dims: [1, 4] }, uploadF32(root, scaleArr));
    const y = matmul(materialized(matrix(1, 4), uploadF32(root, a)), w, {
      scales: s,
      baseRow: 0,
      scaleBase: 0,
      bits: 8,
      groupSize: 4,
    });
    const got = await toArray(y, ex);
    const ref = new Float32Array(4);
    for (let c = 0; c < 4; c++) {
      let acc = 0;
      for (let k = 0; k < 4; k++) acc += a[k]! * wq[k * 4 + c]! * scaleArr[c]!;
      ref[c] = acc;
    }
    for (let c = 0; c < 4; c++) expect(got[c]!).toBeCloseTo(ref[c]!, 4);
    root.destroy();
  });

  it('int4 matmul matches CPU dequant', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const a = new Float32Array([1, 2, 3, 4]); // [M=1, K=4]
    // [K=4, N=8], values in [-8, 7]
    const wq = new Int8Array([
      1, -2, 3, -4, 5, 6, -7, 7, 2, -2, 1, -1, 0, 3, -3, 4, -1, 2, -3, 4, -5, 6, -7, 5, 3, -1, 2,
      -4, 1, -3, 4, -2,
    ]);
    const scaleArr = new Float32Array([0.5, 0.25, 0.5, 1.0, 0.125, 0.75, 0.5, 0.25]); // [KG=1, N=8]
    const { qdata } = packInt4(wq, 4, 8, 4, scaleArr);
    const w = materialized({ elems: 4, dtype: 'quantW', dims: [4, 8] }, uploadU32(root, qdata));
    const s = materialized({ elems: 8, dtype: 'f32', dims: [1, 8] }, uploadF32(root, scaleArr));
    const y = matmul(materialized(matrix(1, 4), uploadF32(root, a)), w, {
      scales: s,
      baseRow: 0,
      scaleBase: 0,
      bits: 4,
      groupSize: 4,
    });
    const got = await toArray(y, ex);
    const ref = new Float32Array(8);
    for (let c = 0; c < 8; c++) {
      let acc = 0;
      for (let k = 0; k < 4; k++) acc += a[k]! * wq[k * 8 + c]! * scaleArr[c]!;
      ref[c] = acc;
    }
    for (let c = 0; c < 8; c++) expect(got[c]!).toBeCloseTo(ref[c]!, 4);
    root.destroy();
  });
});
