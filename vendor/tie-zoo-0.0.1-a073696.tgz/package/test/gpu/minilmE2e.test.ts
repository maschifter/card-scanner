/** End-to-end minilm embedder: createMinilmEmbedder over the real checkpoint
 *  and tokenizer asset, text in → unit embedding out, pinned against the HF
 *  normalized goldens and the fixture similarity matrix. Exercises the full
 *  public path (initTie default root, warm-up, error scopes, tokenize inside
 *  embed). Skips when fixtures are missing (tools/export_minilm_tokenizer.py
 *  + tools/dump_minilm_fixtures.py). */

import { beforeAll, describe, expect, it } from 'vitest';
import { initTie } from '@tie/core';
import { getRoot, maxAbsDiff } from '../../../core/test/gpu/harness.ts';
import { createMinilmEmbedder, similarity, type MinilmEmbedder } from '../../src/minilm/index.ts';

const DIR = '/fixtures/minilm';

interface Meta {
  cases: {
    name: string;
    text: string;
    ids: number[];
    tensors: Record<string, { shape: number[]; file: string }>;
  }[];
  similarity: number[][];
}

describe('minilm embedder e2e', () => {
  let ready = false;
  let meta: Meta;
  let embedder: MinilmEmbedder;

  beforeAll(async () => {
    const probe = await fetch(`${DIR}/meta.json`);
    if (!probe.ok) return;
    const tokProbe = await fetch(`${DIR}/tokenizer.json`);
    if (!tokProbe.ok) return;
    meta = await probe.json();
    initTie(await getRoot());
    embedder = await createMinilmEmbedder(`${DIR}/model.safetensors`, await tokProbe.json());
    ready = true;
  }, 300_000);

  it('embeds every fixture text to the HF normalized golden', async (ctx) => {
    if (!ready) return ctx.skip();
    for (const c of meta.cases) {
      expect(embedder.tokenizer.encode(c.text), c.name).toEqual(c.ids);
      const out = await embedder.embed(c.text);
      const entry = c.tensors['normalized']!;
      const ref = new Float32Array(await (await fetch(`${DIR}/${entry.file}`)).arrayBuffer());
      const diff = maxAbsDiff(out, ref);
      console.log(`${c.name} embed maxAbsDiff ${diff.toExponential(2)}`);
      expect(out).toHaveLength(384);
      expect(diff).toBeLessThan(1e-5);
    }
  });

  it('reproduces the fixture similarity matrix through the public API', async (ctx) => {
    if (!ready) return ctx.skip();
    const embeddings = await Promise.all(meta.cases.map((c) => embedder.embed(c.text)));
    let simDiff = 0;
    for (let a = 0; a < embeddings.length; a++) {
      for (let b = 0; b < embeddings.length; b++) {
        simDiff = Math.max(
          simDiff,
          Math.abs(similarity(embeddings[a]!, embeddings[b]!) - meta.similarity[a]![b]!),
        );
      }
    }
    console.log(`similarity matrix maxAbsDiff ${simDiff.toExponential(2)}`);
    expect(simDiff).toBeLessThan(1e-4);
  });
});
