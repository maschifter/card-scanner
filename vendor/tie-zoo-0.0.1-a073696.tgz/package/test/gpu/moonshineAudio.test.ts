import { describe, expect, it } from 'vitest';
import {
  decodeToMono16k,
  resampleToMono16k,
  TARGET_SAMPLE_RATE,
} from '../../src/moonshine/audio.ts';

/** Browser smoke for the audio ingress: synthesized PCM16 WAV bytes go
 *  through the real decodeAudioData + OfflineAudioContext path — resample to
 *  16 kHz, stereo downmix, and 16 kHz passthrough are each asserted against
 *  the synthesized ground truth. No fixtures, no GPU — runs wherever the gpu
 *  (browser) project runs. */

/** Minimal RIFF/PCM16 WAV encoder — interleaves the given channels. */
function wavBytes(channels: Float32Array[], sampleRate: number): ArrayBuffer {
  const n = channels[0]!.length;
  const numCh = channels.length;
  const dataLen = n * numCh * 2;
  const buf = new ArrayBuffer(44 + dataLen);
  const dv = new DataView(buf);
  const str = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) dv.setUint8(off + i, s.charCodeAt(i));
  };
  str(0, 'RIFF');
  dv.setUint32(4, 36 + dataLen, true);
  str(8, 'WAVE');
  str(12, 'fmt ');
  dv.setUint32(16, 16, true); // fmt chunk size
  dv.setUint16(20, 1, true); // PCM
  dv.setUint16(22, numCh, true);
  dv.setUint32(24, sampleRate, true);
  dv.setUint32(28, sampleRate * numCh * 2, true);
  dv.setUint16(32, numCh * 2, true);
  dv.setUint16(34, 16, true);
  str(36, 'data');
  dv.setUint32(40, dataLen, true);
  let off = 44;
  for (let i = 0; i < n; i++) {
    for (const ch of channels) {
      const v = Math.max(-1, Math.min(1, ch[i]!));
      dv.setInt16(off, v < 0 ? v * 0x8000 : v * 0x7fff, true);
      off += 2;
    }
  }
  return buf;
}

const sine = (freq: number, seconds: number, rate: number, amp = 0.5) =>
  Float32Array.from(
    { length: Math.round(seconds * rate) },
    (_, i) => amp * Math.sin((2 * Math.PI * freq * i) / rate),
  );

/** Single-bin DFT power — dominant-frequency check without an FFT. */
function goertzelPower(x: Float32Array, freq: number, rate: number): number {
  const coeff = 2 * Math.cos((2 * Math.PI * freq) / rate);
  let s1 = 0;
  let s2 = 0;
  for (let i = 0; i < x.length; i++) {
    const s0 = x[i]! + coeff * s1 - s2;
    s2 = s1;
    s1 = s0;
  }
  return s1 * s1 + s2 * s2 - coeff * s1 * s2;
}

const maxAbs = (x: Float32Array) => x.reduce((m, v) => Math.max(m, Math.abs(v)), 0);

describe('decodeToMono16k', () => {
  it('resamples 44.1 kHz mono to 16 kHz preserving the tone', async () => {
    const seconds = 0.5;
    const out = await decodeToMono16k(wavBytes([sine(440, seconds, 44_100)], 44_100));
    expect(Math.abs(out.length - seconds * TARGET_SAMPLE_RATE)).toBeLessThanOrEqual(32);
    // 440 Hz must dominate a probe bin far away from it.
    expect(goertzelPower(out, 440, TARGET_SAMPLE_RATE)).toBeGreaterThan(
      100 * goertzelPower(out, 2000, TARGET_SAMPLE_RATE),
    );
  });

  it('passes 16 kHz mono through with only PCM16 quantization error', async () => {
    const src = sine(440, 0.5, TARGET_SAMPLE_RATE);
    const out = await decodeToMono16k(wavBytes([src], TARGET_SAMPLE_RATE));
    expect(out.length).toBe(src.length);
    let diff = 0;
    for (let i = 0; i < src.length; i++) diff = Math.max(diff, Math.abs(out[i]! - src[i]!));
    expect(diff).toBeLessThan(2e-3);
  });

  it('resampleToMono16k converts raw 48 kHz mic PCM preserving the tone', async () => {
    const seconds = 0.5;
    const out = await resampleToMono16k(sine(440, seconds, 48_000), 48_000);
    expect(Math.abs(out.length - seconds * TARGET_SAMPLE_RATE)).toBeLessThanOrEqual(32);
    expect(goertzelPower(out, 440, TARGET_SAMPLE_RATE)).toBeGreaterThan(
      100 * goertzelPower(out, 2000, TARGET_SAMPLE_RATE),
    );
  });

  it('resampleToMono16k passes 16 kHz input through untouched', async () => {
    const src = sine(440, 0.25, TARGET_SAMPLE_RATE);
    expect(await resampleToMono16k(src, TARGET_SAMPLE_RATE)).toBe(src);
  });

  it('downmixes stereo as the 0.5·(L+R) speaker mix', async () => {
    const l = sine(440, 0.25, TARGET_SAMPLE_RATE, 0.6);
    // Opposite-phase channels cancel to silence…
    const r = Float32Array.from(l, (v) => -v);
    const cancelled = await decodeToMono16k(wavBytes([l, r], TARGET_SAMPLE_RATE));
    expect(maxAbs(cancelled)).toBeLessThan(0.02);
    // …identical channels keep the amplitude.
    const doubled = await decodeToMono16k(wavBytes([l, l], TARGET_SAMPLE_RATE));
    expect(maxAbs(doubled)).toBeGreaterThan(0.5);
    expect(maxAbs(doubled)).toBeLessThan(0.7);
  });
});
