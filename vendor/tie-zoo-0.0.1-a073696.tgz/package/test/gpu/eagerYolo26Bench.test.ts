/** Yolo26n forward-pass wall-clock benchmark. Random f16 weights — the GPU
 *  work is identical to a real checkpoint, so no loader/exporter needed.
 *  Reports warmup (pipeline compiles, one per unique conv geometry) separately
 *  from steady-state. Compare against onnxruntime-web (WebGPU EP) on the same
 *  640×640 protocol: warmup discarded, median of RUNS.
 *
 *  History:
 *    2026-07 M-series, SwiftShader (bad vitest flags): median ~2.7s — bogus
 *    2026-07 M-series, Metal 3: warmup ~1.0s, median ~29.5ms
 *      (gpu 25.9ms / dispatch 3.5ms / dag 0.1ms — naive kernels, no fusion)
 *    2026-07-22 M-series, Metal 3, SAME session: detect ~14.3ms / seg ~21.6ms
 *      (seg = detect graph + proto stack + cv4 towers, +~50%). Absolute
 *      numbers swing run-to-run with machine load — only compare medians
 *      measured in one session.
 *    2026-07-22 + tiled 3×3 conv (smem tile+halo, same session as its
 *      baseline): detect ~12.7ms / seg ~17.2ms — the s=1 3×3 layers (incl.
 *      Proto's 160×160 stack) are where the win lives.
 *    2026-07-23 + dispatch caching (content-keyed uniform cache + identity-
 *      keyed bind-group cache + releaseValues target recycling + persistent
 *      readback staging): detect 12.8→~10.1ms / seg 17.4→~14.4ms same
 *      session; dispatch phase 1.8→0.8ms. Steady-state GPU allocations went
 *      262 buffers / 19.3 MB per frame → ZERO (eagerSteadyStateAlloc.test.ts)
 *      — that churn was the ~30s 2× degradation on iOS WebKit.
 *      DUD (don't retry): ALSO baking input h,w into conv pipelines — ~0%
 *      steady-state (channel/kernel geometry already baked; h,w is just index
 *      math), warmup 103→1273ms from the extra per-resolution compiles.
 *    2026-07-23 + ORT-inspired kernels (same session): detect ~9.3ms /
 *      seg ~13.5ms. (a) smem-tiled 3×3 s=2 (17×17 patch) replaced the direct
 *      path on the downsampling convs — layers 0+1 alone went 2.9→0.7ms
 *      (GPU-only profile); (b) vec4-IO 1×1 GEMM (x/out bound as vec4f over
 *      the contiguous hw axis, ORT gets the same from NHWC channels) —
 *      1.05–1.18× per kernel on M-series (conv1x1V4Bench.test.ts), expected
 *      larger on A-series. ORT-web reference: their edge is vec4 loads via
 *      NHWC + one 32×32×32 smem GEMM for all convs; they can NOT fuse SiLU
 *      (Conv→Sigmoid→Mul has two consumers) and don't pack f16 weights —
 *      both stay our advantages.
 *    2026-07-23 + eval-driver fusion (same session): detect ~8.8ms /
 *      seg ~13.0ms. Residual adds fold into the conv epilogue (hasAdd baked,
 *      res binding) and concat inputs write straight into the concat buffer
 *      via extras.outBase (nested cats flatten into ONE buffer; multi-consumer
 *      inputs fall back to copyInto) — both are evalValues peepholes, model
 *      code stays torch-shaped. Numeric pins: eagerFusion.test.ts.
 *    2026-07-23 + captureFrame replay (same session): detect ~8.4ms replay
 *      vs ~9.1ms eval-mode — DAG walk, fusion passes and handle bookkeeping
 *      skipped; only re-encode + submit remain. Parity: eagerCapture.test.ts.
 *      The JS-side saving matters most on phones.
 *    2026-09-01 HWC4 + native-f16 port (kernels/conv/hwc4.ts; the CHW conv
 *      family deleted): detect eval 8.1→1.8ms / replay 6.8→1.0ms, seg
 *      9.9→2.6ms, pose 9.4→2.7ms (back-to-back stash A/B, M-series Metal).
 *      GPU-only full detect 1.7ms via onSubmittedWorkDone — near the f16
 *      compute floor. Fusion passes carried over (residual add into the conv
 *      epilogue, concat elision via outC4/outOffB block offsets). Numeric
 *      pins: eagerHwc4.test.ts (CPU refs) + yolo26Hwc4.test.ts (whole-graph
 *      pins captured against the pre-deletion f32 arm). Phone knob sweeps
 *      for the new kernels: not done yet — the old CHW device-profile
 *      tables died with the port. */

import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  evalValues,
  gpuExecutor,
  materialized,
  nn,
  f32ArrayToF16Bits,
  tensor3d,
  toHwc4,
  uploadF32,
  uploadF16,
} from '@tie/core';
import { Yolo26Model } from '../../src/yolo26/model.ts';
import { decodePoses, decodeSegmentations } from '../../src/yolo26/pipeline.ts';
import { mulberry32 } from './cpuRefs.ts';

const RUNS = 20;

function stats(xs: number[]) {
  const s = [...xs].sort((a, b) => a - b);
  return {
    min: s[0]!,
    median: s[Math.floor(s.length / 2)]!,
    mean: s.reduce((a, b) => a + b, 0) / s.length,
  };
}

describe('yolo26n forward benchmark (640×640, random f16 weights)', () => {
  it(
    'times warmup and steady-state forward',
    async () => {
      const root = await tgpu.init();
      const exec = gpuExecutor(root);
      const rng = mulberry32(42);

      const model = new Yolo26Model('n');
      for (const [, p] of model.namedParameters()) {
        const data = new Float32Array(p.shape.elems).map(() => (rng() - 0.5) * 0.2);
        // Apply the load-time preprocess (hwc4 tile repack) like the loader
        // does — the GPU work must run against correctly packed weights.
        let bits: Uint16Array | undefined;
        if (p.shape.dtype === 'f16') {
          bits = f32ArrayToF16Bits(data).data;
          if (p.preprocess) bits = p.preprocess(bits) as Uint16Array;
        }
        p.bind(
          materialized(p.shape, bits !== undefined ? uploadF16(root, bits) : uploadF32(root, data)),
        );
      }

      const input = materialized(
        tensor3d(3, 640, 640),
        uploadF32(
          root,
          new Float32Array(3 * 640 * 640).map(() => rng()),
        ),
      );

      const runOnce = async () => {
        const t0 = performance.now();
        const [p3, p4, p5] = model.forward(input);
        const t1 = performance.now();
        evalValues([p3, p4, p5], exec);
        const t2 = performance.now();
        // Force completion: read the smallest output back.
        const out = await exec.readback(p5.buffer, p5.shape);
        const t3 = performance.now();
        exec.releaseValues([p3, p4, p5]); // demo-loop parity: recycle outputs
        return { ms: t3 - t0, build: t1 - t0, dispatch: t2 - t1, gpu: t3 - t2, out };
      };

      // Warmup — pays every pipeline compile (one per unique layer geometry).
      const warmup = await runOnce();
      expect(warmup.out.length).toBe(84 * 20 * 20);
      for (const v of warmup.out.subarray(0, 16)) expect(Number.isFinite(v)).toBe(true);

      const times: number[] = [];
      const builds: number[] = [];
      const dispatches: number[] = [];
      const gpus: number[] = [];
      for (let i = 0; i < RUNS; i++) {
        const r = await runOnce();
        times.push(r.ms);
        builds.push(r.build);
        dispatches.push(r.dispatch);
        gpus.push(r.gpu);
      }
      const s = stats(times);

      // Capture/replay steady state: the demo-loop mode — one recorded handle
      // list re-encoded per frame, no DAG/fusion/handle bookkeeping. Captured
      // last so the executor's replay-only freeze doesn't affect the runs
      // above.
      const cap = exec.captureFrame(() => {
        const ps = model.forward(input);
        evalValues(ps, exec);
        return ps;
      });
      const p5c = cap.targets[2]!;
      await exec.readback(p5c.buffer, p5c.shape); // settle
      const replayTimes: number[] = [];
      for (let i = 0; i < RUNS; i++) {
        const t0 = performance.now();
        cap.replay();
        await exec.readback(p5c.buffer, p5c.shape);
        replayTimes.push(performance.now() - t0);
      }
      const r = stats(replayTimes);

      // Demo-frame span, all three outputs: replay + separate batched
      // readback submit vs the fused single-submit form.
      // Interleaved so clock/thermal drift across the test hits both forms
      // equally.
      const allT = cap.targets.map((p) => ({ buffer: p.buffer, shape: p.shape }));
      const twoSubmitTimes: number[] = [];
      const fusedTimes: number[] = [];
      for (let i = 0; i < RUNS; i++) {
        let t0 = performance.now();
        cap.replay();
        await exec.readbackMany!(allT);
        twoSubmitTimes.push(performance.now() - t0);
        t0 = performance.now();
        const results = exec.readbackManyOnSubmit(cap.targets);
        cap.replay();
        await results;
        fusedTimes.push(performance.now() - t0);
      }
      const two = stats(twoSubmitTimes);
      const fused = stats(fusedTimes);

      // Small-readback variant (p5 only, 132KB) — separates queue-hop savings
      // from large-transfer effects.
      const p5TwoTimes: number[] = [];
      const p5FusedTimes: number[] = [];
      for (let i = 0; i < RUNS; i++) {
        let t0 = performance.now();
        cap.replay();
        await exec.readback(p5c.buffer, p5c.shape);
        p5TwoTimes.push(performance.now() - t0);
        t0 = performance.now();
        const one = exec.readbackOnSubmit(p5c);
        cap.replay();
        await one;
        p5FusedTimes.push(performance.now() - t0);
      }
      const p5two = stats(p5TwoTimes);
      const p5fused = stats(p5FusedTimes);

      console.log(
        `\n=== yolo26n forward (640×640, ${RUNS} runs) ===\n` +
          `warmup (incl. pipeline compiles): ${warmup.ms.toFixed(1)}ms\n` +
          `steady-state: min ${s.min.toFixed(1)}ms  median ${s.median.toFixed(1)}ms  mean ${s.mean.toFixed(1)}ms\n` +
          `phase medians: dag-build ${stats(builds).median.toFixed(1)}ms  ` +
          `dispatch(uniforms+bindgroups+submit) ${stats(dispatches).median.toFixed(1)}ms  ` +
          `gpu+readback ${stats(gpus).median.toFixed(1)}ms\n` +
          `capture/replay steady-state: min ${r.min.toFixed(1)}ms  median ${r.median.toFixed(1)}ms\n` +
          `full-frame (3 outputs): replay+readback ${two.median.toFixed(1)}ms  ` +
          `fused single-submit ${fused.median.toFixed(1)}ms\n` +
          `p5-only (132KB): replay+readback ${p5two.median.toFixed(1)}ms  ` +
          `fused single-submit ${p5fused.median.toFixed(1)}ms`,
      );

      expect(s.median).toBeGreaterThan(0);
      expect(r.median).toBeGreaterThan(0);
      expect(fused.median).toBeGreaterThan(0);
    },
    { timeout: 300_000 },
  );

  it(
    'times seg-task forward (proto + coeff towers on top of detect)',
    async () => {
      const root = await tgpu.init();
      const exec = gpuExecutor(root);
      const rng = mulberry32(42);
      const model = new Yolo26Model('n', { task: 'segment' });
      for (const [, p] of model.namedParameters()) {
        const data = new Float32Array(p.shape.elems).map(() => (rng() - 0.5) * 0.2);
        // Apply the load-time preprocess (hwc4 tile repack) like the loader
        // does — the GPU work must run against correctly packed weights.
        let bits: Uint16Array | undefined;
        if (p.shape.dtype === 'f16') {
          bits = f32ArrayToF16Bits(data).data;
          if (p.preprocess) bits = p.preprocess(bits) as Uint16Array;
        }
        p.bind(
          materialized(p.shape, bits !== undefined ? uploadF16(root, bits) : uploadF32(root, data)),
        );
      }
      const input = materialized(
        tensor3d(3, 640, 640),
        uploadF32(
          root,
          new Float32Array(3 * 640 * 640).map(() => rng()),
        ),
      );
      const runOnce = async () => {
        const t0 = performance.now();
        const { levels, proto } = model.forward(input);
        evalValues([...levels, proto], exec);
        const out = await exec.readback(proto.buffer, proto.shape);
        const ms = performance.now() - t0;
        exec.releaseValues([...levels, proto]); // demo-loop parity
        return { ms, out };
      };
      const warmup = await runOnce();
      expect(warmup.out.length).toBe(32 * 160 * 160);
      for (const v of warmup.out.subarray(0, 16)) expect(Number.isFinite(v)).toBe(true);
      // Integration pin: seg forward output composes with decodeSegmentations
      // at DEFAULT opts (nc=80 → coeffs read at channel offset 84 of the
      // 116-channel levels) without out-of-bounds reads. Random weights give
      // arbitrary logits, so only structural invariants are asserted.
      {
        const { levels, proto } = model.forward(input);
        evalValues([...levels, proto], exec);
        const levelData = await Promise.all(
          levels.map(async (p, i) => ({
            data: await exec.readback(p.buffer, p.shape),
            h: p.shape.dims![1]!,
            w: p.shape.dims![2]!,
            stride: [8, 16, 32][i]!,
          })),
        );
        const protoData = {
          data: await exec.readback(proto.buffer, proto.shape),
          h: proto.shape.dims![1]!,
          w: proto.shape.dims![2]!,
        };
        exec.releaseValues([...levels, proto]);
        const dets = decodeSegmentations(levelData, protoData, { maxDet: 8 });
        for (const d of dets) {
          expect(d.mask.length).toBe(d.maskW * d.maskH);
          expect(Number.isFinite(d.score)).toBe(true);
        }
      }
      const times: number[] = [];
      for (let i = 0; i < RUNS; i++) times.push((await runOnce()).ms);
      const s = stats(times);
      console.log(
        `\n=== yolo26n-SEG forward (640×640, ${RUNS} runs) ===\n` +
          `warmup: ${warmup.ms.toFixed(1)}ms  steady-state: min ${s.min.toFixed(1)}ms  ` +
          `median ${s.median.toFixed(1)}ms  mean ${s.mean.toFixed(1)}ms`,
      );
      expect(s.median).toBeGreaterThan(0);
    },
    { timeout: 300_000 },
  );

  it(
    'times pose-task forward (cv4 keypoint towers on top of detect)',
    async () => {
      const root = await tgpu.init();
      const exec = gpuExecutor(root);
      const rng = mulberry32(42);
      const model = new Yolo26Model('n', { task: 'pose' });
      for (const [, p] of model.namedParameters()) {
        const data = new Float32Array(p.shape.elems).map(() => (rng() - 0.5) * 0.2);
        // Apply the load-time preprocess (hwc4 tile repack) like the loader
        // does — the GPU work must run against correctly packed weights.
        let bits: Uint16Array | undefined;
        if (p.shape.dtype === 'f16') {
          bits = f32ArrayToF16Bits(data).data;
          if (p.preprocess) bits = p.preprocess(bits) as Uint16Array;
        }
        p.bind(
          materialized(p.shape, bits !== undefined ? uploadF16(root, bits) : uploadF32(root, data)),
        );
      }
      const input = materialized(
        tensor3d(3, 640, 640),
        uploadF32(
          root,
          new Float32Array(3 * 640 * 640).map(() => rng()),
        ),
      );
      const runOnce = async () => {
        const t0 = performance.now();
        const levels = model.forward(input);
        evalValues(levels, exec);
        const out = await exec.readback(levels[0].buffer, levels[0].shape);
        const ms = performance.now() - t0;
        exec.releaseValues(levels); // demo-loop parity
        return { ms, out };
      };
      const warmup = await runOnce();
      expect(warmup.out.length).toBe(56 * 80 * 80); // 4+nc(1)+nk(51) channels
      for (const v of warmup.out.subarray(0, 16)) expect(Number.isFinite(v)).toBe(true);
      // Integration pin: forward pose output composes with decodePoses at
      // DEFAULT opts (nc=1 → kpts read from channel offset 5 of the
      // 56-channel levels) without out-of-bounds reads. Random weights give
      // arbitrary logits, so only structural invariants are asserted.
      {
        const levels = model.forward(input);
        evalValues(levels, exec);
        const levelData = await Promise.all(
          levels.map(async (p, i) => ({
            data: await exec.readback(p.buffer, p.shape),
            h: p.shape.dims![1]!,
            w: p.shape.dims![2]!,
            stride: [8, 16, 32][i]!,
          })),
        );
        exec.releaseValues(levels);
        const dets = decodePoses(levelData, { maxDet: 8 });
        for (const d of dets) {
          expect(d.kpts.length).toBe(17);
          for (const k of d.kpts) {
            expect(Number.isFinite(k.x)).toBe(true);
            expect(k.v).toBeGreaterThanOrEqual(0);
            expect(k.v).toBeLessThanOrEqual(1);
          }
        }
      }
      const times: number[] = [];
      for (let i = 0; i < RUNS; i++) times.push((await runOnce()).ms);
      const s = stats(times);
      console.log(
        `\n=== yolo26n-POSE forward (640×640, ${RUNS} runs) ===\n` +
          `warmup: ${warmup.ms.toFixed(1)}ms  steady-state: min ${s.min.toFixed(1)}ms  ` +
          `median ${s.median.toFixed(1)}ms  mean ${s.mean.toFixed(1)}ms`,
      );
      expect(s.median).toBeGreaterThan(0);
    },
    { timeout: 300_000 },
  );

  it(
    'per-layer profile: cumulative backbone prefixes',
    async () => {
      const root = await tgpu.init();
      const exec = gpuExecutor(root);
      const rng = mulberry32(42);
      const model = new Yolo26Model('n');
      for (const [, p] of model.namedParameters()) {
        const data = new Float32Array(p.shape.elems).map(() => (rng() - 0.5) * 0.2);
        // Apply the load-time preprocess (hwc4 tile repack) like the loader
        // does — the GPU work must run against correctly packed weights.
        let bits: Uint16Array | undefined;
        if (p.shape.dtype === 'f16') {
          bits = f32ArrayToF16Bits(data).data;
          if (p.preprocess) bits = p.preprocess(bits) as Uint16Array;
        }
        p.bind(
          materialized(p.shape, bits !== undefined ? uploadF16(root, bits) : uploadF32(root, data)),
        );
      }
      const input = materialized(
        tensor3d(3, 640, 640),
        uploadF32(
          root,
          new Float32Array(3 * 640 * 640).map(() => rng()),
        ),
      );

      // Backbone prefixes only (0–22) — every layer in that range is Value→Value.
      const m = model.model.items as readonly nn.Module[];
      // GPU-only timing: onSubmittedWorkDone instead of readback, so marginal
      // costs are kernel time, not transfer size (readback of a 6.5 MB prefix
      // output used to swamp small layers). Median of 5 to cut scheduler noise.
      const timePrefix = async (upTo: number) => {
        const runOnce = async () => {
          let x = toHwc4(input); // the model's own forward() does the same
          for (let i = 0; i <= upTo; i++) x = m[i]!.forward(x);
          const t0 = performance.now();
          evalValues([x], exec);
          await root.device.queue.onSubmittedWorkDone();
          const ms = performance.now() - t0;
          exec.releaseValues([x]);
          return ms;
        };
        await runOnce(); // warm pipelines for this prefix
        const times: number[] = [];
        for (let i = 0; i < 5; i++) times.push(await runOnce());
        return times.sort((a, b) => a - b)[2]!;
      };

      const cum: number[] = [];
      for (let upTo = 0; upTo <= 10; upTo++) cum.push(await timePrefix(upTo));
      const names = [
        '0 Conv 3→16 /2',
        '1 Conv 16→32 /2',
        '2 C3k2 32→64',
        '3 Conv 64→64 /2',
        '4 C3k2 64→128',
        '5 Conv 128→128 /2',
        '6 C3k2 128→128 c3k',
        '7 Conv 128→256 /2',
        '8 C3k2 256→256 c3k',
        '9 SPPF',
        '10 C2PSA',
      ];
      let report = '\n=== backbone per-layer (marginal ms, GPU-only via onSubmittedWorkDone) ===\n';
      for (let i = 0; i <= 10; i++) {
        const marginal = i === 0 ? cum[0]! : cum[i]! - cum[i - 1]!;
        report += `${names[i]}: cum ${cum[i]!.toFixed(2)}ms  marginal ~${marginal.toFixed(2)}ms\n`;
      }
      // Full detect forward GPU-only, for the backbone-vs-neck/head split.
      const timeFull = async () => {
        const ps = model.forward(input);
        const t0 = performance.now();
        evalValues(ps, exec);
        await root.device.queue.onSubmittedWorkDone();
        const ms = performance.now() - t0;
        exec.releaseValues(ps);
        return ms;
      };
      await timeFull();
      const fulls: number[] = [];
      for (let i = 0; i < 5; i++) fulls.push(await timeFull());
      const fullMs = fulls.sort((a, b) => a - b)[2]!;
      report += `FULL detect forward (GPU-only): ${fullMs.toFixed(2)}ms  → neck+head ≈ ${(fullMs - cum[10]!).toFixed(2)}ms\n`;
      console.log(report);
      expect(cum[10]).toBeGreaterThan(0);
    },
    { timeout: 300_000 },
  );
});
