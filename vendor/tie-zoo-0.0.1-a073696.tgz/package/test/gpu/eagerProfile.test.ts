/** Phase profile of the single-DAG quant forward (post gather-MoE — no more
 *  per-block readbacks). We materialize at each block's attention/MoE boundary
 *  to attribute GPU time to the attention side (rope + SDPA + out-proj) vs the
 *  MoE side (the gather experts), so we know which lever to pull next. The
 *  boundary syncs inflate the total (no pipelining), so we ALSO report the real
 *  single-submit forward time; the SPLIT is the point. */

import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { fromSafetensors, gpuExecutor, initTie, tensor, toArray } from '@tie/core';
import { createTokenizer } from '../../src/privacy-filter/tokenizer.ts';
import { EagerModel } from '../../src/privacy-filter/model.ts';
import { HEAD } from '../../src/privacy-filter/attnBlock.ts';
import { ropeConstants } from '../../src/privacy-filter/rope.ts';

const WEIGHTS_URL = '/fixtures/weights/pf-int8g640.safetensors';
const HIDDEN = 640;
const DEVICE_OPTS = {
  device: {
    requiredLimits: { maxStorageBufferBindingSize: 134_217_728, maxBufferSize: 268_435_456 },
  },
};
const SAMPLE_TEXT = `Dear Support Team,

I'm Jennifer Michelle Parsons, account ID ACC-4729-8156-3401. Reach me at jennifer.parsons@emailservice.com or (415) 627-3849. I was born on March 15, 1987, and live at 742 Maple Street, Denver, CO 80202.`;

describe('eager single-DAG phase profile (int8)', () => {
  it('splits attention-side vs MoE-side GPU time', async (ctx) => {
    const probe = await fetch(WEIGHTS_URL, { method: 'HEAD' });
    if (!probe.ok) return ctx.skip(`no ${WEIGHTS_URL}`);

    const tokenIds = createTokenizer().encode(SAMPLE_TEXT).slice(0, 150);
    const T = tokenIds.length;

    const root = await tgpu.init(DEVICE_OPTS);
    initTie(root);
    const ex = gpuExecutor(root);
    const model = new EagerModel({
      blocks: 8,
      experts: 128,
      vocab: 200064,
      logits: 33,
      weightFormat: 'quantInt8',
      groupSize: 640,
    });
    const sd = await fromSafetensors(WEIGHTS_URL);
    await model.loadStateDict(sd, {});
    const x0 = model.embedding.gather(tokenIds);
    const input = () => tensor(root, x0, [T, HIDDEN]);
    const { cosE, sinE } = ropeConstants(T);
    const cos = tensor(root, cosE, [T, HEAD]);
    const sin = tensor(root, sinE, [T, HEAD]);

    // warm (real single-submit forward)
    await toArray(model.forward(tokenIds), ex);

    // Real forward time (one submit).
    const tReal = performance.now();
    await toArray(model.forward(tokenIds), ex);
    const realMs = performance.now() - tReal;

    // Instrumented: sync at each attn/MoE boundary to attribute GPU time.
    let attnMs = 0;
    let moeMs = 0;
    let x = input();
    for (const b of model.block.items) {
      let t = performance.now();
      x = b.attn.forward(x, cos, sin);
      await toArray(x, ex); // drain rope + SDPA + out-proj
      attnMs += performance.now() - t;
      t = performance.now();
      x = b.mlp.forwardGather(x);
      await toArray(x, ex); // drain the gather experts
      moeMs += performance.now() - t;
    }
    const tHead = performance.now();
    await toArray(model.unembedding.forward(model.norm.forward(x)), ex);
    const headMs = performance.now() - tHead;
    const instrMs = attnMs + moeMs + headMs;

    console.log(
      `\n=== single-DAG phase profile (T=${T}, int8) ===\n` +
        `real forward (1 submit):     ${realMs.toFixed(1)}ms\n` +
        `instrumented total (synced): ${instrMs.toFixed(1)}ms  (syncs inflate this; use for the split)\n` +
        `  attention-side (rope+SDPA+out): ${attnMs.toFixed(1)}ms  (${((attnMs / instrMs) * 100).toFixed(0)}%)\n` +
        `  MoE-side (gather experts):      ${moeMs.toFixed(1)}ms  (${((moeMs / instrMs) * 100).toFixed(0)}%)\n` +
        `  head (final norm + unembed):    ${headMs.toFixed(1)}ms  (${((headMs / instrMs) * 100).toFixed(0)}%)\n`,
    );
    expect(realMs).toBeGreaterThan(0);
    root.destroy();
  }, 900_000);
});
