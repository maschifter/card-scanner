/** Honest single-pass GPU time for one MiniLM forward (random weights):
 *  non-perOp timestamp query spans first-to-last dispatch in ONE compute
 *  pass — no pass-boundary inflation. Separates "GPU is busy" from
 *  "we wait on communication". Reported, not asserted. */

import { beforeAll, describe, expect, it } from 'vitest';
import { gpuExecutor, initTie, materialized, matmul, matrix, toArray, uploadF32 } from '@tie/core';
import type { GpuSubmitTiming } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
import { getRoot } from '../../../core/test/gpu/harness.ts';
import { MinilmModel } from '../../src/minilm/model.ts';

function randomStateDict(model: MinilmModel): Record<string, Float32Array> {
  const sd: Record<string, Float32Array> = {};
  let seed = 1;
  const next = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return (seed / 0x7fffffff - 0.5) * 0.04;
  };
  for (const [name, p] of model.namedParameters()) {
    sd[name] = Float32Array.from({ length: p.shape.elems }, next);
  }
  return sd;
}

/** Binds every Parameter straight from `sd` by name, bypassing
 *  transformStateDict — this model has no checkpoint to remap, just random
 *  f32 weights keyed by the model's own dotted parameter paths. */
function loadDirect(model: MinilmModel, sd: Record<string, Float32Array>, root: TgpuRoot): void {
  for (const [name, p] of model.namedParameters()) {
    p.bind(materialized(p.shape, uploadF32(root, sd[name]!)));
  }
}

describe('minilm single-pass GPU time (random weights)', () => {
  let root: TgpuRoot;
  let model: MinilmModel;

  beforeAll(async () => {
    root = await getRoot();
    initTie(root);
    model = new MinilmModel();
    loadDirect(model, randomStateDict(model), root);
  }, 300_000);

  it('reports wall vs GPU-busy per forward across lengths', async (ctx) => {
    if (!root.device.features.has('timestamp-query')) return ctx.skip();
    const REPS = 20;
    for (const T of [16, 64, 256]) {
      const timings: Promise<GpuSubmitTiming>[] = [];
      const ex = gpuExecutor(root, {
        perf: {
          onSubmit(_n, timing) {
            if (timing) timings.push(timing);
          },
        },
      });
      const ids = Array.from({ length: T }, (_, i) => (i * 37) % 30522);
      const sel = materialized(matrix(1, T), uploadF32(new Float32Array(T).fill(1 / T)));
      const run = () => toArray(matmul(sel, model.forward(ids)), ex);
      await run(); // warm-up
      const skip = timings.length;
      const t0 = performance.now();
      for (let i = 0; i < REPS; i++) await run();
      const wall = (performance.now() - t0) / REPS;
      const settled = await Promise.all(timings.slice(skip));
      const gpuMs = settled.reduce((a, t) => a + t.gpuNs, 0) / settled.length / 1e6;
      expect(settled.length).toBeGreaterThan(0);
      console.log(
        `T=${T}: wall ${wall.toFixed(2)}ms  gpu-busy ${gpuMs.toFixed(2)}ms (single pass)`,
      );

      // Pipelined: submit all REPS forwards back-to-back, await at the end —
      // a continuously fed queue lets the clock governor ramp; a large drop
      // in per-forward GPU-busy vs the serial loop above fingers clock state,
      // not kernel math, as the serial floor.
      const skip2 = timings.length;
      const t1 = performance.now();
      const results: Promise<Float32Array>[] = [];
      for (let i = 0; i < REPS; i++) results.push(run());
      await Promise.all(results);
      const wallPipe = (performance.now() - t1) / REPS;
      const settled2 = await Promise.all(timings.slice(skip2));
      const gpuPipe = settled2.reduce((a, t) => a + t.gpuNs, 0) / settled2.length / 1e6;
      console.log(
        `T=${T} pipelined: wall ${wallPipe.toFixed(2)}ms  gpu-busy ${gpuPipe.toFixed(2)}ms/forward`,
      );
    }
  }, 300_000);
});
