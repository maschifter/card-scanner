import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { initTie, memoryStateDict, tensor, toArray, transposeF32 } from '@tie/core';
import { EagerAttnBlock } from '../../src/privacy-filter/attnBlock.ts';
import { ropeConstants } from '../../src/privacy-filter/rope.ts';
import { cpuAttention, cpuLinear, cpuRms, cpuRopeSection, mulberry32, randArr } from './cpuRefs.ts';

const HIDDEN = 640;
const QKV = 1152;
const ATTN_OUT = 896;
const Q_HEADS = 14;
const HEAD = 64;

describe('eager attention block GPU parity', () => {
  it('matches an f64 CPU reference on random weights (T=160, exercises the band)', async () => {
    const root = await tgpu.init();
    const T = 160;
    const rng = mulberry32(42);

    const normScale = Float32Array.from({ length: HIDDEN }, () => 0.9 + rng() * 0.2);
    const wQkv = randArr(rng, HIDDEN * QKV, 1 / Math.sqrt(HIDDEN));
    const bQkv = randArr(rng, QKV, 0.05);
    const wOut = randArr(rng, ATTN_OUT * HIDDEN, 1 / Math.sqrt(ATTN_OUT));
    const bOut = randArr(rng, HIDDEN, 0.05);
    const sinks = randArr(rng, Q_HEADS, 1);
    const xData = randArr(rng, T * HIDDEN, 1);

    // GPU path: build → load → run. EagerAttnBlock's transformStateDict
    // transposes qkv/out weights from checkpoint torch-layout [out,in] to
    // nn.Linear's [in,out] — pre-transpose here so the round trip lands back
    // on wQkv/wOut exactly, matching the CPU reference below.
    const block = new EagerAttnBlock();
    const ex = initTie(root);
    await block.loadStateDict(
      memoryStateDict({
        'norm.scale': normScale,
        'qkv.weight': { data: transposeF32(wQkv, HIDDEN, QKV), shape: [QKV, HIDDEN] },
        'qkv.bias': bQkv,
        'out.weight': { data: transposeF32(wOut, ATTN_OUT, HIDDEN), shape: [HIDDEN, ATTN_OUT] },
        'out.bias': bOut,
        sinks,
      }),
    );
    const { cosE, sinE } = ropeConstants(T);
    const x = tensor(xData, [T, HIDDEN]);
    const cos = tensor(root, cosE, [T, HEAD]);
    const sin = tensor(root, sinE, [T, HEAD]);
    const got = await toArray(block.forward(x, cos, sin), ex);

    // CPU path, on the SAME f32 rope tables the block uploaded.
    const { rawCos, rawSin } = ropeConstants(T);
    const normed = cpuRms(xData, normScale, T, HIDDEN);
    const qkv = cpuLinear(normed, wQkv, bQkv, T, HIDDEN, QKV);
    for (let h = 0; h < Q_HEADS; h++) cpuRopeSection(qkv, h * HEAD, rawCos, rawSin, T);
    for (let kh = 0; kh < 2; kh++) cpuRopeSection(qkv, 896 + kh * HEAD, rawCos, rawSin, T);
    const attn = cpuAttention(qkv, sinks, T);
    const proj = cpuLinear(attn, wOut, bOut, T, ATTN_OUT, HIDDEN);

    let maxDiff = 0;
    let sumDiff = 0;
    for (let i = 0; i < T * HIDDEN; i++) {
      expect(Number.isFinite(got[i]!)).toBe(true);
      const ref = proj[i]! + xData[i]!; // residual
      const d = Math.abs(got[i]! - ref);
      maxDiff = Math.max(maxDiff, d);
      sumDiff += d;
    }
    const meanDiff = sumDiff / (T * HIDDEN);
    console.log('maxDiff', maxDiff, 'meanDiff', meanDiff);
    expect(maxDiff).toBeLessThan(2e-2);
    expect(meanDiff).toBeLessThan(2e-3);
  });
});
