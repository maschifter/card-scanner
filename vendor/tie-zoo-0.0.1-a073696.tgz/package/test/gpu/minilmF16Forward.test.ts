/** MiniLM end to end in native f16: the same random weights loaded into an
 *  f32 model and a .half() model, both run, embeddings compared.
 *  Fixture-free — the weights are generated, so this checks that the whole op
 *  chain composes in f16 and stays numerically close, not that the model is
 *  right (minilmF16.test.ts does that against the HF goldens). */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { gpuExecutor, gpuUpload, initTie, toArray } from '@tie/core';
import { MinilmModel } from '../../src/minilm/model.ts';
import type { MinilmConfig } from '../../src/minilm/config.ts';

/** L6 geometry, shrunk so the test stays quick; same op chain. */
const CFG: MinilmConfig = {
  hidden: 96,
  layers: 2,
  heads: 4,
  headDim: 24,
  ffn: 192,
  vocab: 512,
  maxPositions: 64,
  eps: 1e-12,
};

let rootPromise: Promise<TgpuRoot> | undefined;
const getRoot = (): Promise<TgpuRoot> =>
  (rootPromise ??= tgpu.init({ device: { optionalFeatures: ['shader-f16', 'subgroups'] } }));

/** Deterministic pseudo-random weights, small enough to stay well inside f16. */
const weights = (n: number, seed: number) =>
  new Float32Array(n).map((_, i) => Math.sin(i * 0.7 + seed * 13) * 0.08);

/** Model-space weights, keyed by the dotted parameter path. Built from the
 *  model itself and bound directly (below), which skips the checkpoint
 *  rename/transpose hooks — this test is about the f16 op chain, not about
 *  the HF key mapping. */
function stateDictFor(model: MinilmModel): Record<string, Float32Array> {
  const sd: Record<string, Float32Array> = {};
  let seed = 0;
  for (const [name, p] of model.namedParameters()) {
    sd[name] = weights(p.shape.elems, seed++);
  }
  return sd;
}

/** Binds every Parameter straight from `sd` by name, bypassing
 *  transformStateDict — gpuUpload narrows each value to the Parameter's own
 *  declared dtype (f32 or, after half(), f16). */
function loadAs(model: MinilmModel, sd: Record<string, Float32Array>, root: TgpuRoot): void {
  const upload = gpuUpload(root);
  for (const [name, p] of model.namedParameters()) {
    const data = sd[name]!;
    p.bind(upload(p.preprocess ? p.preprocess(data) : data, p.shape));
  }
}

describe('minilm forward in native f16', () => {
  it('matches the f32 model on the same weights', async () => {
    const root = await getRoot();
    initTie(root);
    const ids = [5, 91, 3, 77, 12, 40, 8, 61];

    const f32Model = new MinilmModel(CFG);
    const sd = stateDictFor(f32Model);
    loadAs(f32Model, sd, root);
    const want = await toArray(f32Model.forward(ids), gpuExecutor(root));

    const f16Model = new MinilmModel(CFG);
    f16Model.half();
    loadAs(f16Model, sd, root);
    const got = await toArray(f16Model.forward(ids), gpuExecutor(root));

    expect(got.length).toBe(want.length);
    let dot = 0;
    let na = 0;
    let nb = 0;
    let maxErr = 0;
    for (let i = 0; i < want.length; i++) {
      dot += got[i]! * want[i]!;
      na += got[i]! * got[i]!;
      nb += want[i]! * want[i]!;
      maxErr = Math.max(maxErr, Math.abs(got[i]! - want[i]!));
    }
    const cos = dot / Math.sqrt(na * nb);
    console.log(`minilm f16 vs f32: cos=${cos.toFixed(6)} maxAbsDiff=${maxErr.toExponential(2)}`);
    expect(cos).toBeGreaterThan(0.999);
  }, 120_000);
});
