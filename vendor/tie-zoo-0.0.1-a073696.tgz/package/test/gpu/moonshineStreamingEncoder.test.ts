import { beforeAll, describe, expect, it } from 'vitest';
import { gpuExecutor, materialized, matrix, toArray, uploadF32, type Value } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core GPU harness via a relative import.
import { getRoot, maxAbsDiff } from '../../../core/test/gpu/harness.ts';
import { MOONSHINE_STREAMING_TINY } from '../../src/moonshine-streaming/config.ts';
import { frontendFrames, type StreamingFrontend } from '../../src/moonshine-streaming/frontend.ts';
import type { StreamingAdapter, StreamingEncoder } from '../../src/moonshine-streaming/encoder.ts';
import { MoonshineStreamingModel } from '../../src/moonshine-streaming/model.ts';

/** Encoder-side parity vs the HF golden fixtures (librispeech_3s) for
 *  moonshine-streaming tiny: frontend (CMVN → asinh → linear → causal convs),
 *  encoder layer 0, encoder final, the adapter (positions + projection), and
 *  the whole audio → adapter chain. Skips when the fixtures have not been
 *  generated (tools/export_moonshine_v2.py + dump_moonshine_v2_fixtures.py). */

const cfg = MOONSHINE_STREAMING_TINY;
const DIR = '/fixtures/moonshine-streaming/tiny';
const CASE = `${DIR}/cases/librispeech_3s`;

interface CaseMeta {
  paddedSamples: number;
  encoderFrames: number;
  tensors: Record<string, { shape: number[]; file: string }>;
}

describe('moonshine-streaming encoder parity vs HF fixtures (tiny)', () => {
  let ready = false;
  let root: TgpuRoot;
  let meta: CaseMeta;
  let frontend: StreamingFrontend;
  let encoder: StreamingEncoder;
  let adapter: StreamingAdapter;

  const loadTensor = async (tensor: string): Promise<{ shape: number[]; data: Float32Array }> => {
    const entry = meta.tensors[tensor];
    if (!entry) throw new Error(`fixture tensor missing from meta: ${tensor}`);
    const res = await fetch(`${CASE}/${entry.file}`);
    if (!res.ok) throw new Error(`fixture ${tensor}: ${res.status}`);
    return { shape: entry.shape, data: new Float32Array(await res.arrayBuffer()) };
  };

  beforeAll(async () => {
    const probe = await fetch(`${CASE}/meta.json`);
    const weights = await fetch(`${DIR}/model.safetensors`, { method: 'HEAD' });
    if (!probe.ok || !weights.ok) return; // fixtures not generated → every test skips
    meta = await probe.json();
    root = await getRoot();

    // The full model loads (the root transform hook maps the HF names);
    // the stages under test are its sub-modules.
    const model = new MoonshineStreamingModel(cfg);
    await model.loadStateDict(`${DIR}/model.safetensors`, { root });
    frontend = model.frontend;
    encoder = model.encoder;
    adapter = model.adapter;
    ready = true;
  }, 300_000);

  const uploadMat = (data: Float32Array, rows: number, cols: number): Value =>
    materialized(matrix(rows, cols), uploadF32(root, data));

  it('frontend matches frontend_out from raw audio', async (ctx) => {
    if (!ready) return ctx.skip();
    const audio = await loadTensor('audio');
    const ref = await loadTensor('frontend_out'); // [T, d]
    const frames = frontendFrames(meta.paddedSamples, cfg.frameLen);
    // The [L] waveform IS the [L/80, 80] frame matrix — same buffer, no copy.
    const x = uploadMat(audio.data, frames.input, cfg.frameLen);
    const t0 = performance.now();
    const out = await toArray(frontend.forward(x), gpuExecutor(root));
    console.log(
      `frontend: ${(performance.now() - t0).toFixed(1)}ms, ` +
        `maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`,
    );
    expect(out.length).toBe(ref.data.length);
    expect(maxAbsDiff(out, ref.data)).toBeLessThan(1e-4);
  });

  it('encoder layer 0 matches enc_layer0 from the reference frontend output', async (ctx) => {
    if (!ready) return ctx.skip();
    const frontendOut = await loadTensor('frontend_out');
    const ref = await loadTensor('enc_layer0');
    const x = uploadMat(frontendOut.data, meta.encoderFrames, cfg.enc.hidden);
    const out = await toArray(encoder.layers.items[0]!.forward(x), gpuExecutor(root));
    console.log(`enc_layer0 maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`);
    expect(maxAbsDiff(out, ref.data)).toBeLessThan(2e-4);
  });

  it('full encoder matches enc_final from the reference frontend output', async (ctx) => {
    if (!ready) return ctx.skip();
    const frontendOut = await loadTensor('frontend_out');
    const ref = await loadTensor('enc_final');
    const x = uploadMat(frontendOut.data, meta.encoderFrames, cfg.enc.hidden);
    const out = await toArray(encoder.forward(x), gpuExecutor(root));
    console.log(`enc_final maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`);
    expect(out.length).toBe(ref.data.length);
    expect(maxAbsDiff(out, ref.data)).toBeLessThan(2e-4);
  });

  it('adapter matches adapter_out from the reference encoder output', async (ctx) => {
    if (!ready) return ctx.skip();
    const encFinal = await loadTensor('enc_final');
    const ref = await loadTensor('adapter_out'); // [T, dec.hidden]
    const x = uploadMat(encFinal.data, meta.encoderFrames, cfg.enc.hidden);
    const out = await toArray(adapter.forward(x), gpuExecutor(root));
    console.log(`adapter_out maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`);
    expect(out.length).toBe(ref.data.length);
    expect(maxAbsDiff(out, ref.data)).toBeLessThan(2e-4);
  });

  it('audio → frontend → encoder → adapter chain matches adapter_out', async (ctx) => {
    if (!ready) return ctx.skip();
    const audio = await loadTensor('audio');
    const ref = await loadTensor('adapter_out');
    const frames = frontendFrames(meta.paddedSamples, cfg.frameLen);
    const x = uploadMat(audio.data, frames.input, cfg.frameLen);
    const t0 = performance.now();
    const out = await toArray(
      adapter.forward(encoder.forward(frontend.forward(x))),
      gpuExecutor(root),
    );
    console.log(
      `audio→adapter_out: ${(performance.now() - t0).toFixed(1)}ms, ` +
        `maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`,
    );
    expect(maxAbsDiff(out, ref.data)).toBeLessThan(2e-4);
  });
});
