import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  f32ArrayToF16Bits,
  f32ToF16Bits,
  initTie,
  materialized,
  memoryStateDict,
  tensor,
  toArray,
  transposeF32,
  uploadF16,
  uploadF32,
} from '@tie/core';
import { EagerMoeMlp, gateColumnShape } from '../../src/privacy-filter/moeMlp.ts';
import { groupByExpert, parseTopk } from '../../src/privacy-filter/routing.ts';
import { cpuMoe, cpuRms, mulberry32, randArr, splitGluLin } from './cpuRefs.ts';

const E = 8;
const H = 64;
const T = 24;

/** f16 bits → exact f32 value (every f16 is exactly representable in f32). */
function f16BitsToF32(bits: number): number {
  const sign = bits & 0x8000 ? -1 : 1;
  const exp = (bits >>> 10) & 0x1f;
  const mant = bits & 0x3ff;
  if (exp === 0) return sign * mant * 2 ** -24; // subnormal
  if (exp === 31) return mant ? NaN : sign * Infinity;
  return sign * (1 + mant / 1024) * 2 ** (exp - 15);
}

/** f16-round every entry (round-to-nearest-even via the repo's f32ToF16Bits)
 *  so the f32 arm and the half()'d f16 arm compute on bit-identical weight
 *  values — the loader's own f32→f16 conversion is then lossless. */
function f16Round(src: Float32Array): Float32Array {
  const rounded = new Float32Array(src.length);
  for (let i = 0; i < src.length; i++) {
    rounded[i] = f16BitsToF32(f32ToF16Bits(src[i]!));
  }
  return rounded;
}

describe('eager MoE in half precision', () => {
  it('matches the f32 format on f16-rounded weights, clamps active (E=8, H=64, T=24)', async () => {
    const root = await tgpu.init({ device: { optionalFeatures: ['shader-f16'] } });
    const ex = initTie(root);
    const rng = mulberry32(777);

    const normScale = Float32Array.from({ length: H }, () => 0.9 + rng() * 0.2);
    const gateW = randArr(rng, H * E, 1 / Math.sqrt(H));
    const gateB = randArr(rng, E, 0.05);
    const w1 = randArr(rng, E * H * 2 * H, 1 / Math.sqrt(H)); // fused [E·H, 2H]
    const b1 = randArr(rng, E * 2 * H, 0.05); // fused [E, 2H]
    // Clamp-activation coverage: expert 0's biases push every pre-activation u
    // beyond the ±7 swiglu limits (glu ≈ +20 → the max-clamp saturates every
    // column; lin alternates ±20 → both sides of the two-sided clamp fire), so
    // the two GPU formats must match cpuMoe's independent clamp code in the
    // saturated regions, not just on small |u| where the clamps are identity.
    for (let c = 0; c < H; c++) {
      b1[c] = 20; // expert 0, glu half
      b1[H + c] = c % 2 ? -20 : 20; // expert 0, lin half
    }
    const w2 = randArr(rng, E * H * H, 1 / Math.sqrt(H));
    const b2 = randArr(rng, E * H, 0.05);
    const xData = randArr(rng, T * H, 1);

    // Split the fused tensors, then f16-round each weight half: both blocks
    // load the same rounded f32 arrays, so half()'s own f32→f16 conversion
    // is the only difference. Biases stay f32 (exact, shared) in both formats.
    const w1Halves = splitGluLin(w1, E * H, H);
    const b1Split = splitGluLin(b1, E, H);
    const glu = f16Round(w1Halves.glu);
    const lin = f16Round(w1Halves.lin);
    const out = f16Round(w2);

    // EagerMoeMlp's transformStateDict transposes gate.weight from checkpoint
    // torch-layout [out,in] to nn.Linear's [in,out] — pre-transpose here so
    // the round trip lands back on gateW exactly.
    const shared = {
      'norm.scale': normScale,
      'gate.weight': { data: transposeF32(gateW, H, E), shape: [E, H] },
      'gate.bias': gateB,
    };
    const blockF32 = new EagerMoeMlp({ experts: E, hidden: H, weightFormat: 'f32' });
    await blockF32.loadStateDict(
      memoryStateDict({
        ...shared,
        gluWeight: glu,
        linWeight: lin,
        gluBias: b1Split.glu,
        linBias: b1Split.lin,
        outWeight: out,
        outBias: b2,
      }),
    );
    // The half-precision arm: same weights, same block, model.half() — that
    // flips the expert weights AND every activation, the only combination a
    // kernel can bind (one element type per buffer). The rounded values are
    // already f16-representable, so the loader's own f32→f16 conversion
    // round-trips them bit-exactly onto the same weights blockF32 loaded.
    const blockPacked = new EagerMoeMlp({ experts: E, hidden: H, weightFormat: 'f32' });
    blockPacked.half(root);
    await blockPacked.loadStateDict(
      memoryStateDict({
        ...shared,
        gluWeight: glu,
        linWeight: lin,
        gluBias: b1Split.glu,
        linBias: b1Split.lin,
        outWeight: out,
        outBias: b2,
      }),
    );

    // Phase A ONCE (identical norm/gate weights in both blocks): the same
    // grouping and gate columns drive both forwards, isolating the expert
    // compute as the only difference between the two paths.
    const x = tensor(xData, [T, H]);
    const packedSel = await toArray(blockF32.selection(x), ex);
    const sel = parseTopk(packedSel, T, 4);
    const grouping = groupByExpert(sel, E);
    const gateColumns = grouping.groups.map((g) =>
      materialized(gateColumnShape(g.tokens.length), uploadF32(root, Float32Array.from(g.weights))),
    );

    // Seed sanity for the clamp coverage: expert 0 must actually be routed,
    // and its first token's pre-clamp u must exceed the limits on both halves
    // (computed on the same f16-rounded weights the GPU consumes; expert 0's
    // rows start at 0 in the [E·H, H] weights).
    const xn = cpuRms(xData, normScale, T, H);
    const g0 = grouping.groups.find((g) => g.expert === 0);
    expect(g0).toBeDefined();
    {
      const t0 = g0!.tokens[0]!;
      let minGluU = Infinity;
      let minLinU = Infinity;
      let maxLinU = -Infinity;
      for (let c = 0; c < H; c++) {
        let uG = b1[c]!;
        let uL = b1[H + c]!;
        for (let k = 0; k < H; k++) {
          const xv = xn[t0 * H + k]!;
          uG += xv * glu[k * H + c]!;
          uL += xv * lin[k * H + c]!;
        }
        minGluU = Math.min(minGluU, uG);
        minLinU = Math.min(minLinU, uL);
        maxLinU = Math.max(maxLinU, uL);
      }
      expect(minGluU).toBeGreaterThan(7); // glu max-clamp saturates every column
      expect(maxLinU).toBeGreaterThan(7); // lin clamps high…
      expect(minLinU).toBeLessThan(-7); // …and low
    }

    const gotF32 = await toArray(blockF32.forward(x, grouping, gateColumns), ex);
    // The halved block needs f16 activations and f16 gate columns.
    const x16 = materialized(
      { elems: T * H, dtype: 'f16' as const, dims: [T, H] },
      uploadF16(root, f32ArrayToF16Bits(xData).data),
    );
    const gateColumns16 = grouping.groups.map((g) =>
      materialized(
        { elems: g.tokens.length, dtype: 'f16' as const, dims: [g.tokens.length, 1] },
        uploadF16(root, f32ArrayToF16Bits(Float32Array.from(g.weights)).data),
      ),
    );
    const gotPacked = await toArray(blockPacked.forward(x16, grouping, gateColumns16), ex);

    // Path-vs-path: same weight VALUES, same op order, but the f16 arm stores
    // every intermediate at half width — compare at f16 resolution.
    let pathDiff = 0;
    for (let i = 0; i < T * H; i++) {
      expect(Number.isFinite(gotPacked[i]!)).toBe(true);
      pathDiff = Math.max(pathDiff, Math.abs(gotF32[i]! - gotPacked[i]!));
    }
    expect(pathDiff).toBeLessThan(5e-2);

    // The f32 path itself still matches the f64 CPU reference on the rounded
    // values (cpuMoe consumes the FUSED layout — rebuild it from the halves).
    const w1Rounded = new Float32Array(E * H * 2 * H);
    for (let r = 0; r < E * H; r++) {
      w1Rounded.set(glu.subarray(r * H, (r + 1) * H), r * 2 * H);
      w1Rounded.set(lin.subarray(r * H, (r + 1) * H), r * 2 * H + H);
    }
    const delta = cpuMoe(
      xn,
      sel.idx,
      sel.w,
      { w1: w1Rounded, b1, w2: out, b2 },
      { hidden: H, tokens: T },
    );
    let maxDiff = 0;
    let sumDiff = 0;
    for (let i = 0; i < T * H; i++) {
      const dAbs = Math.abs(gotF32[i]! - (xData[i]! + delta[i]!));
      maxDiff = Math.max(maxDiff, dAbs);
      sumDiff += dAbs;
    }
    const meanDiff = sumDiff / (T * H);
    console.log('f32-vs-cpu maxDiff', maxDiff, 'meanDiff', meanDiff);
    // Expert 0's clamp-saturating biases scale its contributions ~50× (|h| up
    // to 7·8 vs ~1 elsewhere), so absolute f32-vs-f64 drift grows with it:
    // observed 7.9e-6 / 5.6e-7 (was 1.7e-7 / ~3e-8 pre-clamp-coverage); bounds
    // keep ~12–18x headroom for other GPUs.
    expect(maxDiff).toBeLessThan(1e-4);
    expect(meanDiff).toBeLessThan(1e-5);
  });

  it('forwardGather in half precision matches the CPU reference (E=8, H=64, T=24)', async () => {
    // forwardGather is the single-DAG path production code actually calls
    // (EagerBlock.forward / EagerModel.forward) — unlike forward() above it
    // never takes an externally-supplied grouping, so this exercises
    // matmulGather's f16 arm directly instead of just gatherRows+matmul.
    const root = await tgpu.init({ device: { optionalFeatures: ['shader-f16'] } });
    const ex = initTie(root);
    const rng = mulberry32(2024);

    const normScale = Float32Array.from({ length: H }, () => 0.9 + rng() * 0.2);
    const gateW = randArr(rng, H * E, 1 / Math.sqrt(H));
    const gateB = randArr(rng, E, 0.05);
    const w1 = randArr(rng, E * H * 2 * H, 1 / Math.sqrt(H));
    const b1 = randArr(rng, E * 2 * H, 0.05);
    const w2 = randArr(rng, E * H * H, 1 / Math.sqrt(H));
    const b2 = randArr(rng, E * H, 0.05);
    const xData = randArr(rng, T * H, 1);

    const w1Halves = splitGluLin(w1, E * H, H);
    const b1Split = splitGluLin(b1, E, H);
    const glu = f16Round(w1Halves.glu);
    const lin = f16Round(w1Halves.lin);
    const out = f16Round(w2);
    // The GPU consumes f16-rounded versions of the norm scale and the input
    // too (model.half() narrows every parameter; x16 below is uploaded as
    // f16 bits) — round them here so the CPU reference starts from the same
    // literal values the kernel actually reads, isolating f16 ARITHMETIC
    // error from mere input-rounding error.
    const normScaleRounded = f16Round(normScale);
    const xRounded = f16Round(xData);

    const block = new EagerMoeMlp({ experts: E, hidden: H, weightFormat: 'f32' });
    block.half(root);
    await block.loadStateDict(
      memoryStateDict({
        'norm.scale': normScale,
        'gate.weight': { data: transposeF32(gateW, H, E), shape: [E, H] },
        'gate.bias': gateB,
        gluWeight: glu,
        linWeight: lin,
        gluBias: b1Split.glu,
        linBias: b1Split.lin,
        outWeight: out,
        outBias: b2,
      }),
    );

    const x16 = materialized(
      { elems: T * H, dtype: 'f16' as const, dims: [T, H] },
      uploadF16(root, f32ArrayToF16Bits(xData).data),
    );
    const got = await toArray(block.forwardGather(x16), ex);

    // Read back the exact routing forwardGather used internally: selection()
    // re-runs the identical norm→gate→topk ops (deterministic, no RNG), so
    // this is not a second independent computation — it is the one
    // forwardGather already did, just surfaced for the CPU reference.
    const selPacked = await toArray(block.selection(x16), ex);
    const sel = parseTopk(selPacked, T, 4);

    const xn = cpuRms(xRounded, normScaleRounded, T, H);
    const w1Rounded = new Float32Array(E * H * 2 * H);
    for (let r = 0; r < E * H; r++) {
      w1Rounded.set(glu.subarray(r * H, (r + 1) * H), r * 2 * H);
      w1Rounded.set(lin.subarray(r * H, (r + 1) * H), r * 2 * H + H);
    }
    const delta = cpuMoe(
      xn,
      sel.idx,
      sel.w,
      { w1: w1Rounded, b1, w2: out, b2 },
      { hidden: H, tokens: T },
    );

    let maxDiff = 0;
    for (let i = 0; i < T * H; i++) {
      expect(Number.isFinite(got[i]!)).toBe(true);
      maxDiff = Math.max(maxDiff, Math.abs(got[i]! - (xRounded[i]! + delta[i]!)));
    }
    console.log('forwardGather f16-vs-cpu maxDiff', maxDiff);
    // f16 has ~3 decimal digits of precision and two chained K=64 matmuls —
    // looser than the f32 arm's 1e-4 (that's f32-vs-f64, not f16-vs-f64).
    expect(maxDiff).toBeLessThan(5e-2);
  });
});
