/** Batched minilm embedding: embedBatch packs sentences row-wise with
 *  segmented attention and pools them in one matmul. Parity vs the
 *  single-sentence path (same rows, different summation orders in attention
 *  chunking) and vs the HF normalized goldens. Skips when fixtures are
 *  missing (tools/export_minilm_tokenizer.py + tools/dump_minilm_fixtures.py). */

import { beforeAll, describe, expect, it } from 'vitest';
import { initTie } from '@tie/core';
import { getRoot, maxAbsDiff } from '../../../core/test/gpu/harness.ts';
import { createMinilmEmbedder, similarity, type MinilmEmbedder } from '../../src/minilm/index.ts';

const DIR = '/fixtures/minilm';

interface Meta {
  cases: {
    name: string;
    text: string;
    ids: number[];
    tensors: Record<string, { shape: number[]; file: string }>;
  }[];
  similarity: number[][];
}

describe('minilm batched embedding', () => {
  let ready = false;
  let meta: Meta;
  let embedder: MinilmEmbedder;

  beforeAll(async () => {
    const probe = await fetch(`${DIR}/meta.json`);
    if (!probe.ok) return;
    const tokProbe = await fetch(`${DIR}/tokenizer.json`);
    if (!tokProbe.ok) return;
    meta = await probe.json();
    initTie(await getRoot());
    embedder = await createMinilmEmbedder(`${DIR}/model.safetensors`, await tokProbe.json());
    ready = true;
  }, 300_000);

  it('one batch matches the single-sentence path per text', async (ctx) => {
    if (!ready) return ctx.skip();
    const texts = meta.cases.map((c) => c.text);
    const batched = await embedder.embedBatch(texts);
    expect(batched).toHaveLength(texts.length);
    for (let i = 0; i < texts.length; i++) {
      const single = await embedder.embed(texts[i]!);
      const diff = maxAbsDiff(batched[i]!, single);
      console.log(`${meta.cases[i]!.name} batch-vs-single maxAbsDiff ${diff.toExponential(2)}`);
      expect(diff).toBeLessThan(5e-6);
    }
  });

  it('batch output matches the HF normalized goldens and similarity matrix', async (ctx) => {
    if (!ready) return ctx.skip();
    const batched = await embedder.embedBatch(meta.cases.map((c) => c.text));
    for (let i = 0; i < meta.cases.length; i++) {
      const entry = meta.cases[i]!.tensors['normalized']!;
      const ref = new Float32Array(await (await fetch(`${DIR}/${entry.file}`)).arrayBuffer());
      expect(maxAbsDiff(batched[i]!, ref), meta.cases[i]!.name).toBeLessThan(1e-5);
    }
    let simDiff = 0;
    for (let a = 0; a < batched.length; a++) {
      for (let b = 0; b < batched.length; b++) {
        simDiff = Math.max(
          simDiff,
          Math.abs(similarity(batched[a]!, batched[b]!) - meta.similarity[a]![b]!),
        );
      }
    }
    expect(simDiff).toBeLessThan(1e-4);
  });

  it('empty batch and single-element batch behave', async (ctx) => {
    if (!ready) return ctx.skip();
    expect(await embedder.embedBatch([])).toEqual([]);
    const [one] = await embedder.embedBatch([meta.cases[0]!.text]);
    const single = await embedder.embed(meta.cases[0]!.text);
    expect(maxAbsDiff(one!, single)).toBeLessThan(5e-6);
  });
});
