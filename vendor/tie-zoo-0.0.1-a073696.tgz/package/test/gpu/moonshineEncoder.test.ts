import { beforeAll, describe, expect, it } from 'vitest';
import {
  conv1d,
  gpuExecutor,
  materialized,
  matrix,
  toArray,
  uploadF32,
  type Value,
} from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core GPU harness via a relative import.
import { getRoot, maxAbsDiff } from '../../../core/test/gpu/harness.ts';
import {
  MOONSHINE_BASE,
  MOONSHINE_TINY,
  type MoonshineConfig,
} from '../../src/moonshine/config.ts';
import { buildRopeTables } from '../../src/moonshine/rope.ts';
import { stemFrames, type ConvStem } from '../../src/moonshine/convStem.ts';
import type { MoonshineEncoder } from '../../src/moonshine/encoder.ts';
import { MoonshineModel } from '../../src/moonshine/model.ts';

/** Encoder-stage parity vs the HF golden fixtures (librispeech_3s), per
 *  exported model size: conv1 pre-tanh output, full stem, encoder layer 0,
 *  encoder final, and the whole audio → encoder chain. A size whose fixtures
 *  have not been generated skips (tools/export_moonshine.py +
 *  tools/dump_moonshine_fixtures.py). */

const MODELS: readonly { name: string; cfg: MoonshineConfig }[] = [
  { name: 'tiny', cfg: MOONSHINE_TINY },
  { name: 'base', cfg: MOONSHINE_BASE },
];

interface CaseMeta {
  audioSamples: number;
  encoderFrames: number;
  tensors: Record<string, { shape: number[]; file: string }>;
}

for (const { name, cfg } of MODELS) {
  const DIR = `/fixtures/moonshine/${name}`;
  const CASE = `${DIR}/cases/librispeech_3s`;

  describe(`moonshine encoder parity vs HF fixtures (${name})`, () => {
    let ready = false;
    let root: TgpuRoot;
    let meta: CaseMeta;
    let stem: ConvStem;
    let encoder: MoonshineEncoder;

    const loadTensor = async (tensor: string): Promise<{ shape: number[]; data: Float32Array }> => {
      const entry = meta.tensors[tensor];
      if (!entry) throw new Error(`fixture tensor missing from meta: ${tensor}`);
      const res = await fetch(`${CASE}/${entry.file}`);
      if (!res.ok) throw new Error(`fixture ${tensor}: ${res.status}`);
      return { shape: entry.shape, data: new Float32Array(await res.arrayBuffer()) };
    };

    beforeAll(async () => {
      const probe = await fetch(`${CASE}/meta.json`);
      const weights = await fetch(`${DIR}/model.safetensors`, { method: 'HEAD' });
      if (!probe.ok || !weights.ok) return; // fixtures not generated → every test skips
      meta = await probe.json();
      root = await getRoot();

      // The full model loads (the root transform hook maps the HF names);
      // the stages under test are its sub-modules.
      const model = new MoonshineModel(cfg);
      await model.loadStateDict(`${DIR}/model.safetensors`, { root });
      stem = model.stem;
      encoder = model.encoder;
      ready = true;
    }, 300_000);

    const uploadMat = (data: Float32Array, rows: number, cols: number): Value =>
      materialized(matrix(rows, cols), uploadF32(root, data));

    const ropeValues = (frames: number): { cos: Value; sin: Value } => {
      const t = buildRopeTables(frames, cfg);
      const hd = cfg.headDim;
      return { cos: uploadMat(t.cos, frames, hd), sin: uploadMat(t.sin, frames, hd) };
    };

    it('conv1 matches the pre-tanh reference (channel-major fixture)', async (ctx) => {
      if (!ready) return ctx.skip();
      const audio = await loadTensor('audio');
      const ref = await loadTensor('conv1_raw'); // [C, T1]
      const [C, T1] = ref.shape as [number, number];
      const x = uploadMat(audio.data, meta.audioSamples, 1);
      // The stem's conv1 fuses tanh; the fixture is pre-tanh, so run the op
      // on the same weight without the activation.
      const c1 = stem.conv1;
      const raw = conv1d(x, c1.weight.value, { kernelSize: c1.kernelSize, stride: c1.stride });
      const out = await toArray(raw, gpuExecutor(root)); // [T1, C]
      let diff = 0;
      for (let t = 0; t < T1; t++) {
        for (let c = 0; c < C; c++) {
          diff = Math.max(diff, Math.abs(out[t * C + c]! - ref.data[c * T1 + t]!));
        }
      }
      console.log(`conv1 maxAbsDiff ${diff.toExponential(2)}`);
      expect(diff).toBeLessThan(1e-5);
    });

    it('full stem matches stem_out', async (ctx) => {
      if (!ready) return ctx.skip();
      const audio = await loadTensor('audio');
      const ref = await loadTensor('stem_out'); // [T, d]
      const x = uploadMat(audio.data, meta.audioSamples, 1);
      const t0 = performance.now();
      const out = await toArray(stem.forward(x), gpuExecutor(root));
      console.log(
        `stem: ${(performance.now() - t0).toFixed(1)}ms, maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`,
      );
      expect(out.length).toBe(ref.data.length);
      // 2e-4 covers both sizes — base's wider conv stack accumulates ~1.3e-4.
      expect(maxAbsDiff(out, ref.data)).toBeLessThan(2e-4);
    });

    it('encoder layer 0 matches enc_layer0 from the reference stem output', async (ctx) => {
      if (!ready) return ctx.skip();
      const stemOut = await loadTensor('stem_out');
      const ref = await loadTensor('enc_layer0');
      const T = meta.encoderFrames;
      const x = uploadMat(stemOut.data, T, cfg.dModel);
      const { cos, sin } = ropeValues(T);
      const out = await toArray(encoder.layers.items[0]!.forward(x, cos, sin), gpuExecutor(root));
      console.log(`enc_layer0 maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`);
      expect(maxAbsDiff(out, ref.data)).toBeLessThan(2e-4);
    });

    it('full encoder matches enc_final from the reference stem output', async (ctx) => {
      if (!ready) return ctx.skip();
      const stemOut = await loadTensor('stem_out');
      const ref = await loadTensor('enc_final'); // [1, T, d] — flat compare
      const T = meta.encoderFrames;
      const x = uploadMat(stemOut.data, T, cfg.dModel);
      const { cos, sin } = ropeValues(T);
      const out = await toArray(encoder.forward(x, cos, sin), gpuExecutor(root));
      console.log(`enc_final maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`);
      expect(out.length).toBe(ref.data.length);
      expect(maxAbsDiff(out, ref.data)).toBeLessThan(1e-4);
    });

    it('audio → stem → encoder chain matches enc_final end to end', async (ctx) => {
      if (!ready) return ctx.skip();
      const audio = await loadTensor('audio');
      const ref = await loadTensor('enc_final');
      const frames = stemFrames(meta.audioSamples);
      const x = uploadMat(audio.data, meta.audioSamples, 1);
      const { cos, sin } = ropeValues(frames.conv3);
      const t0 = performance.now();
      const out = await toArray(encoder.forward(stem.forward(x), cos, sin), gpuExecutor(root));
      console.log(
        `audio→enc_final: ${(performance.now() - t0).toFixed(1)}ms, ` +
          `maxAbsDiff ${maxAbsDiff(out, ref.data).toExponential(2)}`,
      );
      expect(maxAbsDiff(out, ref.data)).toBeLessThan(2e-4);
    });
  });
}
