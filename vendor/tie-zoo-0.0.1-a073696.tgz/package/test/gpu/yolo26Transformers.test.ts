/** Yolo26n through the plugin on the GPU: the tie-backed model takes the
 *  stock yolos image processor's pixel_values for bus.jpg and returns top
 *  anchors that find the bus and the people, sorted, normalized, and the
 *  same on a second call. Needs fixtures/yolo26/n/model.safetensors and
 *  fixtures/yolo26/bus.jpg; a missing file skips. */

import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  AutoModelForObjectDetection,
  RawImage,
  YolosImageProcessor,
  type PretrainedConfig,
  type Tensor,
} from '@huggingface/transformers';
import { initTie } from '@tie/core';
import { getRoot } from '../../../core/test/gpu/harness.ts';
import {
  registerTieBackend,
  unregisterTieBackend,
  yolo26Loader,
} from '../../src/transformers/index.ts';
import { COCO_NAMES } from '../../src/yolo26/pipeline.ts';

const WEIGHTS = '/fixtures/yolo26/n/model.safetensors';
const IMAGE = '/fixtures/yolo26/bus.jpg';
const SIZE = 640;
const sigmoid = (x: number) => 1 / (1 + Math.exp(-x));

describe('yolo26 through the transformers.js plugin', () => {
  let ready = false;
  let model: Awaited<ReturnType<typeof AutoModelForObjectDetection.from_pretrained>>;
  let pixel_values: Tensor;

  beforeAll(async () => {
    const probes = await Promise.all([fetch(WEIGHTS, { method: 'HEAD' }), fetch(IMAGE)]);
    if (probes.some((r) => !r.ok)) return;
    const image = await RawImage.fromBlob(await probes[1]!.blob());
    const processor = new YolosImageProcessor({
      do_resize: true,
      size: { width: SIZE, height: SIZE },
      resample: 2,
      do_rescale: true,
      rescale_factor: 1 / 255,
      do_normalize: false,
    });
    ({ pixel_values } = await processor(image));

    initTie(await getRoot());
    const config = {
      model_type: 'yolos',
      id2label: Object.fromEntries(COCO_NAMES.map((n, i) => [i, n])),
    } as unknown as PretrainedConfig;
    registerTieBackend({ models: { 'tie-test/yolo26n': yolo26Loader(WEIGHTS, { variant: 'n' }) } });
    model = await AutoModelForObjectDetection.from_pretrained('tie-test/yolo26n', { config });
    ready = true;
  }, 300_000);

  afterAll(() => unregisterTieBackend());

  it('returns sorted top anchors that see the bus and the people', async (ctx) => {
    if (!ready) return ctx.skip();
    expect(pixel_values.dims).toEqual([1, 3, SIZE, SIZE]);
    const out = await model({ pixel_values });
    const logits = out['logits']!;
    const boxes = out['pred_boxes']!;
    expect(logits.dims).toEqual([1, 300, 80]);
    expect(boxes.dims).toEqual([1, 300, 4]);
    const rows = Array.from({ length: 300 }, (_, k) => {
      const row = (logits.data as Float32Array).subarray(k * 80, k * 80 + 80);
      let best = 0;
      for (let c = 1; c < 80; c++) if (row[c]! > row[best]!) best = c;
      return { label: COCO_NAMES[best]!, score: sigmoid(row[best]!) };
    });
    for (let k = 1; k < rows.length; k++)
      expect(rows[k]!.score).toBeLessThanOrEqual(rows[k - 1]!.score);
    const confident = rows.filter((r) => r.score > 0.5).map((r) => r.label);
    expect(confident).toContain('bus');
    expect(confident.filter((l) => l === 'person').length).toBeGreaterThanOrEqual(3);
    for (const v of boxes.data as Float32Array) {
      expect(v).toBeGreaterThan(-0.05);
      expect(v).toBeLessThan(1.05);
    }
  }, 120_000);

  it('runs the same image twice to the same rows', async (ctx) => {
    if (!ready) return ctx.skip();
    const a = await model({ pixel_values });
    const b = await model({ pixel_values });
    expect(Array.from(a['logits']!.data as Float32Array)).toEqual(
      Array.from(b['logits']!.data as Float32Array),
    );
    expect(Array.from(a['pred_boxes']!.data as Float32Array)).toEqual(
      Array.from(b['pred_boxes']!.data as Float32Array),
    );
  }, 120_000);
});
