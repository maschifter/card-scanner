/** f16-weight embedder vs the HF f32 goldens. Weight rounding is the only
 *  error source (~5e-4 relative per weight, activations stay f32), so the
 *  normalized embeddings land within a few 1e-3 of the f32 reference and the
 *  cosine to the golden stays ≥ 0.9999. Skips when fixtures are missing. */

import { beforeAll, describe, expect, it } from 'vitest';
import { initTie } from '@tie/core';
import { getRoot, maxAbsDiff } from '../../../core/test/gpu/harness.ts';
import { createMinilmEmbedder, similarity, type MinilmEmbedder } from '../../src/minilm/index.ts';

const DIR = '/fixtures/minilm';

interface Meta {
  cases: { name: string; text: string; tensors: Record<string, { file: string }> }[];
  similarity: number[][];
}

describe('minilm embedder with f16 weights', () => {
  let ready = false;
  let meta: Meta;
  let embedder: MinilmEmbedder;

  beforeAll(async () => {
    const probe = await fetch(`${DIR}/meta.json`);
    if (!probe.ok) return;
    const tokProbe = await fetch(`${DIR}/tokenizer.json`);
    if (!tokProbe.ok) return;
    meta = await probe.json();
    initTie(await getRoot());
    embedder = await createMinilmEmbedder(`${DIR}/model.safetensors`, await tokProbe.json(), {
      weights: 'f16',
    });
    ready = true;
  }, 300_000);

  it('stays within f16 rounding of every normalized golden', async (ctx) => {
    if (!ready) return ctx.skip();
    for (const c of meta.cases) {
      const out = await embedder.embed(c.text);
      const ref = new Float32Array(
        await (await fetch(`${DIR}/${c.tensors['normalized']!.file}`)).arrayBuffer(),
      );
      const diff = maxAbsDiff(out, ref);
      const cos = similarity(out, ref);
      console.log(`${c.name} f16 maxAbsDiff ${diff.toExponential(2)} cos ${cos.toFixed(6)}`);
      expect(diff).toBeLessThan(5e-3);
      expect(cos).toBeGreaterThan(0.9999);
    }
  });

  it('reproduces the fixture similarity matrix within f16 rounding', async (ctx) => {
    if (!ready) return ctx.skip();
    const embeddings = await embedder.embedBatch(meta.cases.map((c) => c.text));
    let simDiff = 0;
    for (let a = 0; a < embeddings.length; a++) {
      for (let b = 0; b < embeddings.length; b++) {
        simDiff = Math.max(
          simDiff,
          Math.abs(similarity(embeddings[a]!, embeddings[b]!) - meta.similarity[a]![b]!),
        );
      }
    }
    console.log(`f16 similarity matrix maxAbsDiff ${simDiff.toExponential(2)}`);
    expect(simDiff).toBeLessThan(5e-3);
  });
});
