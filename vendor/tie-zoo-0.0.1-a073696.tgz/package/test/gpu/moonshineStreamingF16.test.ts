/** moonshine-streaming tiny in native half precision, against the real
 *  checkpoint on disk. Compares each stage of the model to the f32 model
 *  loaded from the SAME state dict, so the only variable is storage width.
 *
 *  Skips when the weights have not been exported
 *  (tools/export_moonshine_v2.py). Unlike the parity tests next door this one
 *  needs no golden activations — the f32 model is the reference.
 *
 *  MEASURED (2026-08-28, M-series Metal, tiny, 4s audio): frontend cosine
 *  0.999999, encoder 0.999959, adapter 0.999964, and a full transcribe is
 *  1.22x faster with identical greedy ids. */
import { beforeAll, describe, expect, it } from 'vitest';
import { gpuExecutor, tensor, toArray } from '@tie/core';
import type { Value } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
import { getRoot } from '../../../core/test/gpu/harness.ts';
import { MOONSHINE_STREAMING_TINY } from '../../src/moonshine-streaming/config.ts';
import { MoonshineStreamingModel } from '../../src/moonshine-streaming/model.ts';
import { frontendFrames } from '../../src/moonshine-streaming/frontend.ts';

const DIR = '/fixtures/moonshine-streaming/tiny';
const SECONDS = 4;

function cosine(a: Float32Array, b: Float32Array): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i]! * b[i]!;
    na += a[i]! * a[i]!;
    nb += b[i]! * b[i]!;
  }
  return dot / Math.sqrt(na * nb);
}

describe('moonshine-streaming tiny in f16', () => {
  let ready = false;
  let root: TgpuRoot;

  beforeAll(async () => {
    const probe = await fetch(`${DIR}/model.safetensors`, { method: 'HEAD' });
    if (!probe.ok) return; // weights not exported → skip
    root = await getRoot();
    ready = true;
  }, 300_000);

  it('tracks the f32 model stage by stage', async () => {
    if (!ready) return;
    const cfg = MOONSHINE_STREAMING_TINY;
    const build = async (half: boolean): Promise<MoonshineStreamingModel> => {
      const m = new MoonshineStreamingModel(cfg);
      if (half) m.half(root);
      await m.loadStateDict(`${DIR}/model.safetensors`, { root });
      return m;
    };
    const f32 = await build(false);
    const f16 = await build(true);
    const ex = gpuExecutor(root);

    // The halved model must actually be halved — this is what caught the
    // gpuUpload bug, where f32 words landed in an f16-labelled buffer.
    const kF32 = await toArray(f32.frontend.k.value, ex);
    const kF16 = await toArray(f16.frontend.k.value, ex);
    expect(f16.frontend.k.value.shape.dtype).toBe('f16');
    expect(kF16[0]).toBeCloseTo(kF32[0]!, 2);

    const raw = new Float32Array(SECONDS * 16_000).map(
      (_, i) => 0.3 * Math.sin((2 * Math.PI * 220 * i) / 16_000),
    );
    const frames = frontendFrames(raw.length, cfg.frameLen);
    const dims: [number, number] = [frames.input, cfg.frameLen];
    const x32 = tensor(root, raw, dims);
    const x16 = tensor(root, raw, { elems: raw.length, dtype: 'f16', dims });

    const stages: [string, Value, Value][] = [
      ['frontend', f32.frontend.forward(x32), f16.frontend.forward(x16)],
      [
        'encoder',
        f32.encoder.forward(f32.frontend.forward(x32)),
        f16.encoder.forward(f16.frontend.forward(x16)),
      ],
      [
        'adapter',
        f32.adapter.forward(f32.encoder.forward(f32.frontend.forward(x32))),
        f16.adapter.forward(f16.encoder.forward(f16.frontend.forward(x16))),
      ],
    ];
    for (const [name, a, b] of stages) {
      const want = await toArray(a, ex);
      const got = await toArray(b, ex);
      for (const v of got)
        expect(Number.isFinite(v), `${name} produced a non-finite value`).toBe(true);
      expect(cosine(got, want), `${name} cosine`).toBeGreaterThan(0.999);
    }
  }, 600_000);
});
