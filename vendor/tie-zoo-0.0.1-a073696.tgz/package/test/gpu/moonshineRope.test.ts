import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { gpuExecutor, materialized, matrix, rope, toArray, uploadF32 } from '@tie/core';
import { MOONSHINE_TINY } from '../../src/moonshine/config.ts';
import { buildRopeTables, ropeQkScale } from '../../src/moonshine/rope.ts';

/** Rope-equivalence gate: the engine's interleaved-pair rope kernel fed with
 *  buildRopeTables must reproduce HF Moonshine's apply_rotary_pos_emb — the
 *  GLM/GPT-J interleaved convention with partial rotary (dims 32..35
 *  untouched) — on packed [T, heads·headDim] slabs, and attention scores must
 *  match HF's 1/√headDim scaling via the folded headDim^(−1/4) tables. If this
 *  ever fails, the loader would instead need an explicit rotary permutation of
 *  the q/k projection weights. */

const HD = MOONSHINE_TINY.headDim; // 36
const R = MOONSHINE_TINY.rotaryDim; // 32
const HEADS = MOONSHINE_TINY.heads; // 8
const W = HEADS * HD;
const S = ropeQkScale(HD);

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

/** f64 HF reference: apply_rotary_pos_emb, faithful — interleaved pairs
 *  (x[0::2], x[1::2]) over the first 32 dims of every head section, dims
 *  32..35 pass through, NO scaling (HF scales inside attention instead). */
function hfRope(x: Float32Array, T: number): Float64Array {
  const out = new Float64Array(T * W);
  for (let t = 0; t < T; t++) {
    for (let h = 0; h < HEADS; h++) {
      const base = t * W + h * HD;
      for (let p = 0; p < R / 2; p++) {
        const angle = t * MOONSHINE_TINY.ropeTheta ** (-(2 * p) / R);
        const c = Math.cos(angle);
        const s = Math.sin(angle);
        const x0 = x[base + 2 * p]!;
        const x1 = x[base + 2 * p + 1]!;
        out[base + 2 * p] = x0 * c - x1 * s;
        out[base + 2 * p + 1] = x1 * c + x0 * s;
      }
      for (let cCol = R; cCol < HD; cCol++) out[base + cCol] = x[base + cCol]!;
    }
  }
  return out;
}

async function engineRope(data: Float32Array, T: number): Promise<Float32Array> {
  const root = await tgpu.init();
  const tables = buildRopeTables(T, MOONSHINE_TINY);
  const x = materialized(matrix(T, W), uploadF32(root, data));
  const cos = materialized(matrix(T, HD), uploadF32(root, tables.cos));
  const sin = materialized(matrix(T, HD), uploadF32(root, tables.sin));
  return toArray(rope(x, cos, sin, { headDim: HD }), gpuExecutor(root));
}

describe('moonshine rope equivalence vs HF apply_rotary_pos_emb', () => {
  const T = 7;

  it('roped values match the HF reference (÷ the folded scale)', async () => {
    const q = randArr(T * W, 1);
    const engine = await engineRope(q, T);
    const ref = hfRope(q, T);
    let maxDiff = 0;
    for (let i = 0; i < engine.length; i++) {
      maxDiff = Math.max(maxDiff, Math.abs(engine[i]! / S - ref[i]!));
    }
    expect(maxDiff).toBeLessThan(1e-5);
  });

  it('identity region passes through exactly (× scale)', async () => {
    const q = randArr(T * W, 2);
    const engine = await engineRope(q, T);
    for (let t = 0; t < T; t++) {
      for (let h = 0; h < HEADS; h++) {
        for (let c = R; c < HD; c++) {
          const i = t * W + h * HD + c;
          expect(Math.abs(engine[i]! - q[i]! * S)).toBeLessThan(1e-6);
        }
      }
    }
  });

  it('attention scores carry exactly HF full-head-dim 1/√36 scaling', async () => {
    const q = randArr(T * W, 3);
    const k = randArr(T * W, 4);
    const [engQ, engK] = [await engineRope(q, T), await engineRope(k, T)];
    const [refQ, refK] = [hfRope(q, T), hfRope(k, T)];
    let maxDiff = 0;
    for (let i = 0; i < T; i++) {
      for (let j = 0; j < T; j++) {
        for (let h = 0; h < HEADS; h++) {
          let eng = 0;
          let ref = 0;
          for (let c = 0; c < HD; c++) {
            eng += engQ[i * W + h * HD + c]! * engK[j * W + h * HD + c]!;
            ref += refQ[i * W + h * HD + c]! * refK[j * W + h * HD + c]!;
          }
          // engine q,k each fold s → scores × s² = 1/√36; HF divides by √36.
          maxDiff = Math.max(maxDiff, Math.abs(eng - ref / Math.sqrt(HD)));
        }
      }
    }
    expect(maxDiff).toBeLessThan(1e-4);
  });
});
