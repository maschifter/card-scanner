/** WordPiece encode parity vs the HF BertTokenizer golden cases — every case
 *  in fixtures/minilm/tokenizer_cases.json must produce identical ids
 *  (lowercase, accent strip, CJK spacing, punctuation splits, [UNK] fallback,
 *  256-piece truncation). Skips when the fixtures have not been generated:
 *  tools/export_minilm_tokenizer.py. */

import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { createMinilmTokenizer, type MinilmTokenizerAsset } from '../src/minilm/tokenizer.ts';

const DIR = fileURLToPath(new URL('../../../fixtures/minilm/', import.meta.url));
const ready = existsSync(`${DIR}tokenizer.json`) && existsSync(`${DIR}tokenizer_cases.json`);

const json = (path: string) => JSON.parse(readFileSync(path, 'utf8'));

describe('minilm WordPiece tokenizer vs HF golden cases', () => {
  it('reproduces every golden case exactly', (ctx) => {
    if (!ready) return ctx.skip();
    const asset = json(`${DIR}tokenizer.json`) as MinilmTokenizerAsset;
    const cases = json(`${DIR}tokenizer_cases.json`) as { text: string; ids: number[] }[];
    const tokenizer = createMinilmTokenizer(asset);
    for (const { text, ids } of cases) {
      expect(tokenizer.encode(text), JSON.stringify(text.slice(0, 40))).toEqual(ids);
    }
  });

  it('asset has the BERT-uncased specials and vocab size', (ctx) => {
    if (!ready) return ctx.skip();
    const asset = json(`${DIR}tokenizer.json`) as MinilmTokenizerAsset;
    expect(asset.vocab).toHaveLength(30522);
    expect(asset.clsId).toBe(101);
    expect(asset.sepId).toBe(102);
    expect(asset.padId).toBe(0);
    expect(asset.unkId).toBe(100);
    expect(asset.vocab[asset.clsId]).toBe('[CLS]');
    expect(asset.vocab[asset.unkId]).toBe('[UNK]');
  });

  it('caps output at maxWordpieces with CLS/SEP intact', (ctx) => {
    if (!ready) return ctx.skip();
    const asset = json(`${DIR}tokenizer.json`) as MinilmTokenizerAsset;
    const tokenizer = createMinilmTokenizer(asset);
    const ids = tokenizer.encode('word '.repeat(1000));
    expect(ids).toHaveLength(asset.maxWordpieces);
    expect(ids[0]).toBe(asset.clsId);
    expect(ids[ids.length - 1]).toBe(asset.sepId);
  });
});
