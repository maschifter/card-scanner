import { describe, expect, it } from 'vitest';
import { hwc4Meta, materialized, memoryStateDict, nn, type Value } from '@tie/core';
import { Pose26 } from '../src/yolo26/pose.ts';
import { Yolo26Model } from '../src/yolo26/model.ts';

/** Same fakeLoad/t3 helpers as eagerYolo26Blocks.test.ts — shape-only, no GPU. */
async function fakeLoad(model: InstanceType<typeof nn.Module>): Promise<void> {
  model.half(); // hwc4 convs need f16 biases; rootless contexts skip the f16 check
  const sd: Record<string, { data: Float32Array | Uint16Array; shape: number[] }> = {};
  for (const [name, p] of model.namedParameters()) {
    sd[name] = {
      data:
        p.shape.dtype === 'f16'
          ? new Uint16Array(p.shape.elems)
          : new Float32Array(p.shape.elems),
      shape: [...p.shape.dims!],
    };
  }
  await model.loadStateDict(memoryStateDict(sd), {
    upload: (_, shape) => materialized(shape, {} as never),
  });
}
// Blocks run HWC4 storage — feed them hwc4-tagged fakes like the model does.
const t3 = (c: number, h: number, w: number): Value => materialized(hwc4Meta(c, h, w), {} as never);
// Model INPUT is row-major (the model converts to hwc4 itself).
const tIn = (c: number, h: number, w: number): Value =>
  materialized({ elems: c * h * w, dtype: 'f32', dims: [c, h, w] }, {} as never);

const CH = [64, 128, 256] as const; // yolo26n P3/P4/P5 channels

describe('Pose26', () => {
  it('per-level output is [4+nc+nk, H, W] (nc=1, nk=51 → 56)', async () => {
    const head = new Pose26(1, 1, CH);
    await fakeLoad(head);
    const [d3, d4, d5] = head.forward([t3(64, 80, 80), t3(128, 40, 40), t3(256, 20, 20)]);
    expect(d3!.shape.dims).toEqual([56, 80, 80]);
    expect(d4!.shape.dims).toEqual([56, 40, 40]);
    expect(d5!.shape.dims).toEqual([56, 20, 20]);
  });

  it('registers one2one_cv4 + one2one_cv4_kpts keys (c4 = max(ch0/4, 17·5) = 85)', () => {
    const head = new Pose26(1, 1, CH);
    const params = Object.fromEntries(Array.from(head.namedParameters()));
    // tower level 0: ConvBlock(64→85 3×3), ConvBlock(85→85 3×3); kpts 1×1 85→51
    expect(params['one2one_cv4.0.0.conv.weight']!.shape.dims).toEqual([85, 64 * 9]);
    expect(params['one2one_cv4.0.1.conv.weight']!.shape.dims).toEqual([85, 85 * 9]);
    expect(params['one2one_cv4.2.0.conv.weight']!.shape.dims).toEqual([85, 256 * 9]);
    expect(params['one2one_cv4_kpts.0.weight']!.shape.dims).toEqual([51, 85]);
    expect(params['one2one_cv4_kpts.2.bias']).toBeDefined();
    // no third tower stage — the 1×1 lives in one2one_cv4_kpts, not the tower
    expect(params['one2one_cv4.0.2.weight']).toBeUndefined();
    // Detect towers still present (inherited), cls tower ends at nc=1
    expect(params['one2one_cv2.0.2.weight']).toBeDefined();
    expect(params['one2one_cv3.0.2.weight']!.shape.dims).toEqual([1, 64]);
  });
});

describe('Yolo26Model pose task', () => {
  it('registers pose head keys at model.23 and defaults numClasses to 1', () => {
    const m = new Yolo26Model('n', { task: 'pose' });
    const names = new Set(Array.from(m.namedParameters()).map(([n]) => n));
    expect(names.has('model.23.one2one_cv4.0.0.conv.weight')).toBe(true);
    expect(names.has('model.23.one2one_cv4_kpts.0.weight')).toBe(true);
    expect(names.has('model.23.one2one_cv2.0.2.weight')).toBe(true); // Detect towers too
    expect(names.has('model.23.proto.cv3.conv.weight')).toBe(false); // no seg proto
  });

  it('640×640 forward yields [56,80,80]/[56,40,40]/[56,20,20]', async () => {
    const m = new Yolo26Model('n', { task: 'pose' });
    await fakeLoad(m);
    const [p3, p4, p5] = m.forward(tIn(3, 640, 640));
    expect(p3.shape.dims).toEqual([56, 80, 80]);
    expect(p4.shape.dims).toEqual([56, 40, 40]);
    expect(p5.shape.dims).toEqual([56, 20, 20]);
  });

  it('detect task is unchanged', async () => {
    const m = new Yolo26Model('n');
    await fakeLoad(m);
    const [p3] = m.forward(tIn(3, 640, 640));
    expect(p3.shape.dims).toEqual([84, 80, 80]);
  });

  it('pose nano parameter count matches the export (≈2.95M)', () => {
    const m = new Yolo26Model('n', { task: 'pose' });
    let total = 0;
    for (const [, p] of m.namedParameters()) {
      total += p.shape.elems;
    }
    // Exported yolo26n-pose.pt keeps 2,953,152 params (detect base at nc=1
    // plus the cv4 keypoint towers ~552k).
    expect(total).toBeGreaterThan(2_700_000);
    expect(total).toBeLessThan(3_200_000);
  });
});
