/** Privacy-filter wrapper contract, offline: padded rows map to per-row
 *  forwards, logits land in each token's slot, pad slots stay zero. GPU
 *  calls are mocked; the fake model's logits encode the token id. */

import { afterEach, describe, expect, it, vi } from 'vitest';
import { PreTrainedModel, Tensor, type PretrainedConfig } from '@huggingface/transformers';

vi.mock('@tie/core', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@tie/core')>()),
  defaultRoot: () => ({ device: {} }),
  inGpuErrorScopes: (_device: unknown, _label: string, fn: () => Promise<unknown>) => fn(),
  toArray: async (v: unknown) => v as Float32Array,
}));

const { PRIVACY_FILTER_LABELS, TiePrivacyFilterForTokenClassification } =
  await import('../src/transformers/privacy-filter/model.ts');
const { assertPrivacyFilterConfig } = await import('../src/transformers/privacy-filter/loader.ts');
const { registerTieBackend, unregisterTieBackend } = await import('../src/transformers/index.ts');
const { V2_NER_CLASS_NAMES } = await import('../src/privacy-filter/config.ts');

const L = PRIVACY_FILTER_LABELS;
const CONFIG = { model_type: 'openai_privacy_filter' } as unknown as PretrainedConfig;

/** Logit k of token id `id` is `id + k / 100`, so every cell says which
 *  token and which label it belongs to. */
const fakeLogits = (ids: readonly number[]): Float32Array =>
  Float32Array.from({ length: ids.length * L }, (_, i) => ids[Math.floor(i / L)]! + (i % L) / 100);

function fakeModel() {
  const calls: number[][] = [];
  const model = {
    // returns the logits directly: the mocked toArray passes them through
    forward: (ids: readonly number[]) => {
      calls.push([...ids]);
      return fakeLogits(ids) as never;
    },
  };
  return { model, calls };
}

const int64 = (values: number[], dims: number[]): Tensor =>
  new Tensor('int64', BigInt64Array.from(values.map(BigInt)), dims);

async function run(ids: number[][], mask?: number[][]) {
  const { model, calls } = fakeModel();
  const wrapped = new TiePrivacyFilterForTokenClassification(CONFIG, model);
  const batch = ids.length;
  const seqLen = ids[0]!.length;
  const inputs: Record<string, Tensor> = { input_ids: int64(ids.flat(), [batch, seqLen]) };
  if (mask) inputs['attention_mask'] = int64(mask.flat(), [batch, seqLen]);
  const out = await wrapped(inputs);
  return { logits: out['logits']!, calls };
}

/** The [L] logit row of token slot t in batch row b. */
const cell = (logits: Tensor, b: number, t: number): Float32Array => {
  const seqLen = logits.dims[1]!;
  return (logits.data as Float32Array).subarray((b * seqLen + t) * L, (b * seqLen + t + 1) * L);
};

describe('privacy-filter through the transformers.js wrapper', () => {
  it('runs one row without a mask and keeps the logit layout', async () => {
    const { logits, calls } = await run([[5, 7, 9]]);
    expect(logits.dims).toEqual([1, 3, L]);
    expect(logits.type).toBe('float32');
    expect(calls).toEqual([[5, 7, 9]]);
    expect(cell(logits, 0, 1)).toEqual(fakeLogits([7]));
  });

  it('skips right padding and zeroes the pad slots', async () => {
    const { logits, calls } = await run([[5, 7, 0, 0]], [[1, 1, 0, 0]]);
    expect(calls).toEqual([[5, 7]]);
    expect(cell(logits, 0, 1)).toEqual(fakeLogits([7]));
    expect(cell(logits, 0, 2).every((v) => v === 0)).toBe(true);
    expect(cell(logits, 0, 3).every((v) => v === 0)).toBe(true);
  });

  it('writes left-padded rows back to their original slots', async () => {
    const { logits, calls } = await run([[0, 0, 5, 7]], [[0, 0, 1, 1]]);
    expect(calls).toEqual([[5, 7]]);
    expect(cell(logits, 0, 0).every((v) => v === 0)).toBe(true);
    expect(cell(logits, 0, 2)).toEqual(fakeLogits([5]));
    expect(cell(logits, 0, 3)).toEqual(fakeLogits([7]));
  });

  it('runs a batch row by row', async () => {
    const { logits, calls } = await run(
      [
        [5, 7, 9],
        [11, 0, 0],
      ],
      [
        [1, 1, 1],
        [1, 0, 0],
      ],
    );
    expect(logits.dims).toEqual([2, 3, L]);
    expect(calls).toEqual([[5, 7, 9], [11]]);
    expect(cell(logits, 1, 0)).toEqual(fakeLogits([11]));
    expect(cell(logits, 1, 2).every((v) => v === 0)).toBe(true);
  });

  it('never calls the model for an all-pad row', async () => {
    const { logits, calls } = await run([[0, 0]], [[0, 0]]);
    expect(calls).toEqual([]);
    expect((logits.data as Float32Array).every((v) => v === 0)).toBe(true);
  });

  it('is a transformers.js model', async () => {
    const wrapped = new TiePrivacyFilterForTokenClassification(CONFIG, fakeModel().model);
    expect(wrapped).toBeInstanceOf(PreTrainedModel);
  });
});

describe('privacy-filter hub config check', () => {
  const good = () =>
    ({
      hidden_size: 640,
      num_hidden_layers: 8,
      num_local_experts: 128,
      num_experts_per_tok: 4,
      id2label: Object.fromEntries(V2_NER_CLASS_NAMES.map((n, i) => [String(i), n])),
    }) as unknown as PretrainedConfig;

  it('accepts the hub config', () => {
    expect(() => assertPrivacyFilterConfig(good())).not.toThrow();
  });

  it('rejects other dimensions', () => {
    const cfg = good() as unknown as Record<string, unknown>;
    cfg['num_hidden_layers'] = 12;
    expect(() => assertPrivacyFilterConfig(cfg as unknown as PretrainedConfig)).toThrow(
      /num_hidden_layers is 12/,
    );
  });

  it('rejects labels in another order', () => {
    const cfg = good() as unknown as { id2label: Record<string, string> };
    cfg.id2label['1'] = 'B-secret';
    expect(() => assertPrivacyFilterConfig(cfg as unknown as PretrainedConfig)).toThrow(
      /label 1 is 'B-secret'/,
    );
  });
});

describe('privacy-filter registration', () => {
  afterEach(() => unregisterTieBackend());

  it('registers openai/privacy-filter by default', async () => {
    registerTieBackend();
    await expect(
      PreTrainedModel.from_pretrained('someone/else', { config: CONFIG }),
    ).rejects.toThrow(/openai\/privacy-filter/);
  });
});
