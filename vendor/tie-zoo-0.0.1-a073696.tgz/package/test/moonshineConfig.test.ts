import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  MOONSHINE_BASE,
  MOONSHINE_TINY,
  assertConfigMatches,
  configFromCheckpoint,
} from '../src/moonshine/config.ts';

const configPath = (model: string) =>
  join(import.meta.dirname, `../../../fixtures/moonshine/${model}/config.json`);

/** Minimal synthetic 4.48-era checkpoint config (the fixture's key subset). */
const TINY_JSON: Record<string, unknown> = {
  hidden_size: 288,
  intermediate_size: 1152,
  encoder_num_hidden_layers: 6,
  decoder_num_hidden_layers: 6,
  encoder_num_attention_heads: 8,
  decoder_num_attention_heads: 8,
  encoder_num_key_value_heads: 8,
  decoder_num_key_value_heads: 8,
  partial_rotary_factor: 0.9,
  rope_theta: 10000,
  attention_bias: false,
  vocab_size: 32768,
  max_position_embeddings: 194,
  bos_token_id: 1,
  eos_token_id: 2,
  decoder_start_token_id: 1,
};

describe('configFromCheckpoint', () => {
  it('parses 4.48-era top-level rope keys into the tiny preset', () => {
    expect(configFromCheckpoint(TINY_JSON)).toEqual(MOONSHINE_TINY);
  });

  it('parses the v5 rope_parameters layout to the same result', () => {
    const v5: Record<string, unknown> = {
      ...TINY_JSON,
      rope_parameters: { rope_theta: 10000, partial_rotary_factor: 0.9 },
    };
    delete v5.rope_theta;
    delete v5.partial_rotary_factor;
    expect(configFromCheckpoint(v5)).toEqual(MOONSHINE_TINY);
  });

  it('prefers top-level rope keys over rope_parameters when both are present', () => {
    const both: Record<string, unknown> = {
      ...TINY_JSON,
      rope_parameters: { rope_theta: 999, partial_rotary_factor: 0.5 },
    };
    expect(configFromCheckpoint(both)).toEqual(MOONSHINE_TINY);
  });

  it('derives rotaryDim = floor(headDim · factor) — both presets land on 32', () => {
    expect(configFromCheckpoint(TINY_JSON).rotaryDim).toBe(32); // int(36 · 0.9)
    expect(Math.floor(52 * 0.62)).toBe(MOONSHINE_BASE.rotaryDim); // int(52 · 0.62)
  });

  it('rejects structural violations loudly', () => {
    expect(() => configFromCheckpoint({ ...TINY_JSON, hidden_size: 289 })).toThrow(/divisible/);
    expect(() => configFromCheckpoint({ ...TINY_JSON, encoder_num_key_value_heads: 4 })).toThrow(
      /key_value/,
    );
    expect(() => configFromCheckpoint({ ...TINY_JSON, attention_bias: true })).toThrow(
      /attention_bias/,
    );
    expect(() => configFromCheckpoint({ ...TINY_JSON, decoder_num_attention_heads: 4 })).toThrow(
      /heads differ/,
    );
    const noRope = { ...TINY_JSON };
    delete noRope.rope_theta;
    delete noRope.partial_rotary_factor;
    expect(() => configFromCheckpoint(noRope)).toThrow(/rope_theta/);
  });

  it('assertConfigMatches names the drifted key', () => {
    const drifted = { ...MOONSHINE_TINY, maxPositions: 512 };
    expect(() => assertConfigMatches(drifted, MOONSHINE_TINY)).toThrow(/maxPositions/);
    expect(() => assertConfigMatches(MOONSHINE_TINY, MOONSHINE_TINY)).not.toThrow();
  });
});

for (const { model, preset } of [
  { model: 'tiny', preset: MOONSHINE_TINY },
  { model: 'base', preset: MOONSHINE_BASE },
]) {
  describe.skipIf(!existsSync(configPath(model)))(`checkpoint config fixture (${model})`, () => {
    it(`the exported config.json parses to exactly the ${model} preset`, () => {
      const json = JSON.parse(readFileSync(configPath(model), 'utf8'));
      const parsed = configFromCheckpoint(json);
      expect(parsed).toEqual(preset);
      expect(() => assertConfigMatches(parsed, preset)).not.toThrow();
    });
  });
}
