/** Yolo26 wrapper contract, offline: `pixel_values` goes to the detector as
 *  one image, the top anchors come back as yolos-shaped logits and boxes.
 *  The top-k conversion is checked on hand-built levels, the variant pick on
 *  hub ids. */

import { afterEach, describe, expect, it, vi } from 'vitest';
import { PreTrainedModel, Tensor, type PretrainedConfig } from '@huggingface/transformers';

let gpu = true;
vi.mock('@tie/core', async (importOriginal) => ({
  ...(await importOriginal<typeof import('@tie/core')>()),
  defaultRoot: () => {
    if (!gpu) throw new Error('tie: no default device');
    return { device: {} };
  },
  inGpuErrorScopes: (_device: unknown, _label: string, fn: () => Promise<unknown>) => fn(),
}));

const { TieYolosForObjectDetection } = await import('../src/transformers/yolo26/model.ts');
type Yolo26Detector = import('../src/transformers/yolo26/model.ts').Yolo26Detector;
import { selectTopAnchors, topIndices } from '../src/transformers/yolo26/output.ts';
import { yolo26Loader, yolo26Variant } from '../src/transformers/yolo26/loader.ts';
import { registerTieBackend, unregisterTieBackend } from '../src/transformers/index.ts';
import type { RawLevel } from '../src/yolo26/pipeline.ts';

const CONFIG = { model_type: 'yolos' } as unknown as PretrainedConfig;

/** A [4+nc, h, w] level filled with -20, so untouched anchors sort last;
 *  the given anchors get their box and logits. */
function level(
  h: number,
  w: number,
  stride: number,
  nc: number,
  cells: { i: number; ltrb: number[]; logits: number[] }[],
): RawLevel {
  const hw = h * w;
  const data = new Float32Array((4 + nc) * hw).fill(-20);
  for (const { i, ltrb, logits } of cells) {
    ltrb.forEach((v, k) => (data[k * hw + i] = v));
    logits.forEach((v, c) => (data[(4 + c) * hw + i] = v));
  }
  return { data, h, w, stride };
}

describe('topIndices', () => {
  it('matches a full sort, ties broken by index', () => {
    const score = new Float32Array(5000);
    let seed = 7;
    for (let i = 0; i < score.length; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      score[i] = (seed % 97) - 48; // many ties
    }
    const sorted = Array.from(score.keys()).sort((a, b) => score[b]! - score[a]! || a - b);
    expect(topIndices(score, 300)).toEqual(sorted.slice(0, 300));
    expect(topIndices(score, 7000)).toEqual(sorted);
    expect(topIndices(new Float32Array(0), 3)).toEqual([]);
  });
});

describe('selectTopAnchors', () => {
  const nc = 3;
  // 2×2 at stride 8 and 1×1 at stride 16 over a 32 px input
  const levels = [
    level(2, 2, 8, nc, [
      { i: 3, ltrb: [1, 1, 1, 1], logits: [-1, 2, 0] },
      { i: 0, ltrb: [0.5, 0.5, 0.5, 0.5], logits: [5, -3, -3] },
    ]),
    level(1, 1, 16, nc, [{ i: 0, ltrb: [1, 0, 1, 0], logits: [0, 0, 1] }]),
  ];

  it('orders anchors by their best class logit and keeps the raw rows', () => {
    const top = selectTopAnchors(levels, { numClasses: nc, maxDet: 3, inputSize: 32 });
    expect(top.count).toBe(3);
    expect(Array.from(top.logits)).toEqual([5, -3, -3, -1, 2, 0, 0, 0, 1]);
  });

  it('writes boxes as normalized [cx, cy, w, h]', () => {
    const top = selectTopAnchors(levels, { numClasses: nc, maxDet: 3, inputSize: 32 });
    const box = (k: number) => Array.from(top.boxes.subarray(k * 4, k * 4 + 4));
    // level 0 cell 0: anchor (0.5, 0.5) grid, ±0.5 → 0..8 px
    expect(box(0)).toEqual([4 / 32, 4 / 32, 8 / 32, 8 / 32]);
    // level 0 cell 3: anchor (1.5, 1.5), ±1 → 4..20 px
    expect(box(1)).toEqual([12 / 32, 12 / 32, 16 / 32, 16 / 32]);
    // level 1: anchor (0.5, 0.5) at stride 16 → (8, 8) px, l=r=1 → 32 wide, 0 tall
    expect(box(2)).toEqual([0.25, 0.25, 1, 0]);
  });

  it('caps at maxDet and at the anchor count', () => {
    expect(selectTopAnchors(levels, { numClasses: nc, maxDet: 2, inputSize: 32 }).count).toBe(2);
    expect(selectTopAnchors(levels, { numClasses: nc, maxDet: 99, inputSize: 32 }).count).toBe(5);
  });
});

describe('TieYolosForObjectDetection', () => {
  const size = 8;
  const nc = 2;
  const calls: Float32Array[] = [];
  const detector: Yolo26Detector = {
    inputSize: size,
    numClasses: nc,
    maxDet: 2,
    async run(pixels) {
      calls.push(pixels);
      return [level(1, 1, size, nc, [{ i: 0, ltrb: [1, 1, 1, 1], logits: [1, 3] }])];
    },
  };
  const model = new TieYolosForObjectDetection(CONFIG, detector);
  const image = (dims: number[]) =>
    new Tensor('float32', new Float32Array(dims.reduce((a, b) => a * b, 1)), dims);

  it('returns yolos-shaped logits and pred_boxes for one image', async () => {
    const out = await model({ pixel_values: image([1, 3, size, size]) });
    expect(out['logits']!.dims).toEqual([1, 1, nc]);
    expect(Array.from(out['logits']!.data as Float32Array)).toEqual([1, 3]);
    expect(out['pred_boxes']!.dims).toEqual([1, 1, 4]);
    expect(Array.from(out['pred_boxes']!.data as Float32Array)).toEqual([0.5, 0.5, 2, 2]);
    expect(calls[0]!.length).toBe(3 * size * size);
  });

  it('rejects batches and other sizes', async () => {
    await expect(model({ pixel_values: image([2, 3, size, size]) })).rejects.toThrow(/one 8×8/);
    await expect(model({ pixel_values: image([1, 3, 16, 16]) })).rejects.toThrow(/one 8×8/);
    await expect(model({})).rejects.toThrow(/pixel_values/);
  });
});

describe('yolo26 loader', () => {
  afterEach(() => {
    unregisterTieBackend();
    gpu = true;
  });

  it('reads the variant off the hub id', () => {
    expect(yolo26Variant('onnx-community/yolo26n-ONNX')).toBe('n');
    expect(yolo26Variant('onnx-community/yolo26x-ONNX')).toBe('x');
    expect(yolo26Variant('me/YOLO26S-custom')).toBe('s');
    expect(() => yolo26Variant('onnx-community/yolo26n-pose-ONNX')).not.toThrow();
    expect(() => yolo26Variant('onnx-community/yolos-tiny')).toThrow(/variant/);
  });

  it('loads under a hub id once registered and fails without a device', async () => {
    gpu = false;
    registerTieBackend({
      models: { 'onnx-community/yolo26n-ONNX': yolo26Loader('/weights/yolo26n.safetensors') },
    });
    await expect(
      PreTrainedModel.from_pretrained('onnx-community/yolo26n-ONNX', { config: CONFIG }),
    ).rejects.toThrow(/loading 'onnx-community\/yolo26n-ONNX' failed/);
  });
});
