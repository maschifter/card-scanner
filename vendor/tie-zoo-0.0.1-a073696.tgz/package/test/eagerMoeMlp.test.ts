import { describe, expect, it } from 'vitest';
import { EagerMoeMlp } from '../src/privacy-filter/moeMlp.ts';

describe('EagerMoeMlp structure', () => {
  it('registers checkpoint-compatible parameter names', () => {
    const m = new EagerMoeMlp({ experts: 8, hidden: 64, weightFormat: 'f32' });
    const names = Array.from(m.namedParameters())
      .map(([n]) => n)
      .sort();
    expect(names).toEqual(
      [
        'gate.bias',
        'gate.weight',
        'gluBias',
        'gluWeight',
        'linBias',
        'linWeight',
        'norm.scale',
        'outBias',
        'outWeight',
      ].sort(),
    );
  });

  it('shapes expert weights per format: f32 plain, quant packs into words', () => {
    const f32 = new EagerMoeMlp({ experts: 8, hidden: 64, weightFormat: 'f32' });
    expect(f32.gluWeight.shape).toEqual({ elems: 8 * 64 * 64, dtype: 'f32', dims: [8 * 64, 64] });
    // Biases are f32 in every format.
    expect(f32.gluBias.shape).toEqual({ elems: 8 * 64, dtype: 'f32', dims: [8, 64] });

    const q8 = new EagerMoeMlp({ experts: 8, hidden: 64, weightFormat: 'quantInt8' });
    // Logical dims stay [E·H, H]; quantW elems is the u32 word count.
    expect(q8.gluWeight.shape).toEqual({
      elems: (8 * 64 * 64) / 4,
      dtype: 'quantW',
      dims: [8 * 64, 64],
    });
  });
});
