/** EagerModel.loadStateDict against the real pf checkpoint: every GPU param
 *  binds through the upload sink, and embedding.weight lands CPU-side as raw
 *  bf16 bits on the model's nn.Embedding (never uploaded). */
import { existsSync, openSync, readSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { fromSafetensors, materialized, nn, type RangeSource, type ValueMeta } from '@tie/core';
import { EagerModel } from '../src/privacy-filter/model.ts';

/** node:fs's readFileSync refuses files >2GiB (the real f16 checkpoint is
 *  ~2.6GiB); read by range off a file descriptor instead — matches what
 *  httpRangeSource does over HTTP, just against a local fd. */
function fileRangeSource(path: string): RangeSource {
  const fd = openSync(path, 'r');
  return {
    read(begin, end) {
      const length = end - begin;
      const buf = Buffer.alloc(length);
      let done = 0;
      while (done < length) {
        const n = readSync(fd, buf, done, length - done, begin + done);
        if (n === 0) break;
        done += n;
      }
      return Promise.resolve(new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength));
    },
  };
}

const FILE = join(import.meta.dirname, '../../../fixtures/weights/pf-f16.safetensors');

describe('EagerModel.loadStateDict — real file', () => {
  it.skipIf(!existsSync(FILE))(
    'loads the full pf checkpoint end-to-end with a fake GPU',
    async () => {
      const sd = await fromSafetensors(fileRangeSource(FILE));
      expect(sd.metadata['model']).toBe('privacy-filter');

      const model = new EagerModel({
        blocks: 8,
        experts: 128,
        vocab: 200064,
        logits: 33,
        weightFormat: 'f32',
      });
      // Production halves an unquantized pf (detector.ts) — that is also the
      // zero-copy path for this F16 checkpoint, so load it the same way here.
      model.half({ enabledFeatures: new Set(['shader-f16']) } as never);
      const calls: Array<{ data: Float32Array | Uint16Array | Uint32Array; shape: ValueMeta }> = [];
      const upload = (data: Float32Array | Uint16Array | Uint32Array, shape: ValueMeta) => {
        calls.push({ data, shape });
        return materialized(shape, {} as never);
      };

      await model.loadStateDict(sd, { upload });

      expect(calls.length).toBeGreaterThan(0);
      for (const call of calls) expect(call.data.length).toBe(call.shape.elems);

      // the embedding bound CPU-side, not through the upload sink
      expect((model.embedding.weight as nn.CpuParameter).data.length).toBe(200064 * 640);
    },
  );
});
