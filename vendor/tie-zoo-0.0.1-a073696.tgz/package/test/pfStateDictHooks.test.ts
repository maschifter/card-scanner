/** The hub-checkpoint mapping on a toy fake (one block, 2 experts, hidden
 *  3): names, shapes, and where the data lands. */

import { describe, expect, it } from 'vitest';
import { memoryStateDict } from '../../core/src/weights/safetensors.ts';
import { transformHfPrivacyFilterStateDict } from '../src/privacy-filter/stateDictHooks.ts';

const E = 2; // experts
const K = 3; // hidden (matmul input)
const H = 3; // expert width (each half of gate_up)
const Q = 4; // q rows, k and v get 1 each

/** 1, 2, 3, ... so every value says where it came from. */
const ramp = (shape: number[]): { data: Float32Array; shape: number[] } => {
  const n = shape.reduce((a, b) => a * b, 1);
  return { data: Float32Array.from({ length: n }, (_, i) => i + 1), shape };
};

function hubStateDict() {
  const layer = 'model.layers.0';
  return memoryStateDict({
    'model.embed_tokens.weight': ramp([10, K]),
    'model.norm.weight': ramp([K]),
    'score.weight': ramp([5, K]),
    'score.bias': ramp([5]),
    [`${layer}.input_layernorm.weight`]: ramp([K]),
    [`${layer}.post_attention_layernorm.weight`]: ramp([K]),
    [`${layer}.self_attn.q_proj.weight`]: ramp([Q, K]),
    [`${layer}.self_attn.q_proj.bias`]: ramp([Q]),
    [`${layer}.self_attn.k_proj.weight`]: ramp([1, K]),
    [`${layer}.self_attn.k_proj.bias`]: ramp([1]),
    [`${layer}.self_attn.v_proj.weight`]: ramp([1, K]),
    [`${layer}.self_attn.v_proj.bias`]: ramp([1]),
    [`${layer}.self_attn.o_proj.weight`]: ramp([K, Q]),
    [`${layer}.self_attn.o_proj.bias`]: ramp([K]),
    [`${layer}.self_attn.sinks`]: ramp([2]),
    [`${layer}.mlp.router.weight`]: ramp([E, K]),
    [`${layer}.mlp.router.bias`]: ramp([E]),
    [`${layer}.mlp.experts.gate_up_proj`]: ramp([E, K, 2 * H]),
    [`${layer}.mlp.experts.gate_up_proj_bias`]: ramp([E, 2 * H]),
    [`${layer}.mlp.experts.down_proj`]: ramp([E, H, K]),
    [`${layer}.mlp.experts.down_proj_bias`]: ramp([E, K]),
  });
}

const EXPECTED_NAMES = [
  'embedding.weight',
  'norm.scale',
  'unembedding.weight',
  'block.0.attn.norm.scale',
  'block.0.mlp.norm.scale',
  'block.0.attn.qkv.weight',
  'block.0.attn.qkv.bias',
  'block.0.attn.out.weight',
  'block.0.attn.out.bias',
  'block.0.attn.sinks',
  'block.0.mlp.gate.weight',
  'block.0.mlp.gate.bias',
  'block.0.mlp.gluWeight',
  'block.0.mlp.linWeight',
  'block.0.mlp.gluBias',
  'block.0.mlp.linBias',
  'block.0.mlp.outWeight',
  'block.0.mlp.outBias',
];

describe('privacy-filter hub checkpoint mapping', () => {
  it('produces exactly the names and shapes EagerModel loads', () => {
    const sd = hubStateDict();
    transformHfPrivacyFilterStateDict(sd);
    expect([...sd.tensors.keys()].sort()).toEqual([...EXPECTED_NAMES].sort());
    expect(sd.metadata['model']).toBe('privacy-filter');
    const shape = (name: string) => sd.tensors.get(name)!.shape;
    expect(shape('block.0.attn.qkv.weight')).toEqual([Q + 2, K]);
    expect(shape('block.0.attn.qkv.bias')).toEqual([Q + 2]);
    expect(shape('block.0.mlp.gluWeight')).toEqual([E * K, H]);
    expect(shape('block.0.mlp.linWeight')).toEqual([E * K, H]);
    expect(shape('block.0.mlp.gluBias')).toEqual([E, H]);
    expect(shape('block.0.mlp.outWeight')).toEqual([E * H, K]);
    expect(shape('block.0.mlp.outBias')).toEqual([E, K]);
  });

  it('stacks q, k and v by rows', async () => {
    const sd = hubStateDict();
    transformHfPrivacyFilterStateDict(sd);
    const w = await sd.tensors.get('block.0.attn.qkv.weight')!.f32();
    // q rows are 1..12, then k's row 1..3, then v's row 1..3
    expect(Array.from(w)).toEqual([...ramp([Q, K]).data, 1, 2, 3, 1, 2, 3]);
    const b = await sd.tensors.get('block.0.attn.qkv.bias')!.f32();
    expect(Array.from(b)).toEqual([1, 2, 3, 4, 1, 1]);
  });

  it('splits gate_up into the left and right column halves', async () => {
    const sd = hubStateDict();
    transformHfPrivacyFilterStateDict(sd);
    const glu = await sd.tensors.get('block.0.mlp.gluWeight')!.f32();
    const lin = await sd.tensors.get('block.0.mlp.linWeight')!.f32();
    // source row r holds 6r+1 .. 6r+6; glu takes the first 3, lin the last 3
    const rows = E * K;
    for (let r = 0; r < rows; r++) {
      expect(Array.from(glu.subarray(r * H, (r + 1) * H))).toEqual([1, 2, 3].map((v) => 6 * r + v));
      expect(Array.from(lin.subarray(r * H, (r + 1) * H))).toEqual([4, 5, 6].map((v) => 6 * r + v));
    }
    const gluBias = await sd.tensors.get('block.0.mlp.gluBias')!.f32();
    const linBias = await sd.tensors.get('block.0.mlp.linBias')!.f32();
    expect(Array.from(gluBias)).toEqual([1, 2, 3, 7, 8, 9]);
    expect(Array.from(linBias)).toEqual([4, 5, 6, 10, 11, 12]);
    // a half can be read again after both were taken once
    expect(await sd.tensors.get('block.0.mlp.gluWeight')!.f32()).toEqual(glu);
  });

  it('folds down_proj into rows without touching the data', async () => {
    const sd = hubStateDict();
    transformHfPrivacyFilterStateDict(sd);
    const out = await sd.tensors.get('block.0.mlp.outWeight')!.f32();
    expect(Array.from(out)).toEqual(Array.from(ramp([E, H, K]).data));
  });

  it('fails loudly on a checkpoint with a tensor missing', () => {
    const sd = hubStateDict();
    sd.tensors.delete('model.layers.0.self_attn.k_proj.weight');
    expect(() => transformHfPrivacyFilterStateDict(sd)).toThrow(/missing tensor/);
  });
});
