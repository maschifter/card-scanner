import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { buildLabelInfo, V2_NER_CLASS_NAMES } from '../src/privacy-filter/config.ts';
import {
  detectedSpansFromLabels,
  labelsToSpans,
  labelPlaceholder,
} from '../src/privacy-filter/spans.ts';
import { createTokenizer } from '../src/privacy-filter/tokenizer.ts';

const FIXTURES = join(import.meta.dirname, '../../../fixtures');
const info = buildLabelInfo(V2_NER_CLASS_NAMES);

describe('labelsToSpans', () => {
  it('merges B-I-E runs and singletons', () => {
    // B-private_email(13) I(14) E(15) O(0) S-secret(32)
    const spans = labelsToSpans([13, 14, 15, 0, 32], info);
    expect(spans).toEqual([
      { label: 4, tokenStart: 0, tokenEnd: 3 },
      { label: 8, tokenStart: 4, tokenEnd: 5 },
    ]);
  });
});

describe('labelPlaceholder', () => {
  it('formats labels', () => {
    expect(labelPlaceholder('private_email')).toBe('<PRIVATE_EMAIL>');
  });
});

describe('end-to-end span reconstruction from reference labels', () => {
  const tok = createTokenizer();
  for (const name of ['email_short', 'mixed_long', 'unicode', 'negatives']) {
    it(`reproduces reference spans for ${name}`, () => {
      const meta = JSON.parse(readFileSync(join(FIXTURES, 'cases', name, 'meta.json'), 'utf8'));
      const spans = detectedSpansFromLabels(meta.viterbi_labels, meta.token_ids, tok, info);
      // Fixture offsets are Python code-point indices; compare by span text+label,
      // which is offset-convention independent.
      expect(spans.map((s) => ({ label: s.label, text: s.text }))).toEqual(
        meta.spans.map((s: { label: string; text: string }) => ({
          label: s.label,
          text: s.text,
        })),
      );
    });
  }
});
