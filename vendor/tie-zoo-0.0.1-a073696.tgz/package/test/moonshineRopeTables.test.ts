import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { MOONSHINE_TINY } from '../src/moonshine/config.ts';
import { buildRopeTables, ropeQkScale } from '../src/moonshine/rope.ts';

const ROPE_BIN = join(import.meta.dirname, '../../../fixtures/moonshine/tiny/rope.bin');
const HD = MOONSHINE_TINY.headDim; // 36
const R = MOONSHINE_TINY.rotaryDim; // 32
const S = ropeQkScale(HD);

describe('buildRopeTables', () => {
  const tables = buildRopeTables(4, MOONSHINE_TINY);

  it('position 0 is the scaled identity rotation', () => {
    for (let p = 0; p < R / 2; p++) {
      expect(tables.cos[2 * p]).toBeCloseTo(S, 7); // cos(0)·s
      expect(tables.sin[2 * p]).toBe(0);
    }
  });

  it('follows inv_freq = theta^(−2p/rotaryDim) at position 1', () => {
    for (let p = 0; p < R / 2; p++) {
      const angle = MOONSHINE_TINY.ropeTheta ** (-(2 * p) / R);
      expect(tables.cos[HD + 2 * p]).toBeCloseTo(Math.cos(angle) * S, 6);
      expect(tables.sin[HD + 2 * p]).toBeCloseTo(Math.sin(angle) * S, 6);
    }
  });

  it('pair-duplicates every rotary column exactly', () => {
    for (let t = 0; t < 4; t++) {
      for (let p = 0; p < R / 2; p++) {
        expect(tables.cos[t * HD + 2 * p]).toBe(tables.cos[t * HD + 2 * p + 1]);
        expect(tables.sin[t * HD + 2 * p]).toBe(tables.sin[t * HD + 2 * p + 1]);
      }
    }
  });

  it('fills the partial-rotary identity region with (s, 0)', () => {
    for (let t = 0; t < 4; t++) {
      for (let c = R; c < HD; c++) {
        expect(tables.cos[t * HD + c]).toBe(Math.fround(S));
        expect(tables.sin[t * HD + c]).toBe(0);
      }
    }
  });

  it('row t depends only on t — decoder sliceRows == rebuild at any length', () => {
    const short = buildRopeTables(50, MOONSHINE_TINY);
    const long = buildRopeTables(194, MOONSHINE_TINY);
    for (const t of [0, 17, 49]) {
      expect(long.cos.slice(t * HD, (t + 1) * HD)).toEqual(short.cos.slice(t * HD, (t + 1) * HD));
      expect(long.sin.slice(t * HD, (t + 1) * HD)).toEqual(short.sin.slice(t * HD, (t + 1) * HD));
    }
  });
});

describe.skipIf(!existsSync(ROPE_BIN))('rope tables vs the HF dump', () => {
  // rope.bin is [2, 256, 32]: [cos|sin][position][HF width-32]. HF's width-32
  // layout is HALF-duplicated — cat(freqs, freqs) = [c0..c15 | c0..c15]; the
  // repeat_interleave(2) to pair-duplicated form happens inside
  // apply_rotary_pos_emb, which is what our table layout pre-bakes.
  const POS = 256;
  const buf = readFileSync(ROPE_BIN);
  const all = new Float32Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
  const cosRef = all.subarray(0, POS * R);
  const sinRef = all.subarray(POS * R);

  it('the dump really is half-duplicated (layout assumption tripwire)', () => {
    for (const t of [0, 1, 100, 255]) {
      for (const p of [0, 7, 15]) {
        expect(cosRef[t * R + p]).toBe(cosRef[t * R + p + R / 2]);
        expect(sinRef[t * R + p]).toBe(sinRef[t * R + p + R / 2]);
      }
    }
  });

  it('our scaled tables match the dump across all 256 positions', () => {
    const tables = buildRopeTables(POS, MOONSHINE_TINY);
    let maxDiff = 0;
    for (let t = 0; t < POS; t++) {
      for (let p = 0; p < R / 2; p++) {
        maxDiff = Math.max(
          maxDiff,
          Math.abs(tables.cos[t * HD + 2 * p]! - S * cosRef[t * R + p]!),
          Math.abs(tables.sin[t * HD + 2 * p]! - S * sinRef[t * R + p]!),
        );
      }
    }
    // HF computes angles in f32 (t up to 255 → ~1e-5 angle noise); we use f64.
    expect(maxDiff).toBeLessThan(1e-4);
  });
});
