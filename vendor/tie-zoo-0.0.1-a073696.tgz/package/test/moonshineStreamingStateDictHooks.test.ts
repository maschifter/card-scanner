import { describe, expect, it } from 'vitest';
import { materialized, memoryStateDict, type ValueMeta } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
// Reuse the @tie/core test helper via a relative import.
import { fakeGpuBuffer } from '../../core/test/helpers.ts';
import { MoonshineStreamingModel } from '../src/moonshine-streaming/model.ts';
import { transformStreamingStateDict } from '../src/moonshine-streaming/stateDictHooks.ts';
import {
  MINI_STREAMING,
  MINI_STREAMING_PROJ,
  buildHfRecord,
  streamingHfShapes,
} from './moonshineTestData.ts';

const CFG = MINI_STREAMING;
const EH = CFG.enc.hidden;
const ENC_QW = CFG.enc.heads * CFG.enc.headDim;

/** A fake root that reports shader-f16 support, for model.half() without a
 *  real GPU device — this file never uploads to an actual buffer. */
const fakeF16Root = { enabledFeatures: new Set(['shader-f16']) } as unknown as TgpuRoot;

/** Collect uploads in namedParameters() order; bind fake Values. */
function collector() {
  const calls: Array<{ data: Float32Array | Uint32Array | Uint16Array; shape: ValueMeta }> = [];
  const upload = (data: Float32Array | Uint32Array | Uint16Array, shape: ValueMeta) => {
    calls.push({ data, shape });
    return materialized(shape, fakeGpuBuffer({}));
  };
  return { calls, upload };
}

/** Load a synthetic HF record into a model; return uploads keyed by name. */
async function loadFake(
  model: MoonshineStreamingModel,
): Promise<Map<string, { data: Float32Array | Uint32Array | Uint16Array; shape: ValueMeta }>> {
  const { calls, upload } = collector();
  await model.loadStateDict(buildHfRecord(streamingHfShapes(model.cfg)), { upload });
  const names = [...model.namedParameters()].map(([n]) => n);
  expect(calls.length).toBe(names.length);
  return new Map(names.map((n, i) => [n, calls[i]!]));
}

describe('transformStreamingStateDict', () => {
  it('maps the full HF key set onto namedParameters(), both config shapes', () => {
    for (const cfg of [MINI_STREAMING, MINI_STREAMING_PROJ]) {
      const sd = memoryStateDict(buildHfRecord(streamingHfShapes(cfg)));
      transformStreamingStateDict(sd, '', cfg);
      const expected = [...new MoonshineStreamingModel(cfg).namedParameters()].map(([n]) => n);
      expect([...sd.tensors.keys()].sort()).toEqual(expected.sort());
    }
  });

  it('synthesizes cmvn as ones and k as exp(log_k)', async () => {
    const logK = Float32Array.from([0.5]);
    const sd = memoryStateDict(
      buildHfRecord(streamingHfShapes(CFG), { 'model.encoder.embedder.comp.log_k': logK }),
    );
    transformStreamingStateDict(sd, '', CFG);
    expect([...(await sd.tensors.get('frontend.cmvn.weight')!.f32())]).toEqual([1, 1, 1, 1]);
    const k = await sd.tensors.get('frontend.k')!.f32();
    expect(k.length).toBe(1);
    expect(k[0]).toBeCloseTo(Math.exp(0.5), 6);
  });

  it('offsets encoder gamma norms by +1; decoder norms pass through', async () => {
    const gamma = new Float32Array(EH).fill(0.25);
    const plain = new Float32Array(CFG.dec.hidden).fill(0.25);
    const sd = memoryStateDict(
      buildHfRecord(streamingHfShapes(CFG), {
        'model.encoder.layers.0.input_layernorm.gamma': gamma,
        'model.decoder.layers.0.input_layernorm.weight': plain,
      }),
    );
    transformStreamingStateDict(sd, '', CFG);
    expect((await sd.tensors.get('encoder.layers.0.norm1.weight')!.f32())[0]).toBeCloseTo(1.25, 6);
    expect((await sd.tensors.get('decoder.layers.0.norm1.weight')!.f32())[0]).toBeCloseTo(0.25, 6);
  });

  it('scales the encoder qkv q rows by 1/√headDim; decoder self-attn stays unscaled', async () => {
    const ones = (n: number) => new Float32Array(n).fill(1);
    const sd = memoryStateDict(
      buildHfRecord(streamingHfShapes(CFG), {
        'model.encoder.layers.0.self_attn.q_proj.weight': ones(ENC_QW * EH),
        'model.encoder.layers.0.self_attn.k_proj.weight': ones(ENC_QW * EH),
        'model.decoder.layers.0.self_attn.q_proj.weight': ones(
          CFG.dec.heads * CFG.dec.headDim * CFG.dec.hidden,
        ),
      }),
    );
    transformStreamingStateDict(sd, '', CFG);
    const enc = await sd.tensors.get('encoder.layers.0.attn.qkv.weight')!.f32();
    expect(enc[0]).toBeCloseTo(1 / Math.sqrt(CFG.enc.headDim), 6); // q rows scaled
    expect(enc[ENC_QW * EH]).toBe(1); // k rows untouched
    const dec = await sd.tensors.get('decoder.layers.0.selfAttn.qkv.weight')!.f32();
    expect(dec[0]).toBe(1);
  });

  it('names the tensor when the checkpoint is missing one', async () => {
    const record = buildHfRecord(streamingHfShapes(CFG));
    delete record['model.encoder.embedder.comp.log_k'];
    await expect(
      new MoonshineStreamingModel(CFG).loadStateDict(record, { upload: collector().upload }),
    ).rejects.toThrow(/log_k/);
  });
});

/** End-to-end through loadStateDict: what actually lands on the (fake)
 *  device — engine layouts after the core hooks, and the f16 dtype split. */
describe('bound state', () => {
  it('f32: fused weights, convs and the adapter arrive in engine layouts', async () => {
    const cfg = MINI_STREAMING_PROJ;
    const bound = await loadFake(new MoonshineStreamingModel(cfg));
    const [eh, dh] = [cfg.enc.hidden, cfg.dec.hidden];
    const decQw = cfg.dec.heads * cfg.dec.headDim;
    // The Linear hook transposes the stacks: [3·qw, d] → [d, 3·qw].
    expect(bound.get('encoder.layers.0.attn.qkv.weight')!.shape.dims).toEqual([eh, 3 * ENC_QW]);
    expect(bound.get('decoder.layers.0.crossAttn.kv.weight')!.shape.dims).toEqual([dh, 2 * decQw]);
    // The Conv1d hook permutes to tap-major: (2·eh, eh, 5) → [5·eh, 2·eh].
    expect(bound.get('frontend.conv1.weight')!.shape.dims).toEqual([5 * eh, 2 * eh]);
    expect(bound.get('adapter.proj.weight')!.shape.dims).toEqual([eh, dh]);
    expect(bound.get('adapter.posEmb')!.shape.dims).toEqual([cfg.maxPositions, eh]);
  });

  it('half(): every float parameter goes f16, none packed', async () => {
    const model = new MoonshineStreamingModel(CFG);
    model.half(fakeF16Root);
    const bound = await loadFake(model);
    // half() is blanket — matmul weights, conv weights, norms and biases all
    // retype to f16 alike; there is no per-tensor exemption in this model.
    for (const [name, entry] of bound) expect(entry.data, name).toBeInstanceOf(Uint16Array);
  });
});
