/** Build a valid safetensors byte blob in memory for tests: 8-byte LE header
 *  length, JSON header (data_offsets relative to payload start), payload.
 *  Local copy of packages/core/test/safetensorsHelpers.ts — cross-package
 *  test-dir imports don't resolve, so this trio is duplicated here. */
import { f32ToF16Bits, type SafeDtype } from '@tie/core';

export function encodeSafetensors(
  tensors: Record<string, { dtype: SafeDtype; shape: number[]; data: Uint8Array }>,
  metadata?: Record<string, string>,
): Uint8Array {
  const header: Record<string, unknown> = {};
  if (metadata) header['__metadata__'] = metadata;
  let offset = 0;
  const payloads: Uint8Array[] = [];
  for (const [name, t] of Object.entries(tensors)) {
    header[name] = {
      dtype: t.dtype,
      shape: t.shape,
      data_offsets: [offset, offset + t.data.length],
    };
    payloads.push(t.data);
    offset += t.data.length;
  }
  const json = new TextEncoder().encode(JSON.stringify(header));
  const out = new Uint8Array(8 + json.length + offset);
  new DataView(out.buffer).setBigUint64(0, BigInt(json.length), true);
  out.set(json, 8);
  let pos = 8 + json.length;
  for (const p of payloads) {
    out.set(p, pos);
    pos += p.length;
  }
  return out;
}

/** f32 tensor payload from plain numbers. */
export function f32Data(values: number[]): Uint8Array {
  return new Uint8Array(new Float32Array(values).buffer.slice(0));
}

/** F16 tensor payload from f32 numbers (encoded via f32ToF16Bits). */
export function f16Data(values: number[]): Uint8Array {
  const bits = new Uint16Array(values.length);
  for (let i = 0; i < values.length; i++) bits[i] = f32ToF16Bits(values[i]!);
  return new Uint8Array(bits.buffer.slice(0));
}

/** BF16 tensor payload from f32 numbers: bf16 is just the top 16 bits of an
 *  f32 (truncation, no rounding). Callers MUST pick exactly-representable
 *  values (e.g. powers of two) so truncation happens to equal correctly
 *  rounded bf16 — that keeps this helper a 3-line truncation. */
export function bf16Data(values: number[]): Uint8Array {
  const f32 = new Float32Array(values);
  const u32 = new Uint32Array(f32.buffer);
  const bits = Uint16Array.from(u32, (word) => word >>> 16);
  return new Uint8Array(bits.buffer.slice(0));
}
