import { describe, expect, it } from 'vitest';
import { decodePoses, type RawLevel } from '../src/yolo26/pipeline.ts';

/** Hand-built fixture: 1 level (2×2 cells, stride 8), nc=1, 2 keypoints.
 *  Cell 0 fires person with a box covering the whole 16×16 image; keypoint
 *  channels hold [x, y, vis] triples as offsets from the SAME anchor center
 *  the box uses (cell + 0.5, grid units). */
function level(): RawLevel {
  const [h, w, nc, nKpt] = [2, 2, 1, 2];
  const hw = h * w;
  const data = new Float32Array((4 + nc + 3 * nKpt) * hw).fill(-10);
  // cell 0 box ltrb: l=0.5,t=0.5,r=1.5,b=1.5 grid units → xyxy (0,0,16,16) at stride 8
  data[0 * hw + 0] = 0.5;
  data[1 * hw + 0] = 0.5;
  data[2 * hw + 0] = 1.5;
  data[3 * hw + 0] = 1.5;
  data[4 * hw + 0] = 2; // person logit → score σ(2) ≈ 0.88
  // kpt 0: offset (+0.5, +1.5), vis logit 2 → pixel (8, 16), v = σ(2)
  data[(5 + 0) * hw + 0] = 0.5;
  data[(5 + 1) * hw + 0] = 1.5;
  data[(5 + 2) * hw + 0] = 2;
  // kpt 1: offset (−0.5, −0.5), vis logit −2 → pixel (0, 0), v = σ(−2)
  data[(5 + 3) * hw + 0] = -0.5;
  data[(5 + 4) * hw + 0] = -0.5;
  data[(5 + 5) * hw + 0] = -2;
  return { data, h, w, stride: 8 };
}

describe('decodePoses', () => {
  it('decodes keypoints as (offset + anchor)·stride with σ(vis)', () => {
    const dets = decodePoses([level()], {
      numClasses: 1,
      numKeypoints: 2,
      confThreshold: 0.5,
    });
    expect(dets.length).toBe(1);
    const d = dets[0]!;
    expect(d.classId).toBe(0);
    expect(d.label).toBe('person');
    expect(d.score).toBeCloseTo(1 / (1 + Math.exp(-2)), 5);
    expect([d.x1, d.y1, d.x2, d.y2]).toEqual([0, 0, 16, 16]);
    expect(d.kpts.length).toBe(2);
    // anchor center of cell 0 is (0.5, 0.5) grid units
    expect(d.kpts[0]!.x).toBeCloseTo((0.5 + 0.5) * 8, 5); // 8
    expect(d.kpts[0]!.y).toBeCloseTo((1.5 + 0.5) * 8, 5); // 16
    expect(d.kpts[0]!.v).toBeCloseTo(1 / (1 + Math.exp(-2)), 5);
    expect(d.kpts[1]!.x).toBeCloseTo(0, 5);
    expect(d.kpts[1]!.y).toBeCloseTo(0, 5);
    expect(d.kpts[1]!.v).toBeCloseTo(1 / (1 + Math.exp(2)), 5);
  });

  it('respects confThreshold and maxDet', () => {
    expect(decodePoses([level()], { numClasses: 1, numKeypoints: 2, confThreshold: 0.95 })).toEqual(
      [],
    );
    const lv = level();
    lv.data[4 * 4 + 1] = 3; // cell 1 also fires, higher score
    const dets = decodePoses([lv], {
      numClasses: 1,
      numKeypoints: 2,
      confThreshold: 0.5,
      maxDet: 1,
    });
    expect(dets.length).toBe(1);
    expect(dets[0]!.score).toBeCloseTo(1 / (1 + Math.exp(-3)), 5); // top-1 kept
  });
});
