/** The privacy filter's MoE MLP block on the eager runtime — GPU topk
 *  routing. Two eval phases per forward:
 *    A) selection(x) = topk(gate(norm(x)), 4) — routing math on the GPU; the
 *       CALLER evaluates it, reads back the small packed [T,8] result, and
 *       runs parseTopk/groupByExpert to shape phase B;
 *    B) forward(x, grouping, gateColumns) builds the expert-compute DAG with the chosen
 *       indices: per selected expert, gatherRows pulls its tokens, the FFN is
 *         glu = g @ Wgluₑ + bgluₑ,  lin = g @ Wlinₑ + blinₑ
 *         h = min(glu,7)·σ(1.702·min(glu,7))·(clamp(lin,±7)+1)
 *         o = (h @ W2ₑ + b2ₑ) · gateW
 *       contributions are stacked (cat along rows) and the four slots gathered
 *       back per token and summed; the residual is folded in (EagerBlock in
 *       model.ts is pure composition and must NOT re-add it).
 *  Dimension-parameterized, with two expert-weight formats behind
 *  `MoeDims.weightFormat`: 'f32' plain matrices (test scale — real E=128 f32
 *  experts need ~210MB per tensor, beyond maxStorageBufferBindingSize) and
 *  'f16' (native half precision, weights and activations alike
 *  path — the real checkpoint path). K==H assumed (holds for the privacy
 *  filter). */

import {
  astype,
  add,
  cat,
  gatherRows,
  matmul,
  matmulGather,
  matrix,
  mul,
  slice,
  swiglu,
  topk,
  nn,
  type Value,
  type ValueMeta,
} from '@tie/core';
import type { Grouping } from './routing.ts';

const RMS_EPS = 1e-5; // legacy rmsnorm kernel epsilon (not the eager 1e-6 default)

export interface MoeDims {
  experts: number;
  hidden: number; // H (== K for the privacy filter)
  /** Expert-weight storage: 'f32' plain matrices, or the quantized formats
   *  'quantInt8'/'quantInt4' — packed ints with f32 scale tensors per
   *  K-group. Half precision is NOT a weight format: `model.half()` flips
   *  the f32 weights AND every activation together, which is the only
   *  coherent combination (one kernel binds one element type). */
  weightFormat: 'f32' | 'quantInt8' | 'quantInt4';
  /** Quant only: K-group size for the scales. Ignored otherwise. */
  groupSize?: number;
}

export class EagerMoeMlp extends nn.Module<[Value, Grouping, Value[]], Value> {
  readonly norm: InstanceType<typeof nn.RMSNorm>;
  readonly gate: InstanceType<typeof nn.Linear>;
  /** Per-expert weights as flat 2D matrices (expert e = row block
   *  e·H..(e+1)·H), split into the swiglu halves the checkpoint fuses:
   *  glu/lin/out weight [E·H, H] each, glu/lin/out bias [E, H] each. The split
   *  is a binding-budget necessity at checkpoint scale (fused [E·H, 2H] f16 is
   *  419MB > maxStorageBufferBindingSize), mirrored here in the module shape.
   *  `norm.scale` / `gate.*` state-dict names match the checkpoint keys; the
   *  six expert tensors use flat camelCase field names (`gluWeight`, ...) —
   *  mapping the checkpoint's fused `swiglu.weight`-style tensors onto them
   *  (column split + optional f16 packing) is the real-checkpoint loader's
   *  job. No fake module nesting just to spoof the dotted names. */
  readonly gluWeight: InstanceType<typeof nn.Parameter>;
  readonly linWeight: InstanceType<typeof nn.Parameter>;
  readonly outWeight: InstanceType<typeof nn.Parameter>;
  readonly gluBias: InstanceType<typeof nn.Parameter>;
  readonly linBias: InstanceType<typeof nn.Parameter>;
  readonly outBias: InstanceType<typeof nn.Parameter>;
  readonly gluScales?: InstanceType<typeof nn.Parameter>;
  readonly linScales?: InstanceType<typeof nn.Parameter>;
  readonly outScales?: InstanceType<typeof nn.Parameter>;

  constructor(readonly dims: MoeDims) {
    super();
    const { experts: e, hidden: h, weightFormat } = dims;
    const quant = weightFormat === 'quantInt8' || weightFormat === 'quantInt4';
    const perU32 = weightFormat === 'quantInt8' ? 4 : weightFormat === 'quantInt4' ? 8 : 0;
    const groupSize = dims.groupSize ?? h;
    if (quant && h % groupSize !== 0)
      throw new Error(`EagerMoeMlp: groupSize ${groupSize} must divide hidden ${h}`);
    const kg = quant ? h / groupSize : 0;
    this.norm = new nn.RMSNorm(h, RMS_EPS);
    this.gate = new nn.Linear(h, e);
    // Weight metas: logical dims [E·H, H] in every format. quantW's elems is
    // the u32 word count (4 int8s or 8 int4s per word — the ValueMeta
    // convention); the float formats count values.
    const weightMeta = (): ValueMeta =>
      quant
        ? { elems: (e * h * h) / perU32, dtype: 'quantW', dims: [e * h, h] }
        : { elems: e * h * h, dtype: 'f32', dims: [e * h, h] };
    this.gluWeight = new nn.Parameter(weightMeta());
    this.linWeight = new nn.Parameter(weightMeta());
    this.outWeight = new nn.Parameter(weightMeta());
    this.gluBias = new nn.Parameter({ elems: e * h, dtype: 'f32', dims: [e, h] });
    this.linBias = new nn.Parameter({ elems: e * h, dtype: 'f32', dims: [e, h] });
    this.outBias = new nn.Parameter({ elems: e * h, dtype: 'f32', dims: [e, h] });
    if (quant) {
      const scaleMeta: ValueMeta = { elems: e * kg * h, dtype: 'f32', dims: [e * kg, h] };
      this.gluScales = new nn.Parameter(scaleMeta);
      this.linScales = new nn.Parameter(scaleMeta);
      this.outScales = new nn.Parameter(scaleMeta);
    }
  }

  /** Router logits [T, E] (exposed for tests). */
  routerLogits(x: Value): Value {
    return this.gate.forward(this.norm.forward(x));
  }

  /** Phase A: GPU routing — packed [T, 8] topk output whose readback feeds
   *  parseTopk/groupByExpert. */
  selection(x: Value): Value {
    return topk(this.routerLogits(x), 4);
  }

  /** x @ Wₑ for expert e — rows [e·H, (e+1)·H) of the fused [E·H, H] weight.
   *  The op's baseRow IS the row view — an offset, no copy. Quant
   *  additionally dequantizes with the per-(expert, K-group, col) `scales`. */
  private expertMatmul(x: Value, w: Value, scales: Value | undefined, expert: number): Value {
    const h = this.dims.hidden;
    const f = this.dims.weightFormat;
    if (f === 'f32') return matmul(x, w, { baseRow: expert * h });
    if (f === 'quantInt8' || f === 'quantInt4') {
      const bits = f === 'quantInt8' ? 8 : 4;
      const groupSize = this.dims.groupSize ?? h;
      const kg = h / groupSize;
      return matmul(x, w, {
        scales: scales!,
        baseRow: expert * h,
        scaleBase: expert * kg * h,
        bits,
        groupSize,
      });
    }
    return matmul(x, slice(w, 0, expert * h, (expert + 1) * h));
  }

  /** Single-DAG expert compute: topk routing stays ON THE GPU and each token
   *  gathers its own expert — NO selection readback, NO CPU grouping. Supports
   *  every weight format (via matmulGather). The two-phase forward() below
   *  stays as the parity oracle. */
  /** The block's activation dtype — model.half() flips every f32 parameter,
   *  so any of them names the current width. */
  private get actDtype(): 'f32' | 'f16' {
    return this.norm.scale.shape.dtype === 'f16' ? 'f16' : 'f32';
  }

  forwardGather(x: Value): Value {
    const f = this.dims.weightFormat;

    const xn = this.norm.forward(x); // [T, H]
    const packed = topk(this.gate.forward(xn), 4); // [T, 8]: 4 ids ‖ 4 weights, on GPU
    let y: Value | undefined;

    if (f === 'f32') {
      for (let s = 0; s < 4; s++) {
        const ids = slice(packed, 1, s, s + 1);
        // topk packs ids next to weights, so its output is f32 in every
        // variant — narrow the weight column to the activation dtype.
        const wgt = astype(slice(packed, 1, 4 + s, 5 + s), this.actDtype);
        const glu = matmulGather(xn, this.gluWeight.value, ids, { bias: this.gluBias.value });
        const lin = matmulGather(xn, this.linWeight.value, ids, { bias: this.linBias.value });
        const act = swiglu(glu, lin);
        const out = matmulGather(act, this.outWeight.value, ids, { bias: this.outBias.value });
        const contrib = mul(out, wgt);
        y = y ? add(y, contrib) : contrib;
      }
      return add(x, y!);
    }

    const bits = f === 'quantInt8' ? 8 : 4;
    const h = this.dims.hidden;
    const groupSize = this.dims.groupSize ?? h;
    const gather = (a: Value, w: Value, scales: Value, bias: Value, ids: Value): Value =>
      matmulGather(a, w, ids, { bias, scales, bits, groupSize });
    for (let s = 0; s < 4; s++) {
      const ids = slice(packed, 1, s, s + 1); // [T,1] expert id for slot s
      const wgt = astype(slice(packed, 1, 4 + s, 5 + s), this.actDtype); // [T,1] gate weight
      const glu = gather(xn, this.gluWeight.value, this.gluScales!.value, this.gluBias.value, ids);
      const lin = gather(xn, this.linWeight.value, this.linScales!.value, this.linBias.value, ids);
      const act = swiglu(glu, lin); // [T, H]
      const out = gather(act, this.outWeight.value, this.outScales!.value, this.outBias.value, ids);
      const contrib = mul(out, wgt); // [T,H] × [T,1] col-broadcast
      y = y ? add(y, contrib) : contrib;
    }
    return add(x, y!); // residual folded in
  }

  /** Phase B: expert compute for a routing decided on the CPU. Folds in the
   *  residual. `gateColumns[g]` must be the [n_g, 1] gate-weight column for
   *  grouping.groups[g], uploaded by the caller (CPU-known numbers). */
  override forward(x: Value, grouping: Grouping, gateColumns: Value[]): Value {
    if (!grouping)
      throw new Error(
        'EagerMoeMlp.forward needs (x, grouping, gateColumns) — evaluate selection(x) and run parseTopk/groupByExpert first (see routing.ts)',
      );
    if (grouping.groups.length === 0) throw new Error('EagerMoeMlp.forward: empty grouping');
    if (gateColumns.length !== grouping.groups.length)
      throw new Error(
        `EagerMoeMlp.forward: ${gateColumns.length} gate columns for ${grouping.groups.length} expert groups`,
      );
    const xn = this.norm.forward(x);
    const contribs: Value[] = [];
    grouping.groups.forEach((g, gi) => {
      const rows = gatherRows(xn, g.tokens); // [n_g, H]
      const e = g.expert;
      const glu = add(
        this.expertMatmul(rows, this.gluWeight.value, this.gluScales?.value, e),
        slice(this.gluBias.value, 0, e, e + 1),
      );
      const lin = add(
        this.expertMatmul(rows, this.linWeight.value, this.linScales?.value, e),
        slice(this.linBias.value, 0, e, e + 1),
      );
      const act = swiglu(glu, lin); // [n_g, H]
      const o = add(
        this.expertMatmul(act, this.outWeight.value, this.outScales?.value, e),
        slice(this.outBias.value, 0, e, e + 1),
      );
      contribs.push(mul(o, gateColumns[gi]!)); // [n_g,1] col-broadcast
    });
    const pile = cat(contribs, 0); // [4T, H] in group order
    let y: Value | undefined;
    for (let s = 0; s < 4; s++) {
      const slot = gatherRows(pile, grouping.slotPos[s]!); // [T, H]
      y = y ? add(y, slot) : slot;
    }
    return add(x, y!); // residual folded in
  }
}

/** Shape helper for the caller-uploaded gate columns. */
export function gateColumnShape(n: number) {
  return matrix(n, 1);
}
