/** YaRN rope table math + the privacy filter's rope wiring. Table
 *  construction is MODEL math (each architecture has its own rope recipe —
 *  HF/MLX keep it in per-model rotary classes too), so it lives here, not in
 *  core; core owns only the `rope` op/kernel that consumes the tables. */

export interface RopeParams {
  positions: number;
  headDim: number;
  theta: number;
  scalingFactor: number;
  ntkAlpha: number;
  ntkBeta: number;
  initialContextLength: number;
}

export interface RopeTables {
  /** [positions * headDim/2], row-major by position. Includes YaRN concentration. */
  cos: Float32Array;
  sin: Float32Array;
}

/** Faithful port of opf RotaryEmbedding._compute_cos_sin (YaRN, NTK-by-parts). */
export function computeRopeTables(p: RopeParams): RopeTables {
  const half = p.headDim / 2;
  const freq = new Float64Array(half);
  for (let i = 0; i < half; i++) freq[i] = p.theta ** ((2 * i) / p.headDim);

  let concentration = 1.0;
  const invFreq = new Float64Array(half);
  if (p.scalingFactor > 1.0) {
    concentration = 0.1 * Math.log(p.scalingFactor) + 1.0;
    const low =
      (half * Math.log(p.initialContextLength / (p.ntkBeta * 2 * Math.PI))) / Math.log(p.theta);
    const high =
      (half * Math.log(p.initialContextLength / (p.ntkAlpha * 2 * Math.PI))) / Math.log(p.theta);
    for (let i = 0; i < half; i++) {
      const ramp = Math.min(1, Math.max(0, (i - low) / (high - low)));
      const mask = 1 - ramp;
      invFreq[i] = (1 / (p.scalingFactor * freq[i]!)) * (1 - mask) + (1 / freq[i]!) * mask;
    }
  } else {
    for (let i = 0; i < half; i++) invFreq[i] = 1 / freq[i]!;
  }

  const cos = new Float32Array(p.positions * half);
  const sin = new Float32Array(p.positions * half);
  for (let t = 0; t < p.positions; t++) {
    for (let i = 0; i < half; i++) {
      const angle = t * invFreq[i]!;
      cos[t * half + i] = Math.cos(angle) * concentration;
      sin[t * half + i] = Math.sin(angle) * concentration;
    }
  }
  return { cos, sin };
}

import { rope, type Value } from '@tie/core';

/** Intentionally NOT imported from @tie/core (kernels/ropeApply.ts): that file
 *  belongs to the legacy trace engine slated for deletion; the eager path must
 *  not depend on it. */
export const QK_SCALE = 0.3535533905932738; // 64^(-1/4), applied to q and k

const HEAD_DIM = 64;
const HALF = HEAD_DIM / 2;

export interface RopeConstants {
  /** [T×64] pair-duplicated cos table, ×QK_SCALE. */
  cosE: Float32Array;
  /** [T×64] pair-duplicated sin table, ×QK_SCALE. */
  sinE: Float32Array;
  /** Raw [T×32] tables — exposed ONLY for CPU parity references in tests;
   *  production callers use cosE/sinE. */
  rawCos: Float32Array;
  rawSin: Float32Array;
}

/** Privacy-filter YaRN rope params (same as the legacy model assembly). */
export function ropeConstants(tokens: number): RopeConstants {
  const { cos, sin } = computeRopeTables({
    positions: tokens,
    headDim: HEAD_DIM,
    theta: 150000,
    scalingFactor: 32,
    ntkAlpha: 1,
    ntkBeta: 32,
    initialContextLength: 4096,
  });
  const cosE = new Float32Array(tokens * HEAD_DIM);
  const sinE = new Float32Array(tokens * HEAD_DIM);
  for (let t = 0; t < tokens; t++) {
    for (let p = 0; p < HALF; p++) {
      const c = cos[t * HALF + p]! * QK_SCALE;
      const s = sin[t * HALF + p]! * QK_SCALE;
      cosE[t * HEAD_DIM + 2 * p] = c;
      cosE[t * HEAD_DIM + 2 * p + 1] = c;
      sinE[t * HEAD_DIM + 2 * p] = s;
      sinE[t * HEAD_DIM + 2 * p + 1] = s;
    }
  }
  return { cosE, sinE, rawCos: cos, rawSin: sin };
}

/** rope(x) for a [T, heads·64] slab (any head count, 64-wide sections);
 *  cosE/sinE are materialized [T,64] constants. */
export function applyRope(x: Value, cosE: Value, sinE: Value): Value {
  return rope(x, cosE, sinE, { headDim: HEAD_DIM });
}
