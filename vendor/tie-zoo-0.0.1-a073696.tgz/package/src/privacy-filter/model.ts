/** Full privacy-filter network on the eager runtime: embedding (CPU-resident
 *  table, see nn.Embedding) → N × Block(attn, mlp) → final RMSNorm → unembed.
 *  Dotted parameter names match the checkpoint layout (embedding.weight,
 *  block.N.attn.*, block.N.mlp.*, norm.scale, unembedding.weight).
 *
 *  Rope tables (cos/sin) are never stored on the model — forward() computes
 *  them per call from the token count. This makes EagerModel T-independent:
 *  one model instance serves all sequence lengths with no per-T rebuilding. */

import { nn, tensor, type Value } from '@tie/core';
import { EagerAttnBlock, HEAD } from './attnBlock.ts';
import { EagerMoeMlp, type MoeDims } from './moeMlp.ts';
import { ropeConstants } from './rope.ts';

const HIDDEN = 640;
export { HIDDEN };
const RMS_EPS = 1e-5;

/** One transformer layer: attention + MoE FFN, single-DAG via forwardGather. */
export class EagerBlock extends nn.Module<[Value, Value, Value], Value> {
  readonly attn: EagerAttnBlock;
  readonly mlp: EagerMoeMlp;

  constructor(moe: MoeDims) {
    super();
    this.attn = new EagerAttnBlock();
    this.mlp = new EagerMoeMlp(moe);
  }

  override forward(x: Value, cos: Value, sin: Value): Value {
    x = this.attn.forward(x, cos, sin);
    x = this.mlp.forwardGather(x);
    return x;
  }
}

export interface ModelDims {
  blocks: number;
  experts: number;
  /** Embedding rows (200064 for the privacy filter). */
  vocab: number;
  /** Classifier width (33 for the privacy filter). */
  logits: number;
  /** Expert-weight storage, plumbed to every block's MoeDims. */
  weightFormat: MoeDims['weightFormat'];
  /** Quant only: scale K-group size, plumbed to every block. */
  groupSize?: number;
}

export class EagerModel extends nn.Module<[readonly number[]], Value> {
  readonly embedding: nn.Embedding;
  readonly block: nn.ModuleList<EagerBlock>;
  readonly norm = new nn.RMSNorm(HIDDEN, RMS_EPS);
  /** Classifier head — bias-less like the reference (all-zero bias). */
  readonly unembedding: nn.Linear;

  constructor(readonly dims: ModelDims) {
    super();
    this.embedding = new nn.Embedding(dims.vocab, HIDDEN, { device: 'cpu' });
    this.block = new nn.ModuleList(
      Array.from(
        { length: dims.blocks },
        () =>
          new EagerBlock({
            experts: dims.experts,
            hidden: HIDDEN,
            weightFormat: dims.weightFormat,
            groupSize: dims.groupSize,
          }),
      ),
    );
    this.unembedding = new nn.Linear(HIDDEN, dims.logits, { bias: false });
  }

  /** Single-DAG forward from token ids: the embedding gathers its rows on the
   *  CPU and uploads the [T, 640] input; rope cos/sin tables ([T,64],
   *  pair-duplicated, ×QK_SCALE) are computed here per call and uploaded;
   *  routing stays on the GPU via forwardGather — no mid-forward readbacks.
   *  Supports every weight format (forwardGather requires
   *  a gather kernel). */
  override forward(tokenIds: readonly number[]): Value {
    const T = tokenIds.length;
    const { cosE, sinE } = ropeConstants(T);
    const cos = tensor(cosE, [T, HEAD]);
    const sin = tensor(sinE, [T, HEAD]);
    let x = this.embedding.forward(tokenIds);
    for (const b of this.block.items) x = b.forward(x, cos, sin);
    return this.unembedding.forward(this.norm.forward(x));
  }
}
