/** Eager-runtime privacy-filter detector. Loads weights once into a single
 *  EagerModel (T-independent — rope tables are computed per forward call),
 *  then per detect runs a single-DAG forward pass. Runs on the initTie()
 *  default device. */

import {
  defaultRoot,
  fromSafetensors,
  inGpuErrorScopes,
  supportsF16,
  toArray,
  type LazyStateDict,
  type WeightCache,
} from '@tie/core';
import { buildLabelInfo, V2_NER_CLASS_NAMES, ZERO_BIASES, type ViterbiBiases } from './config.ts';
import { createTokenizer } from './tokenizer.ts';
import { ViterbiDecoder } from './viterbi.ts';
import { assembleDetect, type Detector } from './pipeline.ts';
import { EagerModel } from './model.ts';
import { transformHfPrivacyFilterStateDict } from './stateDictHooks.ts';

const BLOCKS = 8;
const EXPERTS = 128;
const LOGITS = 33;

export interface LoadedPrivacyFilterModel {
  model: EagerModel;
  /** Short name of the weight format in the file: 'f16', 'int8/g640', ... */
  weightFormat: string;
}

/** Builds an EagerModel and loads the weights into it. Takes the official
 *  hub checkpoint (loaded as f16) or a tools/export_pf_safetensors.py file
 *  (f16 or int8). One warm-up forward compiles the pipelines and checks the
 *  device. */
export async function loadPrivacyFilterModel(
  sd: LazyStateDict,
  opts: {
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
  } = {},
): Promise<LoadedPrivacyFilterModel> {
  const device = defaultRoot().device;
  // No model metadata means the hub checkpoint: transformers names that
  // need mapping. Exported files carry it and use EagerModel names.
  if (sd.metadata['model'] === undefined) transformHfPrivacyFilterStateDict(sd);
  if (sd.metadata['model'] !== 'privacy-filter') {
    throw new Error(
      `privacy-filter weights: file is for model '${sd.metadata['model']}', expected 'privacy-filter'`,
    );
  }
  let quantization: { bits: 8 | 4; groupSize: number } | undefined;
  if (sd.metadata['quantization']) {
    try {
      quantization = JSON.parse(sd.metadata['quantization']) as { bits: 8 | 4; groupSize: number };
    } catch {
      throw new Error(
        `privacy-filter weights: malformed quantization metadata '${sd.metadata['quantization']}'`,
      );
    }
    if ((quantization.bits !== 8 && quantization.bits !== 4) || !(quantization.groupSize > 0)) {
      throw new Error(
        `privacy-filter weights: unsupported quantization ${JSON.stringify(quantization)} — expected bits 8|4 and a positive groupSize`,
      );
    }
  }
  const weightFormat: 'f32' | 'quantInt8' | 'quantInt4' = quantization
    ? quantization.bits === 4
      ? 'quantInt4'
      : 'quantInt8'
    : 'f32';
  // Vocab comes from the checkpoint: embedding.weight is [vocab, hidden].
  const embedding = sd.tensors.get('embedding.weight');
  if (!embedding) {
    throw new Error("privacy-filter weights: missing 'embedding.weight' tensor");
  }
  const vocab = embedding.shape[0];
  if (embedding.shape.length !== 2 || vocab === undefined || vocab <= 0) {
    throw new Error(
      `privacy-filter weights: embedding.weight has shape ${JSON.stringify(embedding.shape)}, expected [vocab, hidden]`,
    );
  }
  const model = new EagerModel({
    blocks: BLOCKS,
    experts: EXPERTS,
    vocab,
    logits: LOGITS,
    weightFormat,
    groupSize: quantization?.groupSize,
  });
  // Unquantized weights run in half precision: the checkpoint is F16 on disk,
  // so this is the zero-copy load path AND half the GPU memory. Quantized
  // formats carry their own narrowing and stay as they are.
  const halved = weightFormat === 'f32' && supportsF16();
  if (halved) model.half();
  await model.loadStateDict(sd, { onProgress: opts.onProgress });
  const formatLabel = quantization
    ? `int${quantization.bits}/g${quantization.groupSize}`
    : halved
      ? 'f16'
      : 'f32';

  const warm = await inGpuErrorScopes(device, 'pipeline warm-up', () =>
    toArray(model.forward([1000])),
  );
  if (!warm.every(Number.isFinite) || warm.every((v) => v === 0)) {
    throw new Error('pipeline warm-up produced unusable logits — inference fails on this device');
  }
  return { model, weightFormat: formatLabel };
}

export async function createEagerDetector(
  weightsUrl: string,
  opts: {
    biases?: ViterbiBiases;
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
    onBytes?: (chunkBytes: number) => void;
    cache?: WeightCache;
  } = {},
): Promise<Detector> {
  const device = defaultRoot().device;
  const sd = await fromSafetensors(weightsUrl, { onBytes: opts.onBytes, cache: opts.cache });
  const { model, weightFormat } = await loadPrivacyFilterModel(sd, {
    onProgress: opts.onProgress,
  });

  const tokenizer = createTokenizer();
  const info = buildLabelInfo(V2_NER_CLASS_NAMES);
  const decoder = new ViterbiDecoder(info, opts.biases ?? ZERO_BIASES);
  return {
    tokenizer,
    weightFormat,
    detect: assembleDetect({
      device,
      tokenizer,
      info,
      decoder,
      model,
    }),
  };
}
