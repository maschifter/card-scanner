/** The privacy filter's attention block on the eager runtime, composed from
 *  core primitives — the "one block first" port. Wiring (faithful to the
 *  legacy AttnModule + Block residual):
 *      x + out( sdpa( rope(qkv(norm(x))) ) )
 *  qkv's row is q(14×64) ‖ k(2×64) ‖ v(2×64); q and k slabs are roped in ONE
 *  `rope` dispatch each (all head sections at once), and sdpa runs the banded
 *  GQA-with-sinks attention fused — no per-head fan-out, no [T,T] scratch.
 *  Rope tables (cos/sin) are passed into forward() by the caller — computed
 *  once per forward pass in detector.ts and uploaded as materialized Values.
 *  Residual note: this block folds the residual add in (legacy splits it —
 *  AttnModule returns the delta, Block adds it), which is why EagerBlock in
 *  model.ts is pure composition and adds NOTHING. */

import { add, nn, sdpa, slice, type Value } from '@tie/core';
import { applyRope } from './rope.ts';

const HIDDEN = 640;
const QKV_WIDTH = 1152; // q(14×64) ‖ k(2×64) ‖ v(2×64)
const ATTN_OUT = 896; // 14 heads × 64 concatenated back
const Q_HEADS = 14;
const KV_HEADS = 2;
export const HEAD = 64;
const WINDOW = 128; // bidirectional: attend within |i−j| ≤ 128
const K_OFF = Q_HEADS * HEAD; // 896 — k sections start here in the qkv row
const V_OFF = K_OFF + KV_HEADS * HEAD; // 1024 — v sections start here

export class EagerAttnBlock extends nn.Module<[Value, Value, Value], Value> {
  // eps = 1e-5 is the legacy rmsnorm KERNEL's epsilon — the eager RMSNorm
  // default (1e-6) would silently diverge from the reference model.
  readonly norm = new nn.RMSNorm(HIDDEN, 1e-5);
  readonly qkv = new nn.Linear(HIDDEN, QKV_WIDTH);
  readonly out = new nn.Linear(ATTN_OUT, HIDDEN);
  /** Per-head sink logits; [1,14] so slice can pick head h's logit. */
  readonly sinks = new nn.Parameter(
    { elems: Q_HEADS, dtype: 'f32', dims: [1, Q_HEADS] },
    undefined,
    true, // attention sinks are f32 in every kernel variant
  );

  /** cos/sin are [T,64] pair-duplicated tables, ×QK_SCALE, computed and
   *  uploaded by the caller once per forward pass. */
  override forward(x: Value, cos: Value, sin: Value): Value {
    const qkv = this.qkv.forward(this.norm.forward(x)); // [T,1152]

    const qRoped = applyRope(slice(qkv, 1, 0, K_OFF), cos, sin); // [T, 896]
    const kRoped = applyRope(slice(qkv, 1, K_OFF, V_OFF), cos, sin); // [T, 128]
    const vAll = slice(qkv, 1, V_OFF, V_OFF + KV_HEADS * HEAD); // [T, 128]

    const attnOut = sdpa(qRoped, kRoped, vAll, {
      qHeads: Q_HEADS,
      kvHeads: KV_HEADS,
      headDim: HEAD,
      windowLeft: WINDOW,
      windowRight: WINDOW,
      sinks: this.sinks.value,
    });
    return add(x, this.out.forward(attnOut));
  }
}
