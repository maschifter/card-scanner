/** CPU pre/post-processing around the yolo26 GPU forward.
 *  Preprocess: RGBA canvas pixels → [3, S, S] CHW f32 in [0,1] (RGB order).
 *  Decode: per-level raw [4+nc, H, W] (detect) or [4+nc+nm, H, W] (seg) →
 *  boxes, plus per-instance masks for seg (coeffs · prototypes, thresholded
 *  at logit 0). YOLO26 is end-to-end (one-to-one assignment): threshold +
 *  top-k, NO NMS. Box channels are ltrb distances from the cell's anchor
 *  center in grid units (reg_max=1, no DFL); class channels are logits
 *  (sigmoid applied here). */

export interface Detection {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  score: number;
  classId: number;
  label: string;
}

export interface RawLevel {
  /** Flat [4+nc, H, W] readback ([4+nc+nm, H, W] for seg, [4+nc+3·nKpt, H, W]
   *  for pose — the box/class scan never reads past channel 4+nc, so all
   *  three layouts fit). */
  data: Float32Array;
  h: number;
  w: number;
  stride: number;
}

export interface ProtoData {
  /** Flat [nm, H, W] prototype readback (H = W = inputSize/4). */
  data: Float32Array;
  h: number;
  w: number;
}

export interface SegDetection extends Detection {
  /** Soft mask cropped to the box, in PROTO grid coords (multiply by
   *  inputSize/proto.w — 4 px/cell at 640 — to place on the input image).
   *  Each byte is round(255·σ(mask logit)) — a coverage/alpha value, so
   *  bilinear upscaling feathers the boundary instead of showing proto-res
   *  stairsteps. Threshold at ≥128 (σ > 0.5 ≡ logit > 0) to recover
   *  ultralytics' binary mask exactly. */
  mask: Uint8Array; // maskW·maskH, row-major
  /** Crop-rect origin/size, also in proto grid units — image-space origin is
   *  (maskX·protoStride, maskY·protoStride). */
  maskX: number;
  maskY: number;
  maskW: number;
  maskH: number;
}

/** RGBA (canvas ImageData) → CHW RGB f32 in [0,1]. Pass `out` to reuse one
 *  scratch array across frames — a camera loop otherwise allocates 4.9 MB of
 *  JS garbage per frame on top of the GPU upload. */
export function preprocessRgba(
  rgba: Uint8ClampedArray,
  size: number,
  out?: Float32Array,
): Float32Array {
  const hw = size * size;
  out ??= new Float32Array(3 * hw);
  for (let i = 0; i < hw; i++) {
    out[i] = rgba[i * 4]! / 255;
    out[hw + i] = rgba[i * 4 + 1]! / 255;
    out[2 * hw + i] = rgba[i * 4 + 2]! / 255;
  }
  return out;
}

const sigmoid = (x: number) => 1 / (1 + Math.exp(-x));

interface CellHit {
  levelIdx: number;
  cell: number;
  det: Detection;
}

/** Shared detect/seg scan: threshold in logit space (sigmoid is monotonic —
 *  cells reject on the raw logit and sigmoid runs only for survivors), decode
 *  ltrb boxes, remember which cell each survivor came from (seg gathers its
 *  coeffs by cell). Coeff channels beyond 4+nc are never read here, so the
 *  same scan works for both detect [4+nc, H, W] and seg [4+nc+nm, H, W]
 *  levels. */
function scanCells(
  levels: readonly RawLevel[],
  numClasses: number,
  confThreshold: number,
): CellHit[] {
  const logitThreshold = Math.log(confThreshold / (1 - confThreshold));
  const hits: CellHit[] = [];
  levels.forEach(({ data, h, w, stride }, levelIdx) => {
    const hw = h * w;
    for (let i = 0; i < hw; i++) {
      let bestLogit = -Infinity;
      let bestClass = 0;
      for (let c = 0; c < numClasses; c++) {
        const v = data[(4 + c) * hw + i]!;
        if (v > bestLogit) {
          bestLogit = v;
          bestClass = c;
        }
      }
      if (bestLogit < logitThreshold) continue;
      const score = sigmoid(bestLogit);
      const ax = (i % w) + 0.5;
      const ay = Math.floor(i / w) + 0.5;
      const l = data[i]!;
      const t = data[hw + i]!;
      const r = data[2 * hw + i]!;
      const b = data[3 * hw + i]!;
      hits.push({
        levelIdx,
        cell: i,
        det: {
          x1: (ax - l) * stride,
          y1: (ay - t) * stride,
          x2: (ax + r) * stride,
          y2: (ay + b) * stride,
          score,
          classId: bestClass,
          label: COCO_NAMES[bestClass] ?? `cls${bestClass}`,
        },
      });
    }
  });
  hits.sort((a, b) => b.det.score - a.det.score);
  return hits;
}

export function decodeDetections(
  levels: readonly RawLevel[],
  opts: { numClasses?: number; confThreshold?: number; maxDet?: number } = {},
): Detection[] {
  const { numClasses = 80, confThreshold = 0.3, maxDet = 300 } = opts;
  return scanCells(levels, numClasses, confThreshold)
    .slice(0, maxDet)
    .map((h) => h.det);
}

/** Seg decode: detect scan + per-survivor mask assembly. mask(y,x) =
 *  round(255·σ(Σ_c coeff[c]·proto[c,y,x])) — soft coverage; ≥128 is exactly
 *  ultralytics' binary mask (they threshold the logit at 0 ≡ σ > 0.5), the
 *  in-between band feathers the boundary when upscaled. Computed only inside
 *  the box's proto-space crop (≈ nm · cropArea MACs per detection —
 *  microseconds on CPU). */
export function decodeSegmentations(
  levels: readonly RawLevel[],
  proto: ProtoData,
  opts: {
    numClasses?: number;
    numMasks?: number;
    confThreshold?: number;
    maxDet?: number;
    inputSize?: number;
  } = {},
): SegDetection[] {
  const {
    numClasses = 80,
    numMasks = 32,
    confThreshold = 0.3,
    maxDet = 300,
    inputSize = 640,
  } = opts;
  const protoStride = inputSize / proto.w;
  const phw = proto.h * proto.w;
  return scanCells(levels, numClasses, confThreshold)
    .slice(0, maxDet)
    .map(({ levelIdx, cell, det }) => {
      const { data, h, w } = levels[levelIdx]!;
      const hw = h * w;
      const coeffs = new Float32Array(numMasks);
      for (let c = 0; c < numMasks; c++) coeffs[c] = data[(4 + numClasses + c) * hw + cell]!;
      const px1 = Math.min(proto.w, Math.max(0, Math.floor(det.x1 / protoStride)));
      const py1 = Math.min(proto.h, Math.max(0, Math.floor(det.y1 / protoStride)));
      const px2 = Math.min(proto.w, Math.max(px1, Math.ceil(det.x2 / protoStride)));
      const py2 = Math.min(proto.h, Math.max(py1, Math.ceil(det.y2 / protoStride)));
      const maskW = px2 - px1;
      const maskH = py2 - py1;
      const mask = new Uint8Array(maskW * maskH);
      for (let y = 0; y < maskH; y++) {
        for (let x = 0; x < maskW; x++) {
          const pi = (py1 + y) * proto.w + (px1 + x);
          let v = 0;
          for (let c = 0; c < numMasks; c++) v += coeffs[c]! * proto.data[c * phw + pi]!;
          // Soft coverage instead of a hard >0 cut: interiors saturate to
          // 255/0 (|logit| is large away from boundaries), only the thin
          // boundary band lands in between — that's the feather.
          mask[y * maskW + x] = Math.round(255 * sigmoid(v));
        }
      }
      return { ...det, mask, maskX: px1, maskY: py1, maskW, maskH };
    });
}

export interface Keypoint {
  /** Input-image pixel coords. */
  x: number;
  y: number;
  /** Visibility, σ of the raw logit in [0,1] — ultralytics draws at v ≥ 0.25. */
  v: number;
}

export interface PoseDetection extends Detection {
  kpts: Keypoint[]; // COCO_KEYPOINTS order
}

/** Pose decode: detect scan (nc=1, person) + per-survivor keypoint gather.
 *  Channels 4+nc.. hold [x, y, vis] triples per keypoint; xy are offsets from
 *  the SAME anchor center the box uses (cell + 0.5, in grid units), so
 *  kx = (raw + ax)·stride — ultralytics Pose26.kpts_decode exactly. */
export function decodePoses(
  levels: readonly RawLevel[],
  opts: {
    numClasses?: number;
    numKeypoints?: number;
    confThreshold?: number;
    maxDet?: number;
  } = {},
): PoseDetection[] {
  const { numClasses = 1, numKeypoints = 17, confThreshold = 0.3, maxDet = 300 } = opts;
  return scanCells(levels, numClasses, confThreshold)
    .slice(0, maxDet)
    .map(({ levelIdx, cell, det }) => {
      const { data, h, w, stride } = levels[levelIdx]!;
      const hw = h * w;
      const ax = (cell % w) + 0.5;
      const ay = Math.floor(cell / w) + 0.5;
      const kpts: Keypoint[] = [];
      for (let k = 0; k < numKeypoints; k++) {
        const o = (4 + numClasses + 3 * k) * hw + cell;
        kpts.push({
          x: (data[o]! + ax) * stride,
          y: (data[o + hw]! + ay) * stride,
          v: sigmoid(data[o + 2 * hw]!),
        });
      }
      return { ...det, kpts };
    });
}

/** COCO-17 keypoint names (ultralytics ordering). */
export const COCO_KEYPOINTS = [
  'nose',
  'left_eye',
  'right_eye',
  'left_ear',
  'right_ear',
  'left_shoulder',
  'right_shoulder',
  'left_elbow',
  'right_elbow',
  'left_wrist',
  'right_wrist',
  'left_hip',
  'right_hip',
  'left_knee',
  'right_knee',
  'left_ankle',
  'right_ankle',
] as const;

/** Skeleton edges as COCO_KEYPOINTS index pairs (ultralytics skeleton, 0-based). */
export const COCO_SKELETON: readonly [number, number][] = [
  [15, 13],
  [13, 11],
  [16, 14],
  [14, 12],
  [11, 12],
  [5, 11],
  [6, 12],
  [5, 6],
  [5, 7],
  [6, 8],
  [7, 9],
  [8, 10],
  [1, 2],
  [0, 1],
  [0, 2],
  [1, 3],
  [2, 4],
  [3, 5],
  [4, 6],
];

/** COCO-80 class names (ultralytics ordering). */
export const COCO_NAMES = [
  'person',
  'bicycle',
  'car',
  'motorcycle',
  'airplane',
  'bus',
  'train',
  'truck',
  'boat',
  'traffic light',
  'fire hydrant',
  'stop sign',
  'parking meter',
  'bench',
  'bird',
  'cat',
  'dog',
  'horse',
  'sheep',
  'cow',
  'elephant',
  'bear',
  'zebra',
  'giraffe',
  'backpack',
  'umbrella',
  'handbag',
  'tie',
  'suitcase',
  'frisbee',
  'skis',
  'snowboard',
  'sports ball',
  'kite',
  'baseball bat',
  'baseball glove',
  'skateboard',
  'surfboard',
  'tennis racket',
  'bottle',
  'wine glass',
  'cup',
  'fork',
  'knife',
  'spoon',
  'bowl',
  'banana',
  'apple',
  'sandwich',
  'orange',
  'broccoli',
  'carrot',
  'hot dog',
  'pizza',
  'donut',
  'cake',
  'chair',
  'couch',
  'potted plant',
  'bed',
  'dining table',
  'toilet',
  'tv',
  'laptop',
  'mouse',
  'remote',
  'keyboard',
  'cell phone',
  'microwave',
  'oven',
  'toaster',
  'sink',
  'refrigerator',
  'book',
  'clock',
  'vase',
  'scissors',
  'teddy bear',
  'hair drier',
  'toothbrush',
] as const;
