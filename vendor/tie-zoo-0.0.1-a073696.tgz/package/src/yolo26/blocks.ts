/** YOLO26 building blocks, mirroring ultralytics/nn/modules 1:1 — same
 *  submodule field names (cv1/cv2/m/...) so state-dict keys line up in the
 *  loader, same channel math, same forward graphs. nn.BatchNorm2d folds
 *  itself into the preceding conv at load (unfused checkpoints), so
 *  ConvBlock executes as Conv2d(+bias) + optional SiLU
 *  (ultralytics Conv = conv + bn + act). */

import { add, cat, chunk, maxPool2d, mul, nn, sigmoid } from '@tie/core';
import type { Value } from '@tie/core';

const { BatchNorm2d, Conv2d, Module, ModuleList } = nn;

/** SiLU: x · σ(x) — YOLO's activation, composed from existing ops. */
export function silu(x: Value): Value {
  return mul(x, sigmoid(x));
}

/** ultralytics Conv: Conv2d(bias=False) + BN + SiLU, with autopad p = k//2.
 *  Post-BN-fold this is a biased conv; `act: false` mirrors Conv(act=False)
 *  (SPPF cv1, attention qkv/proj/pe, ffn's second conv). */
export class ConvBlock extends Module {
  /** ultralytics BatchNorm2d(eps=1e-3) — NOT torch's 1e-5 default. */
  static readonly BN_EPS = 1e-3;

  readonly conv: InstanceType<typeof Conv2d>;
  readonly bn: InstanceType<typeof BatchNorm2d>;
  constructor(
    c1: number,
    c2: number,
    opts: { kernelSize?: number; stride?: number; groups?: number; act?: boolean } = {},
  ) {
    super();
    const { kernelSize = 1, stride = 1, groups = 1 } = opts;
    this.conv = new Conv2d(c1, c2, {
      kernelSize,
      stride,
      padding: Math.floor(kernelSize / 2), // autopad
      groups,
      bias: true, // BN folds in here
      act: opts.act ?? true, // SiLU fused into the conv kernel epilogue
    });
    this.bn = new BatchNorm2d(c2, { eps: ConvBlock.BN_EPS });
  }
  forward(x: Value): Value {
    return this.conv.forward(x);
  }
}

/** ultralytics Bottleneck: cv1 (k0) → cv2 (k1) with optional residual.
 *  Hidden width c_ = floor(c2·e). */
export class Bottleneck extends Module {
  readonly cv1: ConvBlock;
  readonly cv2: ConvBlock;
  private readonly add: boolean;
  constructor(
    c1: number,
    c2: number,
    opts: { shortcut?: boolean; k?: [number, number]; e?: number } = {},
  ) {
    super();
    const { shortcut = true, k = [3, 3], e = 0.5 } = opts;
    const c = Math.floor(c2 * e);
    this.cv1 = new ConvBlock(c1, c, { kernelSize: k[0] });
    this.cv2 = new ConvBlock(c, c2, { kernelSize: k[1] });
    this.add = shortcut && c1 === c2;
  }
  forward(x: Value): Value {
    const y = this.cv2.forward(this.cv1.forward(x));
    return this.add ? add(x, y) : y;
  }
}

/** ultralytics C3k (a C3 with k×k bottlenecks): two parallel 1×1 projections,
 *  n bottlenecks (e=1.0, k×k) on one path, concat, 1×1 out. */
export class C3k extends Module {
  readonly cv1: ConvBlock;
  readonly cv2: ConvBlock;
  readonly cv3: ConvBlock;
  readonly m: InstanceType<typeof ModuleList<Bottleneck>>;
  constructor(
    c1: number,
    c2: number,
    opts: { n?: number; shortcut?: boolean; e?: number; k?: number } = {},
  ) {
    super();
    const { n = 2, shortcut = true, e = 0.5, k = 3 } = opts;
    const c = Math.floor(c2 * e);
    this.cv1 = new ConvBlock(c1, c, { kernelSize: 1 });
    this.cv2 = new ConvBlock(c1, c, { kernelSize: 1 });
    this.cv3 = new ConvBlock(2 * c, c2, { kernelSize: 1 });
    this.m = new ModuleList(
      Array.from({ length: n }, () => new Bottleneck(c, c, { shortcut, k: [k, k], e: 1.0 })),
    );
  }
  forward(x: Value): Value {
    return this.cv3.forward(cat([this.m.forward(this.cv1.forward(x)), this.cv2.forward(x)], 0));
  }
}

/** ultralytics C3k2 (C2f subclass): cv1 → chunk into two c-wide halves, each
 *  inner block's output is APPENDED to the running list (not replacing it),
 *  cv2 sees all (2+n)·c channels. Inner block per repeat: C3k(c,c,n=2) when
 *  c3k, else Bottleneck(c,c,e=0.5). (The attn=True variant lives in psa.ts —
 *  C3k2Attn — to keep attention deps out of the plain conv path.) */
export class C3k2 extends Module {
  readonly cv1: ConvBlock;
  readonly cv2: ConvBlock;
  // Repeat blocks (C3k | Bottleneck) are all plain Value→Value.
  readonly m: nn.ModuleList<nn.Module>;
  protected readonly c: number;
  constructor(
    c1: number,
    c2: number,
    opts: { n?: number; c3k?: boolean; e?: number; shortcut?: boolean } = {},
  ) {
    super();
    const { n = 1, c3k = false, e = 0.5, shortcut = true } = opts;
    this.c = Math.floor(c2 * e);
    this.cv1 = new ConvBlock(c1, 2 * this.c, { kernelSize: 1 });
    this.cv2 = new ConvBlock((2 + n) * this.c, c2, { kernelSize: 1 });
    this.m = new ModuleList<nn.Module>(
      Array.from({ length: n }, () =>
        c3k
          ? new C3k(this.c, this.c, { n: 2, shortcut })
          : new Bottleneck(this.c, this.c, { shortcut }),
      ),
    );
  }
  forward(x: Value): Value {
    const ys: Value[] = chunk(this.cv1.forward(x), 2, 0);
    for (const m of this.m.items) ys.push(m.forward(ys[ys.length - 1]!));
    return this.cv2.forward(cat(ys, 0));
  }
}

/** ultralytics SPPF: cv1 (1×1, NO activation) → n cascaded k×k stride-1 pools
 *  (each pooling the previous result) → concat all n+1 → cv2, plus a residual
 *  add when shortcut && c1 == c2 (YOLO26 passes shortcut=True). */
export class SPPF extends Module {
  readonly cv1: ConvBlock;
  readonly cv2: ConvBlock;
  private readonly k: number;
  private readonly n: number;
  private readonly add: boolean;
  constructor(c1: number, c2: number, opts: { k?: number; n?: number; shortcut?: boolean } = {}) {
    super();
    const { k = 5, n = 3, shortcut = false } = opts;
    const c = Math.floor(c1 / 2);
    this.cv1 = new ConvBlock(c1, c, { kernelSize: 1, act: false });
    this.cv2 = new ConvBlock(c * (n + 1), c2, { kernelSize: 1 });
    this.k = k;
    this.n = n;
    this.add = shortcut && c1 === c2;
  }
  forward(x: Value): Value {
    const ys: Value[] = [this.cv1.forward(x)];
    for (let i = 0; i < this.n; i++) {
      ys.push(
        maxPool2d(ys[ys.length - 1]!, {
          kernelSize: this.k,
          stride: 1,
          padding: Math.floor(this.k / 2),
        }),
      );
    }
    const y = this.cv2.forward(cat(ys, 0));
    return this.add ? add(x, y) : y;
  }
}
