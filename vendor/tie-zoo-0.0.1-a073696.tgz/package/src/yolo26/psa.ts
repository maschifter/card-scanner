/** YOLO26 attention blocks (ultralytics C2PSA / PSABlock / Attention),
 *  composed from 2D primitives: per-head channel slice → reshape [c, H·W] →
 *  matmul/softmax → reshape back. Field names mirror ultralytics so
 *  state-dict keys line up (qkv/proj/pe, attn/ffn, cv1/cv2/m). */

import {
  add,
  cat,
  chunk,
  matmul,
  mul,
  nn,
  reshape,
  slice,
  softmax,
  toChw,
  toHwc4,
  transpose,
} from '@tie/core';
import type { Value } from '@tie/core';
import { Bottleneck, ConvBlock } from './blocks.ts';

const { Module, ModuleList } = nn;

/** ultralytics Attention: spatial self-attention over N = H·W positions.
 *  qkv is one 1×1 conv producing per-head [q(keyDim) | k(keyDim) | v(headDim)]
 *  channel groups; pe is a depthwise 3×3 positional conv on v; proj is 1×1.
 *  All three have act=False. */
export class Attention extends Module {
  readonly qkv: ConvBlock;
  readonly proj: ConvBlock;
  readonly pe: ConvBlock;
  private readonly numHeads: number;
  private readonly headDim: number;
  private readonly keyDim: number;
  private readonly scale: number;
  constructor(dim: number, opts: { numHeads?: number; attnRatio?: number } = {}) {
    super();
    const { numHeads = 8, attnRatio = 0.5 } = opts;
    this.numHeads = numHeads;
    this.headDim = Math.floor(dim / numHeads);
    this.keyDim = Math.floor(this.headDim * attnRatio);
    this.scale = this.keyDim ** -0.5;
    const nhKd = this.keyDim * numHeads;
    this.qkv = new ConvBlock(dim, dim + nhKd * 2, { kernelSize: 1, act: false });
    this.proj = new ConvBlock(dim, dim, { kernelSize: 1, act: false });
    this.pe = new ConvBlock(dim, dim, { kernelSize: 3, groups: dim, act: false });
  }
  forward(x: Value): Value {
    const [, h, w] = x.shape.dims! as [number, number, number];
    const n = h * w;
    // The qkv conv emits hwc4; the per-head slice/reshape/matmul math below
    // is row-major, so convert once here (20² maps — the copies are noise)
    // and re-enter hwc4 for the pe/proj convs at the tail.
    const qkv = toChw(this.qkv.forward(x), 'f16'); // [(2·keyDim+headDim)·heads, H, W]
    const per = 2 * this.keyDim + this.headDim;
    const headOuts: Value[] = [];
    const vSlices: Value[] = [];
    for (let head = 0; head < this.numHeads; head++) {
      const base = head * per;
      const q = reshape(slice(qkv, 0, base, base + this.keyDim), [this.keyDim, n]);
      const k = reshape(slice(qkv, 0, base + this.keyDim, base + 2 * this.keyDim), [
        this.keyDim,
        n,
      ]);
      const v3 = slice(qkv, 0, base + 2 * this.keyDim, base + per); // [headDim, H, W]
      const v = reshape(v3, [this.headDim, n]);
      // attn[i,j] = softmax_j( (q_i·scale) · k_j ) — rows are queries, matching
      // torch's softmax(dim=-1) on (q^T @ k).
      const attn = softmax(matmul(transpose(mul(q, this.scale)), k)); // [N, N]
      const o = matmul(v, transpose(attn)); // [headDim, N] = v @ attn^T
      headOuts.push(reshape(o, [this.headDim, h, w]));
      vSlices.push(v3);
    }
    const attnOut = cat(headOuts, 0);
    const vAll = cat(vSlices, 0);
    const pe = this.pe.forward(toHwc4(vAll));
    return this.proj.forward(add(toHwc4(attnOut), pe));
  }
}

/** ultralytics PSABlock: x += attn(x); x += ffn(x) (both residual).
 *  ffn = 1×1 expand (SiLU) → 1×1 project (no act). */
export class PSABlock extends Module {
  readonly attn: Attention;
  readonly ffn: InstanceType<typeof ModuleList<ConvBlock>>;
  constructor(c: number, opts: { numHeads?: number; attnRatio?: number } = {}) {
    super();
    this.attn = new Attention(c, {
      numHeads: opts.numHeads ?? 4,
      attnRatio: opts.attnRatio ?? 0.5,
    });
    this.ffn = new ModuleList([
      new ConvBlock(c, c * 2, { kernelSize: 1 }),
      new ConvBlock(c * 2, c, { kernelSize: 1, act: false }),
    ]);
  }
  forward(x: Value): Value {
    const y = add(x, this.attn.forward(x));
    return add(y, this.ffn.forward(y));
  }
}

/** ultralytics C2PSA: cv1 → split [c|c], attention stack on the second half,
 *  concat, cv2. Requires c1 == c2; heads = c // 64 (nano: 128//64 = 2). */
export class C2PSA extends Module {
  readonly cv1: ConvBlock;
  readonly cv2: ConvBlock;
  readonly m: InstanceType<typeof ModuleList<PSABlock>>;
  private readonly c: number;
  constructor(c1: number, c2: number, opts: { n?: number; e?: number } = {}) {
    super();
    if (c1 !== c2) throw new Error(`C2PSA: c1 must equal c2, got ${c1} vs ${c2}`);
    const { n = 1, e = 0.5 } = opts;
    this.c = Math.floor(c1 * e);
    this.cv1 = new ConvBlock(c1, 2 * this.c, { kernelSize: 1 });
    this.cv2 = new ConvBlock(2 * this.c, c1, { kernelSize: 1 });
    this.m = new ModuleList(
      Array.from(
        { length: n },
        () => new PSABlock(this.c, { numHeads: Math.floor(this.c / 64), attnRatio: 0.5 }),
      ),
    );
  }
  forward(x: Value): Value {
    const [a, b] = chunk(this.cv1.forward(x), 2, 0) as [Value, Value];
    return this.cv2.forward(cat([a, this.m.forward(b)], 0));
  }
}

/** C3k2 with attn=True (YOLO26 head P5 layer): each repeat is
 *  Sequential(Bottleneck, PSABlock) — ultralytics keys m.{i}.0 / m.{i}.1.
 *  Same C2f-style progressive concat as C3k2. */
export class C3k2Attn extends Module {
  readonly cv1: ConvBlock;
  readonly cv2: ConvBlock;
  readonly m: InstanceType<typeof ModuleList<InstanceType<typeof ModuleList>>>;
  private readonly c: number;
  constructor(c1: number, c2: number, opts: { n?: number; e?: number; shortcut?: boolean } = {}) {
    super();
    const { n = 1, e = 0.5, shortcut = true } = opts;
    this.c = Math.floor(c2 * e);
    this.cv1 = new ConvBlock(c1, 2 * this.c, { kernelSize: 1 });
    this.cv2 = new ConvBlock((2 + n) * this.c, c2, { kernelSize: 1 });
    this.m = new ModuleList(
      Array.from(
        { length: n },
        () =>
          new ModuleList<InstanceType<typeof Module>>([
            new Bottleneck(this.c, this.c, { shortcut }),
            new PSABlock(this.c, {
              numHeads: Math.max(Math.floor(this.c / 64), 1),
              attnRatio: 0.5,
            }),
          ]),
      ),
    );
  }
  forward(x: Value): Value {
    const ys: Value[] = chunk(this.cv1.forward(x), 2, 0);
    for (const m of this.m.items) ys.push(m.forward(ys[ys.length - 1]!));
    return this.cv2.forward(cat(ys, 0));
  }
}
