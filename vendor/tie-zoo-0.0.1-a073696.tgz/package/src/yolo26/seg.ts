/** YOLO26 segmentation head (ultralytics Segment26 + Proto26, end2end path).
 *  Segment26 = Detect + one2one_cv4 mask-coefficient towers (nm=32 coeffs per
 *  cell) + a shared Proto26 prototype generator. Proto26 fuses P3+P4+P5
 *  (1×1 refine + nearest ×2/×4 upsample + add) then runs the classic Proto
 *  stack whose learned ConvTranspose2d doubles P3 resolution → [nm, S/4, S/4].
 *  Field names match checkpoint keys; one2many cv4 and proto.semseg are
 *  training-only (dropped by ultralytics fuse(), skipped by our exporter). */

import { add, nn, toChw, toHwc4, upsample2d } from '@tie/core';
import type { Value } from '@tie/core';
import { ConvBlock } from './blocks.ts';
import { catHeads, Detect, plainConv1x1 } from './head.ts';

const { ConvTranspose2d, Module, ModuleList } = nn;

export class Proto26 extends Module<[readonly Value[]], Value> {
  readonly feat_refine: nn.ModuleList<ConvBlock>;
  readonly feat_fuse: ConvBlock;
  readonly cv1: ConvBlock;
  readonly upsample: nn.ConvTranspose2d;
  readonly cv2: ConvBlock;
  readonly cv3: ConvBlock;
  /** ch: per-level input channels [P3, P4, P5]; cHidden: width-scaled npr. */
  constructor(ch: readonly number[], cHidden: number, nm: number) {
    super();
    this.feat_refine = new ModuleList(
      ch.slice(1).map((x) => new ConvBlock(x, ch[0]!, { kernelSize: 1 })),
    );
    this.feat_fuse = new ConvBlock(ch[0]!, cHidden, { kernelSize: 3 });
    this.cv1 = new ConvBlock(cHidden, cHidden, { kernelSize: 3 });
    // Learned 2× upsampler — plain ConvTranspose2d (bias, no BN/act).
    this.upsample = new ConvTranspose2d(cHidden, cHidden, { kernelSize: 2, stride: 2 });
    this.cv2 = new ConvBlock(cHidden, cHidden, { kernelSize: 3 });
    this.cv3 = new ConvBlock(cHidden, nm, { kernelSize: 1 });
  }
  override forward(feats: readonly Value[]): Value {
    let feat = feats[0]!;
    for (let i = 1; i < feats.length; i++) {
      const refined = this.feat_refine.items[i - 1]!.forward(feats[i]!);
      feat = add(feat, upsample2d(refined, { scale: 2 ** i }));
    }
    // The learned ConvTranspose2d is a CHW-storage kernel — hwc4 feats step
    // out for that one op and re-enter for the tail convs.
    const refined = this.cv1.forward(this.feat_fuse.forward(feat));
    const up = toHwc4(this.upsample.forward(toChw(refined, 'f16')));
    return this.cv3.forward(this.cv2.forward(up));
  }
}

export class Segment26 extends Detect {
  readonly one2one_cv4: nn.ModuleList<nn.ModuleList<nn.Module>>;
  readonly proto: Proto26;
  readonly nm: number;
  constructor(
    nc: number,
    regMax: number,
    ch: readonly number[],
    opts: { nm?: number; npr: number },
  ) {
    super(nc, regMax, ch);
    const { nm = 32, npr } = opts;
    this.nm = nm;
    const c4 = Math.max(Math.floor(ch[0]! / 4), nm);
    this.one2one_cv4 = new ModuleList(
      ch.map(
        (x) =>
          new ModuleList<nn.Module>([
            new ConvBlock(x, c4, { kernelSize: 3 }),
            new ConvBlock(c4, c4, { kernelSize: 3 }),
            plainConv1x1(c4, nm),
          ]),
      ),
    );
    this.proto = new Proto26(ch, npr, nm);
  }
  /** Per level: [4 + nc + nm, H, W] — ultralytics channel order (box, cls,
   *  mask coeffs). Raw logits/coeffs; CPU post-process decodes. */
  override forward(feats: readonly Value[]): Value[] {
    return feats.map((f, l) => {
      const box = this.one2one_cv2.items[l]!.forward(f);
      const cls = this.one2one_cv3.items[l]!.forward(f);
      const coef = this.one2one_cv4.items[l]!.forward(f);
      return catHeads([box, cls, coef]);
    });
  }
  forwardProto(feats: readonly Value[]): Value {
    return this.proto.forward(feats);
  }
}
