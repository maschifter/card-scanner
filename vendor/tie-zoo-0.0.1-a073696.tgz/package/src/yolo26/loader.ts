/** Load yolo26 weights from an unfused safetensors export
 *  (tools/export_weights_yolo26.py) via the core streaming loader onto the
 *  initTie() device. BN folding is declared by the blocks themselves
 *  (ConvBlock.transformStateDict); this is just transport + upload. */
import { fromSafetensors, type WeightCache } from '@tie/core';
import type { Yolo26Model, Yolo26Task } from './model.ts';

export async function loadYolo26Weights(
  model: Yolo26Model<Yolo26Task>,
  baseUrl: string,
  opts: {
    onBytes?: (chunkBytes: number) => void;
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
    cache?: WeightCache;
  } = {},
): Promise<void> {
  const url = `${baseUrl}/model.safetensors`;
  // cacheId defaults to the URL basename, which is 'model.safetensors' for
  // every variant here — key by the full URL so variants never collide.
  const sd = await fromSafetensors(url, { onBytes: opts.onBytes, cache: opts.cache, cacheId: url });
  await model.loadStateDict(sd, { onProgress: opts.onProgress });
}
