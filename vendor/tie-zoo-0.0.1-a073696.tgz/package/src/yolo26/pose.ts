/** YOLO26 pose head (ultralytics Pose26, end2end inference path).
 *  Pose26 = Detect (nc=1, person) + a per-level keypoint branch:
 *    one2one_cv4.{l}:      Conv(3×3) → Conv(3×3), c4 = max(ch0/4, nKpt·(ndim+2))
 *    one2one_cv4_kpts.{l}: plain 1×1 conv (bias, no BN/act) → nk = nKpt·ndim
 *  Channels per keypoint are [x, y, vis-logit]; decode is (xy + anchor)·stride
 *  with sigmoid on vis, CPU-side (pipeline.decodePoses). The checkpoint's
 *  cv4_sigma towers and RealNVP flow_model are training-only (ultralytics
 *  fuse() deletes them; our exporter skips them). */

import { nn } from '@tie/core';
import type { Value } from '@tie/core';
import { ConvBlock } from './blocks.ts';
import { catHeads, Detect, plainConv1x1 } from './head.ts';

const { ModuleList } = nn;

export class Pose26 extends Detect {
  readonly one2one_cv4: nn.ModuleList<nn.ModuleList<nn.Module>>;
  readonly one2one_cv4_kpts: nn.ModuleList<nn.Module>;
  readonly nk: number;
  constructor(
    nc: number,
    regMax: number,
    ch: readonly number[],
    opts: { kptShape?: readonly [number, number] } = {},
  ) {
    super(nc, regMax, ch);
    const [nKpt, ndim] = opts.kptShape ?? [17, 3];
    this.nk = nKpt * ndim;
    const c4 = Math.max(Math.floor(ch[0]! / 4), nKpt * (ndim + 2));
    this.one2one_cv4 = new ModuleList(
      ch.map(
        (x) =>
          new ModuleList<nn.Module>([
            new ConvBlock(x, c4, { kernelSize: 3 }),
            new ConvBlock(c4, c4, { kernelSize: 3 }),
          ]),
      ),
    );
    this.one2one_cv4_kpts = new ModuleList(ch.map(() => plainConv1x1(c4, this.nk)));
  }
  /** Per level: [4 + nc + nk, H, W] — ultralytics channel order (box, cls,
   *  keypoints). Raw logits/offsets; CPU post-process decodes. */
  override forward(feats: readonly Value[]): Value[] {
    return super.forward(feats).map((boxCls, l) => {
      const kpt = this.one2one_cv4_kpts.items[l]!.forward(
        this.one2one_cv4.items[l]!.forward(feats[l]!),
      );
      return catHeads([boxCls, kpt]);
    });
  }
}
