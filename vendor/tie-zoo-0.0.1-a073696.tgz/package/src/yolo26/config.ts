/** YOLO26 model constants + compound scaling (ultralytics/cfg/models/26/yolo26.yaml).
 *  A variant scales the yaml's base channel counts by `width` (capped at
 *  maxChannels before scaling) and block repeat counts by `depth`. */

export interface Yolo26Scale {
  depth: number;
  width: number;
  maxChannels: number;
}

/** Compound scaling table from yolo26.yaml. */
export const YOLO26_SCALES = {
  n: { depth: 0.5, width: 0.25, maxChannels: 1024 },
  s: { depth: 0.5, width: 0.5, maxChannels: 1024 },
  m: { depth: 0.5, width: 1.0, maxChannels: 512 },
  l: { depth: 1.0, width: 1.0, maxChannels: 512 },
  x: { depth: 1.0, width: 1.5, maxChannels: 512 },
} as const satisfies Record<string, Yolo26Scale>;

export type Yolo26Variant = keyof typeof YOLO26_SCALES;

/** Ultralytics channel scaling: make_divisible(min(c, maxChannels) · width, 8). */
export function scaleChannels(c: number, scale: Yolo26Scale): number {
  const scaled = Math.min(c, scale.maxChannels) * scale.width;
  return Math.max(Math.round(scaled / 8) * 8, 8);
}

/** Ultralytics depth scaling: max(round(n · depth), 1) for n > 1. */
export function scaleRepeats(n: number, scale: Yolo26Scale): number {
  return n > 1 ? Math.max(Math.round(n * scale.depth), 1) : n;
}

export interface Yolo26Config {
  numClasses: number;
  inputSize: number;
  strides: readonly [number, number, number];
  /** DFL bins — 1 in YOLO26 (plain box regression, no distribution head). */
  regMax: number;
}

export const YOLO26_CONFIG: Yolo26Config = {
  numClasses: 80,
  inputSize: 640,
  strides: [8, 16, 32],
  regMax: 1,
};
