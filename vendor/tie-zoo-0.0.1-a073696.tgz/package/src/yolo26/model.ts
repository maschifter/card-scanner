/** Yolo26Model: the full 24-layer graph from ultralytics yolo26.yaml, laid out
 *  as one flat `model` ModuleList so parameter names match checkpoint keys
 *  (`model.{i}.…` after the exporter strips the outer `model.` prefix).
 *  Param-less yaml layers (nn.Upsample, Concat) get placeholder modules to
 *  keep the indices aligned; forward() wires the skip connections explicitly.
 *  Pass `{ task: 'segment' }` to swap layer 23 from Detect to Segment26;
 *  forward() then returns `{ levels, proto }` instead of the level triple.
 *  `{ task: 'pose' }` swaps in Pose26 (nc defaults to 1 — person) and the
 *  levels grow to [4+nc+51, …]. */

import { astype, cat, nn, toChw, toHwc4, upsample2d } from '@tie/core';
import type { Value } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
import { C3k2, ConvBlock, SPPF } from './blocks.ts';
import { C2PSA, C3k2Attn } from './psa.ts';
import { Detect } from './head.ts';
import { Segment26 } from './seg.ts';
import { Pose26 } from './pose.ts';
import {
  scaleChannels,
  scaleRepeats,
  YOLO26_CONFIG,
  YOLO26_SCALES,
  type Yolo26Variant,
} from './config.ts';

const { Module, ModuleList } = nn;

/** Placeholder for nn.Upsample — no params, keeps yaml indexing. */
class Upsample2x extends Module {
  forward(x: Value): Value {
    return upsample2d(x, { scale: 2 });
  }
}

/** Placeholder for ultralytics' Concat, a param-less nn.Module that occupies a
 *  yaml slot (it adds no state_dict keys, but shifts `model.{i}` numbering):
 *  https://github.com/ultralytics/ultralytics/blob/main/ultralytics/nn/modules/conv.py (class Concat)
 *  Upstream it does the cat itself because BaseModel._predict_once gathers the
 *  saved outputs listed in each layer's `f` and passes the list in:
 *  https://github.com/ultralytics/ultralytics/blob/main/ultralytics/nn/tasks.py (_predict_once)
 *  Our forward() calls cat inline instead and this slot only preserves
 *  checkpoint-key alignment. */
class ConcatSlot extends Module {
  forward(x: Value): Value {
    return x;
  }
}

export type Yolo26Task = 'detect' | 'segment' | 'pose';
/** forward()'s result per task: detect/pose → the [P3, P4, P5] raw-level
 *  triple, segment → the triple plus prototype masks. */
export type Yolo26Output<T extends Yolo26Task> = T extends 'segment'
  ? { levels: [Value, Value, Value]; proto: Value }
  : [Value, Value, Value];

export class Yolo26Model<T extends Yolo26Task = 'detect'> extends Module<[Value], Yolo26Output<T>> {
  readonly model: nn.ModuleList<nn.AnyModule>;
  readonly variant: Yolo26Variant;
  readonly task: Yolo26Task;
  constructor(
    variant: Yolo26Variant = 'n',
    /** `root` feeds half()'s shader-f16 check — defaults to the initTie()
     *  root; graph-only contexts (no device) skip the check. */
    opts: { numClasses?: number; task?: T; root?: TgpuRoot } = {},
  ) {
    super();
    const { task = 'detect' } = opts;
    // Pose checkpoints are single-class (person); detect/seg default to COCO-80.
    const { numClasses = task === 'pose' ? 1 : YOLO26_CONFIG.numClasses } = opts;
    this.variant = variant;
    this.task = task;
    const s = YOLO26_SCALES[variant];
    const c = (base: number) => scaleChannels(base, s);
    const r = (base: number) => scaleRepeats(base, s);
    // m/l/x force c3k=True on every C3k2 (ultralytics parse_model rule).
    const c3kForced = variant === 'm' || variant === 'l' || variant === 'x';
    const k3 = (yamlC3k: boolean) => yamlC3k || c3kForced;

    // Backbone (yaml indices 0–10), base channels in comments.
    const layers: nn.AnyModule[] = [
      new ConvBlock(3, c(64), { kernelSize: 3, stride: 2 }), // 0 P1/2
      new ConvBlock(c(64), c(128), { kernelSize: 3, stride: 2 }), // 1 P2/4
      new C3k2(c(128), c(256), { n: r(2), c3k: k3(false), e: 0.25 }), // 2
      new ConvBlock(c(256), c(256), { kernelSize: 3, stride: 2 }), // 3 P3/8
      new C3k2(c(256), c(512), { n: r(2), c3k: k3(false), e: 0.25 }), // 4
      new ConvBlock(c(512), c(512), { kernelSize: 3, stride: 2 }), // 5 P4/16
      new C3k2(c(512), c(512), { n: r(2), c3k: k3(true) }), // 6
      new ConvBlock(c(512), c(1024), { kernelSize: 3, stride: 2 }), // 7 P5/32
      new C3k2(c(1024), c(1024), { n: r(2), c3k: k3(true) }), // 8
      new SPPF(c(1024), c(1024), { k: 5, n: 3, shortcut: true }), // 9
      new C2PSA(c(1024), c(1024), { n: r(2) }), // 10
      // Head (yaml indices 11–22)
      new Upsample2x(), // 11
      new ConcatSlot(), // 12: cat [11, 6] → c(1024)+c(512)
      new C3k2(c(1024) + c(512), c(512), { n: r(2), c3k: k3(true) }), // 13
      new Upsample2x(), // 14
      new ConcatSlot(), // 15: cat [14, 4] → c(512)+c(512)
      new C3k2(c(512) + c(512), c(256), { n: r(2), c3k: k3(true) }), // 16 P3 out
      new ConvBlock(c(256), c(256), { kernelSize: 3, stride: 2 }), // 17
      new ConcatSlot(), // 18: cat [17, 13] → c(256)+c(512)
      new C3k2(c(256) + c(512), c(512), { n: r(2), c3k: k3(true) }), // 19 P4 out
      new ConvBlock(c(512), c(512), { kernelSize: 3, stride: 2 }), // 20
      new ConcatSlot(), // 21: cat [20, 10] → c(512)+c(1024)
      new C3k2Attn(c(512) + c(1024), c(1024), { n: 1, e: 0.5 }), // 22 P5 out
      task === 'segment'
        ? new Segment26(numClasses, YOLO26_CONFIG.regMax, [c(256), c(512), c(1024)], {
            npr: scaleChannels(256, s), // yaml npr=256, width-scaled (64 for n)
          })
        : task === 'pose'
          ? new Pose26(numClasses, YOLO26_CONFIG.regMax, [c(256), c(512), c(1024)])
          : new Detect(numClasses, YOLO26_CONFIG.regMax, [c(256), c(512), c(1024)]), // 23
    ];
    this.model = new ModuleList(layers);
    // The model runs HWC4+f16 throughout: nn.Conv2d packs mat4 tiles at
    // load, and half() flips the biases and every row-major island to f16.
    this.half(opts.root);
  }

  /** hwc4 head output → CPU-ready f32 CHW. Heads leave the model either
   *  hwc4 (aligned cats) or CHW f16 (catHeads' mixed-alignment fallback). */
  private outF32(v: Value): Value {
    if (v.shape.layout === 'hwc4') return toChw(v, 'f32');
    return astype(v, 'f32');
  }

  /** Backbone + FPN/PAN neck → [P3, P4, P5] feature maps (pre-head). */
  private forwardFeats(x: Value): [Value, Value, Value] {
    // Layers 0–22 are all plain Value→Value; only the head (23) is not, and
    // forward() below calls it separately with the feature triple.
    const m = this.model.items as readonly nn.Module[];
    // Backbone
    const y0 = m[0]!.forward(x);
    const y1 = m[1]!.forward(y0);
    const y2 = m[2]!.forward(y1);
    const y3 = m[3]!.forward(y2);
    const y4 = m[4]!.forward(y3); // → head skip (P3 features, 80×80)
    const y5 = m[5]!.forward(y4);
    const y6 = m[6]!.forward(y5); // → head skip (P4 features, 40×40)
    const y7 = m[7]!.forward(y6);
    const y8 = m[8]!.forward(y7);
    const y9 = m[9]!.forward(y8);
    const y10 = m[10]!.forward(y9); // → head skip (P5 features, 20×20)
    // FPN top-down
    const y13 = m[13]!.forward(cat([m[11]!.forward(y10), y6], 0));
    const y16 = m[16]!.forward(cat([m[14]!.forward(y13), y4], 0)); // P3 out
    // PAN bottom-up
    const y19 = m[19]!.forward(cat([m[17]!.forward(y16), y13], 0)); // P4 out
    const y22 = m[22]!.forward(cat([m[20]!.forward(y19), y10], 0)); // P5 out
    return [y16, y19, y22];
  }

  /** x: [3, H, W] → per-stride raw predictions [4+nc, H/8, W/8], [.., /16],
   *  [.., /32]; segment models add prototype masks [nm, H/4, W/4]. The
   *  `as Yolo26Output<T>` casts bridge the runtime `this.task` check to the
   *  compile-time `T` — TS cannot link the two on its own. */
  override forward(x: Value): Yolo26Output<T> {
    const feats = this.forwardFeats(toHwc4(x));
    const out = (v: Value) => this.outF32(v);
    if (this.task === 'segment') {
      const head = this.model.items[23] as Segment26;
      const [d3, d4, d5] = head.forward(feats);
      return {
        levels: [out(d3!), out(d4!), out(d5!)],
        proto: out(head.forwardProto(feats)),
      } as Yolo26Output<T>;
    }
    const [d3, d4, d5] = (this.model.items[23] as Detect).forward(feats);
    return [out(d3!), out(d4!), out(d5!)] as Yolo26Output<T>;
  }
}
