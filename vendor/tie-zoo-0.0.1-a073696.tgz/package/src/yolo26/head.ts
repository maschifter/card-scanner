/** YOLO26 Detect head (ultralytics head.py, end2end inference path).
 *  reg_max=1 → no DFL, the box branch emits 4 raw ltrb distances directly.
 *  End-to-end inference uses ONLY the one2one_cv2/one2one_cv3 towers (the
 *  one2many cv2/cv3 exist in the checkpoint for training alone — the loader
 *  skips them). Field names match checkpoint keys:
 *    one2one_cv2.{l}: Conv(3×3) → Conv(3×3) → plain 1×1 conv (bias, no BN/act)
 *    one2one_cv3.{l}: [DWConv(3×3)+Conv(1×1)] ×2 → plain 1×1 conv */

import { cat, nn, toChw } from '@tie/core';
import type { Value } from '@tie/core';
import { ConvBlock } from './blocks.ts';

const { Conv2d, Module, ModuleList } = nn;
// Tower stages (ConvBlock / DWConv / plain 1x1) are all plain Value→Value.
type Tower = nn.ModuleList<nn.Module>;

function gcd(a: number, b: number): number {
  return b === 0 ? a : gcd(b, a % b);
}

/** ultralytics DWConv: Conv with groups = gcd(c1, c2). */
function dwConv(c1: number, c2: number, k: number): ConvBlock {
  return new ConvBlock(c1, c2, { kernelSize: k, groups: gcd(c1, c2) });
}

/** Plain nn.Conv2d 1×1 (bias, no BN, no activation) — the towers' last layer.
 *  Registered directly (not via ConvBlock) so its keys are `{i}.weight` /
 *  `{i}.bias` like the checkpoint's. */
export function plainConv1x1(c1: number, c2: number): InstanceType<typeof Conv2d> {
  return new Conv2d(c1, c2, { kernelSize: 1, bias: true });
}

/** Channel-concat head outputs whatever their storage: hwc4 parts whose
 *  channel counts all align to 4 concat in place; anything else (pose's
 *  1-channel cls, 51-channel kpts) drops to CHW f16 first — head maps are
 *  tiny, the copies are noise. */
export function catHeads(parts: readonly Value[]): Value {
  if (
    parts.every((p) => p.shape.layout === 'hwc4') &&
    parts.every((p) => p.shape.dims![0]! % 4 === 0)
  ) {
    return cat(parts, 0);
  }
  return cat(
    parts.map((p) => (p.shape.layout === 'hwc4' ? toChw(p, 'f16') : p)),
    0,
  );
}

export class Detect extends Module<[readonly Value[]], Value[]> {
  readonly one2one_cv2: nn.ModuleList<Tower>;
  readonly one2one_cv3: nn.ModuleList<Tower>;
  readonly nc: number;
  constructor(nc: number, regMax: number, ch: readonly number[]) {
    super();
    this.nc = nc;
    const c2 = Math.max(16, Math.floor(ch[0]! / 4), regMax * 4);
    const c3 = Math.max(ch[0]!, Math.min(nc, 100));
    this.one2one_cv2 = new ModuleList(
      ch.map(
        (x) =>
          new ModuleList<nn.Module>([
            new ConvBlock(x, c2, { kernelSize: 3 }),
            new ConvBlock(c2, c2, { kernelSize: 3 }),
            plainConv1x1(c2, 4 * regMax),
          ]),
      ),
    );
    this.one2one_cv3 = new ModuleList(
      ch.map(
        (x) =>
          new ModuleList<nn.Module>([
            new ModuleList<nn.Module>([dwConv(x, x, 3), new ConvBlock(x, c3, { kernelSize: 1 })]),
            new ModuleList<nn.Module>([
              dwConv(c3, c3, 3),
              new ConvBlock(c3, c3, { kernelSize: 1 }),
            ]),
            plainConv1x1(c3, nc),
          ]),
      ),
    );
  }
  /** Per level: [4 + nc, H, W] — box distances stacked over class logits.
   *  Raw (no sigmoid/decode); the CPU post-process handles that. */
  override forward(feats: readonly Value[]): Value[] {
    return feats.map((f, l) => {
      const box = this.one2one_cv2.items[l]!.forward(f);
      const cls = this.one2one_cv3.items[l]!.forward(f);
      return catHeads([box, cls]);
    });
  }
}
