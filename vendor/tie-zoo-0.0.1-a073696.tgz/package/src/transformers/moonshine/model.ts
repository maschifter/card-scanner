import { PreTrainedModel, Tensor, type PretrainedConfig } from '@huggingface/transformers';
import { defaultRoot, inGpuErrorScopes } from '@tie/core';
import { MIN_SAMPLES } from '../../moonshine/convStem.ts';
import type { Transcriber } from '../../moonshine/transcriber.ts';

/** Speech-to-text stand-in running the zoo moonshine transcriber. The
 *  pipeline hands over 16 kHz audio as `input_values` [1, samples] and
 *  gets back the generated ids as int64 [1, L], BOS first, EOS last when
 *  reached; it decodes the text with the hub tokenizer. The transcriber
 *  does everything from audio to ids: encoder, greedy burst decode, and
 *  splitting clips longer than its chunk limit. */
export class TieMoonshineForConditionalGeneration extends PreTrainedModel {
  constructor(
    config: PretrainedConfig,
    private readonly tie: Pick<Transcriber, 'transcribe'>,
    private readonly tokens: { bos: number; eos: number },
  ) {
    super(config, {}, {});
  }

  /** Only `input_values` (or `inputs`) is read. Generation options like
   *  `max_new_tokens` are ignored: decoding is always greedy and stops at
   *  EOS or the transcriber's own token budget. */
  override async generate(options: {
    inputs?: Tensor | null;
    [key: string]: unknown;
  }): Promise<Tensor> {
    const audio = (options['input_values'] as Tensor | undefined) ?? options.inputs;
    if (!audio) throw new Error('tie backend: moonshine generate() needs input_values');
    if (audio.dims.length !== 2 || audio.dims[0] !== 1) {
      throw new Error(
        `tie backend: moonshine takes one clip per call, got input_values [${audio.dims}]`,
      );
    }
    const samples = audio.data as Float32Array;
    // Too short for one encoder frame: the empty transcript.
    const ids =
      samples.length < MIN_SAMPLES
        ? [this.tokens.bos, this.tokens.eos]
        : (
            await inGpuErrorScopes(defaultRoot().device, 'inference', () =>
              this.tie.transcribe(samples),
            )
          ).ids;
    return new Tensor('int64', BigInt64Array.from(ids.map(BigInt)), [1, ids.length]);
  }
}
