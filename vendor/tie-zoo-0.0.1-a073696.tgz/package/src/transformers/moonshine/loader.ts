import { defaultRoot, inGpuErrorScopes } from '@tie/core';
import type { PretrainedConfig } from '@huggingface/transformers';
import {
  MOONSHINE_BASE,
  MOONSHINE_TINY,
  assertConfigMatches,
  configFromCheckpoint,
  type MoonshineConfig,
} from '../../moonshine/config.ts';
import type { MoonshineTokenizer } from '../../moonshine/tokenizer.ts';
import { createTranscriber } from '../../moonshine/transcriber.ts';
import { TieMoonshineForConditionalGeneration } from './model.ts';
import { cachedWeightsSource } from '../weights.ts';
import type { TieModelLoader } from '../registry.ts';

/** The official checkpoints (f32), loaded as f16. Picked by the hub
 *  config's size. */
const MOONSHINE_WEIGHTS_URLS = {
  tiny: 'https://huggingface.co/moonshine-ai/moonshine-tiny/resolve/main/model.safetensors',
  base: 'https://huggingface.co/moonshine-ai/moonshine-base/resolve/main/model.safetensors',
} as const;

/** The hub repos with a full tokenizer_config.json; the original
 *  moonshine-ai repos lack it, so the stock pipeline cannot decode there. */
export const MOONSHINE_MODEL_IDS = [
  'onnx-community/moonshine-tiny-ONNX',
  'onnx-community/moonshine-base-ONNX',
];

/** Parses the hub config and matches it to the tiny or base preset. Throws
 *  on any other size or on a field the presets do not have. The preset's
 *  position count wins: the onnx-community configs say 512, the official
 *  moonshine-ai configs 194. */
export function moonshinePreset(config: PretrainedConfig): {
  size: 'tiny' | 'base';
  cfg: MoonshineConfig;
} {
  const parsed = configFromCheckpoint(config as unknown as Record<string, unknown>);
  const size =
    parsed.dModel === MOONSHINE_TINY.dModel
      ? 'tiny'
      : parsed.dModel === MOONSHINE_BASE.dModel
        ? 'base'
        : undefined;
  if (!size) {
    throw new Error(`tie backend: moonshine hidden_size ${parsed.dModel} is neither tiny nor base`);
  }
  const cfg = size === 'tiny' ? MOONSHINE_TINY : MOONSHINE_BASE;
  assertConfigMatches({ ...parsed, maxPositions: cfg.maxPositions }, cfg);
  return { size, cfg };
}

/** The transcriber builds a `text` field next to the ids; the plugin uses
 *  the ids only, so it gets a vocabulary of empty strings. */
function idsOnlyTokenizer(cfg: MoonshineConfig): MoonshineTokenizer {
  return {
    version: 0,
    bosId: cfg.bos,
    eosId: cfg.eos,
    specialIds: [cfg.bos, cfg.eos],
    vocab: new Array<string>(cfg.vocab).fill(''),
  };
}

/** `weightsUrl`: an HF moonshine checkpoint; defaults to the official one
 *  for the size the hub config names. Weights land on the GPU as f16 unless
 *  `weightDtype` says f32. */
export function moonshineLoader(
  weightsUrl?: string,
  opts: {
    weightDtype?: 'f16' | 'f32';
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
  } = {},
): TieModelLoader {
  return {
    async load(_modelId, config) {
      defaultRoot(); // fail fast (→ ONNX fallback) before fetching weights
      const { size, cfg } = moonshinePreset(config);
      const url = weightsUrl ?? MOONSHINE_WEIGHTS_URLS[size];
      const source = await cachedWeightsSource(
        url,
        `whole/moonshine-v1/${size}/${url.split('/').pop()!}`,
      );
      const transcriber = await createTranscriber(source, idsOnlyTokenizer(cfg), {
        cfg,
        weightDtype: opts.weightDtype ?? 'f16',
        onProgress: opts.onProgress,
      });
      // One second of silence compiles every pipeline before the first call.
      await inGpuErrorScopes(defaultRoot().device, 'plugin warm-up', () =>
        transcriber.transcribe(new Float32Array(16_000)),
      );
      return new TieMoonshineForConditionalGeneration(config, transcriber, cfg);
    },
  };
}
