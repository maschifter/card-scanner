import { defaultRoot } from '@tie/core';
import type { PretrainedConfig } from '@huggingface/transformers';
import { V2_NER_CLASS_NAMES } from '../../privacy-filter/config.ts';
import { loadPrivacyFilterModel } from '../../privacy-filter/detector.ts';
import { TiePrivacyFilterForTokenClassification } from './model.ts';
import { loadStreamedWeights } from '../weights.ts';
import type { TieModelLoader } from '../registry.ts';

/** The official checkpoint (bf16, 2.8 GB), loaded as f16. */
const PRIVACY_FILTER_WEIGHTS_URL =
  'https://huggingface.co/openai/privacy-filter/resolve/main/model.safetensors';

export const PRIVACY_FILTER_MODEL_IDS = ['openai/privacy-filter'];

/** Shape the TIE model is built for. The hub config must match it. */
const EXPECTED_CONFIG = {
  hidden_size: 640,
  num_hidden_layers: 8,
  num_local_experts: 128,
  num_experts_per_tok: 4,
} as const;

/** Throws when the hub config has other dimensions or another label order
 *  than the TIE model. */
export function assertPrivacyFilterConfig(config: PretrainedConfig): void {
  const cfg = config as unknown as Record<string, unknown>;
  for (const [key, expected] of Object.entries(EXPECTED_CONFIG)) {
    if (cfg[key] !== expected) {
      throw new Error(
        `tie backend: privacy-filter config ${key} is ${String(cfg[key])}, expected ${expected}`,
      );
    }
  }
  const id2label = cfg['id2label'] as Record<string, string> | undefined;
  if (!id2label) throw new Error('tie backend: privacy-filter config is missing id2label');
  V2_NER_CLASS_NAMES.forEach((name, i) => {
    if (id2label[String(i)] !== name) {
      throw new Error(
        `tie backend: privacy-filter label ${i} is '${id2label[String(i)]}', expected '${name}'`,
      );
    }
  });
}

/** `weightsUrl`: the official checkpoint or an int8 file from
 *  tools/export_pf_safetensors.py. */
export function privacyFilterLoader(
  weightsUrl: string = PRIVACY_FILTER_WEIGHTS_URL,
  opts: {
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
  } = {},
): TieModelLoader {
  return {
    async load(_modelId, config) {
      defaultRoot(); // fail fast (→ ONNX fallback) before fetching weights
      assertPrivacyFilterConfig(config);
      // The file is gigabytes: streamed by byte range, never whole in memory.
      const sd = await loadStreamedWeights(
        weightsUrl,
        `range/privacy-filter-v1/${weightsUrl.split('/').pop()!}`,
      );
      const { model } = await loadPrivacyFilterModel(sd, { onProgress: opts.onProgress });
      return new TiePrivacyFilterForTokenClassification(config, model);
    },
  };
}
