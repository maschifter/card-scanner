import { defaultRoot, inGpuErrorScopes } from '@tie/core';
import { MINILM_L6 } from '../../minilm/config.ts';
import { MinilmModel } from '../../minilm/model.ts';
import { TieBertModel } from './model.ts';
import { loadCachedWeights } from '../weights.ts';
import type { TieModelLoader } from '../registry.ts';

/** The original sentence-transformers checkpoint; loadStateDict fuses qkv
 *  and folds the token-type embedding while loading it. */
const MINILM_WEIGHTS_URL =
  'https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/model.safetensors';

export const MINILM_MODEL_IDS = [
  'Xenova/all-MiniLM-L6-v2',
  'sentence-transformers/all-MiniLM-L6-v2',
];

export function minilmLoader(weightsUrl: string = MINILM_WEIGHTS_URL): TieModelLoader {
  return {
    async load(_modelId, config) {
      defaultRoot(); // fail fast (→ ONNX fallback) before fetching weights
      const sd = await loadCachedWeights(
        weightsUrl,
        `whole/minilm-v1/${weightsUrl.split('/').pop()!}`,
      );
      const model = new MinilmModel(MINILM_L6);
      await model.loadStateDict(sd);
      const wrapped = new TieBertModel(config, model);
      await inGpuErrorScopes(defaultRoot().device, 'plugin warm-up', () => wrapped.warm());
      return wrapped;
    },
  };
}
