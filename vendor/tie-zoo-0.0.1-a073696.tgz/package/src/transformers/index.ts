/** transformers.js plugin: hub ids we implement load as TypeGPU zoo models
 *  through the stock pipeline() call.
 *  - init.ts       one-call setup: device + initTie + registerTieBackend
 *  - registry.ts   patches PreTrainedModel.from_pretrained and holds the
 *                  id → loader registry
 *  - weights.ts    OPFS weight caches for the loaders: whole-file for small
 *                  models, byte ranges for big ones
 *  - tieModel.ts   isTieModel, knows every wrapper class
 *  One folder per zoo model, each with:
 *  - model.ts      the transformers.js model stand-in running the zoo model
 *  - loader.ts     fetches the weights and builds the stand-in for a hub id */

export { initTieBackend } from './init.ts';
export {
  registerTieBackend,
  unregisterTieBackend,
  type RegisterTieBackendOpts,
  type TieModelLoader,
} from './registry.ts';
export { isTieModel } from './tieModel.ts';
export { minilmLoader } from './minilm/loader.ts';
export { privacyFilterLoader } from './privacy-filter/loader.ts';
export { moonshineLoader } from './moonshine/loader.ts';
export { yolo26Loader } from './yolo26/loader.ts';
