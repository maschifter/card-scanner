import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { initTie } from '@tie/core';
import { registerTieBackend, type RegisterTieBackendOpts } from './registry.ts';

/** One-call plugin setup: creates the WebGPU device, points @tie/core at it
 *  and patches transformers.js. Requests the subgroups feature, which the
 *  fast matmul and attention kernels need. Options go straight to
 *  registerTieBackend(), so `models` and `fallbackToOnnx` work here too.
 *  Returns the root for apps that also use TypeGPU directly. */
export async function initTieBackend(opts: RegisterTieBackendOpts = {}): Promise<TgpuRoot> {
  const root = await tgpu.init({ device: { optionalFeatures: ['subgroups'] } });
  initTie(root);
  registerTieBackend(opts);
  return root;
}
