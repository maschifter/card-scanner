import {
  bufferSource,
  createOpfsCache,
  fromSafetensors,
  httpRangeSource,
  type RangeSource,
} from '@tie/core';

/** Loads a safetensors file too big to hold in memory: byte ranges are
 *  fetched per tensor and saved in OPFS under `cacheId`. */
export async function loadStreamedWeights(
  url: string,
  cacheId: string,
): Promise<Awaited<ReturnType<typeof fromSafetensors>>> {
  const cache = await createOpfsCache('tie-weights');
  return fromSafetensors(url, { cache, cacheId });
}

/** The whole safetensors file, cached in OPFS under `key`: one network
 *  fetch cold, none warm. Whole-file on purpose — caching byte ranges turns
 *  a cold load into hundreds of CDN round-trips. */
export async function cachedWeightsSource(url: string, key: string): Promise<RangeSource> {
  const cache = await createOpfsCache('tie-weights');
  if (!cache) return httpRangeSource(url);
  const fetchAll = async () => {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`tie backend: fetching weights failed (${res.status})`);
    return new Uint8Array(await res.arrayBuffer());
  };
  const fromCache = async () => bufferSource(await cache.getOrCompute(key, fetchAll));
  let source = await fromCache();
  try {
    await fromSafetensors(source); // header parse only
  } catch {
    // A truncated cache entry (a write interrupted mid-download) fails the
    // header parse. Drop the cache and reload from the network.
    await cache.clear();
    source = await fromCache();
  }
  return source;
}

/** Loads a safetensors file from the whole-file cache. */
export async function loadCachedWeights(
  url: string,
  key: string,
): Promise<Awaited<ReturnType<typeof fromSafetensors>>> {
  return fromSafetensors(await cachedWeightsSource(url, key));
}
