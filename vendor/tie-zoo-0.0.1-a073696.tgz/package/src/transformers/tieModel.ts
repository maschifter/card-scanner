import { TieBertModel } from './minilm/model.ts';
import { TiePrivacyFilterForTokenClassification } from './privacy-filter/model.ts';
import { TieMoonshineForConditionalGeneration } from './moonshine/model.ts';
import { TieYolosForObjectDetection } from './yolo26/model.ts';

/** True when a model is one of the plugin's TypeGPU ones, not the ONNX
 *  fallback. */
export function isTieModel(model: unknown): boolean {
  return (
    model instanceof TieBertModel ||
    model instanceof TiePrivacyFilterForTokenClassification ||
    model instanceof TieMoonshineForConditionalGeneration ||
    model instanceof TieYolosForObjectDetection
  );
}
