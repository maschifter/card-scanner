import { defaultRoot, fromSafetensors, inGpuErrorScopes } from '@tie/core';
import { YOLO26_SCALES, scaleChannels, type Yolo26Variant } from '../../yolo26/config.ts';
import { Yolo26Model } from '../../yolo26/model.ts';
import { createYolo26Detector } from './detector.ts';
import { TieYolosForObjectDetection } from './model.ts';
import { cachedWeightsSource } from '../weights.ts';
import type { TieModelLoader } from '../registry.ts';

/** The variant letter in a hub id such as `onnx-community/yolo26s-ONNX`. */
export function yolo26Variant(modelId: string): Yolo26Variant {
  const m = /yolo26([nsmlx])(?![a-z])/i.exec(modelId);
  if (!m) throw new Error(`tie backend: cannot tell the yolo26 variant from '${modelId}'`);
  return m[1]!.toLowerCase() as Yolo26Variant;
}

/** `weightsUrl`: a safetensors export of the ultralytics checkpoint
 *  (tools/export_weights_yolo26.py); the hub has none, so the caller hosts
 *  it and registers the loader under a hub id such as
 *  `onnx-community/yolo26n-ONNX`, whose config, labels and image processor
 *  the pipeline keeps using. `variant` overrides the letter read from the
 *  id. */
export function yolo26Loader(
  weightsUrl: string,
  opts: {
    variant?: Yolo26Variant;
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
  } = {},
): TieModelLoader {
  return {
    async load(modelId, config) {
      const root = defaultRoot(); // fail fast (→ ONNX fallback) before fetching weights
      const variant = opts.variant ?? yolo26Variant(modelId);
      const source = await cachedWeightsSource(
        weightsUrl,
        `whole/yolo26/${variant}/${weightsUrl.split('/').pop()!}`,
      );
      const sd = await fromSafetensors(source);
      const stem = sd.tensors.get('model.0.conv.weight');
      const want = scaleChannels(64, YOLO26_SCALES[variant]);
      if (stem?.shape[0] !== want) {
        throw new Error(
          `tie backend: '${weightsUrl}' is not a yolo26${variant} checkpoint (stem has ${stem?.shape[0] ?? 'no'} channels, expected ${want})`,
        );
      }
      const model = new Yolo26Model(variant, { task: 'detect' });
      await model.loadStateDict(sd, { onProgress: opts.onProgress });
      // Capturing the frame compiles and runs every kernel before the first call.
      const detector = await inGpuErrorScopes(root.device, 'plugin warm-up', () =>
        createYolo26Detector(model),
      );
      return new TieYolosForObjectDetection(config, detector);
    },
  };
}
