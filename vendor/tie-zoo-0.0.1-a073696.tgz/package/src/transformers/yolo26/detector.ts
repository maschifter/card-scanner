import {
  defaultRoot,
  evalValues,
  gpuExecutor,
  materialized,
  tensor3d,
  uploadF32,
  writeF32,
  type Value,
} from '@tie/core';
import type { TgpuRoot } from 'typegpu';
import { YOLO26_CONFIG } from '../../yolo26/config.ts';
import type { Yolo26Model } from '../../yolo26/model.ts';
import type { RawLevel } from '../../yolo26/pipeline.ts';
import type { Yolo26Detector } from './model.ts';

/** Records the forward once and replays it per image: one input buffer
 *  rewritten in place, the three level readbacks riding the replay's own
 *  submit. Runs on its own executor, since a captured executor is
 *  replay-only. Resolves once the recording's submit is done, so the
 *  caller's warm-up covers the kernels' first run. Calls run one at a time.
 *  `root` defaults to the initTie() root. */
export async function createYolo26Detector(
  model: Yolo26Model<'detect'>,
  opts: { maxDet?: number; root?: TgpuRoot } = {},
): Promise<Yolo26Detector> {
  const { inputSize: size, strides } = YOLO26_CONFIG;
  const { maxDet = 300, root = defaultRoot() } = opts;
  const ex = gpuExecutor(root);
  const buffer = uploadF32(root, new Float32Array(3 * size * size));
  const input = materialized(tensor3d(3, size, size), buffer);
  const cap = ex.captureFrame(() => {
    const targets: Value[] = [...model.forward(input)];
    evalValues(targets, ex);
    return targets;
  });
  await root.device.queue.onSubmittedWorkDone();
  // Each level is [4 + classes, h, w].
  const numClasses = cap.targets[0]!.shape.dims![0]! - 4;
  const toLevels = (outs: readonly Float32Array[]): RawLevel[] =>
    cap.targets.map((p, i) => ({
      data: outs[i]!,
      h: p.shape.dims![1]!,
      w: p.shape.dims![2]!,
      stride: strides[i]!,
    }));
  let busy: Promise<unknown> = Promise.resolve();
  return {
    inputSize: size,
    numClasses,
    maxDet,
    run(pixels) {
      const job = busy.then(async () => {
        writeF32(root, buffer, pixels);
        const outs = ex.readbackManyOnSubmit(cap.targets);
        cap.replay();
        return toLevels(await outs);
      });
      busy = job.catch(() => undefined);
      return job;
    },
  };
}
