import type { RawLevel } from '../../yolo26/pipeline.ts';

/** `a` ranks above `b`: higher score, index breaks ties. */
const beats = (score: Float32Array, a: number, b: number) =>
  score[a]! > score[b]! || (score[a] === score[b] && a < b);

/** Indices of the `k` highest scores, best first. A min-heap of size k over
 *  the candidates, so the full array is never sorted. */
export function topIndices(score: Float32Array, k: number): number[] {
  const n = score.length;
  const size = Math.min(k, n);
  const heap = new Int32Array(size);
  let len = 0;
  const siftDown = (start: number) => {
    let i = start;
    for (;;) {
      const l = 2 * i + 1;
      const r = l + 1;
      let worst = i;
      if (l < len && beats(score, heap[worst]!, heap[l]!)) worst = l;
      if (r < len && beats(score, heap[worst]!, heap[r]!)) worst = r;
      if (worst === i) return;
      const t = heap[i]!;
      heap[i] = heap[worst]!;
      heap[worst] = t;
      i = worst;
    }
  };
  for (let i = 0; i < n; i++) {
    if (len < size) {
      heap[len] = i;
      let j = len++;
      while (j > 0) {
        const parent = (j - 1) >> 1;
        if (!beats(score, heap[parent]!, heap[j]!)) break;
        const t = heap[j]!;
        heap[j] = heap[parent]!;
        heap[parent] = t;
        j = parent;
      }
    } else if (beats(score, i, heap[0]!)) {
      heap[0] = i;
      siftDown(0);
    }
  }
  return Array.from(heap.subarray(0, len)).sort((a, b) => (beats(score, a, b) ? -1 : 1));
}

export interface TopAnchors {
  /** [count, numClasses] raw class logits, best anchor first. */
  logits: Float32Array;
  /** [count, 4] boxes as [cx, cy, w, h], divided by the input size. */
  boxes: Float32Array;
  count: number;
}

/** Picks the `maxDet` anchors with the highest class logit over every level
 *  and lays them out the way the stock object-detection pipeline reads a
 *  yolos model: raw logits per class and normalized center boxes, sorted by
 *  the top logit. The hub ONNX export ends in the same top-k, so both engines
 *  hand the pipeline the same rows. */
export function selectTopAnchors(
  levels: readonly RawLevel[],
  opts: { numClasses: number; maxDet: number; inputSize: number },
): TopAnchors {
  const { numClasses, maxDet, inputSize } = opts;
  const total = levels.reduce((n, l) => n + l.h * l.w, 0);
  // Best class logit per anchor; the class loop is outermost so each pass
  // reads one channel plane sequentially.
  const best = new Float32Array(total).fill(-Infinity);
  let base = 0;
  for (const { data, h, w } of levels) {
    const hw = h * w;
    for (let c = 0; c < numClasses; c++) {
      const plane = (4 + c) * hw;
      for (let i = 0; i < hw; i++) {
        const v = data[plane + i]!;
        if (v > best[base + i]!) best[base + i] = v;
      }
    }
    base += hw;
  }
  const order = topIndices(best, maxDet);
  const count = Math.min(maxDet, total);
  const logits = new Float32Array(count * numClasses);
  const boxes = new Float32Array(count * 4);
  for (let k = 0; k < count; k++) {
    let idx = order[k]!;
    let level = 0;
    while (idx >= levels[level]!.h * levels[level]!.w) {
      idx -= levels[level]!.h * levels[level]!.w;
      level++;
    }
    const { data, h, w, stride } = levels[level]!;
    const hw = h * w;
    for (let c = 0; c < numClasses; c++) logits[k * numClasses + c] = data[(4 + c) * hw + idx]!;
    const ax = (idx % w) + 0.5;
    const ay = Math.floor(idx / w) + 0.5;
    const l = data[idx]!;
    const t = data[hw + idx]!;
    const r = data[2 * hw + idx]!;
    const b = data[3 * hw + idx]!;
    const scale = stride / inputSize;
    boxes[k * 4] = (ax + (r - l) / 2) * scale;
    boxes[k * 4 + 1] = (ay + (b - t) / 2) * scale;
    boxes[k * 4 + 2] = (l + r) * scale;
    boxes[k * 4 + 3] = (t + b) * scale;
  }
  return { logits, boxes, count };
}
