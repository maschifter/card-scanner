import { PreTrainedModel, Tensor, type PretrainedConfig } from '@huggingface/transformers';
import { defaultRoot, inGpuErrorScopes } from '@tie/core';
import type { RawLevel } from '../../yolo26/pipeline.ts';
import { selectTopAnchors } from './output.ts';

/** The GPU side of the stand-in: one image in, the raw detect levels out. */
export interface Yolo26Detector {
  inputSize: number;
  numClasses: number;
  maxDet: number;
  /** `pixels`: CHW RGB in [0, 1], inputSize² per channel. */
  run(pixels: Float32Array): Promise<RawLevel[]>;
}

/** Object-detection stand-in running the zoo yolo26 model. The pipeline's
 *  image processor hands over one stretched `pixel_values` image
 *  [1, 3, S, S] in [0, 1]; the model returns the top anchors as
 *  `logits` [1, maxDet, classes] and `pred_boxes` [1, maxDet, 4], the
 *  layout the stock post-processing reads for a yolos model. */
export class TieYolosForObjectDetection extends PreTrainedModel {
  constructor(
    config: PretrainedConfig,
    private readonly tie: Yolo26Detector,
  ) {
    super(config, {}, {});
  }

  override async forward(inputs: Record<string, Tensor>): Promise<Record<string, Tensor>> {
    const pixels = inputs['pixel_values'];
    if (!pixels) throw new Error('tie backend: yolo26 forward() needs pixel_values');
    const { inputSize: size, numClasses } = this.tie;
    const [n, c, h, w] = pixels.dims;
    if (n !== 1 || c !== 3 || h !== size || w !== size) {
      throw new Error(
        `tie backend: yolo26 takes one ${size}×${size} RGB image per call, got pixel_values [${pixels.dims}]`,
      );
    }
    const levels = await inGpuErrorScopes(defaultRoot().device, 'inference', () =>
      this.tie.run(pixels.data as Float32Array),
    );
    const top = selectTopAnchors(levels, { numClasses, maxDet: this.tie.maxDet, inputSize: size });
    return {
      logits: new Tensor('float32', top.logits, [1, top.count, numClasses]),
      pred_boxes: new Tensor('float32', top.boxes, [1, top.count, 4]),
    };
  }
}
