/** Moonshine transcriber: load once, then transcribe(audio) = encode once +
 *  greedy KV-cached decode.
 *
 *  Audio of any length is accepted: clips over the decoder's ~30 s position
 *  budget are split on quiet points (see chunking.ts), each chunk transcribed
 *  as its own utterance, texts joined and ids/timings concatenated. A clip
 *  within the budget takes the single-utterance path untouched.
 *
 *  Per utterance: upload audio + encoder rope tables (utterance-sized),
 *  run stem + encoder + every layer's cross K/V in ONE eval with the K/V
 *  Values as co-targets (only eval targets survive the eval boundary), then
 *  decode in BURSTS of up to 8 positions per submit: within a burst each
 *  step's fused gemv+argmax id feeds the next step's embedding ON DEVICE
 *  (embedFrom) and lands in row t of a preallocated id buffer (writeRows),
 *  so the GPU runs 8 tokens without a single CPU round-trip; one readback
 *  of the id rows closes the burst, appends, and stops at EOS or
 *  min(maxPositions, ceil(6.5 tokens/s of audio)). A burst may overshoot
 *  EOS by up to 7 positions — those steps are cheap, their ids are
 *  discarded, and the cache rows they touch are dead (nothing reads past
 *  the truncation point, and the next utterance overwrites from row 0).
 *  The per-step dispatch count and memory traffic are constant in the
 *  sequence length; only the attention key scan grows with position.
 *
 *  Decoder rope tables are built and uploaded once at maxPositions and
 *  sliced to the live position — nothing re-uploads per step, and the
 *  per-step DAG has a constant shape, so no pipeline ever recompiles.
 *  Self-attention K/V caches are PREALLOCATED [maxPositions, qw] buffers
 *  (one k + one v per layer, transcriber-lifetime): each step writes row t
 *  in place (writeRows — never copies the existing rows) and nothing about
 *  them is pinned or released. Per step only the id readback buffer cycles;
 *  per utterance the cross K/V and encoder output are released — GPU memory
 *  stays flat. Utterances reuse the cache buffers (rows overwrite from 0),
 *  so transcribe() calls must stay sequential. */

import {
  defaultRoot,
  evalValues,
  fromSafetensors,
  gpuExecutor,
  slice,
  tensor,
  writeRows,
  type GpuPerfSink,
  type RangeSource,
  type Value,
  type WeightCache,
} from '@tie/core';
import { MOONSHINE_TINY, type MoonshineConfig } from './config.ts';
import { splitIntoChunks, type ChunkOpts } from './chunking.ts';
import { buildRopeTables } from './rope.ts';
import { stemFrames } from './convStem.ts';
import { MoonshineModel } from './model.ts';
import type { SelfKV } from './decoder.ts';
import { decodeTokens, type MoonshineTokenizer } from './tokenizer.ts';

export interface TranscribeResult {
  /** Full generated sequence including BOS and (when reached) EOS —
   *  concatenated across chunks when the clip was split. */
  ids: number[];
  text: string;
  /** Summed across chunks when the clip was split. */
  timings: { encodeMs: number; decodeMs: number; steps: number };
}

export interface Transcriber {
  /** audio: 16 kHz mono PCM, ≥ 895 samples (one encoder frame); any length. */
  transcribe(audio: Float32Array): Promise<TranscribeResult>;
}

/** One decode burst's CPU-side spans (diagnostic; see TranscriberPerf). */
export interface BurstSample {
  /** Positions submitted this burst (may overshoot EOS). */
  positions: number;
  /** DAG construction: the forwardStep loop (pure JS, no GPU calls). */
  buildMs: number;
  /** evalValues: DAG walk + dispatch encode + queue.submit. */
  evalMs: number;
  /** Awaiting the ids readback (staging copy + mapAsync round trip). */
  readbackMs: number;
}

/** Measurement taps and scheduling knobs. All hooks are observational except
 *  `burst` and `syncAfterEncode`, which change scheduling (never math): burst
 *  resizes the positions-per-submit window; syncAfterEncode awaits queue idle
 *  after the encoder eval so encodeMs/decodeMs attribute GPU time honestly —
 *  for any caller that displays the split. Callers that only need the
 *  transcript omit it and keep the encode/decode overlap. */
export interface TranscriberPerf {
  burst?: number;
  syncAfterEncode?: boolean;
  gpuPerf?: GpuPerfSink;
  onBurst?(sample: BurstSample): void;
  /** Fired before the encoder eval / before the decode loop of each
   *  utterance — lets a gpuPerf sink attribute its onSubmit events to a
   *  phase (execution is sequential, so the last onPhase wins). */
  onPhase?(phase: 'encode' | 'decode'): void;
}

const SAMPLE_RATE = 16_000;
const TOKENS_PER_SECOND = 6.5;
/** Decode positions per submit — the EOS-overshoot / round-trip trade-off. */
const BURST = 8;
/** Per-chunk audio ceiling. The decoder position budget allows ~30 s
 *  (194 positions at ~6.5 tokens/s); 26 keeps one chunk's encode submit
 *  under the Windows TDR 2-second GPU timeout. */
const MAX_CHUNK_SECONDS = 26;
/** Tail span scanned for a quiet cut point when splitting long clips. */
const SPLIT_SEARCH_SECONDS = 5;

export async function createTranscriber(
  weights: string | RangeSource,
  tokenizer: MoonshineTokenizer,
  opts: {
    cfg?: MoonshineConfig;
    /** 'f16' is NATIVE half precision: every parameter AND every activation
     *  is f16 (model.half()) — halved memory traffic and bandwidth, not just
     *  storage. An f16 weights file feeds the params bit-exactly; an f32 file
     *  is rounded to f16 at load. */
    weightDtype?: 'f32' | 'f16';
    /** Caches every fetched byte range of the weights file — warm loads
     *  touch no network. Keys embed `cacheId` (defaults to the URL's file
     *  name; required when `weights` is a RangeSource), so a renamed file
     *  never serves stale bytes. */
    cache?: WeightCache;
    cacheId?: string;
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
    onBytes?: (chunkBytes: number) => void;
    /** Chunking overrides — tests force small chunks with short clips. */
    chunking?: Partial<Pick<ChunkOpts, 'maxSeconds' | 'searchSeconds'>>;
    /** Diagnostic hooks + scheduling knobs — absent in production. */
    perf?: TranscriberPerf;
  } = {},
): Promise<Transcriber> {
  const root = defaultRoot();
  const cfg = opts.cfg ?? MOONSHINE_TINY;
  const perf = opts.perf;
  const burstMax = Math.max(1, Math.min(perf?.burst ?? BURST, cfg.maxPositions));
  const ex = gpuExecutor(root, { perf: perf?.gpuPerf });

  const sd = await fromSafetensors(weights, {
    onBytes: opts.onBytes,
    cache: opts.cache,
    cacheId: opts.cacheId,
  });
  if (sd.metadata['model'] && sd.metadata['model'] !== 'moonshine') {
    throw new Error(
      `moonshine weights: file is for model '${sd.metadata['model']}', expected 'moonshine'`,
    );
  }
  // 'f16' is NATIVE half precision — parameters and activations alike.
  const half = opts.weightDtype === 'f16';
  const model = new MoonshineModel(cfg);
  if (half) model.half(root);
  await model.loadStateDict(sd, { root, onProgress: opts.onProgress });

  /** An activation buffer in the model's storage dtype — the KV caches and
   *  the audio slab feed f16 kernels on a halved model. Rope tables and the
   *  id buffer stay f32 in every variant. */
  const actTensor = (data: Float32Array, dims: [number, number]): Value =>
    tensor(root, data, { elems: data.length, dtype: half ? 'f16' : 'f32', dims });

  // Position-constant: decoder tables cover every legal step count.
  const dec = buildRopeTables(cfg.maxPositions, cfg);
  const decCos = tensor(root, dec.cos, [cfg.maxPositions, cfg.headDim]);
  const decSin = tensor(root, dec.sin, [cfg.maxPositions, cfg.headDim]);

  // Preallocated per-layer self-attention caches, written in place row by row
  // (see the header); sized by the config, allocated once, reused by every
  // utterance (and every chunk of a long clip — chunks run sequentially).
  const qw = cfg.heads * cfg.headDim;
  const kvInit = new Float32Array(cfg.maxPositions * qw);
  const selfKV: SelfKV[] = Array.from({ length: cfg.decLayers }, () => ({
    k: actTensor(kvInit, [cfg.maxPositions, qw]),
    v: actTensor(kvInit, [cfg.maxPositions, qw]),
  }));
  // Per-position greedy ids, written on device by each burst step and read
  // back once per burst.
  const idsBuf = tensor(root, new Float32Array(cfg.maxPositions), [cfg.maxPositions, 1]);

  const transcribeUtterance = async (audio: Float32Array): Promise<TranscribeResult> => {
    perf?.onPhase?.('encode');
    const t0 = performance.now();
    const frames = stemFrames(audio.length);
    const x = actTensor(audio, [audio.length, 1]);
    const enc = buildRopeTables(frames.conv3, cfg);
    const encCos = tensor(root, enc.cos, [frames.conv3, cfg.headDim]);
    const encSin = tensor(root, enc.sin, [frames.conv3, cfg.headDim]);

    const encOut = model.encoder.forward(model.stem.forward(x), encCos, encSin);
    const cross = model.decoder.precomputeCrossKV(encOut);
    // One eval; the K/V co-targets pin every buffer the decode loop reads.
    evalValues([encOut, ...cross.flatMap((c) => [c.k, c.v])], ex);
    // Drain the queue so the encoder's GPU tail doesn't bleed into the first
    // burst's readback wait; callers that don't display the encode/decode
    // split omit the flag and keep the overlap.
    if (perf?.syncAfterEncode) await root.device.queue.onSubmittedWorkDone();
    const encodeMs = performance.now() - t0;

    const maxTokens = Math.min(
      cfg.maxPositions,
      Math.ceil((audio.length / SAMPLE_RATE) * TOKENS_PER_SECOND),
    );
    // Hand pinned eval-target K/V pairs (the cross-attention set) back to
    // the pool at the end of the utterance.
    const release = (kvs: readonly { k: Value; v: Value }[]) => {
      for (const { k, v } of kvs) {
        ex.releaseOutput(k.buffer, k.shape);
        k.markReleased();
        ex.releaseOutput(v.buffer, v.shape);
        v.markReleased();
      }
    };
    ex.releaseOutput(encOut.buffer, encOut.shape); // only the cross K/V outlive the encode
    encOut.markReleased();

    const ids: number[] = [cfg.bos];
    perf?.onPhase?.('decode');
    const t1 = performance.now();
    decode: while (ids.length < maxTokens) {
      const base = ids.length - 1; // position of the burst's first fed token
      const burst = Math.min(burstMax, maxTokens - ids.length);
      const tBuild = performance.now();
      // Build the whole burst as ONE DAG: step j's argmax id chains into
      // step j+1's embedding on device, and every id lands in its row of
      // idsBuf. The in-place writes (KV rows, id rows) ride the chain.
      const idRows: Value[] = [];
      let x = model.embed([ids[base]!]); // burst opener: CPU-known id
      for (let j = 0; j < burst; j++) {
        const t = base + j;
        const h = model.decoder.forwardStep(
          x,
          slice(decCos, 0, t, t + 1),
          slice(decSin, 0, t, t + 1),
          cross,
          selfKV,
          t,
        );
        const idVal = model.nextTokenId(h); // [1,1] f32 greedy id
        idRows.push(writeRows(idsBuf, idVal, t));
        if (j + 1 < burst) x = model.embedFrom(idVal);
      }
      const tEval = performance.now();
      evalValues(idRows, ex);
      const tRead = performance.now();
      // One readback per burst: the id rows written so far (4 bytes each).
      const data = await ex.readback(idsBuf.buffer, {
        elems: base + burst,
        dtype: 'f32',
        dims: [base + burst, 1],
      });
      perf?.onBurst?.({
        positions: burst,
        buildMs: tEval - tBuild,
        evalMs: tRead - tEval,
        readbackMs: performance.now() - tRead,
      });
      for (let j = 0; j < burst; j++) {
        const best = data[base + j]!;
        ids.push(best);
        if (best === cfg.eos) break decode;
      }
    }
    release(cross);
    return {
      ids,
      text: decodeTokens(tokenizer, ids),
      timings: { encodeMs, decodeMs: performance.now() - t1, steps: ids.length - 1 },
    };
  };

  const chunkOpts: ChunkOpts = {
    maxSeconds: opts.chunking?.maxSeconds ?? MAX_CHUNK_SECONDS,
    searchSeconds: opts.chunking?.searchSeconds ?? SPLIT_SEARCH_SECONDS,
    sampleRate: SAMPLE_RATE,
  };

  const transcribe = async (audio: Float32Array): Promise<TranscribeResult> => {
    const chunks = splitIntoChunks(audio, chunkOpts);
    if (chunks.length === 1) return transcribeUtterance(audio);
    const results: TranscribeResult[] = [];
    for (const chunk of chunks) results.push(await transcribeUtterance(chunk));
    return {
      ids: results.flatMap((r) => r.ids),
      text: results
        .map((r) => r.text.trim())
        .filter((t) => t.length > 0)
        .join(' '),
      timings: results.reduce(
        (sum, r) => ({
          encodeMs: sum.encodeMs + r.timings.encodeMs,
          decodeMs: sum.decodeMs + r.timings.decodeMs,
          steps: sum.steps + r.timings.steps,
        }),
        { encodeMs: 0, decodeMs: 0, steps: 0 },
      ),
    };
  };

  return { transcribe };
}
