/** Moonshine decoder: pre-norm layers with three sublayers each —
 *  LN → causal MHA self-attn (partial rope) → residual;
 *  LN → cross-attn over the encoder output → residual;
 *  LN → SwiGLU MLP (fc1 [d, 2·ffn] → chunk → silu(gate)·hidden → fc2) →
 *  residual. Final weight-only LN.
 *
 *  Self-attention: fused qkv matmul (loader-fused q|k|v columns), q/k roped
 *  with the decoder tables, attn window (∞, 0). Two drive modes: forward()
 *  runs all t tokens at once (offset 0 — teacher forcing, parity tests);
 *  forwardStep() feeds ONE token against the per-layer SelfKV cache with
 *  qPosOffset = t, so per-step cost is independent of the sequence length.
 *  Rope tables carry headDim^(−1/4) on q and k each, so no score scale
 *  appears here.
 *
 *  Cross-attention: no rope, no positions. The full 1/√headDim score scale
 *  is folded into the q weights at load. K/V come from the encoder output
 *  through the fused [d, 2·qw] kv projection — computed ONCE per utterance
 *  via precomputeCrossKV and evaluated as co-targets with the encoder eval
 *  (only eval targets survive the eval boundary), then reused by every
 *  decode step.
 *
 *  SwiGLU chunk order matches HF fc1(x).chunk(2): hidden = first ffn
 *  columns, gate = second — out = silu(gate) · hidden. */

import { chunk, nn, rope, slice, swigluChunk, writeRows, type Value } from '@tie/core';
import type { MoonshineConfig } from './config.ts';

/** Per-layer cross-attention K/V, precomputed once per utterance. */
export interface CrossKV {
  k: Value;
  v: Value;
}

/** Per-layer causal self-attention cache: caller-owned PREALLOCATED
 *  [maxPositions, qw] buffers (materialized Values). forwardStep writes the
 *  new position's roped k / raw v IN PLACE via writeRows — the existing rows
 *  are never copied, so per-step cost is O(1) in the sequence length — and
 *  attention reads a [t+1, qw] view of the same buffer. Nothing is returned
 *  or released per step; the buffers persist across steps and utterances
 *  (rows are overwritten from position 0 each utterance). Causality makes
 *  cached rows exact: position j's k/v never change once computed. */
export interface SelfKV {
  k: Value;
  v: Value;
}

class DecoderSelfAttn extends nn.Module<[Value, Value, Value, Value?], Value> {
  readonly qkv: nn.Linear;
  readonly mha: nn.MultiHeadAttention;
  readonly out: nn.Linear;
  constructor(private readonly cfg: MoonshineConfig) {
    super();
    const qw = cfg.heads * cfg.headDim;
    this.qkv = new nn.Linear(cfg.dModel, 3 * qw, { bias: false });
    this.mha = new nn.MultiHeadAttention({
      qHeads: cfg.heads,
      kvHeads: cfg.heads,
      headDim: cfg.headDim,
      windowLeft: Infinity,
      windowRight: 0, // causal
    });
    this.out = new nn.Linear(qw, cfg.dModel, { bias: false });
  }
  /** `residual` folds the sublayer's residual add into the out-projection's
   *  matmul epilogue — same operation order as a separate add. */
  forward(x: Value, cos: Value, sin: Value, residual?: Value): Value {
    const { heads, headDim } = this.cfg;
    const qw = heads * headDim;
    const qkv = this.qkv.forward(x); // [t, 3·qw], columns q|k|v
    const q = rope(qkv, cos, sin, { headDim, srcStart: 0, width: qw });
    const k = rope(qkv, cos, sin, { headDim, srcStart: qw, width: qw });
    const v = slice(qkv, 1, 2 * qw, 3 * qw);
    return this.out.forward(this.mha.forward(q, k, v), { addend: residual });
  }
  /** One new token at position t: its roped k / raw v are written in place
   *  into row t of the preallocated cache and the single query attends over
   *  the [t+1, qw] view with qPosOffset = t — the offset rides a uniform, so
   *  no pipeline recompiles as it changes every step. */
  forwardStep(
    x1: Value,
    cosRow: Value,
    sinRow: Value,
    cache: SelfKV,
    t: number,
    residual?: Value,
  ): Value {
    const { heads, headDim } = this.cfg;
    const qw = heads * headDim;
    const qkv = this.qkv.forward(x1); // [1, 3·qw]
    const q = rope(qkv, cosRow, sinRow, { headDim, srcStart: 0, width: qw });
    const kNew = rope(qkv, cosRow, sinRow, { headDim, srcStart: qw, width: qw });
    const vNew = slice(qkv, 1, 2 * qw, 3 * qw);
    const k = writeRows(cache.k, kNew, t); // [t+1, qw] view of the cache buffer
    const v = writeRows(cache.v, vNew, t);
    const ctx = this.mha.forward(q, k, v, { qPosOffset: t });
    return this.out.forward(ctx, { addend: residual });
  }
}

class DecoderCrossAttn extends nn.Module<[Value, CrossKV, Value?], Value> {
  readonly q: nn.Linear;
  readonly kv: nn.Linear;
  readonly mha: nn.MultiHeadAttention;
  readonly out: nn.Linear;
  constructor(cfg: MoonshineConfig) {
    super();
    const qw = cfg.heads * cfg.headDim;
    this.q = new nn.Linear(cfg.dModel, qw, { bias: false });
    this.kv = new nn.Linear(cfg.dModel, 2 * qw, { bias: false });
    this.mha = new nn.MultiHeadAttention({
      qHeads: cfg.heads,
      kvHeads: cfg.heads,
      headDim: cfg.headDim,
      windowLeft: Infinity,
      windowRight: Infinity,
    });
    this.out = new nn.Linear(qw, cfg.dModel, { bias: false });
  }
  /** Encoder output [kvLen, d] → this layer's k/v [kvLen, qw] each. */
  precompute(encOut: Value): CrossKV {
    const fused = this.kv.forward(encOut); // [kvLen, 2·qw], columns k|v
    const [k, v] = chunk(fused, 2, 1);
    return { k: k!, v: v! };
  }
  forward(x: Value, cross: CrossKV, residual?: Value): Value {
    return this.out.forward(this.mha.forward(this.q.forward(x), cross.k, cross.v), {
      addend: residual,
    });
  }
}

/** fc1 [d, 2·ffn] (+bias) → fused SwiGLU chunk (silu(gate)·hidden, HF
 *  chunk order) → fc2 (+bias, residual in the epilogue). */
class DecoderMlp extends nn.Module {
  readonly fc1: nn.Linear;
  readonly fc2: nn.Linear;
  constructor(ffn: number, dModel: number) {
    super();
    this.fc1 = new nn.Linear(dModel, 2 * ffn);
    this.fc2 = new nn.Linear(ffn, dModel);
  }
  forward(x: Value, residual?: Value): Value {
    return this.fc2.forward(swigluChunk(this.fc1.forward(x)), { addend: residual });
  }
}

export class DecoderLayer extends nn.Module<[Value, Value, Value, CrossKV], Value> {
  readonly norm1: nn.LayerNorm;
  readonly selfAttn: DecoderSelfAttn;
  readonly norm2: nn.LayerNorm;
  readonly crossAttn: DecoderCrossAttn;
  readonly norm3: nn.LayerNorm;
  readonly mlp: DecoderMlp;
  constructor(cfg: MoonshineConfig) {
    super();
    this.norm1 = new nn.LayerNorm(cfg.dModel);
    this.selfAttn = new DecoderSelfAttn(cfg);
    this.norm2 = new nn.LayerNorm(cfg.dModel);
    this.crossAttn = new DecoderCrossAttn(cfg);
    this.norm3 = new nn.LayerNorm(cfg.dModel);
    this.mlp = new DecoderMlp(cfg.ffn, cfg.dModel);
  }
  forward(x: Value, cos: Value, sin: Value, cross: CrossKV): Value {
    const h1 = this.selfAttn.forward(this.norm1.forward(x), cos, sin, x);
    const h2 = this.crossAttn.forward(this.norm2.forward(h1), cross, h1);
    return this.mlp.forward(this.norm3.forward(h2), h2);
  }
  /** Single-token variant of forward: self-attention goes through the
   *  preallocated cache; cross-attention and the MLP are per-row, so the
   *  [1, d] input flows through the same paths as the batch forward. */
  forwardStep(
    x1: Value,
    cosRow: Value,
    sinRow: Value,
    cross: CrossKV,
    cache: SelfKV,
    t: number,
  ): Value {
    const h1 = this.selfAttn.forwardStep(this.norm1.forward(x1), cosRow, sinRow, cache, t, x1);
    const h2 = this.crossAttn.forward(this.norm2.forward(h1), cross, h1);
    return this.mlp.forward(this.norm3.forward(h2), h2);
  }
}

export class MoonshineDecoder extends nn.Module<[Value, Value, Value, readonly CrossKV[]], Value> {
  readonly layers: nn.ModuleList<DecoderLayer>;
  readonly norm: nn.LayerNorm;
  constructor(cfg: MoonshineConfig) {
    super();
    this.layers = new nn.ModuleList(
      Array.from({ length: cfg.decLayers }, () => new DecoderLayer(cfg)),
    );
    this.norm = new nn.LayerNorm(cfg.dModel);
  }
  /** Every layer's cross K/V from the encoder output — evaluate the returned
   *  Values as co-targets of the encoder eval so their buffers survive it. */
  precomputeCrossKV(encOut: Value): CrossKV[] {
    return this.layers.items.map((layer) => layer.crossAttn.precompute(encOut));
  }
  /** x [t, d] embedded tokens; cos/sin [t, headDim] decoder rope tables;
   *  cross = precomputeCrossKV output, one entry per layer. */
  forward(x: Value, cos: Value, sin: Value, cross: readonly CrossKV[]): Value {
    if (cross.length !== this.layers.items.length) {
      throw new Error(
        `MoonshineDecoder: ${cross.length} cross K/V entries for ${this.layers.items.length} layers`,
      );
    }
    let h = x;
    this.layers.items.forEach((layer, i) => {
      h = layer.forward(h, cos, sin, cross[i]!);
    });
    return this.norm.forward(h);
  }
  /** Incremental decode step at position t: one embedded token [1, d] + its
   *  rope table row, against per-layer PREALLOCATED caches (written in place —
   *  nothing is returned per step and nothing needs releasing; the writeRows
   *  nodes ride the returned value's dependency chain). */
  forwardStep(
    x1: Value,
    cosRow: Value,
    sinRow: Value,
    cross: readonly CrossKV[],
    caches: readonly SelfKV[],
    t: number,
  ): Value {
    const n = this.layers.items.length;
    if (cross.length !== n || caches.length !== n) {
      throw new Error(
        `MoonshineDecoder.forwardStep: got ${cross.length} cross / ${caches.length} cache entries for ${n} layers`,
      );
    }
    let h = x1;
    this.layers.items.forEach((layer, i) => {
      h = layer.forwardStep(h, cosRow, sinRow, cross[i]!, caches[i]!, t);
    });
    return this.norm.forward(h);
  }
}
