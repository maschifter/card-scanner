/** Moonshine rope table builder. Model math, not core: core owns only the
 *  `rope` op/kernel that consumes [T, headDim] pair-duplicated tables.
 *
 *  Convention: HF Moonshine inherits GLM's apply_rotary_pos_emb — GPT-J
 *  INTERLEAVED pairs (x[0::2], x[1::2]) with cos/sin repeat_interleave(2),
 *  which is exactly the engine kernel's (2p, 2p+1) pair-duplicated form. No
 *  permutation of any kind is needed on the projections — the gpu equivalence
 *  test (test/gpu/moonshineRope.test.ts) guards this assumption.
 *
 *  Partial rotary: only dims 0..rotaryDim−1 rotate; dims rotaryDim..headDim−1
 *  get (cos=1, sin=0) — the kernel's rotation degenerates to an exact identity
 *  there, zero kernel changes. The boundary is pair-aligned (rotaryDim even).
 *
 *  Scale fold: every entry (identity region included) is multiplied by
 *  s = headDim^(−1/4), so q and k each pick up s across the full head vector
 *  and scores carry s² = 1/√headDim — HF's full-head-dim scaling, split-sqrt
 *  style (same trick as privacy-filter's QK_SCALE). Cross-attention has no
 *  rope; its 1/√headDim is folded into crossAttn.q at load instead.
 *
 *  Lifecycle (caller-supplied idiom): plain Float32Arrays. The transcriber
 *  uploads them via tensor() — encoder tables sized to the utterance's frame
 *  count; decoder tables built once at maxPositions and sliced to the
 *  live step count. Row t depends only on t, so slicing == rebuilding. */

import type { MoonshineConfig } from './config.ts';

export interface MoonshineRopeTables {
  /** [positions × headDim] pair-duplicated cos, ×headDim^(−1/4). */
  cos: Float32Array;
  /** [positions × headDim] pair-duplicated sin, ×headDim^(−1/4). */
  sin: Float32Array;
}

/** The per-tensor score scale folded into the tables (q and k each). */
export function ropeQkScale(headDim: number): number {
  return headDim ** -0.25;
}

export function buildRopeTables(positions: number, cfg: MoonshineConfig): MoonshineRopeTables {
  const hd = cfg.headDim;
  const half = cfg.rotaryDim / 2;
  const s = ropeQkScale(hd);
  const cos = new Float32Array(positions * hd);
  const sin = new Float32Array(positions * hd);
  for (let t = 0; t < positions; t++) {
    const base = t * hd;
    for (let p = 0; p < half; p++) {
      // inv_freq_p = theta^(−2p/rotaryDim), HF's arange(0, dim, 2)/dim exponent.
      const angle = t * cfg.ropeTheta ** (-(2 * p) / cfg.rotaryDim);
      const c = Math.cos(angle) * s;
      const sn = Math.sin(angle) * s;
      cos[base + 2 * p] = c;
      cos[base + 2 * p + 1] = c;
      sin[base + 2 * p] = sn;
      sin[base + 2 * p + 1] = sn;
    }
    for (let c = cfg.rotaryDim; c < hd; c++) {
      cos[base + c] = s; // identity pass-through, scale still applied
      sin[base + c] = 0;
    }
  }
  return { cos, sin };
}
