/** Decode-only detokenizer for Moonshine's Llama-style BPE vocabulary. STT
 *  never encodes text — the decoder starts from BOS and emits ids, so id →
 *  string is the whole job: special ids skipped, `▁` → space, byte-fallback
 *  tokens (`<0xNN>`) accumulated per run and decoded as UTF-8 (multibyte
 *  characters span several byte tokens), one leading space stripped (the
 *  sentencepiece prefix on the first word). Asset produced by
 *  tools/export_moonshine_tokenizer.py. */

export interface MoonshineTokenizer {
  version: number;
  bosId: number;
  eosId: number;
  specialIds: number[];
  /** id → token string, Llama BPE surface forms. */
  vocab: string[];
}

const BYTE_TOKEN = /^<0x([0-9A-Fa-f]{2})>$/;

export function decodeTokens(tok: MoonshineTokenizer, ids: readonly number[]): string {
  const specials = new Set(tok.specialIds);
  const utf8 = new TextDecoder('utf-8');
  let out = '';
  let bytes: number[] = [];
  const flushBytes = () => {
    if (bytes.length === 0) return;
    out += utf8.decode(Uint8Array.from(bytes));
    bytes = [];
  };
  for (const id of ids) {
    if (specials.has(id)) continue;
    const token = tok.vocab[id];
    if (token === undefined) throw new Error(`decodeTokens: id ${id} outside vocab`);
    const byte = BYTE_TOKEN.exec(token);
    if (byte) {
      bytes.push(parseInt(byte[1]!, 16));
      continue;
    }
    flushBytes();
    out += token.replaceAll('▁', ' ');
  }
  flushBytes();
  return out.startsWith(' ') ? out.slice(1) : out;
}
