/** Maps the HF Moonshine checkpoint onto MoonshineModel's parameter tree, all
 *  as lazy derived tensors (nothing is fetched here — transforms run per
 *  tensor during the load):
 *  - self-attn q|k|v → one torch-layout [3·qw, d] qkv weight (row-stacked;
 *    one matmul on the hot path). NO rotary permutation: HF Moonshine's rope
 *    convention is already the engine's interleaved-pair form (see rope.ts);
 *  - cross-attn q × headDim^(−1/2) (no rope on the cross path, so the full
 *    score scale folds into q); k|v row-stacked [2·qw, d] for the
 *    once-per-utterance encoder-side K/V precompute;
 *  - everything else renames (norms, biases, convs, embedding).
 *  Every weight stays in torch layout — Linear.transformStateDict transposes
 *  and Conv1d.transformStateDict goes tap-major afterwards. Derived
 *  byteLengths carry the source tensors' file bytes so load progress still
 *  sums to the checkpoint size. */

import { derivedTensor, type LazyStateDict, type LazyTensor } from '@tie/core';
import type { MoonshineConfig } from './config.ts';

/** Dotted-path join matching namedParameters()'s convention: empty prefix
 *  (the module loaded as root) yields the bare key. */
export const qualify = (prefix: string, name: string): string =>
  prefix ? `${prefix}.${name}` : name;

export function take(sd: LazyStateDict, name: string): LazyTensor {
  const t = sd.tensors.get(name);
  if (!t) throw new Error(`moonshine state dict: missing tensor '${name}'`);
  sd.tensors.delete(name);
  return t;
}

export function move(sd: LazyStateDict, from: string, to: string): void {
  sd.tensors.set(to, take(sd, from));
}

/** Row-stack torch-layout [rows_i, cols] parts into one [Σrows_i, cols]
 *  derived tensor (a plain contiguous concat), each part optionally scaled.
 *  Part shapes are checked eagerly — header info, no fetch. */
export function stackRows(
  parts: readonly { t: LazyTensor; scale?: number }[],
  cols: number,
): LazyTensor {
  let rows = 0;
  for (const { t } of parts) {
    if (t.shape.length !== 2 || t.shape[1] !== cols) {
      throw new Error(`moonshine state dict: stackRows part shape [${t.shape}] != [_, ${cols}]`);
    }
    rows += t.shape[0]!;
  }
  return derivedTensor(
    [rows, cols],
    async () => {
      const out = new Float32Array(rows * cols);
      let base = 0;
      for (const { t, scale } of parts) {
        const data = await t.f32();
        if (scale === undefined) out.set(data, base);
        else for (let i = 0; i < data.length; i++) out[base + i] = data[i]! * scale;
        base += data.length;
      }
      return out;
    },
    parts.reduce((sum, p) => sum + p.t.byteLength, 0),
  );
}

/** Stacks q|k|v projections into one [3·qw, cols] qkv weight; the q rows
 *  are scaled by qScale when given. */
export function fuseQkv(
  sd: LazyStateDict,
  hfPrefix: string,
  ours: string,
  cols: number,
  qScale?: number,
): void {
  sd.tensors.set(
    ours,
    stackRows(
      ['q', 'k', 'v'].map((p) => ({
        t: take(sd, `${hfPrefix}.${p}_proj.weight`),
        scale: p === 'q' ? qScale : undefined,
      })),
      cols,
    ),
  );
}

/** Drops the tied LM head (present only in raw HF checkpoints) and renames
 *  the token embedding — the embedding weight serves both roles. */
export function moveTiedEmbedding(sd: LazyStateDict, prefix: string): void {
  sd.tensors.delete(qualify(prefix, 'proj_out.weight'));
  move(
    sd,
    qualify(prefix, 'model.decoder.embed_tokens.weight'),
    qualify(prefix, 'embedding.weight'),
  );
}

/** Maps the decoder layers — shared by both moonshine variants, which use
 *  the same MoonshineDecoder class. Self-attn q|k|v fuse unscaled (the rope
 *  tables carry the scale). Cross-attn has no rope, so q takes the full
 *  1/√headDim score scale; its k|v fuse into one [2·qw, hidden] weight. */
export function transformDecoder(
  sd: LazyStateDict,
  prefix: string,
  dec: { layers: number; hidden: number; headDim: number },
): void {
  const q = (name: string) => qualify(prefix, name);
  const crossQScale = 1 / Math.sqrt(dec.headDim);
  for (let i = 0; i < dec.layers; i++) {
    const hf = q(`model.decoder.layers.${i}`);
    const en = q(`decoder.layers.${i}`);
    move(sd, `${hf}.input_layernorm.weight`, `${en}.norm1.weight`);
    fuseQkv(sd, `${hf}.self_attn`, `${en}.selfAttn.qkv.weight`, dec.hidden);
    move(sd, `${hf}.self_attn.o_proj.weight`, `${en}.selfAttn.out.weight`);
    move(sd, `${hf}.post_attention_layernorm.weight`, `${en}.norm2.weight`);
    sd.tensors.set(
      `${en}.crossAttn.q.weight`,
      stackRows(
        [{ t: take(sd, `${hf}.encoder_attn.q_proj.weight`), scale: crossQScale }],
        dec.hidden,
      ),
    );
    sd.tensors.set(
      `${en}.crossAttn.kv.weight`,
      stackRows(
        ['k', 'v'].map((p) => ({ t: take(sd, `${hf}.encoder_attn.${p}_proj.weight`) })),
        dec.hidden,
      ),
    );
    move(sd, `${hf}.encoder_attn.o_proj.weight`, `${en}.crossAttn.out.weight`);
    move(sd, `${hf}.final_layernorm.weight`, `${en}.norm3.weight`);
    // fc1 is one fused [2·ffn, d] projection; the swigluChunk kernel
    // splits it (hidden = first half, gate = second half).
    move(sd, `${hf}.mlp.fc1.weight`, `${en}.mlp.fc1.weight`);
    move(sd, `${hf}.mlp.fc1.bias`, `${en}.mlp.fc1.bias`);
    move(sd, `${hf}.mlp.fc2.weight`, `${en}.mlp.fc2.weight`);
    move(sd, `${hf}.mlp.fc2.bias`, `${en}.mlp.fc2.bias`);
  }
  move(sd, q('model.decoder.norm.weight'), q('decoder.norm.weight'));
}

export function transformMoonshineStateDict(
  sd: LazyStateDict,
  prefix: string,
  cfg: MoonshineConfig,
): void {
  const q = (name: string) => qualify(prefix, name);
  const d = cfg.dModel;

  moveTiedEmbedding(sd, prefix);

  move(sd, q('model.encoder.conv1.weight'), q('stem.conv1.weight'));
  move(sd, q('model.encoder.groupnorm.weight'), q('stem.groupnorm.weight'));
  move(sd, q('model.encoder.groupnorm.bias'), q('stem.groupnorm.bias'));
  move(sd, q('model.encoder.conv2.weight'), q('stem.conv2.weight'));
  move(sd, q('model.encoder.conv2.bias'), q('stem.conv2.bias'));
  move(sd, q('model.encoder.conv3.weight'), q('stem.conv3.weight'));
  move(sd, q('model.encoder.conv3.bias'), q('stem.conv3.bias'));

  for (let i = 0; i < cfg.encLayers; i++) {
    const hf = q(`model.encoder.layers.${i}`);
    const en = q(`encoder.layers.${i}`);
    move(sd, `${hf}.input_layernorm.weight`, `${en}.norm1.weight`);
    fuseQkv(sd, `${hf}.self_attn`, `${en}.attn.qkv.weight`, d);
    move(sd, `${hf}.self_attn.o_proj.weight`, `${en}.attn.out.weight`);
    move(sd, `${hf}.post_attention_layernorm.weight`, `${en}.norm2.weight`);
    move(sd, `${hf}.mlp.fc1.weight`, `${en}.mlp.fc1.weight`);
    move(sd, `${hf}.mlp.fc1.bias`, `${en}.mlp.fc1.bias`);
    move(sd, `${hf}.mlp.fc2.weight`, `${en}.mlp.fc2.weight`);
    move(sd, `${hf}.mlp.fc2.bias`, `${en}.mlp.fc2.bias`);
  }
  move(sd, q('model.encoder.layer_norm.weight'), q('encoder.norm.weight'));

  transformDecoder(sd, prefix, { layers: cfg.decLayers, hidden: d, headDim: cfg.headDim });
}
