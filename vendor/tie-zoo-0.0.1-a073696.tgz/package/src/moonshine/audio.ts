/** Browser-only audio ingress: encoded clips and raw mic PCM → 16 kHz mono
 *  Float32Array, the transcriber's input format. decodeAudioData resamples
 *  to the owning context's rate by spec, so decoding inside a 16 kHz
 *  OfflineAudioContext performs the resample; multi-channel clips are
 *  downmixed by a second 1-channel render pass (standard speaker mixdown —
 *  stereo → 0.5·(L+R)). Mic capture should record raw PCM and use
 *  resampleToMono16k instead of round-tripping through a lossy encoder —
 *  decodeAudioData on MediaRecorder blobs is unreliable on mobile browsers.
 *  Exported only via the `@tie/zoo/moonshine/audio` subpath so node code
 *  never imports it. */

export const TARGET_SAMPLE_RATE = 16_000;

/** Any clip the browser can decode (wav, mp3, ogg, …) → 16 kHz mono PCM. */
export async function decodeToMono16k(data: ArrayBuffer): Promise<Float32Array> {
  // The probe context exists only to host decodeAudioData at the target rate;
  // its 1-frame render buffer is never used.
  const probe = new OfflineAudioContext(1, 1, TARGET_SAMPLE_RATE);
  const decoded = await probe.decodeAudioData(data);
  if (decoded.numberOfChannels === 1) return decoded.getChannelData(0);
  const mix = new OfflineAudioContext(1, decoded.length, TARGET_SAMPLE_RATE);
  const src = mix.createBufferSource();
  src.buffer = decoded;
  src.connect(mix.destination);
  src.start();
  return (await mix.startRendering()).getChannelData(0);
}

/** Raw mono PCM at `sourceRate` → 16 kHz, via an OfflineAudioContext render
 *  (the browser's own resampler — same one decodeToMono16k relies on).
 *  Returns the input untouched when it is already at the target rate. */
export async function resampleToMono16k(
  samples: Float32Array,
  sourceRate: number,
): Promise<Float32Array> {
  if (sourceRate === TARGET_SAMPLE_RATE) return samples;
  const frames = Math.ceil((samples.length * TARGET_SAMPLE_RATE) / sourceRate);
  const off = new OfflineAudioContext(1, frames, TARGET_SAMPLE_RATE);
  const buf = off.createBuffer(1, samples.length, sourceRate);
  // copyToChannel's lib type wants a non-shared backing buffer; capture PCM
  // always is one.
  buf.copyToChannel(samples as Float32Array<ArrayBuffer>, 0);
  const src = off.createBufferSource();
  src.buffer = buf;
  src.connect(off.destination);
  src.start();
  return (await off.startRendering()).getChannelData(0);
}
