/** MoonshineModel: full module tree (stem + encoder + decoder + embedding),
 *  T-independent — no sequence length in any constructor; rope tables, ones
 *  columns and cross K/V enter through the sub-modules' forward arguments.
 *  transformStateDict maps the HF checkpoint onto the parameter tree (see
 *  stateDictHooks.ts), so one loadStateDict binds the whole checkpoint.
 *
 *  The nn.Embedding weight [V, d] is one GPU tensor with two roles: token
 *  lookup (its forward — ids are CPU-known each step) and the tied LM head
 *  (matmul against the raw [V, d] orientation, so no transposed copy exists
 *  and tying is exact by construction). */

import {
  argmaxDot,
  gatherRowsFrom,
  matmul,
  nn,
  slice,
  transpose,
  type LazyStateDict,
  type Value,
} from '@tie/core';
import type { MoonshineConfig } from './config.ts';
import { ConvStem } from './convStem.ts';
import { MoonshineEncoder } from './encoder.ts';
import { MoonshineDecoder } from './decoder.ts';
import { transformMoonshineStateDict } from './stateDictHooks.ts';

export class MoonshineModel extends nn.Module {
  readonly embedding: nn.Embedding;
  readonly stem: ConvStem;
  readonly encoder: MoonshineEncoder;
  readonly decoder: MoonshineDecoder;
  /** Half precision is `model.half()` — every parameter and every activation
   *  at once (see nn.Module.half). There is no per-tensor weight dtype. */
  constructor(readonly cfg: MoonshineConfig) {
    super();
    this.embedding = new nn.Embedding(cfg.vocab, cfg.dModel);
    this.stem = new ConvStem(cfg);
    this.encoder = new MoonshineEncoder(cfg);
    this.decoder = new MoonshineDecoder(cfg);
  }

  override transformStateDict(sd: LazyStateDict, prefix: string): void {
    transformMoonshineStateDict(sd, prefix, this.cfg);
  }

  /** Token ids → embedded rows [ids.length, d]. */
  embed(ids: readonly number[]): Value {
    return this.embedding.forward(ids);
  }

  /** GPU-resident token id(s) (f32, e.g. a nextTokenId result) → embedded
   *  rows [n, d] — the decode chain feeds itself without a CPU readback. */
  embedFrom(ids: Value): Value {
    return gatherRowsFrom(this.embedding.weight.value, ids);
  }

  /** Decoder output [t, d] → next-token logits [V, 1] for the LAST row only —
   *  never a [t, V] logits matrix. Teacher-forced parity paths use this; the
   *  incremental decode loop uses nextTokenId instead (the logits never
   *  materialize there). f32 embedding only: matmul cannot take the packed
   *  table as its LEFT operand — packed models decode via nextTokenId. */
  logitsLast(h: Value): Value {
    const w = this.embedding.weight.value;
    if (w.shape.dtype !== h.shape.dtype) {
      throw new Error(
        `MoonshineModel.logitsLast: embedding is ${w.shape.dtype} but h is ${h.shape.dtype}`,
      );
    }
    const t = h.shape.dims![0]!;
    return matmul(w, transpose(slice(h, 0, t - 1, t)));
  }

  /** Incremental-decode step output [1, d] → greedy token id as a [1,1] f32
   *  (fused gemv + argmax over the tied embedding — one dispatch, 4-byte
   *  readback, lowest index on ties like the CPU loop it replaces). */
  nextTokenId(h1: Value): Value {
    return argmaxDot(this.embedding.weight.value, h1);
  }

  /** The model is driven through stem/encoder/decoder + the helpers above —
   *  there is no single x → y pass. */
  forward(): Value {
    throw new Error('MoonshineModel: use stem/encoder/decoder forwards, embed() and logitsLast()');
  }
}
