/** Sentence embedder. Loads weights once into a MinilmModel, then per embed
 *  runs tokenize → forward → mean pool → L2 normalize. Runs on the initTie()
 *  default device.
 *
 *  Single-sentence embeds ride a captured replay path (createReplayCache):
 *  the forward for each padded length bucket is recorded once, and each call
 *  only rewrites four small input buffers and re-submits the recording — one
 *  submit whose command buffer also carries the result copy. Batches keep
 *  the packed-rows eager path.
 *
 *  Pooling: mean over tokens as a [1, T] × [T, hidden] matmul against a row
 *  of 1/L over the sentence's real tokens (pad rows weighted 0). L2
 *  normalization runs on the CPU on the 384 read-back floats — exact, no
 *  extra dispatch. */

import {
  createReplayCache,
  defaultRoot,
  fromSafetensors,
  inGpuErrorScopes,
  matmul,
  toArray,
  tensor,
  type Value,
  type WeightCache,
} from '@tie/core';
import { EMBEDDING_DIM, MINILM_L6 } from './config.ts';
import { MinilmModel } from './model.ts';
import {
  createMinilmTokenizer,
  type MinilmTokenizer,
  type MinilmTokenizerAsset,
} from './tokenizer.ts';

export interface MinilmEmbedder {
  tokenizer: MinilmTokenizer;
  /** text → unit-length sentence embedding [EMBEDDING_DIM]. */
  embed(text: string): Promise<Float32Array>;
  /** Pre-tokenized ids (with specials) → unit-length embedding. */
  embedTokens(tokenIds: readonly number[]): Promise<Float32Array>;
  /** Many texts in one GPU pass (packed rows + segmented attention) — the
   *  fixed per-kernel cost is paid once for the whole batch, so throughput
   *  scales far better than calling embed() in a loop. */
  embedBatch(texts: readonly string[]): Promise<Float32Array[]>;
  /** Pre-tokenized batch (each with specials) → unit-length embeddings. */
  embedTokensBatch(tokenIdsList: readonly (readonly number[])[]): Promise<Float32Array[]>;
}

/** Dot product of two unit-length embeddings = their cosine similarity. */
export function similarity(a: Float32Array, b: Float32Array): number {
  let dot = 0;
  for (let i = 0; i < a.length; i++) dot += a[i]! * b[i]!;
  return dot;
}

/** Padded lengths with a captured replay each; sentences longer than the
 *  largest bucket fall back to the eager path. */
export const MINILM_BUCKETS: readonly number[] = [16, 32, 64, 128, 256];

/** Smallest bucket that fits `len` tokens, or undefined past the largest. */
export function pickBucket(len: number, buckets: readonly number[] = MINILM_BUCKETS) {
  for (const b of buckets) if (len <= b) return b;
  return undefined;
}

/** The four replay input planes for bucket length T (see fillBucketInputs). */
const bucketShapes = (T: number) =>
  ({
    ids: [T, 1],
    positions: [T, 1],
    segments: [T, 2],
    selector: [1, T],
  }) as const;

/** The four replay inputs for `ids` padded to bucket length T. Pad tokens sit
 *  in their own attention segment ([L, T)) with positions restarting at 0, so
 *  they never mix with the sentence; the pooling selector weighs them 0. */
export function fillBucketInputs(
  T: number,
  ids: readonly number[],
  out: {
    ids: Float32Array;
    positions: Float32Array;
    segments: Float32Array;
    selector: Float32Array;
  },
): void {
  const L = ids.length;
  if (L < 1 || L > T) throw new Error(`fillBucketInputs: ${L} tokens do not fit bucket ${T}`);
  for (let i = 0; i < T; i++) {
    out.ids[i] = i < L ? ids[i]! : 0;
    out.positions[i] = i < L ? i : i - L;
    out.segments[2 * i] = i < L ? 0 : L;
    out.segments[2 * i + 1] = i < L ? L : T;
    out.selector[i] = i < L ? 1 / L : 0;
  }
}

/** Model-level embed core: bucketed replay for single sentences, packed rows
 *  for batches. Exported separately from the weight/tokenizer loading so GPU
 *  tests can drive it with random weights. */
export function createMinilmEmbedCore(model: MinilmModel) {
  // The pooling selector is multiplied against the model's hidden states, so
  // it follows the model's dtype; ids/positions/segments are index planes and
  // stay f32 in every variant.
  const actDtype = model.embeddings.norm.weight.shape.dtype === 'f16' ? 'f16' : 'f32';
  const pooler = (data: Float32Array, dims: [number, number]): Value =>
    tensor(data, { elems: data.length, dtype: actDtype, dims });
  // The replay mechanics live in core; this config is the minilm-specific
  // part: the input planes, their padding, and the pooled-forward DAG.
  const replays = createReplayCache({
    buckets: MINILM_BUCKETS,
    inputs: bucketShapes,
    planeDtype: { selector: actDtype },
    // Capture on a valid full-length dummy (all-[PAD] single segment) so the
    // recording run computes finite values.
    captureFill: (T, scratch) => fillBucketInputs(T, new Array<number>(T).fill(0), scratch),
    build: (T, inp) =>
      matmul(
        inp.selector,
        model.forward(inp.ids, { positions: inp.positions, segments: inp.segments, maxSegment: T }),
      ),
  });

  /** Eager fallback (sentences past the largest bucket). */
  const embedPooledEager = (tokenIds: readonly number[]): Promise<Float32Array> => {
    const t = tokenIds.length;
    const s = pooler(new Float32Array(t).fill(1 / t), [1, t]);
    return toArray(matmul(s, model.forward(tokenIds)));
  };

  const embedPooled = (tokenIds: readonly number[]): Promise<Float32Array> => {
    const T = replays.pick(tokenIds.length);
    return T === undefined
      ? embedPooledEager(tokenIds)
      : replays.run(T, (_, scratch) => fillBucketInputs(T, tokenIds, scratch));
  };

  /** One forward for the whole batch: sentences packed row-wise with
   *  segmented attention, then all means at once as one [B, ΣT] × [ΣT, H]
   *  matmul — row b of the selector holds 1/T_b over its sentence's rows. */
  const embedPooledBatch = async (
    tokenIdsList: readonly (readonly number[])[],
  ): Promise<Float32Array> => {
    const lengths = tokenIdsList.map((ids) => ids.length);
    const packed = tokenIdsList.flat() as number[];
    const total = packed.length;
    const selector = new Float32Array(tokenIdsList.length * total);
    let start = 0;
    lengths.forEach((len, b) => {
      for (let i = 0; i < len; i++) selector[b * total + start + i] = 1 / len;
      start += len;
    });
    const hidden = model.forward(packed, lengths);
    const s = pooler(selector, [tokenIdsList.length, total]);
    return toArray(matmul(s, hidden));
  };

  /** Build and validate every bucket up front (one capture + replay each) —
   *  called from load-time warm-up so runtime replays never hit a first-use
   *  compile or an unscoped capture. */
  const warmBuckets = async (probeIds: readonly number[]): Promise<void> => {
    for (const T of MINILM_BUCKETS) {
      await replays.run(T, (_, scratch) => fillBucketInputs(T, probeIds, scratch));
    }
  };

  return { embedPooled, embedPooledBatch, warmBuckets };
}

const normalize = (v: Float32Array): Float32Array => {
  let sumSq = 0;
  for (const x of v) sumSq += x * x;
  const inv = 1 / Math.sqrt(sumSq);
  for (let i = 0; i < v.length; i++) v[i]! *= inv;
  return v;
};

export async function createMinilmEmbedder(
  weightsUrl: string,
  tokenizerAsset: MinilmTokenizerAsset,
  opts: {
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
    onBytes?: (chunkBytes: number) => void;
    cache?: WeightCache;
    /** 'f16' runs the whole model in native half precision — weights AND
     *  activations, half the memory traffic. Needs a device with shader-f16;
     *  half() throws without it. Default 'f32'. */
    weights?: 'f32' | 'f16';
  } = {},
): Promise<MinilmEmbedder> {
  const device = defaultRoot().device;

  // Version-prefixed cache id: the filename alone ('model.safetensors') is
  // the only invalidation handle, so a re-hosted file under the same name
  // would otherwise serve stale cached bytes forever. Bump the prefix if the
  // hosted weights ever change.
  const sd = await fromSafetensors(weightsUrl, {
    onBytes: opts.onBytes,
    cache: opts.cache,
    cacheId: `minilm-v1/${weightsUrl.split('/').pop()!}`,
  });

  const model = new MinilmModel(MINILM_L6);
  if (opts.weights === 'f16') model.half();
  await model.loadStateDict(sd, { onProgress: opts.onProgress });
  const tokenizer = createMinilmTokenizer(tokenizerAsset);
  const core = createMinilmEmbedCore(model);

  const embedTokens = async (tokenIds: readonly number[]): Promise<Float32Array> =>
    normalize(await core.embedPooled(tokenIds));

  const embedTokensBatch = async (
    tokenIdsList: readonly (readonly number[])[],
  ): Promise<Float32Array[]> => {
    if (tokenIdsList.length === 0) return [];
    // A batch of one is a single sentence — take the replay path.
    if (tokenIdsList.length === 1) return [await embedTokens(tokenIdsList[0]!)];
    const pooled = await core.embedPooledBatch(tokenIdsList);
    return tokenIdsList.map((_, b) =>
      normalize(pooled.slice(b * EMBEDDING_DIM, (b + 1) * EMBEDDING_DIM)),
    );
  };

  // Warm both routes inside error scopes: the batched forward and the replay
  // captures (every bucket) compile and validate every pipeline the hot path
  // will use. Per-call scopes are deliberately absent afterwards: each pop is
  // a GPU-process round-trip, and a replay re-submits already-validated work.
  const warm = await inGpuErrorScopes(device, 'pipeline warm-up', async () => {
    const pair = [tokenizer.clsId, tokenizer.sepId];
    await embedTokensBatch([pair, pair]);
    await core.warmBuckets(pair);
    return embedTokens(pair);
  });
  if (!warm.every(Number.isFinite) || warm.every((v) => v === 0)) {
    throw new Error(
      'pipeline warm-up produced an unusable embedding — inference fails on this device',
    );
  }

  return {
    tokenizer,
    embedTokens,
    embed: (text) => embedTokens(tokenizer.encode(text)),
    embedTokensBatch,
    embedBatch: (texts) => embedTokensBatch(texts.map((t) => tokenizer.encode(t))),
  };
}
