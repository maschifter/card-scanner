/** all-MiniLM-L6-v2: a BERT encoder built from core nn blocks. Post-LN
 *  transformer: LayerNorm runs AFTER each residual add, and every LayerNorm
 *  carries a bias.
 *
 *  Attention: one fused qkv matmul ([hidden, 3·hidden] — the loader lays q,
 *  k and v side by side as column blocks), sliced back into q/k/v, then the
 *  attn kernel with an unbounded window on both sides (every token sees every
 *  token). The kernel applies no score scale; the loader pre-multiplies the q
 *  and k projections (weights and biases) by headDim^(−1/4) each, so together
 *  they carry the 1/√headDim exactly. Positions are a learned
 *  [maxPositions, hidden] table gathered at [0..T); the constant token-type-0
 *  row is folded into it at load. */

import {
  add,
  gelu,
  materialized,
  matrix,
  nn,
  slice,
  uploadF32,
  type LazyStateDict,
  type Value,
} from '@tie/core';
import { MINILM_L6, type MinilmConfig } from './config.ts';

import { transformMinilmStateDict } from './stateDictHooks.ts';

/** word[ids] + position (restarting at each sentence of a packed batch) →
 *  LayerNorm (token-type row folded into position at load). */
class MinilmEmbeddings extends nn.Module<
  [readonly number[] | Value, (readonly number[] | Value)?],
  Value
> {
  readonly word: nn.Embedding;
  readonly position: nn.Embedding;
  readonly norm: nn.LayerNorm;
  constructor(cfg: MinilmConfig) {
    super();
    this.word = new nn.Embedding(cfg.vocab, cfg.hidden);
    this.position = new nn.Embedding(cfg.maxPositions, cfg.hidden);
    this.norm = new nn.LayerNorm(cfg.hidden, cfg.eps, { bias: true });
  }
  forward(ids: readonly number[], lengths?: readonly number[]): Value;
  /** Capture/replay form: GPU-resident id/position vectors (f32 buffers, one
   *  row per token) — the graph shape is fixed, token content lives in the
   *  buffers. */
  forward(ids: Value, positions: Value): Value;
  forward(ids: readonly number[] | Value, second?: readonly number[] | Value): Value {
    if (!Array.isArray(ids)) {
      return this.norm.forward(
        add(this.word.forward(ids as Value), this.position.forward(second as Value)),
      );
    }
    const lengths = second as readonly number[] | undefined;
    const positions = lengths
      ? lengths.flatMap((len) => Array.from({ length: len }, (_, i) => i))
      : Array.from({ length: ids.length }, (_, i) => i);
    return this.norm.forward(add(this.word.forward(ids), this.position.forward(positions)));
  }
}

/** One post-LN encoder layer:
 *  h  = attnNorm(x + out(attn(qkv(x))))
 *  x' = ffnNorm(h + down(gelu(up(h))))
 *  The GELU rides the up matmul's activation epilogue and each residual add
 *  the out/down matmul's addend epilogue — no separate gelu/add dispatches. */
class MinilmLayer extends nn.Module<[Value, Value?, number?], Value> {
  readonly qkv: nn.Linear;
  readonly mha: nn.MultiHeadAttention;
  readonly out: nn.Linear;
  readonly attnNorm: nn.LayerNorm;
  readonly up: nn.Linear;
  readonly down: nn.Linear;
  readonly ffnNorm: nn.LayerNorm;
  constructor(private readonly cfg: MinilmConfig) {
    super();
    const qw = cfg.heads * cfg.headDim;
    this.qkv = new nn.Linear(cfg.hidden, 3 * qw);
    this.mha = new nn.MultiHeadAttention({
      qHeads: cfg.heads,
      kvHeads: cfg.heads,
      headDim: cfg.headDim,
      windowLeft: Infinity,
      windowRight: Infinity,
    });
    this.out = new nn.Linear(qw, cfg.hidden);
    this.attnNorm = new nn.LayerNorm(cfg.hidden, cfg.eps, { bias: true });
    this.up = new nn.Linear(cfg.hidden, cfg.ffn, { activation: 'gelu' });
    this.down = new nn.Linear(cfg.ffn, cfg.hidden);
    this.ffnNorm = new nn.LayerNorm(cfg.hidden, cfg.eps, { bias: true });
  }
  override forward(x: Value, segments?: Value, maxSegment?: number): Value {
    const qkv = this.qkv.forward(x); // [T, 3·qw], columns q|k|v read in place
    const attn = this.mha.forwardPacked(qkv, { segments, maxSegment });
    const h = this.attnNorm.forward(this.out.forward(attn, { addend: x }));
    return this.ffnNorm.forward(this.down.forward(this.up.forward(h), { addend: h }));
  }
}

/** Token ids → final hidden states [T, hidden]. Pooling/normalization live in
 *  the embedder tail — this module is the checkpoint-shaped part.
 *
 *  Batched forward: `lengths` marks sentence boundaries of ids packed
 *  back-to-back — positions restart at each sentence and every layer's
 *  attention gets a per-row segment range, so sentences never attend across
 *  each other while all row-wise ops run on the pack as one matrix. */
/** Capture/replay inputs to MinilmModel.forward: positions and per-row
 *  attention ranges live in rewritable device buffers; `maxSegment` bounds
 *  the longest segment any replay carries (the attention key-split route is
 *  baked at capture). */
export interface MinilmReplayInputs {
  positions: Value;
  segments: Value;
  maxSegment: number;
}

export class MinilmModel extends nn.Module<
  [readonly number[] | Value, (readonly number[] | MinilmReplayInputs)?],
  Value
> {
  readonly embeddings: MinilmEmbeddings;
  readonly layers: nn.ModuleList<MinilmLayer>;
  constructor(readonly cfg: MinilmConfig = MINILM_L6) {
    super();
    this.embeddings = new MinilmEmbeddings(cfg);
    this.layers = new nn.ModuleList(Array.from({ length: cfg.layers }, () => new MinilmLayer(cfg)));
  }
  override forward(ids: readonly number[], lengths?: readonly number[]): Value;
  /** Capture/replay forward: ids are a GPU-resident f32 vector and the rest
   *  arrives via MinilmReplayInputs — all rewritable in place, so one
   *  captured graph serves every sentence padded to the same T. */
  override forward(ids: Value, replay: MinilmReplayInputs): Value;
  override forward(
    ids: readonly number[] | Value,
    second?: readonly number[] | MinilmReplayInputs,
  ): Value {
    if (!Array.isArray(ids)) {
      const { positions, segments, maxSegment } = second as MinilmReplayInputs;
      let h: Value = this.embeddings.forward(ids as Value, positions);
      for (const layer of this.layers.items) h = layer.forward(h, segments, maxSegment);
      return h;
    }
    const lengths = second as readonly number[] | undefined;
    let segments: Value | undefined;
    let maxSegment: number | undefined;
    if (lengths) {
      const total = lengths.reduce((s, l) => s + l, 0);
      if (total !== ids.length) {
        throw new Error(`minilm: lengths sum ${total} != packed ids length ${ids.length}`);
      }
      const segs = new Float32Array(ids.length * 2);
      let start = 0;
      for (const len of lengths) {
        if (len < 1) throw new Error('minilm: every sentence needs at least one token');
        for (let i = 0; i < len; i++) {
          segs[2 * (start + i)] = start;
          segs[2 * (start + i) + 1] = start + len;
        }
        start += len;
      }
      segments = materialized(matrix(ids.length, 2), uploadF32(segs));
      // No row attends outside its sentence, so the longest sentence (not
      // the pack length) drives the attention key-split decision.
      maxSegment = Math.max(...lengths);
    }
    let h: Value = this.embeddings.forward(ids, lengths);
    for (const layer of this.layers.items) h = layer.forward(h, segments, maxSegment);
    return h;
  }
  override transformStateDict(sd: LazyStateDict, prefix: string): void {
    transformMinilmStateDict(sd, prefix, this.cfg);
  }
}
