/** Moonshine v2 encoder: pre-norm transformer layers over the frontend
 *  frames, with NO positional information of any kind — locality comes
 *  entirely from per-layer asymmetric sliding-window attention. Each layer:
 *  LN → banded MHA self-attn → residual; LN → MLP (fc1 → gelu → fc2, biases)
 *  → residual. Final weight-only LN. The checkpoint's norms store gamma with
 *  a −1 offset (applied as gamma+1); the loader adds the 1, so plain
 *  weight-only LayerNorms serve here.
 *
 *  Attention: one fused qkv matmul ([d, 3·qw], loader-fused q|k|v columns,
 *  qw = heads·headDim — NOT d above tiny). No rope, so the full 1/√headDim
 *  score scale is folded into the q columns at load; the kernel's
 *  sm_scale = 1 is exact. Windows are per layer from the config, converted
 *  from HF's strict-bound [left, right] to the kernel's inclusive form
 *  (left−1, max(0, right−1)) — two distinct window shapes per model, so two
 *  attn pipelines total.
 *
 *  The adapter is the encoder→decoder bridge: a learned position embedding
 *  table added to the encoder output (positions appear HERE, not in the
 *  encoder), then a linear projection when encoder and decoder dims differ. */

import { add, chunk, gelu, nn, slice, type Value } from '@tie/core';
import type { MoonshineStreamingConfig } from './config.ts';

/** Self-attention sublayer: qkv → banded mha → out. The owning layer's
 *  residual folds into the out-projection's matmul epilogue via `residual`. */
class EncoderAttn extends nn.Module {
  readonly qkv: nn.Linear;
  readonly mha: nn.MultiHeadAttention;
  readonly out: nn.Linear;
  constructor(
    private readonly cfg: MoonshineStreamingConfig,
    window: readonly [number, number],
  ) {
    super();
    const { hidden, heads, headDim } = cfg.enc;
    const qw = heads * headDim;
    this.qkv = new nn.Linear(hidden, 3 * qw, { bias: false });
    this.mha = new nn.MultiHeadAttention({
      qHeads: heads,
      kvHeads: heads,
      headDim,
      windowLeft: window[0] - 1,
      windowRight: Math.max(0, window[1] - 1),
    });
    this.out = new nn.Linear(qw, hidden, { bias: false });
  }
  forward(x: Value, residual?: Value): Value {
    const qkv = this.qkv.forward(x); // [T, 3·qw], columns q|k|v
    const [q, k, v] = chunk(qkv, 3, 1) as [Value, Value, Value];
    return this.out.forward(this.mha.forward(q, k, v), { addend: residual });
  }
}

/** fc1 → gelu → fc2, both with biases; `residual` rides fc2's epilogue. */
class EncoderMlp extends nn.Module {
  readonly fc1: nn.Linear;
  readonly fc2: nn.Linear;
  constructor(cfg: MoonshineStreamingConfig) {
    super();
    this.fc1 = new nn.Linear(cfg.enc.hidden, cfg.enc.ffn);
    this.fc2 = new nn.Linear(cfg.enc.ffn, cfg.enc.hidden);
  }
  forward(x: Value, residual?: Value): Value {
    return this.fc2.forward(gelu(this.fc1.forward(x)), { addend: residual });
  }
}

export class EncoderLayer extends nn.Module {
  readonly norm1: nn.LayerNorm;
  readonly attn: EncoderAttn;
  readonly norm2: nn.LayerNorm;
  readonly mlp: EncoderMlp;
  constructor(cfg: MoonshineStreamingConfig, window: readonly [number, number]) {
    super();
    this.norm1 = new nn.LayerNorm(cfg.enc.hidden);
    this.attn = new EncoderAttn(cfg, window);
    this.norm2 = new nn.LayerNorm(cfg.enc.hidden);
    this.mlp = new EncoderMlp(cfg);
  }
  forward(x: Value): Value {
    const h = this.attn.forward(this.norm1.forward(x), x);
    return this.mlp.forward(this.norm2.forward(h), h);
  }
}

export class StreamingEncoder extends nn.Module {
  readonly layers: nn.ModuleList<EncoderLayer>;
  readonly norm: nn.LayerNorm;
  constructor(cfg: MoonshineStreamingConfig) {
    super();
    this.layers = new nn.ModuleList(cfg.enc.windows.map((w) => new EncoderLayer(cfg, w)));
    this.norm = new nn.LayerNorm(cfg.enc.hidden);
  }
  /** x [T, enc.hidden] frontend output → [T, enc.hidden]. */
  forward(x: Value): Value {
    let h = x;
    for (const layer of this.layers.items) h = layer.forward(h);
    return this.norm.forward(h);
  }
}

/** Encoder→decoder adapter: adds learned positions (rows 0..T−1 of a
 *  [maxPositions, enc.hidden] table) to the encoder output, then projects to
 *  the decoder dim when the two differ (tiny: identity, no proj Parameter).
 *  Its output is what every decoder layer cross-attends to. */
export class StreamingAdapter extends nn.Module {
  readonly posEmb: nn.Parameter;
  readonly proj?: nn.Linear;
  constructor(cfg: MoonshineStreamingConfig) {
    super();
    const [eh, dh] = [cfg.enc.hidden, cfg.dec.hidden];
    this.posEmb = new nn.Parameter({
      elems: cfg.maxPositions * eh,
      dtype: 'f32',
      dims: [cfg.maxPositions, eh],
    });
    this.proj = eh === dh ? undefined : new nn.Linear(eh, dh, { bias: false });
  }
  /** x [T, enc.hidden] encoder output → [T, dec.hidden]. */
  forward(x: Value): Value {
    const t = x.shape.dims![0]!;
    const positioned = add(x, slice(this.posEmb.value, 0, 0, t));
    return this.proj ? this.proj.forward(positioned) : positioned;
  }
}
