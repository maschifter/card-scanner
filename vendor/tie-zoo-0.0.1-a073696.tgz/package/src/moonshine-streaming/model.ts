/** MoonshineStreamingModel: full module tree (frontend + encoder + adapter +
 *  decoder + embedding), T-independent — no sequence length in any
 *  constructor. transformStateDict maps the HF checkpoint onto the parameter
 *  tree (see stateDictHooks.ts), so one loadStateDict binds the whole
 *  checkpoint.
 *
 *  The decoder IS the moonshine v1 decoder class: v2's decoder is the same
 *  architecture (causal partial-rope self-attn, cross-attn, SwiGLU, plain
 *  bias-free norms, interleaved rope), only its dims come from cfg.dec — the
 *  decoderView projection bridges the two config shapes, and the v1 rope
 *  table builder consumes the same view. Cross K/V read the ADAPTER output.
 *
 *  The nn.Embedding weight [V, dec.hidden] is one GPU tensor with two roles:
 *  token lookup (ids are CPU-known each step) and the tied LM head (matmul
 *  against the raw [V, d] orientation, so no transposed copy exists and tying
 *  is exact by construction — the checkpoint stores proj_out identical to the
 *  embedding and the exporter dedupes it). */

import {
  argmaxDot,
  gatherRowsFrom,
  matmul,
  nn,
  slice,
  transpose,
  type LazyStateDict,
  type Value,
} from '@tie/core';
import type { MoonshineConfig } from '../moonshine/config.ts';
import { MoonshineDecoder } from '../moonshine/decoder.ts';
import type { MoonshineStreamingConfig } from './config.ts';
import { StreamingFrontend } from './frontend.ts';
import { StreamingAdapter, StreamingEncoder } from './encoder.ts';
import { transformStreamingStateDict } from './stateDictHooks.ts';

/** cfg.dec exposed in the v1 MoonshineConfig shape, so the v1 decoder class
 *  and rope table builder consume v2 configs unchanged. encLayers is not a
 *  decoder-side field but the type requires it. */
export function decoderView(cfg: MoonshineStreamingConfig): MoonshineConfig {
  return {
    dModel: cfg.dec.hidden,
    ffn: cfg.dec.ffn,
    encLayers: cfg.enc.layers,
    decLayers: cfg.dec.layers,
    heads: cfg.dec.heads,
    headDim: cfg.dec.headDim,
    rotaryDim: cfg.dec.rotaryDim,
    ropeTheta: cfg.dec.ropeTheta,
    vocab: cfg.vocab,
    maxPositions: cfg.maxPositions,
    bos: cfg.bos,
    eos: cfg.eos,
  };
}

export class MoonshineStreamingModel extends nn.Module {
  readonly embedding: nn.Embedding;
  readonly frontend: StreamingFrontend;
  readonly encoder: StreamingEncoder;
  readonly adapter: StreamingAdapter;
  readonly decoder: MoonshineDecoder;
  /** Half precision is `model.half()` — every parameter and every activation
   *  at once (see nn.Module.half). There is no per-tensor weight dtype. */
  constructor(readonly cfg: MoonshineStreamingConfig) {
    super();
    this.embedding = new nn.Embedding(cfg.vocab, cfg.dec.hidden);
    this.frontend = new StreamingFrontend(cfg);
    this.encoder = new StreamingEncoder(cfg);
    this.adapter = new StreamingAdapter(cfg);
    this.decoder = new MoonshineDecoder(decoderView(cfg));
  }

  override transformStateDict(sd: LazyStateDict, prefix: string): void {
    transformStreamingStateDict(sd, prefix, this.cfg);
  }

  /** Token ids → embedded rows [ids.length, dec.hidden]. */
  embed(ids: readonly number[]): Value {
    return this.embedding.forward(ids);
  }

  /** GPU-resident token id(s) (f32, e.g. a nextTokenId result) → embedded
   *  rows [n, d] — the decode chain feeds itself without a CPU readback. */
  embedFrom(ids: Value): Value {
    return gatherRowsFrom(this.embedding.weight.value, ids);
  }

  /** Decoder output [t, d] → next-token logits [V, 1] for the LAST row only —
   *  never a [t, V] logits matrix. Teacher-forced parity paths use this; the
   *  incremental decode loop uses nextTokenId instead (the logits never
   *  materialize there). The embedding and h must share a dtype — the matmul
   *  binds one element type. */
  logitsLast(h: Value): Value {
    const w = this.embedding.weight.value;
    if (w.shape.dtype !== h.shape.dtype) {
      throw new Error(
        `MoonshineStreamingModel.logitsLast: embedding is ${w.shape.dtype} but h is ${h.shape.dtype}`,
      );
    }
    const t = h.shape.dims![0]!;
    return matmul(w, transpose(slice(h, 0, t - 1, t)));
  }

  /** Incremental-decode step output [1, d] → greedy token id as a [1,1] f32
   *  (fused gemv + argmax over the tied embedding — one dispatch, 4-byte
   *  readback, lowest index on ties like the CPU loop it replaces). */
  nextTokenId(h1: Value): Value {
    return argmaxDot(this.embedding.weight.value, h1);
  }

  /** The model is driven through frontend/encoder/adapter/decoder + the
   *  helpers above — there is no single x → y pass. */
  forward(): Value {
    throw new Error(
      'MoonshineStreamingModel: use frontend/encoder/adapter/decoder forwards, embed() and logitsLast()',
    );
  }
}
