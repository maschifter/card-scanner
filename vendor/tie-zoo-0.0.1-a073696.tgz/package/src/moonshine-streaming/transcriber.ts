/** Moonshine v2 (streaming) transcriber: load once, then transcribe(audio) =
 *  encode once + greedy KV-cached burst decode — the moonshine v1 decode loop
 *  driving the v2 frontend/encoder/adapter.
 *
 *  Audio of any length is accepted: clips over the per-chunk ceiling are
 *  split on quiet points (chunking.ts), each chunk transcribed as its own
 *  utterance, texts joined and ids/timings concatenated. Each utterance is
 *  zero-padded to a whole number of 80-sample frames (HF's processor pads
 *  identically) and uploaded AS the [T, 80] frame matrix — same buffer.
 *
 *  Per utterance: frontend + encoder + adapter + every layer's cross K/V in
 *  ONE eval with the K/V Values as co-targets (only eval targets survive the
 *  eval boundary), then decode in BURSTS of up to 8 positions per submit:
 *  within a burst each step's fused gemv+argmax id feeds the next step's
 *  embedding ON DEVICE (embedFrom) and lands in row t of a preallocated id
 *  buffer (writeRows), so the GPU runs 8 tokens without a CPU round-trip;
 *  one readback of the id rows closes the burst, appends, and stops at EOS
 *  or min(DECODE_POSITIONS, ceil(6.5 tokens/s of audio)). A burst may
 *  overshoot EOS by up to 7 positions — those steps are cheap, their ids are
 *  discarded, and the cache rows they touch are dead.
 *
 *  Decoder rope tables and the per-layer self-attention K/V caches are
 *  allocated once at DECODE_POSITIONS rows — the checkpoint's 4096-position
 *  budget is far past any 30 s chunk (~200 tokens), so the practical cap
 *  keeps the caches small; the adapter's position table still covers the
 *  full 4096 encoder frames. Each step writes cache row t in place
 *  (writeRows); per utterance only the cross K/V and adapter output are
 *  released — GPU memory stays flat. Utterances reuse the cache buffers, so
 *  transcribe() calls must stay sequential. */

import {
  defaultRoot,
  evalValues,
  fromSafetensors,
  gpuExecutor,
  slice,
  tensor,
  writeRows,
  type Value,
  type WeightCache,
} from '@tie/core';
import { splitIntoChunks, type ChunkOpts } from '../moonshine/chunking.ts';
import { buildRopeTables } from '../moonshine/rope.ts';
import { decodeTokens, type MoonshineTokenizer } from '../moonshine/tokenizer.ts';
import type { SelfKV } from '../moonshine/decoder.ts';
import type { TranscribeResult, Transcriber, TranscriberPerf } from '../moonshine/transcriber.ts';
import { MOONSHINE_STREAMING_TINY, type MoonshineStreamingConfig } from './config.ts';
import { frontendFrames } from './frontend.ts';
import { MoonshineStreamingModel, decoderView } from './model.ts';

export type { TranscribeResult, Transcriber };

const SAMPLE_RATE = 16_000;
const TOKENS_PER_SECOND = 6.5;
/** Decode positions per submit — the EOS-overshoot / round-trip trade-off. */
const BURST = 8;
/** Rope-table and KV-cache rows: covers a 30 s chunk's ~195 tokens with
 *  headroom at 2% of the checkpoint's 4096-position budget. */
const DECODE_POSITIONS = 256;
/** Per-chunk audio ceiling; at ~6.5 tokens/s this stays inside DECODE_POSITIONS. */
const MAX_CHUNK_SECONDS = 30;
/** Tail span scanned for a quiet cut point when splitting long clips. */
const SPLIT_SEARCH_SECONDS = 5;

export async function createTranscriber(
  weightsUrl: string,
  tokenizer: MoonshineTokenizer,
  opts: {
    cfg?: MoonshineStreamingConfig;
    /** 'f16' is NATIVE half precision: every parameter AND every activation
     *  is f16 (model.half()) — halved memory traffic and bandwidth, not just
     *  storage. An f16 weights file feeds the params bit-exactly; an f32 file
     *  is rounded to f16 at load. */
    weightDtype?: 'f32' | 'f16';
    /** Caches every fetched byte range of the weights file — warm loads
     *  touch no network. Keys embed `cacheId` (defaults to the URL's file
     *  name), so a renamed file never serves stale bytes. */
    cache?: WeightCache;
    cacheId?: string;
    onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
    onBytes?: (chunkBytes: number) => void;
    /** Chunking overrides — tests force small chunks with short clips. */
    chunking?: Partial<Pick<ChunkOpts, 'maxSeconds' | 'searchSeconds'>>;
    /** Diagnostic hooks + scheduling knobs — absent in production. */
    perf?: TranscriberPerf;
  } = {},
): Promise<Transcriber> {
  const root = defaultRoot();
  const cfg = opts.cfg ?? MOONSHINE_STREAMING_TINY;
  const dec = decoderView(cfg);
  const perf = opts.perf;
  const burstMax = Math.max(1, Math.min(perf?.burst ?? BURST, DECODE_POSITIONS));
  const ex = gpuExecutor(root, { perf: perf?.gpuPerf });

  const sd = await fromSafetensors(weightsUrl, {
    onBytes: opts.onBytes,
    cache: opts.cache,
    cacheId: opts.cacheId,
  });
  if (sd.metadata['model'] && sd.metadata['model'] !== 'moonshine-streaming') {
    throw new Error(
      `moonshine-streaming weights: file is for model '${sd.metadata['model']}', ` +
        `expected 'moonshine-streaming'`,
    );
  }
  // 'f16' is NATIVE half precision — parameters and activations alike.
  const half = opts.weightDtype === 'f16';
  const model = new MoonshineStreamingModel(cfg);
  if (half) model.half(root);
  await model.loadStateDict(sd, { root, onProgress: opts.onProgress });

  /** An activation buffer in the model's storage dtype. The KV caches and the
   *  audio slab feed f16 kernels on a halved model, so they cannot stay f32.
   *  Rope tables and the id buffer are NOT built through this: both are f32 in
   *  every variant (see kernels/attention/rope.ts and argmaxDot.ts). */
  const actTensor = (data: Float32Array, dims: [number, number]): Value =>
    tensor(root, data, { elems: data.length, dtype: half ? 'f16' : 'f32', dims });

  // Position-constant: decoder tables cover every legal step count.
  const tables = buildRopeTables(DECODE_POSITIONS, dec);
  const decCos = tensor(root, tables.cos, [DECODE_POSITIONS, dec.headDim]);
  const decSin = tensor(root, tables.sin, [DECODE_POSITIONS, dec.headDim]);

  // Preallocated per-layer self-attention caches, written in place row by row
  // (see the header); allocated once, reused by every utterance (and every
  // chunk of a long clip — chunks run sequentially).
  const qw = dec.heads * dec.headDim;
  const kvInit = new Float32Array(DECODE_POSITIONS * qw);
  const selfKV: SelfKV[] = Array.from({ length: dec.decLayers }, () => ({
    k: actTensor(kvInit, [DECODE_POSITIONS, qw]),
    v: actTensor(kvInit, [DECODE_POSITIONS, qw]),
  }));
  // Per-position greedy ids, written on device by each burst step and read
  // back once per burst.
  const idsBuf = tensor(root, new Float32Array(DECODE_POSITIONS), [DECODE_POSITIONS, 1]);

  /** Zero-pad the tail to a whole number of frontend frames. */
  const padToFrames = (audio: Float32Array): Float32Array => {
    if (audio.length === 0) throw new Error('transcribe: empty audio');
    const frames = Math.ceil(audio.length / cfg.frameLen);
    if (frames * cfg.frameLen === audio.length) return audio;
    const padded = new Float32Array(frames * cfg.frameLen);
    padded.set(audio);
    return padded;
  };

  const transcribeUtterance = async (rawAudio: Float32Array): Promise<TranscribeResult> => {
    perf?.onPhase?.('encode');
    const t0 = performance.now();
    const audio = padToFrames(rawAudio);
    const frames = frontendFrames(audio.length, cfg.frameLen);
    const x = actTensor(audio, [frames.input, cfg.frameLen]);

    const adapterOut = model.adapter.forward(model.encoder.forward(model.frontend.forward(x)));
    const cross = model.decoder.precomputeCrossKV(adapterOut);
    // One eval; the K/V co-targets pin every buffer the decode loop reads.
    evalValues([adapterOut, ...cross.flatMap((c) => [c.k, c.v])], ex);
    // Drain the queue so the encoder's GPU tail doesn't bleed into the first
    // burst's readback wait; callers that don't display the encode/decode
    // split omit the flag and keep the overlap.
    if (perf?.syncAfterEncode) await root.device.queue.onSubmittedWorkDone();
    const encodeMs = performance.now() - t0;

    const maxTokens = Math.min(
      DECODE_POSITIONS,
      Math.ceil((rawAudio.length / SAMPLE_RATE) * TOKENS_PER_SECOND),
    );
    // Hand pinned eval-target K/V pairs (the cross-attention set) back to
    // the pool at the end of the utterance.
    const release = (kvs: readonly { k: Value; v: Value }[]) => {
      for (const { k, v } of kvs) {
        ex.releaseOutput(k.buffer, k.shape);
        k.markReleased();
        ex.releaseOutput(v.buffer, v.shape);
        v.markReleased();
      }
    };
    ex.releaseOutput(adapterOut.buffer, adapterOut.shape); // only the cross K/V outlive the encode
    adapterOut.markReleased();

    const ids: number[] = [cfg.bos];
    perf?.onPhase?.('decode');
    const t1 = performance.now();
    decode: while (ids.length < maxTokens) {
      const base = ids.length - 1; // position of the burst's first fed token
      const burst = Math.min(burstMax, maxTokens - ids.length);
      const tBuild = performance.now();
      // Build the whole burst as ONE DAG: step j's argmax id chains into
      // step j+1's embedding on device, and every id lands in its row of
      // idsBuf. The in-place writes (KV rows, id rows) ride the chain.
      const idRows: Value[] = [];
      let x1 = model.embed([ids[base]!]); // burst opener: CPU-known id
      for (let j = 0; j < burst; j++) {
        const t = base + j;
        const h = model.decoder.forwardStep(
          x1,
          slice(decCos, 0, t, t + 1),
          slice(decSin, 0, t, t + 1),
          cross,
          selfKV,
          t,
        );
        const idVal = model.nextTokenId(h); // [1,1] f32 greedy id
        idRows.push(writeRows(idsBuf, idVal, t));
        if (j + 1 < burst) x1 = model.embedFrom(idVal);
      }
      const tEval = performance.now();
      evalValues(idRows, ex);
      const tRead = performance.now();
      // One readback per burst: the id rows written so far (4 bytes each).
      const data = await ex.readback(idsBuf.buffer, {
        elems: base + burst,
        dtype: 'f32',
        dims: [base + burst, 1],
      });
      perf?.onBurst?.({
        positions: burst,
        buildMs: tEval - tBuild,
        evalMs: tRead - tEval,
        readbackMs: performance.now() - tRead,
      });
      for (let j = 0; j < burst; j++) {
        const best = data[base + j]!;
        ids.push(best);
        if (best === cfg.eos) break decode;
      }
    }
    release(cross);
    return {
      ids,
      text: decodeTokens(tokenizer, ids),
      timings: { encodeMs, decodeMs: performance.now() - t1, steps: ids.length - 1 },
    };
  };

  const chunkOpts: ChunkOpts = {
    maxSeconds: opts.chunking?.maxSeconds ?? MAX_CHUNK_SECONDS,
    searchSeconds: opts.chunking?.searchSeconds ?? SPLIT_SEARCH_SECONDS,
    sampleRate: SAMPLE_RATE,
  };

  const transcribe = async (audio: Float32Array): Promise<TranscribeResult> => {
    const chunks = splitIntoChunks(audio, chunkOpts);
    if (chunks.length === 1) return transcribeUtterance(audio);
    const results: TranscribeResult[] = [];
    for (const chunk of chunks) results.push(await transcribeUtterance(chunk));
    return {
      ids: results.flatMap((r) => r.ids),
      text: results
        .map((r) => r.text.trim())
        .filter((t) => t.length > 0)
        .join(' '),
      timings: results.reduce(
        (sum, r) => ({
          encodeMs: sum.encodeMs + r.timings.encodeMs,
          decodeMs: sum.decodeMs + r.timings.decodeMs,
          steps: sum.steps + r.timings.steps,
        }),
        { encodeMs: 0, decodeMs: 0, steps: 0 },
      ),
    };
  };

  return { transcribe };
}
