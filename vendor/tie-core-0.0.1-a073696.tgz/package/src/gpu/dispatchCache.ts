/** Per-root caches for the two objects every kernel dispatch used to allocate
 *  fresh: the tiny dims/meta UNIFORM buffer and the BIND GROUP. A camera loop
 *  dispatches ~150 kernels per frame; allocating both per dispatch measured
 *  262 buffers / 19.3 MB of GPU allocations per steady-state frame (see
 *  zoo/test/gpu/eagerSteadyStateAlloc.test.ts) — on iOS WebKit that outruns
 *  GC and memory pressure halves throughput after ~30 s.
 *
 *  Uniforms are keyed by CONTENT (schema + field values): dims recur, so a
 *  fixed-shape vision model converges to a fixed set and steady-state frames
 *  allocate nothing. Bind groups are keyed by IDENTITY of their entries
 *  (layout + which buffers fill the slots): the BufferPool recycles the same
 *  buffers frame over frame, so combos recur too. Growth is bounded by the
 *  set of distinct dim values / buffer combos actually seen — for the LLM
 *  path that's one small entry per distinct token count, far cheaper than
 *  per-dispatch allocation ever was. */

import type { TgpuBindGroup, TgpuRoot } from 'typegpu';

interface RootCaches {
  /** schema → (content key → uniform buffer) */
  uniforms: WeakMap<object, Map<string, object>>;
  /** layout → (entry-identity key → bind group) */
  bindGroups: WeakMap<object, Map<string, TgpuBindGroup>>;
  /** stable small ints for identity keys */
  ids: WeakMap<object, number>;
  nextId: number;
}

const perRoot = new WeakMap<TgpuRoot, RootCaches>();

function caches(root: TgpuRoot): RootCaches {
  let c = perRoot.get(root);
  if (c === undefined) {
    c = { uniforms: new WeakMap(), bindGroups: new WeakMap(), ids: new WeakMap(), nextId: 1 };
    perRoot.set(root, c);
  }
  return c;
}

function idOf(c: RootCaches, o: object): number {
  let v = c.ids.get(o);
  if (v === undefined) {
    v = c.nextId++;
    c.ids.set(o, v);
  }
  return v;
}

/** Get-or-create the uniform buffer holding `values` for `schema`. Cached
 *  buffers are never written after creation — callers treat them as
 *  immutable snapshots of their content. */
export function cachedUniform(
  root: TgpuRoot,
  schema: object,
  values: number | Record<string, number>,
): object {
  const c = caches(root);
  let bySchema = c.uniforms.get(schema);
  if (bySchema === undefined) {
    bySchema = new Map();
    c.uniforms.set(schema, bySchema);
  }
  const key = typeof values === 'number' ? String(values) : JSON.stringify(values);
  let buf = bySchema.get(key);
  if (buf === undefined) {
    buf = (root.createBuffer as (s: object, v: unknown) => { $usage: (u: string) => object })(
      schema,
      values,
    ).$usage('uniform');
    bySchema.set(key, buf);
  }
  return buf;
}

/** Get-or-create the bind group binding exactly these entry objects into
 *  `layout`'s slots. Correct under buffer pooling: the key is the identity of
 *  the bound buffers, and a bind group is nothing more than that binding. */
export function cachedBindGroup(
  root: TgpuRoot,
  layout: object,
  entries: Record<string, object>,
): TgpuBindGroup {
  const c = caches(root);
  let byLayout = c.bindGroups.get(layout);
  if (byLayout === undefined) {
    byLayout = new Map();
    c.bindGroups.set(layout, byLayout);
  }
  const names = Object.keys(entries).sort();
  let key = '';
  for (const n of names) key += `${n}=${idOf(c, entries[n]!)},`;
  let bg = byLayout.get(key);
  if (bg === undefined) {
    bg = (root.createBindGroup as (l: object, e: object) => TgpuBindGroup)(layout, entries);
    byLayout.set(key, bg);
  }
  return bg;
}
