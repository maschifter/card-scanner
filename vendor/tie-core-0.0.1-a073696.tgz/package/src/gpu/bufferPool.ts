import type { GpuBufferRef, ValueMeta } from '../graph/value.ts';

/** Recycles GPU buffers for op intermediates instead of allocating a fresh one
 *  per op. Every op in an eval needs an output buffer, and GPU allocation is
 *  slow; but once an intermediate's last consumer has been dispatched, its
 *  buffer is dead and can back a later op's output. The eval driver calls
 *  acquire() for each output and release() after the last read (liveness pass
 *  in evalCore.ts), so a 30-op chain runs in ~2 buffers instead of 30.
 *
 *  Buffers are interchangeable only within the same size AND dtype, hence the
 *  `${dtype}:${elems}` bucket key: an f32[64] can't stand in for a vec4f[64].
 *  Allocation itself is injected (createBuffer) to keep this class free of
 *  WebGPU — gpuExecutor passes the real `root.createBuffer` call. */
export class BufferPool {
  private free = new Map<string, GpuBufferRef[]>();

  /** @param createBuffer allocate a fresh buffer for `shape`. */
  constructor(private readonly createBuffer: (shape: ValueMeta) => GpuBufferRef) {}

  private key(shape: ValueMeta): string {
    return `${shape.dtype}:${shape.elems}`;
  }

  acquire(shape: ValueMeta): GpuBufferRef {
    const bucket = this.free.get(this.key(shape));
    const reused = bucket?.pop();
    return reused ?? this.createBuffer(shape);
  }

  release(buffer: GpuBufferRef, shape: ValueMeta): void {
    const k = this.key(shape);
    const bucket = this.free.get(k);
    if (bucket) bucket.push(buffer);
    else this.free.set(k, [buffer]);
  }
}
