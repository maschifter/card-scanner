/** Default-device state — the leaf module behind initTie(root) (defined in
 *  eval.ts, which owns executor construction). Kept import-free so buffers.ts
 *  can resolve the default root without creating an import cycle through the
 *  executor machinery. */
import type { TgpuRoot } from 'typegpu';

let currentRoot: TgpuRoot | undefined;

/** One executor per root, ever — pool + dispatch caches must accumulate.
 *  Values are untyped here (leaf module); eval.ts casts on the way out. */
export const executorPerRoot = new WeakMap<TgpuRoot, unknown>();

/** @internal set by initTie. */
export function setDefaultRoot(root: TgpuRoot): void {
  currentRoot = root;
}

/** Whether `root` can run f16 shaders. TypeGPU emits `enable f16;` into every
 *  shader compiled from a root whose device enabled the feature, so this is
 *  the only gate: request it with
 *  `tgpu.init({ device: { optionalFeatures: ['shader-f16'] } })`, then check
 *  here before calling Module.half(). */
export function supportsF16(root: TgpuRoot = defaultRoot()): boolean {
  return root.enabledFeatures.has('shader-f16');
}

export function defaultRoot(): TgpuRoot {
  if (!currentRoot) {
    throw new Error('no default device — call initTie(root) first, or pass root explicitly');
  }
  return currentRoot;
}

/** The default root if one was set, else undefined — for callers whose check
 *  is best-effort (Module.half in graph-only contexts). */
export function maybeDefaultRoot(): TgpuRoot | undefined {
  return currentRoot;
}

/** Test isolation only — forgets the default root (memoized executors survive
 *  via the WeakMap so re-init of the same root keeps its pool). */
export function resetTie(): void {
  currentRoot = undefined;
}
