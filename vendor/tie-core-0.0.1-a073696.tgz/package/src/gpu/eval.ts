/** WebGPU wiring for the eager eval driver. The device-agnostic driver logic
 *  lives in evalCore.ts (unit-tested without a device); this file provides the
 *  real Executor that batches every node's dispatch into ONE compute pass and
 *  submits once. Buffers come from the pool; pipelines from the cache (built at
 *  most once per op). Dtype-aware: allocates f32 or vec4f per node. */

import { d } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { MAX_WORKGROUPS_PER_DIM, WORKGROUP_SIZE } from '../kernels/common.ts';
import type { F16Buffer, F32Buffer, KernelHandle, U32Buffer } from '../kernels/common.ts';
import {
  createStorageFor,
  leaseStaging,
  readbackF16,
  readbackF32,
  readbackManySpans,
  uploadU32,
} from './buffers.ts';
import { BufferPool } from './bufferPool.ts';
import { f16ToF32 } from '../weights/convert.ts';
import { elemFor, F16_ELEM, F32_ELEM } from '../kernels/elem.ts';
import { PipelineCache } from './pipelineCache.ts';
import {
  createMatmulPipeline,
  createMatmulTiledPipeline,
  getMatmulAccum,
  MATMUL_TILED_MIN_M,
  matmulHandle,
  matmulTiledHandle,
} from '../kernels/matmul/matmul.ts';
import {
  createMatmulGemvPipeline,
  createMatmulSmallMPipeline,
  matmulGemvHandle,
  matmulSmallMEligible,
  matmulSmallMHandle,
} from '../kernels/matmul/matmulGemv.ts';
import { createMatmulQuantWPipeline, matmulQuantWHandle } from '../kernels/matmul/matmulQuantW.ts';
import { createRopePipeline, ropeHandle } from '../kernels/attention/rope.ts';
import {
  ATTN_ROWS_CHUNK,
  ATTN_ROWS_MAX_CHUNKS,
  attnHandle,
  attnRowsHandle,
  attnRowsSplitHandles,
  createAttnPipeline,
  createAttnRowsMergePipeline,
  createAttnRowsPipeline,
  createAttnRowsSplitPipeline,
  createAttnRowsSubgroupSplitPipeline,
} from '../kernels/attention/attn.ts';
import {
  ATTN_DECODE_CHUNK,
  ATTN_DECODE_MAX_CHUNKS,
  ATTN_SPLIT_SCRATCH_ELEMS,
  attnDecodeHandle,
  attnDecodeSplitHandles,
  createAttnDecodeMergePipeline,
  createAttnDecodePipeline,
  createAttnDecodeSplitPipeline,
} from '../kernels/attention/attnDecode.ts';
import {
  ARGMAX_SPLIT,
  argmaxDotPartialHandle,
  argmaxDotReduceHandle,
  createArgmaxDotPipeline,
  createArgmaxDotReducePipeline,
} from '../kernels/matmul/argmaxDot.ts';
import {
  createMatmulGatherQuantWPipeline,
  matmulGatherQuantWHandle,
} from '../kernels/matmul/matmulGatherQuantW.ts';
import { createMatmulGatherPipeline, matmulGatherHandle } from '../kernels/matmul/matmulGather.ts';
import {
  createAddF32Pipeline,
  createMulF32Pipeline,
  createSubF32Pipeline,
  createSwigluF32Pipeline,
  elementwiseF32Handle,
} from '../kernels/elementwise/elementwiseF32.ts';
import { createSoftmaxPipeline, softmaxHandle } from '../kernels/reduce/softmax.ts';
import { createLayerNormPipeline, layerNormHandle } from '../kernels/reduce/layerNorm.ts';
import {
  createSwigluChunkPipeline,
  swigluChunkHandle,
} from '../kernels/elementwise/swigluChunk.ts';
import { createMeanPipeline, meanHandle } from '../kernels/reduce/reduce.ts';
import {
  createAddScalarPipeline,
  createAsinhPipeline,
  createClampScalarPipeline,
  createGeluPipeline,
  createMulScalarPipeline,
  createRsqrtPipeline,
  createSigmoidPipeline,
  createSiluPipeline,
  createTanhPipeline,
  unaryHandle,
} from '../kernels/elementwise/unary.ts';
import { conv1dHandle, createConv1dPipeline } from '../kernels/conv/conv1d.ts';
import { castHandle, createCastPipeline } from '../kernels/shape/cast.ts';
import { createTransposePipeline, transposeHandle } from '../kernels/shape/transpose.ts';
import {
  concatColsHandle,
  createConcatColsPipeline,
  createSliceColsPipeline,
  sliceColsHandle,
} from '../kernels/shape/columns.ts';
import {
  concatRowsHandle,
  createConcatRowsPipeline,
  createGatherRowsFromPipeline,
  createGatherRowsPipeline,
  createSliceRowsPipeline,
  createWriteRowsPipeline,
  gatherRowsFromHandle,
  gatherRowsHandle,
  sliceRowsHandle,
  writeRowsHandle,
} from '../kernels/shape/rows.ts';
import { createTopkSelectPipeline, topkSelectHandle } from '../kernels/reduce/topkSelect.ts';
import {
  type ConvTranspose2dCfg,
  convTranspose2dHandle,
  createConvTranspose2dPipeline,
} from '../kernels/conv/convTranspose2d.ts';
import {
  type Conv2dHwc4Cfg,
  conv2dHwc4Handle,
  copyChHwc4Handle,
  createConv2dHwc4Pipeline,
  createCopyChHwc4Pipeline,
  createMaxPool2dHwc4Pipeline,
  createToChwPipeline,
  createToHwc4Pipeline,
  createUpsample2dHwc4Pipeline,
  type MaxPool2dHwc4Cfg,
  moveHwc4Handle,
  type MoveHwc4Pipeline,
  toChwHandle,
  toHwc4Handle,
} from '../kernels/conv/hwc4.ts';
import {
  evalValues as evalValuesWith,
  toArray as toArrayWith,
  type Executor,
  type Readback,
  type Releaser,
} from '../graph/evalCore.ts';
import type { GpuOpTime, GpuPerfSink, GpuSubmitTiming } from './perf.ts';
import type { Value, ValueMeta } from '../graph/value.ts';
import { defaultRoot, executorPerRoot, setDefaultRoot } from './context.ts';

const UNARY_OPS = new Set([
  'rsqrt',
  'addScalar',
  'sigmoid',
  'mulScalar',
  'clampScalar',
  'tanh',
  'gelu',
  'silu',
  'asinh',
]);

export type { Executor, Readback, Releaser };

/** Evaluate pending Values now (cf. mx.eval). Runs on the initTie() executor
 *  unless one is passed explicitly. */
export function evalValues(targets: readonly Value[], ex?: Executor): void {
  evalValuesWith(targets, ex ?? defaultExecutor());
}

/** Single-submit readback: ride the result copy on the SAME command buffer as
 *  the compute pass, so one embed/decode step costs one queue.submit + one
 *  mapAsync round-trip instead of two submits. */
export interface FusedReadback {
  /** Queue `value`'s buffer for a staging copy encoded by the NEXT submit()
   *  (or captured replay()) on this executor; resolves with the flattened f32
   *  contents once that submit's work completes. The value must be
   *  materialized by the time the submit encodes — evalValues/replay do that.
   *  One pending readback at a time. */
  readbackOnSubmit(value: Value): Promise<Float32Array>;
  /** Multi-output form: all values ride ONE staging copy set in the next
   *  submit's command buffer and resolve together (a replayed frame's
   *  detection levels + prototypes in a single submit). */
  readbackManyOnSubmit(values: readonly Value[]): Promise<Float32Array[]>;
  /** toArray with the copy fused into the eval's own submit. Falls back to a
   *  plain readback for already-materialized values. */
  toArrayFused(value: Value): Promise<Float32Array>;
}

export type TieExecutor = Executor & Readback & Releaser & CaptureExecutor & FusedReadback;

/** Set the default device and return its executor — call once at startup,
 *  after which tensor()/toArray()/loadStateDict() need no root/executor args
 *  (cf. torch.set_default_device). The returned executor is for advanced use
 *  (captureFrame, readbackMany); most callers ignore it. Re-initing with the
 *  same root returns the same executor — pool and dispatch caches accumulate
 *  per root for the lifetime of the page. */
export function initTie(root: TgpuRoot): TieExecutor {
  setDefaultRoot(root);
  let ex = executorPerRoot.get(root) as TieExecutor | undefined;
  if (!ex) {
    ex = gpuExecutor(root);
    executorPerRoot.set(root, ex);
  }
  return ex;
}

export function defaultExecutor(): TieExecutor {
  return initTie(defaultRoot());
}

/** Read a Value's numbers on the CPU, evaluating it first if still pending.
 *  Runs on the initTie() executor unless one is passed explicitly. */
export async function toArray(value: Value, ex?: Executor & Readback): Promise<Float32Array> {
  const executor = ex ?? defaultExecutor();
  return 'toArrayFused' in executor
    ? (executor as TieExecutor).toArrayFused(value)
    : toArrayWith(value, executor);
}

/** Build the WebGPU implementation of the eval driver's Executor interface —
 *  the object evalValues()/toArray() call into to run a DAG on a real device.
 *  Holds three pieces of state per executor: a BufferPool for intermediate
 *  outputs, a PipelineCache (each op's shader compiled once, on first use),
 *  and the list of KernelHandles queued by dispatch() until submit().
 *  Create it once and reuse it — pooled buffers and cached pipelines only pay
 *  off across calls.
 *
 *  `opts.perf` (diagnostic, see perf.ts) reports each submit's dispatch count
 *  and — when the device has 'timestamp-query' — a promise for its GPU time;
 *  `perf.perOp` additionally encodes one pass per dispatch for a per-kernel
 *  histogram. Without a sink, submit() encodes one plain compute pass and
 *  touches no query machinery. */
/** One dispatch's GPU time from profileReplay (timestamp queries). */
export interface KernelTiming {
  name: string;
  workgroups: number | readonly [number, number];
  ns: number;
}

/** Capture-and-replay surface of the GPU executor (see captureFrame docs). */
export interface CaptureExecutor {
  captureFrame<T>(fn: () => T): {
    targets: T;
    replay: () => void;
    /** Replay once with one compute pass per dispatch + timestamp queries;
     *  resolves to per-kernel GPU times. Needs the 'timestamp-query' device
     *  feature (resolves to undefined without it). Pass-per-dispatch removes
     *  overlap, so the SUM overstates the real frame — use it for relative
     *  attribution, not absolute totals. */
    profileReplay: () => Promise<KernelTiming[] | undefined>;
  };
}

/** Compiled pipelines are pure functions of (root, op, dtype, cfg) — share ONE
 *  cache per root so a second executor on the same device (per-shape replay
 *  buckets) reuses every shader instead of recompiling the full set. */
const pipelinesPerRoot = new WeakMap<TgpuRoot, ReturnType<typeof makePipelineCache>>();

function makePipelineCache(root: TgpuRoot) {
  return new PipelineCache((op: string, dtype: string, cfg?: Record<string, number>) => {
    if (op === 'add') return createAddF32Pipeline(root, elemFor(dtype));
    if (op === 'mul') return createMulF32Pipeline(root, elemFor(dtype));
    if (op === 'sub') return createSubF32Pipeline(root, elemFor(dtype)); // f32 and f16 both validate
    if (op === 'swiglu') return createSwigluF32Pipeline(root, elemFor(dtype));
    if (op === 'matmul') {
      const matmulCfg = {
        k: cfg!.k!,
        n: cfg!.n!,
        hasBias: cfg!.hasBias!,
        hasAdd: cfg!.hasAdd!,
        accum: cfg!.accum ?? 0,
        hasBaseRow: cfg!.hasBaseRow ?? 0,
      };
      if (cfg!.smallm === 1)
        return createMatmulSmallMPipeline(
          root,
          { ...matmulCfg, act: cfg!.act ?? 0 },
          elemFor(dtype),
        );
      if (cfg!.gemv! === 1) return createMatmulGemvPipeline(root, matmulCfg, elemFor(dtype));
      return cfg!.tiled === 1
        ? createMatmulTiledPipeline(root, { ...matmulCfg, act: cfg!.act ?? 0 })
        : createMatmulPipeline(root, { ...matmulCfg, act: cfg!.act ?? 0 }, elemFor(dtype));
    }
    if (op === 'matmulQuantW')
      return createMatmulQuantWPipeline(root, {
        k: cfg!.k!,
        n: cfg!.n!,
        bits: cfg!.bits!,
        groupSize: cfg!.groupSize!,
      });
    if (op === 'rope')
      return createRopePipeline(
        root,
        {
          cols: cfg!.cols!,
          headDim: cfg!.headDim!,
          srcStart: cfg!.srcStart!,
          srcCols: cfg!.srcCols!,
        },
        elemFor(dtype),
      );
    if (op === 'swigluChunk') return createSwigluChunkPipeline(root, elemFor(dtype));
    if (op === 'attn' || op === 'attnDecodeMerge' || op === 'attnRowsMerge') {
      const attnCfg = {
        qHeads: cfg!.qHeads!,
        kvHeads: cfg!.kvHeads!,
        headDim: cfg!.headDim!,
        windowLeft: cfg!.windowLeft!,
        windowRight: cfg!.windowRight!,
        hasSinks: cfg!.hasSinks!,
        hasSegs: cfg!.hasSegs ?? 0,
        qkvPacked: cfg!.qkvPacked ?? 0,
      };
      if (op === 'attnDecodeMerge')
        return createAttnDecodeMergePipeline(root, attnCfg, elemFor(dtype));
      if (op === 'attnRowsMerge') return createAttnRowsMergePipeline(root, attnCfg, elemFor(dtype));
      if (cfg!.decode! !== 1) {
        if (cfg!.rows! !== 1) return createAttnPipeline(root, attnCfg, elemFor(dtype));
        if (cfg!.sub! === 1)
          return createAttnRowsSubgroupSplitPipeline(root, attnCfg, elemFor(dtype));
        if (cfg!.split! === 1) return createAttnRowsSplitPipeline(root, attnCfg, elemFor(dtype));
        return createAttnRowsPipeline(root, attnCfg, elemFor(dtype));
      }
      return cfg!.split! === 1
        ? createAttnDecodeSplitPipeline(root, attnCfg, elemFor(dtype))
        : createAttnDecodePipeline(root, attnCfg, elemFor(dtype));
    }
    if (op === 'matmulGatherQuantW')
      return createMatmulGatherQuantWPipeline(root, {
        k: cfg!.k!,
        n: cfg!.n!,
        bits: cfg!.bits!,
        groupSize: cfg!.groupSize!,
      });
    if (op === 'matmulGather')
      return createMatmulGatherPipeline(root, { k: cfg!.k!, n: cfg!.n! }, elemFor(dtype));
    if (op === 'softmax') return createSoftmaxPipeline(root, elemFor(dtype));
    if (op === 'layerNorm') return createLayerNormPipeline(root, elemFor(dtype));
    if (op === 'argmaxDot')
      return createArgmaxDotPipeline(
        root,
        { cols: cfg!.cols! },
        // The NODE is always f32 (it holds a row index), so the operand
        // width has to travel in the config or both variants would share
        // one cache slot.
        cfg!.f16 === 1 ? F16_ELEM : F32_ELEM,
      );
    if (op === 'argmaxDotReduce') return createArgmaxDotReducePipeline(root);
    if (op === 'mean') return createMeanPipeline(root, elemFor(dtype));
    // meanSquare reads at the model's width and writes an f32 statistic, so
    // the node's dtype names the OUTPUT — the operand width rides the config.
    if (op === 'meanSquare')
      return createMeanPipeline(root, cfg!.f16 === 1 ? F16_ELEM : F32_ELEM, true);
    if (op === 'rsqrt') return createRsqrtPipeline(root, elemFor(dtype));
    if (op === 'addScalar') return createAddScalarPipeline(root, elemFor(dtype));
    if (op === 'sigmoid') return createSigmoidPipeline(root, elemFor(dtype));
    if (op === 'mulScalar') return createMulScalarPipeline(root, elemFor(dtype));
    if (op === 'clampScalar') return createClampScalarPipeline(root, elemFor(dtype));
    if (op === 'tanh') return createTanhPipeline(root, elemFor(dtype));
    if (op === 'gelu') return createGeluPipeline(root, elemFor(dtype));
    if (op === 'silu') return createSiluPipeline(root, elemFor(dtype));
    if (op === 'asinh') return createAsinhPipeline(root, elemFor(dtype));
    if (op === 'conv1d')
      return createConv1dPipeline(
        root,
        {
          kernel: cfg!.kernel!,
          stride: cfg!.stride!,
          cIn: cfg!.cIn!,
          cOut: cfg!.cOut!,
          padLeft: cfg!.padLeft!,
          hasBias: cfg!.hasBias!,
          act: cfg!.act!,
        },
        elemFor(dtype),
      );
    if (op === 'transpose') return createTransposePipeline(root, elemFor(dtype));
    // astype is the one op whose input and output widths differ, so the
    // SOURCE width rides the config; the node's dtype is the destination.
    if (op === 'astype')
      return createCastPipeline(root, cfg!.f16 === 1 ? F16_ELEM : F32_ELEM, elemFor(dtype));
    if (op === 'sliceCols') return createSliceColsPipeline(root, elemFor(dtype));
    if (op === 'concatCols') return createConcatColsPipeline(root, elemFor(dtype));
    if (op === 'sliceRows') return createSliceRowsPipeline(root, elemFor(dtype));
    if (op === 'concatRows') return createConcatRowsPipeline(root, elemFor(dtype));
    if (op === 'writeRows') return createWriteRowsPipeline(root, elemFor(dtype));
    if (op === 'gatherRowsFrom') return createGatherRowsFromPipeline(root, elemFor(dtype));
    if (op === 'gatherRows') return createGatherRowsPipeline(root, elemFor(dtype));
    // topk's OUTPUT is f32 (packed ids + weights), so the operand width has
    // to travel in the config or both variants share one cache slot.
    if (op === 'topk') return createTopkSelectPipeline(root, cfg!.f16 === 1 ? F16_ELEM : F32_ELEM);
    if (op === 'reshape') return createSliceRowsPipeline(root, elemFor(dtype));
    if (op === 'concatChannels') return createConcatRowsPipeline(root, elemFor(dtype));
    if (op === 'sliceChannels') return createSliceRowsPipeline(root, elemFor(dtype));
    if (op === 'convTranspose2d')
      return createConvTranspose2dPipeline(
        root,
        cfg as unknown as ConvTranspose2dCfg,
        elemFor(dtype),
      );
    // ---- hwc4 family: f16-only kernels, no Elem parameter. ----
    if (op === 'conv2dHwc4') return createConv2dHwc4Pipeline(root, cfg as unknown as Conv2dHwc4Cfg);
    if (op === 'maxPool2dHwc4')
      return createMaxPool2dHwc4Pipeline(root, cfg as unknown as MaxPool2dHwc4Cfg);
    if (op === 'upsample2dHwc4') return createUpsample2dHwc4Pipeline(root, { scale: cfg!.scale! });
    if (op === 'concatChannelsHwc4' || op === 'sliceChannelsHwc4')
      return createCopyChHwc4Pipeline(root);
    if (op === 'toHwc4') return createToHwc4Pipeline(root, cfg!.f16 === 1 ? 'f16' : 'f32');
    if (op === 'toChw') return createToChwPipeline(root, dtype as 'f32' | 'f16');
    throw new Error(`eager: no kernel for op '${op}' dtype '${dtype}'`);
  });
}

function pipelineCacheFor(root: TgpuRoot): ReturnType<typeof makePipelineCache> {
  let c = pipelinesPerRoot.get(root);
  if (c === undefined) {
    c = makePipelineCache(root);
    pipelinesPerRoot.set(root, c);
  }
  return c;
}

/** Bytes a Value's buffer occupies, and how to widen those bytes to f32 on
 *  the CPU. The batched readback paths pack several buffers into one staging
 *  buffer, so they size and decode per value rather than assuming f32.
 *  Copy sizes round up to a multiple of 4 — copyBufferToBuffer rejects other
 *  sizes, and an f16 Value with an odd element count is allocated with the
 *  matching pad halfword (see createStorageFor). */
function readbackSpan(shape: ValueMeta): {
  bytes: number;
  decode: (mapped: ArrayBuffer, offset: number) => Float32Array;
} {
  if (shape.layout !== undefined) {
    throw new Error(
      `readback: Value is stored '${shape.layout}' — convert with toChw() before reading`,
    );
  }
  if (shape.dtype === 'f16') {
    const bytes = (shape.elems + (shape.elems & 1)) * 2;
    return {
      bytes,
      decode: (mapped, offset) =>
        f16ToF32(new Uint16Array(mapped.slice(offset, offset + bytes)).subarray(0, shape.elems)),
    };
  }
  if (shape.dtype !== 'f32') {
    throw new Error(`eager: cannot read back a ${shape.dtype} Value — it is weight storage`);
  }
  const bytes = shape.elems * 4;
  return {
    bytes,
    decode: (mapped, offset) => new Float32Array(mapped.slice(offset, offset + bytes)),
  };
}

export function gpuExecutor(root: TgpuRoot, opts: { perf?: GpuPerfSink } = {}): TieExecutor {
  const perf = opts.perf;
  const canTime = root.device.features.has('timestamp-query');
  // Subgroup-cooperative attention needs the feature AND lanes >= the kernel's
  // 32-wide layout (subgroupAdd over a 32-thread workgroup that spans two
  // 16-wide subgroups would fold half sums). Devices without adapterInfo
  // report 0 and take the serial path.
  const subgroupsOk =
    root.device.features.has('subgroups') &&
    ((root.device as GPUDevice & { adapterInfo?: { subgroupMinSize?: number } }).adapterInfo
      ?.subgroupMinSize ?? 0) >= 32;
  const pool = new BufferPool((shape) => createStorageFor(root, shape));
  const pipelines = pipelineCacheFor(root);
  const handles: KernelHandle[] = [];
  // ---- Handle memo plumbing ----
  // Stable identities for GPU objects (buffers, pipelines) so they can key a
  // Map; WeakMap so dropped buffers don't pin ids.
  const objectIds = new WeakMap<object, number>();
  let nextObjectId = 1;
  const idOf = (o: object): number => {
    let id = objectIds.get(o);
    if (id === undefined) {
      id = nextObjectId++;
      objectIds.set(o, id);
    }
    return id;
  };
  /** op memo key → the finished handle(s) it encoded (argmaxDot is two). */
  const handleCache = new Map<string, KernelHandle[]>();

  // One shared dummy for bias-less convs, add-less residual slots and
  // bias-less layerNorms — the bind slot must be filled but the read is dead
  // (hasBias/hasAdd baked or flagged to 0). 4 elems: the vec4-IO layout binds
  // it as array<vec4f>, whose minimum binding size is 16 bytes.
  // One dummy PER DTYPE: the slot's element type has to match the layout the
  // pipeline was built from, even though the read is dead.
  const dummyBias = new Map<string, F32Buffer>();
  const getDummyBias = (dtype: string = 'f32') => {
    let b = dummyBias.get(dtype);
    if (!b) {
      b = (
        dtype === 'f16'
          ? root.createBuffer(d.arrayOf(d.f16, 4)).$usage('storage')
          : root.createBuffer(d.arrayOf(d.f32, 4)).$usage('storage')
      ) as F32Buffer;
      dummyBias.set(dtype, b);
    }
    return b;
  };

  // Capture/replay (CUDA-graphs style): a fixed-shape per-frame forward
  // dispatches the exact same handle list every frame — pipelines, bind
  // groups, uniforms and pooled buffers are all stable in steady state. So
  // record the handles ONCE and re-encode them per frame, skipping the Value
  // DAG walk, fusion passes and handle lookup entirely. After capture the
  // executor is replay-only: a fresh evalValues would acquire pooled buffers
  // that alias the captured graph's intermediates and silently corrupt it,
  // so acquireOutput throws instead.
  let capturing: KernelHandle[] | undefined;
  let frozen = false;

  // WebGPU caps each dispatch dimension at MAX_WORKGROUPS_PER_DIM; big
  // tensors (yolo26x's 320² stage maps need ~82k) exceed that on flat 1-D
  // kernels, and an over-cap dispatch is REJECTED — its command buffer is
  // dropped silently, which reads as "the model ran in 2ms and output
  // garbage". Split into a 2-D grid of exactly MAX_WORKGROUPS_PER_DIM
  // columns; flat kernels add GRID_Y_STRIDE per gid.y to recover the index.
  // Under the cap, y is 1 and the index math is unchanged. Kernels that
  // spread work themselves carry an [x, y] pair and pass through untouched.
  const dispatchSplit = (wgs: number): readonly [number, number] =>
    wgs > MAX_WORKGROUPS_PER_DIM
      ? [MAX_WORKGROUPS_PER_DIM, Math.ceil(wgs / MAX_WORKGROUPS_PER_DIM)]
      : [wgs, 1];
  const wgOf = (h: KernelHandle): readonly [number, number] =>
    typeof h.workgroups === 'number' ? dispatchSplit(h.workgroups) : h.workgroups;

  // ---- Fused readback (see FusedReadback docs) ----
  // The values whose buffers the next submit copies into one staging lease
  // right inside its own command buffer.
  let pendingRb:
    | {
        values: readonly Value[];
        resolve: (a: Float32Array[]) => void;
        reject: (e: unknown) => void;
      }
    | undefined;
  /** Encode the pending readback's staging copies onto `encoder` (call after
   *  pass.end()); returns the completion to invoke right after queue.submit:
   *  called bare it maps the staging buffer and settles the caller's promise,
   *  called with an error (the submit threw) it rejects instead and returns
   *  the lease unread. */
  const encodePendingRb = (encoder: GPUCommandEncoder): ((err?: unknown) => void) | undefined => {
    if (pendingRb === undefined) return undefined;
    const rb = pendingRb;
    pendingRb = undefined;
    let lease: ReturnType<typeof leaseStaging>;
    const spans: ReturnType<typeof readbackSpan>[] = [];
    const byteSizes: number[] = [];
    let total = 0;
    try {
      for (const v of rb.values) {
        const span = readbackSpan(v.shape);
        spans.push(span);
        byteSizes.push(span.bytes);
        total += span.bytes;
      }
      lease = leaseStaging(root, total);
      let offset = 0;
      rb.values.forEach((v, i) => {
        encoder.copyBufferToBuffer(
          root.unwrap(v.buffer as F32Buffer),
          0,
          lease.staging,
          offset,
          byteSizes[i]!,
        );
        offset += byteSizes[i]!;
      });
    } catch (err) {
      rb.reject(err);
      return undefined;
    }
    return (err?: unknown) => {
      if (err !== undefined) {
        rb.reject(err);
        void lease.finish(() => undefined).catch(() => undefined);
        return;
      }
      lease
        .finish((mapped) => {
          const outs: Float32Array[] = [];
          let offset = 0;
          spans.forEach((span, i) => {
            outs.push(span.decode(mapped, offset));
            offset += byteSizes[i]!;
          });
          return outs;
        })
        .then(rb.resolve, rb.reject);
    };
  };

  /** Build a command buffer via `build`, append any pending readback copies,
   *  and submit — on a throw anywhere along the way the pending readback's
   *  promise rejects instead of staying queued forever (a stuck pendingRb
   *  would poison every later readbackManyOnSubmit on this executor). */
  const submitEncoderWithRb = (build: (encoder: GPUCommandEncoder) => void): void => {
    const encoder = root.device.createCommandEncoder();
    let finishRb: ((err?: unknown) => void) | undefined;
    try {
      build(encoder);
      finishRb = encodePendingRb(encoder);
      root.device.queue.submit([encoder.finish()]);
    } catch (err) {
      if (finishRb !== undefined) finishRb(err);
      else if (pendingRb !== undefined) {
        pendingRb.reject(err);
        pendingRb = undefined;
      }
      throw err;
    }
    finishRb?.();
  };

  const encodeAndSubmit = (hs: readonly KernelHandle[]) => {
    submitEncoderWithRb((encoder) => {
      const pass = encoder.beginComputePass();
      for (const h of hs) {
        const [x, y] = wgOf(h);
        h.pipeline.with(pass).with(h.bindGroup).dispatchWorkgroups(x, y);
      }
      pass.end();
    });
  };
  /** Executor-lifetime scratch for argmaxDot partials — deliberately NOT from
   *  the pool: memoized handles capture their buffers, and a pooled scratch
   *  could later be handed to a long-lived eval target (a KV cache) while a
   *  cached handle still writes into it. 1 KiB once instead. */
  let argmaxScratch: F32Buffer | undefined;
  /** Executor-lifetime scratch for the key-chunked attention pair — same
   *  not-from-the-pool reasoning as argmaxScratch. */
  let attnSplitScratch: F32Buffer | undefined;
  /** Executor-lifetime scratch for the key-split row-attention pair; grows
   *  to the largest (Tq · qHeads · headDim) seen. A grown replacement leaves
   *  earlier memoized pairs on the old buffer — each pair reads the same
   *  buffer it writes, so both stay correct. */
  let attnRowsScratch: F32Buffer | undefined;
  let attnRowsScratchElems = 0;

  const executor: TieExecutor = {
    /** Capture one frame: `fn` runs the forward + evalValues as usual; every
     *  handle it submits is recorded. Returns fn's result (keep it — the
     *  target Values' buffers stay valid across replays) and replay(), which
     *  re-encodes the recorded dispatches. Rules: overwrite inputs in place
     *  (writeF32) before each replay; NEVER releaseValues captured targets;
     *  the executor becomes replay-only afterwards. */
    captureFrame: <T>(fn: () => T) => {
      if (frozen || capturing) throw new Error('captureFrame: executor already captured');
      capturing = [];
      const targets = fn();
      const recorded = capturing;
      capturing = undefined;
      frozen = true;
      if (recorded.length === 0) throw new Error('captureFrame: fn() submitted no GPU work');
      return {
        targets,
        replay: () => encodeAndSubmit(recorded),
        profileReplay: async (): Promise<KernelTiming[] | undefined> => {
          const dev = root.device;
          if (!dev.features.has('timestamp-query')) return undefined;
          const n = recorded.length;
          const querySet = dev.createQuerySet({ type: 'timestamp', count: 2 * n });
          const resolve = dev.createBuffer({
            size: 16 * n,
            usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC,
          });
          const staging = dev.createBuffer({
            size: 16 * n,
            usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST,
          });
          const encoder = dev.createCommandEncoder();
          recorded.forEach((h, i) => {
            const pass = encoder.beginComputePass({
              timestampWrites: {
                querySet,
                beginningOfPassWriteIndex: 2 * i,
                endOfPassWriteIndex: 2 * i + 1,
              },
            });
            const [x, y] = wgOf(h);
            h.pipeline.with(pass).with(h.bindGroup).dispatchWorkgroups(x, y);
            pass.end();
          });
          encoder.resolveQuerySet(querySet, 0, 2 * n, resolve, 0);
          encoder.copyBufferToBuffer(resolve, 0, staging, 0, 16 * n);
          dev.queue.submit([encoder.finish()]);
          await staging.mapAsync(GPUMapMode.READ);
          const t = new BigInt64Array(staging.getMappedRange());
          const out = recorded.map((h, i) => ({
            name: h.name,
            workgroups: h.workgroups,
            ns: Number(t[2 * i + 1]! - t[2 * i]!),
          }));
          staging.unmap();
          staging.destroy();
          resolve.destroy();
          querySet.destroy();
          return out;
        },
      };
    },
    /** Output buffer for one op: reused from the pool, or freshly allocated. */
    acquireOutput: (shape) => {
      if (frozen) {
        throw new Error(
          'gpuExecutor: executor is replay-only after captureFrame() — use replay(), or a separate executor for other work',
        );
      }
      return pool.acquire(shape);
    },
    /** Return a dead intermediate's buffer to the pool for reuse. */
    releaseOutput: (buffer, shape) => pool.release(buffer, shape),
    /** Queue one node's kernel launch (runs nothing yet): route by op, read
     *  the op-specific dims off the node's metadata, build the bind group +
     *  workgroup count via the kernel's *Handle(), and push it onto `handles`.
     *  Sole interpreter of GpuBufferRef — narrows buffers to f32/vec4f here. */
    dispatch: (node, inputs, out, extras) => {
      const op = node.pending!.op;
      /** Shape of the node's i-th input. */
      const inShape = (i: number) => node.pending!.inputs[i]!.shape;
      /** Dimension d of the i-th input's shape. */
      const inDim = (i: number, d: number) => inShape(i).dims![d]!;
      /** 1 when the first input has a single row (m/qLen = 1) — the flag that
       *  routes matmul/attn nodes to their split-K single-row pipelines. */
      const singleRow = () => (inDim(0, 0) === 1 ? 1 : 0);
      // Load-time-constant config baked into specialized pipelines — pipelines
      // are keyed (op, dtype, config), NEVER input shape: only weight-determined
      // dims and op attrs appear here, so new token counts never compile
      // shaders (invariant 5's intent, measured 1.6x on the gather kernel).
      let cfg: Record<string, number> | undefined;
      if (op === 'matmul') {
        // attrs = [hasBias, hasAdd, act] — comptime epilogue variants. `gemv`
        // IS part of the key: m = 1 nodes get the split-K GEMV pipeline
        // (workgroup per column tile) — at one row the batch kernel would
        // run N/4 threads against a K-deep serial loop. GEMV has no
        // activation epilogue, so act > 0 keeps even m = 1 off it.
        const [hasBias, hasAdd, act, , hasBaseRow] = node.pending!.attrs! as number[];
        // `smallm` IS part of the key: matmulSmallMEligible shapes get the
        // subgroup split-K pipeline — one 32-lane subgroup per 4×4 output
        // block, full bias/act/addend epilogue.
        // `tiled` IS part of the key too: m >= MATMUL_TILED_MIN_M nodes get
        // the shared-memory tiled kernel (weight bytes read once per
        // workgroup, not once per row block) — below it too few workgroups
        // launch and the plain kernel wins on latency.
        const mRows = inDim(0, 0);
        const nCols = node.shape.dims![1]!;
        const f16 = node.shape.dtype === 'f16';
        cfg = {
          k: inDim(0, 1),
          n: nCols,
          hasBias: hasBias!,
          hasAdd: hasAdd!,
          act: act ?? 0,
          // Part of the key: switching accumulation compiles a new pipeline.
          accum: f16 ? getMatmulAccum() : 0,
          // gemv and subgroup small-m both take f16 now; the shared-memory
          // tiled kernel is still f32-only (see the `tiled` line below), so
          // f16 shapes past MATMUL_TILED_MIN_M fall back to the plain
          // register-blocked kernel. Correct, not yet fast — converting
          // tiled is the next slice of the f16 rollout.
          // A row VIEW into a fused multi-expert weight. Comptime, so plain
          // matmuls keep their exact shader; only the view reads the uniform.
          // The three specialised routes have no baseRow, so a view always
          // takes the plain kernel — mirrored on the dispatch side.
          hasBaseRow: hasBaseRow ?? 0,
          gemv: (hasBaseRow ?? 0) === 1 || (act ?? 0) > 0 ? 0 : singleRow(),
          smallm:
            (hasBaseRow ?? 0) === 0 && matmulSmallMEligible(mRows, nCols, subgroupsOk) ? 1 : 0,
          tiled: (hasBaseRow ?? 0) === 0 && !f16 && mRows >= MATMUL_TILED_MIN_M ? 1 : 0,
        };
      } else if (op === 'matmulQuantW') {
        const [, , bits, groupSize] = node.pending!.attrs! as number[];
        cfg = {
          k: inDim(0, 1),
          n: node.shape.dims![1]!,
          bits: bits!,
          groupSize: groupSize!,
        };
      } else if (op === 'matmulGatherQuantW') {
        const [bits, groupSize] = node.pending!.attrs! as number[];
        cfg = {
          k: inDim(0, 1),
          n: node.shape.dims![1]!,
          bits: bits!,
          groupSize: groupSize!,
        };
      } else if (op === 'matmulGather') {
        cfg = { k: inDim(0, 1), n: node.shape.dims![1]! };
      } else if (op === 'topk' || op === 'astype' || op === 'meanSquare') {
        cfg = { f16: inShape(0).dtype === 'f16' ? 1 : 0 };
      } else if (op === 'attn') {
        // attrs[5] (qPosOffset) deliberately excluded — it changes every
        // incremental-decode step and rides the Dims uniform instead.
        // `decode` IS part of the key: qLen = 1 nodes get the split-K decode
        // pipeline (workgroup per (row, head)) — at one query row the batch
        // kernel would leave qHeads threads scanning all keys serially.
        // `rows` keys the qLen > 1 side: register-resident row kernels
        // (per-config factories in attn.ts), unless their workgroup count
        // would exceed one dispatch dimension (then the thread-per-(row,
        // head) batch kernel serves the node). `split` marks a key range
        // past the shape's chunk size (ATTN_DECODE_CHUNK for qLen = 1,
        // ATTN_ROWS_CHUNK for rows): both shapes run it as a key-chunked
        // partial + merge pair (kvLen is shape-derived, but only the
        // >CHUNK/≤CHUNK side of it keys the pipeline — the exact key count
        // still rides the uniform). `sub` routes to the subgroup partial +
        // merge pair whenever the device supports it — even below the chunk
        // size (chunks = 1): the serial rows kernel is one THREAD per (row,
        // head), which at a few hundred threads leaves most of the GPU idle,
        // while the subgroup kernel puts a 32-lane workgroup on each.
        const [qHeads, kvHeads, headDim, windowLeft, windowRight, _qPosOffset, hasSinks, hasSegs] =
          node.pending!.attrs! as number[];
        // attrs[9] = 1 (sdpaPacked): one tensor input carries the q|k|v
        // column blocks — kvLen is that tensor's own row count.
        const qkvPacked = (node.pending!.attrs! as number[])[9] ?? 0;
        const qLen = inDim(0, 0);
        const kvLen = qkvPacked === 1 ? qLen : inDim(1, 0);
        // With segments no row scans more keys than the longest segment, so
        // maxSegment (attrs[8], 0 = unknown) replaces the pack length in the
        // split decision — must mirror the dispatch-side route exactly.
        const maxSegment = (node.pending!.attrs! as number[])[8] ?? 0;
        const effKvLen = hasSegs === 1 && maxSegment > 0 ? Math.min(maxSegment, kvLen) : kvLen;
        const attnF16 = node.shape.dtype === 'f16';
        cfg = {
          qHeads: qHeads!,
          kvHeads: kvHeads!,
          headDim: headDim!,
          windowLeft: windowLeft!,
          windowRight: windowRight!,
          hasSinks: hasSinks!,
          hasSegs: hasSegs ?? 0,
          qkvPacked,
          decode: qLen === 1 ? 1 : 0,
          // MEASURED (2026-08-28, M-series, min of 7x20 dispatches, qHeads=12
          // hd=32): f16 makes the ROW kernel 2.1x faster (1.00 -> 0.47ms at
          // T=197) but does nothing for the key-split pair (0.500 -> 0.505) —
          // the pair's cost is the f32 partials it writes and re-reads, and
          // those do not shrink. So f16 keeps the row kernel at every band
          // width tested (split/row = 1.07x at 197, 1.30x at 384, 1.45x at
          // 512, 1.67x at 1024), while f32 still wants the split pair below
          // ~512 (0.50x at 197). Making the partials f16 is the untried lever
          // that could flip this.
          //
          // That verdict is about qLen > 1, where the alternative is a real
          // row kernel. At qLen == 1 the alternative is ONE workgroup walking
          // the whole key range, so both dtypes take the split pair — and the
          // dispatch-side route below has no dtype condition either. The two
          // MUST agree: picking the plain pipeline here and the split pair
          // there fails with "Missing bind groups for layouts".
          split:
            qLen === 1
              ? kvLen > ATTN_DECODE_CHUNK
                ? 1
                : 0
              : !attnF16 && effKvLen > ATTN_ROWS_CHUNK
                ? 1
                : 0,
          rows:
            qLen > 1 && Math.ceil((qLen * qHeads!) / WORKGROUP_SIZE) <= MAX_WORKGROUPS_PER_DIM
              ? 1
              : 0,
          // Subgroup split partial: one workgroup per (row, head), so its own
          // grid-x bound is qLen·qHeads workgroups, tighter than the rows one.
          sub:
            !attnF16 && subgroupsOk && qLen > 1 && qLen * qHeads! <= MAX_WORKGROUPS_PER_DIM ? 1 : 0,
        };
      } else if (op === 'argmaxDot') {
        cfg = {
          cols: inDim(0, 1), // weight-determined, like matmul K
          f16: inShape(1).dtype === 'f16' ? 1 : 0,
        };
      } else if (op === 'rope') {
        // attrs = [headDim, srcStart, width]; srcCols is the input's stride.
        const [headDim, srcStart] = node.pending!.attrs! as number[];
        cfg = {
          cols: node.shape.dims![1]!,
          headDim: headDim!,
          srcStart: srcStart!,
          srcCols: inDim(0, 1),
        };
      } else if (op === 'conv1d') {
        const [kernel, stride, padLeft, , hasBias, act] = node.pending!.attrs! as number[];
        cfg = {
          kernel: kernel!,
          stride: stride!,
          cIn: inDim(0, 1),
          cOut: node.shape.dims![1]!,
          padLeft: padLeft!,
          hasBias: hasBias!,
          act: act!,
        };
      } else if (op === 'convTranspose2d') {
        const [k, hasBias] = node.pending!.attrs! as number[];
        cfg = {
          cIn: node.pending!.inputs[0]!.shape.dims![0]!,
          cOut: node.shape.dims![0]!,
          k: k!,
          hasBias: hasBias!,
        };
      } else if (op === 'upsample2dHwc4') {
        cfg = { scale: node.pending!.attrs![0]! };
      } else if (op === 'conv2dHwc4') {
        const [kH, kW, stride, padding, groups, hasBias, hasAct] = node.pending!.attrs! as number[];
        const [xc, xh, xw] = node.pending!.inputs[0]!.shape.dims! as number[];
        const oneByOne =
          kH === 1 && kW === 1 && stride === 1 && padding === 0 && groups === 1
            ? (xh! * xw!) % 4 === 0
            : false;
        cfg = {
          cIn: xc!,
          cOut: node.shape.dims![0]!,
          kH: kH!,
          kW: kW!,
          stride: stride!,
          padding: padding!,
          hasBias: hasBias!,
          hasAct: hasAct ?? 0,
          hasAdd: extras?.addend !== undefined ? 1 : 0,
          kind: oneByOne ? 1 : groups !== 1 ? 2 : 0,
          pxT: oneByOne && (xh! * xw!) % 8 === 0 ? 8 : 4,
        };
      } else if (op === 'maxPool2dHwc4') {
        const [kernelSize, stride, padding] = node.pending!.attrs! as number[];
        cfg = { kernelSize: kernelSize!, stride: stride!, padding: padding! };
      } else if (op === 'toHwc4') {
        cfg = { f16: node.pending!.inputs[0]!.shape.dtype === 'f16' ? 1 : 0 };
      }
      const pipeline = pipelines.get(op, node.shape.dtype, cfg);
      // ---- Handle memo ----
      // A dispatch's uniform buffer + bind group depend only on (pipeline,
      // exact buffer set, shapes/attrs/scalar) — and the decode loop re-issues
      // the SAME dispatches every step against pool-cycled buffers, so cache
      // the finished KernelHandles and skip ~all per-step createBuffer/
      // createBindGroup CPU work. Keyed on everything a uniform value can be
      // derived from. gatherRows is excluded: it uploads a fresh index buffer
      // whose contents are the token ids. Keys with step-dependent values
      // (attn's qPosOffset, growing concats) miss and accrete — entries are
      // small and bounded by steps × ops per session.
      const p = node.pending!;
      let key: string | undefined;
      if (op !== 'gatherRows') {
        const parts: (string | number)[] = [op, idOf(pipeline as object), idOf(out)];
        for (const b of inputs) parts.push(idOf(b));
        for (const input of p.inputs) parts.push(-1, ...(input.shape.dims ?? [input.shape.elems]));
        parts.push(-2, ...(node.shape.dims ?? [node.shape.elems]));
        if (p.attrs) parts.push(-3, ...p.attrs);
        if (p.scalar !== undefined) parts.push(-4, p.scalar);
        if (extras !== undefined) {
          parts.push(
            -5,
            extras.outBase ?? 0,
            extras.outElems ?? 0,
            extras.addend !== undefined ? idOf(extras.addend) : -1,
          );
        }
        key = parts.join(':');
        const cached = handleCache.get(key);
        if (cached !== undefined) {
          handles.push(...cached);
          return;
        }
      }
      const before = handles.length;
      const encode = (): void => {
        if (op === 'reshape') {
          const total = node.shape.elems;
          const [x] = inputs as F32Buffer[];
          handles.push(
            sliceRowsHandle(
              root,
              pipelines.get('reshape', node.shape.dtype, undefined) as ReturnType<
                typeof createSliceRowsPipeline
              >,
              { total, cols: total, start: 0, outBase: extras?.outBase ?? 0 },
              { x: x!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'topk') {
          const xd = node.pending!.inputs[0]!.shape.dims!;
          const [logits] = inputs as F32Buffer[];
          handles.push(
            topkSelectHandle(
              root,
              pipeline as ReturnType<typeof createTopkSelectPipeline>,
              { tokens: xd[0]!, experts: xd[1]! },
              { logits: logits!, out: out as F32Buffer },
              elemFor(node.pending!.inputs[0]!.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'convTranspose2d') {
          const [, h, w] = node.pending!.inputs[0]!.shape.dims! as number[];
          const hasBias = node.pending!.attrs![1]! === 1;
          const [x, wBuf, biasBuf] = inputs;
          // Kernel layout always binds bias; 1-elem dummy when absent (the read
          // is comptime-dead — hasBias is baked to 0 in the pipeline).
          const bias = hasBias ? (biasBuf as F32Buffer) : getDummyBias();
          handles.push(
            convTranspose2dHandle(
              root,
              pipeline as ReturnType<typeof createConvTranspose2dPipeline>,
              cfg as unknown as ConvTranspose2dCfg,
              { h: h!, w: w! },
              { x: x as F32Buffer, w: wBuf as U32Buffer, bias, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'conv2dHwc4') {
          const [, h, w] = node.pending!.inputs[0]!.shape.dims! as number[];
          const hasBias = node.pending!.attrs![5]! === 1;
          const [x, wBuf, biasBuf] = inputs;
          const bias = hasBias
            ? (biasBuf as F16Buffer)
            : (getDummyBias('f16') as unknown as F16Buffer);
          const res =
            (extras?.addend as F16Buffer | undefined) ??
            (getDummyBias('f16') as unknown as F16Buffer);
          // Elided into a concat: derive the holder's channel-block stride
          // and this node's block offset from the element offset/total (both
          // exact — hwc4 concat channels are multiples of 4).
          const pOut = node.shape.dims![1]! * node.shape.dims![2]!;
          const outC4 = extras?.outElems !== undefined ? extras.outElems / (4 * pOut) : undefined;
          const outOffB = extras?.outBase !== undefined ? extras.outBase / (4 * pOut) : undefined;
          handles.push(
            conv2dHwc4Handle(
              root,
              pipeline as ReturnType<typeof createConv2dHwc4Pipeline>,
              cfg as unknown as Conv2dHwc4Cfg,
              { h: h!, w: w!, outC4, outOffB },
              { x: x as F16Buffer, w: wBuf as F16Buffer, bias, res, out: out as F16Buffer },
            ),
          );
          return;
        }
        if (op === 'maxPool2dHwc4' || op === 'upsample2dHwc4') {
          const [c, h, w] = node.pending!.inputs[0]!.shape.dims! as number[];
          const [x] = inputs as F16Buffer[];
          const pOut = node.shape.dims![1]! * node.shape.dims![2]!;
          const outC4 = extras?.outElems !== undefined ? extras.outElems / (4 * pOut) : undefined;
          const outOffB = extras?.outBase !== undefined ? extras.outBase / (4 * pOut) : undefined;
          handles.push(
            moveHwc4Handle(
              root,
              pipeline as MoveHwc4Pipeline,
              op === 'maxPool2dHwc4' ? 'maxPool2d_hwc4' : 'upsample2d_hwc4',
              { c: c!, h: h!, w: w!, outElems: node.shape.elems, outC4, outOffB },
              { x: x!, out: out as F16Buffer },
            ),
          );
          return;
        }
        if (op === 'concatChannelsHwc4') {
          // Two strided block copies into the output — [a | b] along the
          // channel-block axis of every pixel. evalCore elides a concat
          // that feeds another concat via ex.copyInto, never through this
          // dispatch path, so this node's own output is always its full
          // buffer at offset 0 — no outer-holder offset to apply here.
          const [a, b] = inputs as F16Buffer[];
          const [ca, h, w] = node.pending!.inputs[0]!.shape.dims! as number[];
          const cb = node.pending!.inputs[1]!.shape.dims![0]!;
          const pElems = h! * w!;
          const dstC4 = Math.ceil(node.shape.dims![0]! / 4);
          const pl = pipeline as ReturnType<typeof createCopyChHwc4Pipeline>;
          handles.push(
            copyChHwc4Handle(
              root,
              pl,
              { pElems, srcC4: ca! / 4, dstC4, srcOffB: 0, dstOffB: 0, nB: ca! / 4 },
              { x: a!, out: out as F16Buffer },
            ),
            copyChHwc4Handle(
              root,
              pl,
              { pElems, srcC4: cb / 4, dstC4, srcOffB: 0, dstOffB: ca! / 4, nB: cb / 4 },
              { x: b!, out: out as F16Buffer },
            ),
          );
          return;
        }
        if (op === 'sliceChannelsHwc4') {
          const [c, h, w] = node.pending!.inputs[0]!.shape.dims! as number[];
          const [start, end] = node.pending!.attrs! as number[];
          const nB = (end! - start!) / 4;
          const pElems = h! * w!;
          const dstC4 = extras?.outElems !== undefined ? extras.outElems / (4 * pElems) : nB;
          const dstOffB = extras?.outBase !== undefined ? extras.outBase / (4 * pElems) : 0;
          const [x] = inputs as F16Buffer[];
          handles.push(
            copyChHwc4Handle(
              root,
              pipeline as ReturnType<typeof createCopyChHwc4Pipeline>,
              {
                pElems,
                srcC4: Math.ceil(c! / 4),
                dstC4,
                srcOffB: start! / 4,
                dstOffB,
                nB,
              },
              { x: x!, out: out as F16Buffer },
            ),
          );
          return;
        }
        if (op === 'toHwc4' || op === 'toChw') {
          const [c, h, w] = node.pending!.inputs[0]!.shape.dims! as number[];
          const [x] = inputs;
          if (op === 'toHwc4') {
            handles.push(
              toHwc4Handle(
                root,
                pipeline as ReturnType<typeof createToHwc4Pipeline>,
                inShape(0).dtype === 'f16' ? 'f16' : 'f32',
                { c: c!, h: h!, w: w! },
                { x: x as F32Buffer | F16Buffer, out: out as F16Buffer },
              ),
            );
          } else {
            handles.push(
              toChwHandle(
                root,
                pipeline as ReturnType<typeof createToChwPipeline>,
                node.shape.dtype === 'f16' ? 'f16' : 'f32',
                { c: c!, h: h!, w: w! },
                { x: x as F16Buffer, out: out as F32Buffer | F16Buffer },
              ),
            );
          }
          return;
        }
        if (op === 'sliceChannels') {
          const xd = node.pending!.inputs[0]!.shape.dims!;
          const hw = xd[1]! * xd[2]!;
          const startCh = node.pending!.attrs![0]!;
          const [x] = inputs as F32Buffer[];
          handles.push(
            sliceRowsHandle(
              root,
              pipeline as ReturnType<typeof createSliceRowsPipeline>,
              { total: node.shape.elems, cols: hw, start: startCh, outBase: extras?.outBase ?? 0 },
              { x: x!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'concatChannels') {
          const aTotal = node.pending!.inputs[0]!.shape.elems;
          const [a, b] = inputs as F32Buffer[];
          handles.push(
            concatRowsHandle(
              root,
              pipeline as ReturnType<typeof createConcatRowsPipeline>,
              { total: node.shape.elems, aTotal },
              { a: a!, b: b!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'matmul') {
          const ad = inShape(0).dims!;
          const m = ad[0]!;
          const n = node.shape.dims![1]!;
          // Inputs beyond (a, b) follow attrs order: bias first, then addend.
          const [hasBias, hasAdd, act, baseRow, hasBaseRow] = node.pending!.attrs! as number[];
          const [a, b] = inputs as F32Buffer[];
          const bias = hasBias === 1 ? (inputs[2] as F32Buffer) : undefined;
          const addend = hasAdd === 1 ? (inputs[hasBias === 1 ? 3 : 2] as F32Buffer) : undefined;
          const buffers = { a: a!, b: b!, bias, addend, out: out as F32Buffer };
          // Mirrors the pipeline key EXACTLY — the two must agree or a
          // pipeline gets bound with another route's layout. matmulSmallMEligible
          // shapes go to the subgroup split-K kernel and activation keeps m = 1
          // off the GEMV route (no activation epilogue there) — both take f16
          // now. m >= MATMUL_TILED_MIN_M routes to the shared-memory tiled
          // kernel, which is still f32-only, so f16 falls through to the plain
          // kernel past that threshold.
          const f16 = node.shape.dtype === 'f16';
          const view = (hasBaseRow ?? 0) === 1;
          if (!view && matmulSmallMEligible(m, n, subgroupsOk)) {
            handles.push(
              matmulSmallMHandle(
                root,
                pipeline as ReturnType<typeof createMatmulSmallMPipeline>,
                m,
                n,
                buffers,
                elemFor(node.shape.dtype),
              ),
            );
          } else if (!view && m === 1 && (act ?? 0) === 0) {
            handles.push(
              matmulGemvHandle(
                root,
                pipeline as ReturnType<typeof createMatmulGemvPipeline>,
                n,
                buffers,
                elemFor(node.shape.dtype),
              ),
            );
          } else if (!view && !f16 && m >= MATMUL_TILED_MIN_M) {
            handles.push(
              matmulTiledHandle(
                root,
                pipeline as ReturnType<typeof createMatmulTiledPipeline>,
                m,
                n,
                buffers,
              ),
            );
          } else {
            handles.push(
              matmulHandle(
                root,
                pipeline as ReturnType<typeof createMatmulPipeline>,
                m,
                n,
                buffers,
                elemFor(node.shape.dtype),
                baseRow ?? 0,
              ),
            );
          }
          return;
        }
        if (op === 'matmulQuantW') {
          const ad = inShape(0).dims!;
          const m = ad[0]!;
          const k = ad[1]!;
          const n = node.shape.dims![1]!;
          const [baseRow, scaleBase, bits, groupSize] = node.pending!.attrs! as number[];
          const [a, w, scales] = inputs;
          handles.push(
            matmulQuantWHandle(
              root,
              pipeline as ReturnType<typeof createMatmulQuantWPipeline>,
              { m, n, baseRow: baseRow!, scaleBase: scaleBase! },
              {
                a: a as F32Buffer,
                w: w as U32Buffer,
                scales: scales as F32Buffer,
                out: out as F32Buffer,
              },
            ),
          );
          return;
        }
        if (op === 'matmulGatherQuantW') {
          const ad = inShape(0).dims!;
          const m = ad[0]!;
          const k = ad[1]!;
          const n = node.shape.dims![1]!;
          const [bits, groupSize] = node.pending!.attrs! as number[];
          const [a, w, scales, bias, expertIdx] = inputs;
          handles.push(
            matmulGatherQuantWHandle(
              root,
              pipeline as ReturnType<typeof createMatmulGatherQuantWPipeline>,
              { m, n },
              {
                a: a as F32Buffer,
                w: w as U32Buffer,
                scales: scales as F32Buffer,
                bias: bias as F32Buffer,
                expertIdx: expertIdx as F32Buffer,
                out: out as F32Buffer,
              },
            ),
          );
          return;
        }
        if (op === 'matmulGather') {
          const ad = inShape(0).dims!;
          const m = ad[0]!;
          const n = node.shape.dims![1]!;
          const [a, w, bias, expertIdx] = inputs;
          handles.push(
            matmulGatherHandle(
              root,
              pipeline as ReturnType<typeof createMatmulGatherPipeline>,
              { m, n },
              {
                a: a as F32Buffer,
                w: w as F32Buffer,
                bias: bias as F32Buffer,
                expertIdx: expertIdx as F32Buffer,
                out: out as F32Buffer,
              },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'rope') {
          const [rows, cols] = node.shape.dims! as [number, number];
          const [headDim] = node.pending!.attrs! as number[];
          const [x, cos, sin] = inputs as F32Buffer[];
          handles.push(
            ropeHandle(
              root,
              pipeline as ReturnType<typeof createRopePipeline>,
              { rows, cols },
              { x: x!, cos: cos!, sin: sin!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'attn') {
          const attrs = node.pending!.attrs! as number[];
          // attrs[9] = 1 (sdpaPacked): one tensor input carries the q|k|v
          // column blocks — all three bindings point at it and kvLen is its
          // own row count. Optional inputs then start at index 1, not 3.
          const qkvPacked = attrs[9] === 1;
          const qLen = inDim(0, 0);
          const kvLen = qkvPacked ? qLen : inDim(1, 0);
          const [q, k, v] = qkvPacked ? [inputs[0], inputs[0], inputs[0]] : inputs;
          // attrs[6] (hasSinks) decides whether the next input is the sinks
          // buffer; attrs[7] (hasSegments) marks the segment-range buffer
          // right after.
          const optBase = qkvPacked ? 1 : 3;
          const sinks = attrs[6] === 1 ? (inputs[optBase] as F32Buffer) : undefined;
          const segs = attrs[7] === 1 ? (inputs[optBase + attrs[6]!] as F32Buffer) : undefined;
          const args = { qLen, kvLen, qPosOffset: attrs[5]!, qHeads: attrs[0]! };
          const bufs = {
            q: q as F32Buffer,
            k: k as F32Buffer,
            v: v as F32Buffer,
            out: out as F32Buffer,
            sinks,
            segs,
          };
          if (qLen === 1 && kvLen > ATTN_DECODE_CHUNK) {
            // Key-chunked partial + merge pair. The scratch is executor-
            // lifetime and deliberately NOT from the pool (argmaxScratch's
            // reasoning); in-pass ordering completes each partial → merge
            // pair before the next pair overwrites it.
            attnSplitScratch ??= root
              .createBuffer(d.arrayOf(d.f32, ATTN_SPLIT_SCRATCH_ELEMS))
              .$usage('storage');
            const chunks = Math.min(ATTN_DECODE_MAX_CHUNKS, Math.ceil(kvLen / ATTN_DECODE_CHUNK));
            const attnCfg = {
              qHeads: attrs[0]!,
              kvHeads: attrs[1]!,
              headDim: attrs[2]!,
              windowLeft: attrs[3]!,
              windowRight: attrs[4]!,
              hasSinks: attrs[6]!,
            };
            handles.push(
              ...attnDecodeSplitHandles(
                root,
                pipeline as ReturnType<typeof createAttnDecodeSplitPipeline>,
                pipelines.get('attnDecodeMerge', node.shape.dtype, attnCfg) as ReturnType<
                  typeof createAttnDecodeMergePipeline
                >,
                { kvLen, qPosOffset: attrs[5]!, qHeads: attrs[0]!, chunks },
                { ...bufs, partials: attnSplitScratch, dummyF32: getDummyBias('f32') },
                elemFor(node.shape.dtype),
              ),
            );
            return;
          }
          if (qLen === 1) {
            handles.push(
              attnDecodeHandle(
                root,
                pipeline as ReturnType<typeof createAttnDecodePipeline>,
                args,
                { ...bufs, dummyF32: getDummyBias('f32') },
                elemFor(node.shape.dtype),
              ),
            );
            return;
          }
          if (Math.ceil((qLen * attrs[0]!) / WORKGROUP_SIZE) > MAX_WORKGROUPS_PER_DIM) {
            handles.push(
              attnHandle(
                root,
                pipeline as ReturnType<typeof createAttnPipeline>,
                args,
                { ...bufs, dummyF32: getDummyBias('f32') },
                elemFor(node.shape.dtype),
              ),
            );
            return;
          }
          // Split kernels chunk each row's own visible band, so with segments
          // the longest segment (attrs[8], 0 = unknown), not the pack length,
          // sets the chunk count — mirrors the pipeline key exactly. The
          // subgroup pair also serves bands BELOW the chunk size (chunks = 1):
          // one 32-lane workgroup per (row, head) instead of one thread.
          const effKvLen = attrs[7] === 1 && attrs[8]! > 0 ? Math.min(attrs[8]!, kvLen) : kvLen;
          // Mirrors the pipeline key EXACTLY (see the attn cfg above).
          const attnF16 = node.shape.dtype === 'f16';
          const subgroup = !attnF16 && subgroupsOk && qLen * attrs[0]! <= MAX_WORKGROUPS_PER_DIM;
          if (subgroup || (!attnF16 && effKvLen > ATTN_ROWS_CHUNK)) {
            // Key-split row pair. The scratch grows to the largest
            // qLen · qHeads · headDim seen; in-pass ordering completes each
            // partial → merge pair before the next pair overwrites it.
            const elems = qLen * attrs[0]! * ATTN_ROWS_MAX_CHUNKS * (2 + attrs[2]!);
            if (attnRowsScratch === undefined || attnRowsScratchElems < elems) {
              attnRowsScratch = root.createBuffer(d.arrayOf(d.f32, elems)).$usage('storage');
              attnRowsScratchElems = elems;
            }
            const chunks = Math.max(
              1,
              Math.min(ATTN_ROWS_MAX_CHUNKS, Math.ceil(effKvLen / ATTN_ROWS_CHUNK)),
            );
            const attnCfg = {
              qHeads: attrs[0]!,
              kvHeads: attrs[1]!,
              headDim: attrs[2]!,
              windowLeft: attrs[3]!,
              windowRight: attrs[4]!,
              hasSinks: attrs[6]!,
              qkvPacked: attrs[9] ?? 0,
            };
            handles.push(
              ...attnRowsSplitHandles(
                root,
                pipeline as ReturnType<typeof createAttnRowsSplitPipeline>,
                pipelines.get('attnRowsMerge', node.shape.dtype, attnCfg) as ReturnType<
                  typeof createAttnRowsMergePipeline
                >,
                { ...args, chunks, subgroup },
                { ...bufs, partials: attnRowsScratch, dummyF32: getDummyBias('f32') },
                elemFor(node.shape.dtype),
              ),
            );
            return;
          }
          handles.push(
            attnRowsHandle(
              root,
              pipeline as ReturnType<typeof createAttnRowsPipeline>,
              args,
              { ...bufs, dummyF32: getDummyBias('f32') },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'conv1d') {
          const tIn = inDim(0, 0);
          const [tOut, cOut] = node.shape.dims! as [number, number];
          const hasBias = (node.pending!.attrs! as number[])[4]!;
          const [x, w] = inputs as F32Buffer[];
          const bias = hasBias === 1 ? (inputs[2] as F32Buffer) : undefined;
          handles.push(
            conv1dHandle(
              root,
              pipeline as ReturnType<typeof createConv1dPipeline>,
              { tIn, tOut, cOut },
              { x: x!, w: w!, bias, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'softmax') {
          const rows = node.shape.dims![0]!;
          const cols = node.shape.dims![1]!;
          const [x] = inputs as F32Buffer[];
          handles.push(
            softmaxHandle(
              root,
              pipeline as ReturnType<typeof createSoftmaxPipeline>,
              rows,
              cols,
              { x: x!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'argmaxDot') {
          const wShape = inShape(0);
          const rows = wShape.dims![0]!;
          const [w, x] = inputs;
          // Two dispatches, one node: partial pass → dedicated scratch
          // [SPLIT, 2] → 1-thread reduce into the node's [1,1] output.
          // Consecutive argmaxDot nodes may share the scratch: in-pass
          // ordering completes each partial → reduce pair before the next
          // partial overwrites it.
          argmaxScratch ??= root.createBuffer(d.arrayOf(d.f32, ARGMAX_SPLIT * 2)).$usage('storage');
          const partials = argmaxScratch;
          handles.push(
            argmaxDotPartialHandle(
              root,
              pipeline as ReturnType<typeof createArgmaxDotPipeline>,
              rows,
              { w: w as F32Buffer, x: x as F32Buffer, partials },
              elemFor(inShape(1).dtype),
            ),
            argmaxDotReduceHandle(
              root,
              pipelines.get('argmaxDotReduce', 'f32') as ReturnType<
                typeof createArgmaxDotReducePipeline
              >,
              { partials, out: out as F32Buffer },
            ),
          );
          return;
        }
        if (op === 'swigluChunk') {
          const [x] = inputs as F32Buffer[];
          handles.push(
            swigluChunkHandle(
              root,
              pipeline as ReturnType<typeof createSwigluChunkPipeline>,
              { total: node.shape.elems, half: node.shape.dims![1]! },
              { x: x!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'layerNorm') {
          const [rows, cols] = node.shape.dims! as [number, number];
          const eps = node.pending!.scalar!;
          const [x, weight, bias] = inputs as F32Buffer[];
          handles.push(
            layerNormHandle(
              root,
              pipeline as ReturnType<typeof createLayerNormPipeline>,
              { rows, cols, eps, hasBias: bias !== undefined ? 1 : 0 },
              {
                x: x!,
                weight: weight!,
                bias: bias ?? getDummyBias(node.shape.dtype),
                out: out as F32Buffer,
              },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'mean' || op === 'meanSquare') {
          const rows = inDim(0, 0);
          const cols = inDim(0, 1);
          const [x] = inputs as F32Buffer[];
          handles.push(
            meanHandle(
              root,
              pipeline as ReturnType<typeof createMeanPipeline>,
              rows,
              cols,
              { x: x!, out: out as F32Buffer },
              elemFor(inShape(0).dtype),
              op === 'meanSquare',
            ),
          );
          return;
        }
        if (UNARY_OPS.has(op)) {
          const [x] = inputs as F32Buffer[];
          const FLT_MAX = 3.4028235e38; // f32 max — WGSL uniforms can't hold Infinity
          const clamp = (v: number) => (v === Infinity ? FLT_MAX : v === -Infinity ? -FLT_MAX : v);
          const a =
            op === 'clampScalar' ? clamp(node.pending!.attrs![0]!) : (node.pending!.scalar ?? 0);
          const b = op === 'clampScalar' ? clamp(node.pending!.attrs![1]!) : 0;
          handles.push(
            unaryHandle(
              root,
              pipeline as ReturnType<typeof createRsqrtPipeline>,
              op,
              node.shape.elems,
              a,
              b,
              { x: x!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'astype') {
          const [x] = inputs as F32Buffer[];
          handles.push(
            castHandle(
              root,
              pipeline as ReturnType<typeof createCastPipeline>,
              node.shape.elems,
              { x: x!, out: out as F32Buffer },
              elemFor(inShape(0).dtype),
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'transpose') {
          const xd = inShape(0).dims!;
          const [x] = inputs as F32Buffer[];
          handles.push(
            transposeHandle(
              root,
              pipeline as ReturnType<typeof createTransposePipeline>,
              xd[0]!,
              xd[1]!,
              { x: x!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'sliceCols') {
          const srcCols = inDim(0, 1);
          const start = node.pending!.attrs![0]!;
          const outCols = node.shape.dims![1]!;
          const [x] = inputs as F32Buffer[];
          handles.push(
            sliceColsHandle(
              root,
              pipeline as ReturnType<typeof createSliceColsPipeline>,
              { total: node.shape.elems, srcCols, start, outCols },
              { x: x!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'concatCols') {
          const aCols = inDim(0, 1);
          const bCols = inDim(1, 1);
          const [a, b] = inputs as F32Buffer[];
          handles.push(
            concatColsHandle(
              root,
              pipeline as ReturnType<typeof createConcatColsPipeline>,
              { total: node.shape.elems, aCols, bCols },
              { a: a!, b: b!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'sliceRows') {
          const cols = node.shape.dims![1]!;
          const start = node.pending!.attrs![0]!;
          const [x] = inputs as F32Buffer[];
          handles.push(
            sliceRowsHandle(
              root,
              pipeline as ReturnType<typeof createSliceRowsPipeline>,
              { total: node.shape.elems, cols, start },
              { x: x!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'concatRows') {
          const aTotal = inShape(0).elems;
          const [a, b] = inputs as F32Buffer[];
          handles.push(
            concatRowsHandle(
              root,
              pipeline as ReturnType<typeof createConcatRowsPipeline>,
              { total: node.shape.elems, aTotal },
              { a: a!, b: b!, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'gatherRowsFrom') {
          const cols = node.shape.dims![1]!;
          const [x, idx] = inputs;
          handles.push(
            gatherRowsFromHandle(
              root,
              pipeline as ReturnType<typeof createGatherRowsFromPipeline>,
              { total: node.shape.elems, cols },
              { x: x as F32Buffer, idx: idx as F32Buffer, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'writeRows') {
          // In-place: `out` IS inputs[0]'s buffer (the eval driver aliases it);
          // the kernel touches only the written rows.
          const cols = inDim(1, 1);
          const startRow = node.pending!.attrs![0]!;
          handles.push(
            writeRowsHandle(
              root,
              pipeline as ReturnType<typeof createWriteRowsPipeline>,
              { total: inShape(1).elems, offset: startRow * cols },
              { src: inputs[1] as F32Buffer, dst: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'gatherRows') {
          const cols = node.shape.dims![1]!;
          // Fresh idx buffer per eval — same accepted cost as the per-dispatch uniforms.
          const idx = uploadU32(root, Uint32Array.from(node.pending!.attrs!));
          const [x] = inputs;
          handles.push(
            gatherRowsHandle(
              root,
              pipeline as ReturnType<typeof createGatherRowsPipeline>,
              { total: node.shape.elems, cols },
              idx,
              { x: x as F32Buffer, out: out as F32Buffer },
              elemFor(node.shape.dtype),
            ),
          );
          return;
        }
        if (op === 'topk') {
          const xd = inShape(0).dims!;
          const [logits] = inputs as F32Buffer[];
          handles.push(
            topkSelectHandle(
              root,
              pipeline as ReturnType<typeof createTopkSelectPipeline>,
              { tokens: xd[0]!, experts: xd[1]! },
              { logits: logits!, out: out as F32Buffer },
              elemFor(node.pending!.inputs[0]!.shape.dtype),
            ),
          );
          return;
        }
        const [af, bf] = inputs as F32Buffer[];
        const cols = node.shape.dims ? node.shape.dims[1]! : node.shape.elems;
        const mode = node.pending!.attrs![0]!; // decided by broadcastPlan (ops.ts)
        handles.push(
          elementwiseF32Handle(
            root,
            pipeline as ReturnType<typeof createAddF32Pipeline>,
            op,
            node.shape.elems,
            cols,
            mode,
            {
              a: af!,
              b: bf!,
              out: out as F32Buffer,
            },
            elemFor(node.shape.dtype),
          ),
        );
      };
      encode();
      if (key !== undefined) handleCache.set(key, handles.slice(before));
    },
    /** Run everything dispatch() queued: encode all handles into ONE compute
     *  pass, submit once, clear the queue. DAG walk order = encode order, so
     *  in-pass ordering guarantees dependencies without explicit syncs.
     *  (Timestamped perf variants keep that ordering: perOp splits into
     *  consecutive passes on the same encoder — pass order on one queue is
     *  still execution order.) */
    submit: () => {
      if (handles.length === 0) return; // nothing queued (e.g. toArray on an already-materialized Value)
      const device = root.device;
      const n = handles.length;
      const timed = perf !== undefined && canTime;
      const perOp = timed && perf.perOp === true;
      // 4096 is the WebGPU per-querySet limit → at most 2048 timed dispatches.
      const pairs = timed ? (perOp ? Math.min(n, 2048) : 1) : 0;
      const query = timed
        ? {
            set: device.createQuerySet({ type: 'timestamp', count: pairs * 2 }),
            resolve: device.createBuffer({
              size: pairs * 16,
              usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC,
            }),
            staging: device.createBuffer({
              size: pairs * 16,
              usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
            }),
            names: [] as string[],
          }
        : undefined;
      submitEncoderWithRb((encoder) => {
        if (perOp && query) {
          for (let i = 0; i < n; i++) {
            const h = handles[i]!;
            const record = i < pairs;
            const pass = encoder.beginComputePass(
              record
                ? {
                    timestampWrites: {
                      querySet: query.set,
                      beginningOfPassWriteIndex: i * 2,
                      endOfPassWriteIndex: i * 2 + 1,
                    },
                  }
                : {},
            );
            const [x, y] = wgOf(h);
            h.pipeline.with(pass).with(h.bindGroup).dispatchWorkgroups(x, y);
            pass.end();
            if (record) query.names.push(h.name);
          }
        } else {
          const pass = encoder.beginComputePass(
            query
              ? {
                  timestampWrites: {
                    querySet: query.set,
                    beginningOfPassWriteIndex: 0,
                    endOfPassWriteIndex: 1,
                  },
                }
              : {},
          );
          for (const h of handles) {
            const [x, y] = wgOf(h);
            h.pipeline.with(pass).with(h.bindGroup).dispatchWorkgroups(x, y);
          }
          pass.end();
        }
        if (query) {
          encoder.resolveQuerySet(query.set, 0, pairs * 2, query.resolve, 0);
          encoder.copyBufferToBuffer(query.resolve, 0, query.staging, 0, pairs * 16);
        }
      });
      if (capturing) capturing.push(...handles);
      handles.length = 0;
      if (perf === undefined) return;
      if (query === undefined) {
        perf.onSubmit(n);
        return;
      }
      const timing = query.staging.mapAsync(GPUMapMode.READ).then((): GpuSubmitTiming => {
        const ts = new BigUint64Array(query.staging.getMappedRange().slice(0));
        query.staging.unmap();
        query.staging.destroy();
        query.resolve.destroy();
        query.set.destroy();
        // Timestamps can be zeroed/reordered by the implementation; clamp.
        const span = (i: number) => Math.max(0, Number(ts[i * 2 + 1]! - ts[i * 2]!));
        if (query.names.length === 0) return { gpuNs: span(0) };
        let gpuNs = 0;
        const opNs = new Map<string, GpuOpTime>();
        query.names.forEach((name, i) => {
          const ns = span(i);
          gpuNs += ns;
          const entry = opNs.get(name);
          if (entry) {
            entry.ns += ns;
            entry.count += 1;
          } else {
            opNs.set(name, { ns, count: 1 });
          }
        });
        return { gpuNs, opNs };
      });
      perf.onSubmit(n, timing);
    },
    /** Copy one concat input the driver could not elide. CHW: a flat element
     *  copy via the sliceRows kernel. HWC4: a strided channel-block copy —
     *  the destination interleaves per pixel, so flat copying would scramble
     *  channels. */
    copyInto: (src, dst, srcShape, dstShape, dstBase) => {
      if (srcShape.layout === 'hwc4') {
        const [, h, w] = srcShape.dims! as number[];
        const pElems = h! * w!;
        handles.push(
          copyChHwc4Handle(
            root,
            pipelines.get('concatChannelsHwc4', 'f16', undefined) as ReturnType<
              typeof createCopyChHwc4Pipeline
            >,
            {
              pElems,
              srcC4: srcShape.elems / (4 * pElems),
              dstC4: dstShape.elems / (4 * pElems),
              srcOffB: 0,
              dstOffB: dstBase / (4 * pElems),
              nB: srcShape.elems / (4 * pElems),
            },
            { x: src as F16Buffer, out: dst as F16Buffer },
          ),
        );
        return;
      }
      handles.push(
        sliceRowsHandle(
          root,
          pipelines.get('reshape', srcShape.dtype, undefined) as ReturnType<
            typeof createSliceRowsPipeline
          >,
          { total: srcShape.elems, cols: srcShape.elems, start: 0, outBase: dstBase },
          { x: src as F32Buffer, out: dst as F32Buffer },
          elemFor(srcShape.dtype),
        ),
      );
    },
    /** Recycle finished Values' buffers into the pool (see Releaser docs). */
    releaseValues: (values) => {
      if (frozen) {
        throw new Error(
          'releaseValues: captured targets keep their buffers — a replay-only executor never releases',
        );
      }
      for (const v of values) {
        if (v.state !== 'materialized') continue;
        pool.release(v.buffer, v.shape);
        v.markReleased();
      }
    },
    /** Copy a materialized buffer back to the CPU as f32s, whatever the
     *  Value's dtype (a vec4f element is 4 floats; an f16 element widens).
     *  Only toArray()/run() call this, after submit(). */
    readback: (buffer, shape) => {
      if (shape.layout !== undefined) {
        throw new Error(
          `readback: Value is stored '${shape.layout}' — convert with toChw() before reading`,
        );
      }
      return shape.dtype === 'f16'
        ? readbackF16(root, root.unwrap(buffer as F16Buffer), shape.elems)
        : readbackF32(root, root.unwrap(buffer as F32Buffer), shape.elems);
    },
    /** Batched: one staging buffer / submit / map for all requested values. */
    readbackMany: (items) =>
      readbackManySpans(
        root,
        items.map(({ buffer, shape }) => ({
          buffer: root.unwrap(buffer as F32Buffer),
          ...readbackSpan(shape),
        })),
      ),
    /** See FusedReadback: register the values whose buffers the next submit
     *  (or replay) copies out within its own command buffer. */
    readbackManyOnSubmit: (values) => {
      if (pendingRb !== undefined) {
        throw new Error('readbackManyOnSubmit: a readback is already queued for the next submit');
      }
      return new Promise<Float32Array[]>((resolve, reject) => {
        pendingRb = { values, resolve, reject };
      });
    },
    readbackOnSubmit: (value) => executor.readbackManyOnSubmit([value]).then((outs) => outs[0]!),
    toArrayFused: (value) => {
      if (value.state === 'materialized') {
        // No submit is coming — fall back to the standalone copy+map.
        return executor.readback(value.buffer, value.shape);
      }
      const result = executor.readbackOnSubmit(value);
      // Attach a no-op handler first: if evalValues throws before submitting
      // (validation error mid-walk), the cleared pending promise rejects and
      // would otherwise surface as an unhandled rejection alongside the throw.
      result.catch(() => undefined);
      try {
        evalValuesWith([value], executor);
      } catch (err) {
        // A throw before the submit leaves the request queued — reject and
        // clear it so this executor's next readback starts clean.
        if (pendingRb?.values[0] === value) {
          pendingRb.reject(err);
          pendingRb = undefined;
        }
        throw err;
      }
      return result;
    },
  };
  return executor;
}
