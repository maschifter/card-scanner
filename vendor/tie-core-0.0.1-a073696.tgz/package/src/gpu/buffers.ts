import { d } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import type { F16Buffer, F32Buffer, U32Buffer } from '../kernels/common.ts';
import {
  elemBytes,
  type GpuBufferRef,
  materialized,
  matrix,
  type Value,
  type ValueMeta,
} from '../graph/value.ts';
import { f16ToF32, f32ArrayToF16Bits } from '../weights/convert.ts';
import { defaultRoot } from './context.ts';

/**
 * Raw upload/readback utilities. Uploads go through `queue.writeBuffer` on
 * the unwrapped GPUBuffer (typegpu's default usage flags include
 * COPY_DST/COPY_SRC). Deliberately NOT `buffer.write()`: typegpu copies
 * writes through a retained full-size host-side staging ArrayBuffer, which
 * for the ~1.2 GiB of weight buffers would double host memory.
 */

/** Refuse a storage buffer no shader could bind.
 *
 *  WebGPU caps a single storage BINDING at `maxStorageBufferBindingSize`
 *  (128 MiB on a lot of hardware), which is well under `maxBufferSize`. A
 *  buffer past the cap is created happily and only fails when a bind group
 *  reaches for it — inside an error scope nobody reads — so the model runs at
 *  full speed and returns garbage. The privacy filter's fused expert weight
 *  is 209.7 MB in f32 and hit exactly this: ~1e7 logits, no error anywhere.
 *  Half precision brings it to 104.9 MB, which is why an unquantized pf must
 *  run halved. Fail at allocation instead, naming the size and the cap. */
function checkBindable(root: TgpuRoot, bytes: number, what: string): void {
  // Test doubles stand in for a device without reporting limits; nothing to
  // check against there.
  const cap = root.device?.limits?.maxStorageBufferBindingSize;
  if (cap !== undefined && bytes > cap) {
    throw new Error(
      `${what}: ${(bytes / 1e6).toFixed(1)} MB exceeds this device's ` +
        `maxStorageBufferBindingSize of ${(cap / 1e6).toFixed(1)} MB — no shader can bind it. ` +
        'Halve the model (nn.Module.half()) or use a quantized weight format.',
    );
  }
}

/** writeBuffer via the typed array's backing buffer (TS rejects
 *  TypedArray<ArrayBufferLike> as GPUAllowSharedBufferSource). */
function rawWrite(
  root: TgpuRoot,
  dst: GPUBuffer,
  data: Uint32Array | Float32Array | Uint16Array,
): void {
  root.device.queue.writeBuffer(
    dst,
    0,
    data.buffer as ArrayBuffer,
    data.byteOffset,
    data.byteLength,
  );
}

/** Overwrite an existing f32 storage buffer in place (per-frame input update —
 *  the demo loop reuses ONE input buffer instead of uploading a fresh 4.9 MB
 *  buffer every frame). */
export function writeF32(root: TgpuRoot, dst: F32Buffer, data: Float32Array): void {
  rawWrite(root, root.unwrap(dst), data);
}

/** First arg of the root-optional upload/tensor overloads: a TgpuRoot is the
 *  only argument shape carrying a GPUDevice. */
const isRoot = (x: unknown): x is TgpuRoot =>
  typeof x === 'object' && x !== null && 'device' in x && 'createBuffer' in x;

/** Create a storage buffer and upload a u32 typed array via queue.writeBuffer.
 *  Root defaults to the initTie() device. */
export function uploadU32(data: Uint32Array): U32Buffer;
export function uploadU32(root: TgpuRoot, data: Uint32Array): U32Buffer;
export function uploadU32(a: TgpuRoot | Uint32Array, b?: Uint32Array): U32Buffer {
  const [root, data] = isRoot(a) ? [a, b!] : [defaultRoot(), a];
  checkBindable(root, data.byteLength, 'uploadU32');
  const buf = root.createBuffer(d.arrayOf(d.u32, data.length)).$usage('storage');
  rawWrite(root, root.unwrap(buf), data);
  return buf;
}

/** Create a storage buffer and upload an f32 typed array via queue.writeBuffer.
 *  Root defaults to the initTie() device. */
export function uploadF32(data: Float32Array): F32Buffer;
export function uploadF32(root: TgpuRoot, data: Float32Array): F32Buffer;
export function uploadF32(a: TgpuRoot | Float32Array, b?: Float32Array): F32Buffer {
  const [root, data] = isRoot(a) ? [a, b!] : [defaultRoot(), a];
  checkBindable(root, data.byteLength, 'uploadF32');
  const buf = root.createBuffer(d.arrayOf(d.f32, data.length)).$usage('storage');
  rawWrite(root, root.unwrap(buf), data);
  return buf;
}

/** Make a materialized f32 tensor (Value) from CPU data — the clean way to get
 *  model input onto the device: `tensor(x, [rows, cols])` on the initTie()
 *  device, or with an explicit root as the first arg. Shape is [rows, cols]
 *  (a row-major f32 matrix) or a full ValueMeta. */
export function tensor(data: Float32Array, shape: readonly [number, number] | ValueMeta): Value;
export function tensor(
  root: TgpuRoot,
  data: Float32Array,
  shape: readonly [number, number] | ValueMeta,
): Value;
export function tensor(
  a: TgpuRoot | Float32Array,
  b: Float32Array | readonly [number, number] | ValueMeta,
  c?: readonly [number, number] | ValueMeta,
): Value {
  const [root, data, shape] = isRoot(a)
    ? [a, b as Float32Array, c!]
    : [defaultRoot(), a, b as readonly [number, number] | ValueMeta];
  const meta = Array.isArray(shape)
    ? matrix(shape[0] as number, shape[1] as number)
    : (shape as ValueMeta);
  // The META decides the buffer, like gpuUpload: a caller feeding f32 numbers
  // to a half-precision model asks for an f16 tensor by passing an f16 meta,
  // and gets one. Building an f32 buffer under an f16 label would be read as
  // garbage by every kernel.
  if (meta.dtype === 'f16') {
    return materialized(meta, uploadF16(root, f32ArrayToF16Bits(data).data));
  }
  if (meta.dtype !== 'f32') {
    throw new Error(`tensor: cannot build a '${meta.dtype}' tensor from f32 data`);
  }
  return materialized(meta, uploadF32(root, data));
}

/** An f16 buffer's element count is rounded up to even so its byte size stays
 *  a multiple of 4 — copyBufferToBuffer (readback) rejects other sizes. */
const evenElems = (elems: number): number => elems + (elems & 1);

/** Overwrite an existing f16 storage buffer in place from f32 numbers — the
 *  replay loop's per-frame input update for a halved model. */
export function writeF16(root: TgpuRoot, dst: F16Buffer, data: Float32Array): void {
  const bits = f32ArrayToF16Bits(data).data;
  const n = evenElems(bits.length);
  let src = bits;
  if (n !== bits.length) {
    src = new Uint16Array(n);
    src.set(bits);
  }
  rawWrite(root, root.unwrap(dst), src);
}

/** Create a storage buffer and upload raw f16 halfwords (IEEE binary16 bits,
 *  the layout WGSL f16 expects) via queue.writeBuffer. An odd-length tensor
 *  (a [33] bias, say) is padded by one halfword: writeBuffer rejects byte
 *  counts that are not a multiple of 4, and the pad element is never read. */
export function uploadF16(root: TgpuRoot, bits: Uint16Array): F16Buffer {
  const n = evenElems(bits.length);
  checkBindable(root, n * 2, 'uploadF16');
  const buf = root.createBuffer(d.arrayOf(d.f16, n)).$usage('storage');
  let src = bits;
  if (n !== bits.length) {
    src = new Uint16Array(n);
    src.set(bits);
  }
  rawWrite(root, root.unwrap(buf), src);
  return buf as F16Buffer;
}

/** Read `count` f16 values back, widened to f32 (the engine's CPU-facing
 *  array type is Float32Array whatever the model's dtype). */
export async function readbackF16(
  root: TgpuRoot,
  src: GPUBuffer,
  count: number,
): Promise<Float32Array> {
  const bytes = evenElems(count) * 2;
  return withStaging(
    root,
    bytes,
    (enc, staging) => enc.copyBufferToBuffer(src, 0, staging, 0, bytes),
    (mapped) => f16ToF32(new Uint16Array(mapped.slice(0, bytes)).subarray(0, count)),
  );
}

/** THE dtype -> storage buffer mapping for op outputs (the BufferPool's
 *  allocator). Weight-only dtypes are rejected: no op produces them, so being
 *  asked for one means an output shape is wrong. */
export function createStorageFor(root: TgpuRoot, shape: ValueMeta): GpuBufferRef {
  const { dtype, elems } = shape;
  if (dtype === 'quantW') {
    throw new Error(`eager: ${dtype} buffers are upload-only — no op produces them`);
  }
  checkBindable(root, elems * elemBytes(dtype), `allocating a ${dtype} [${shape.dims ?? elems}]`);
  if (dtype === 'f16') {
    return root.createBuffer(d.arrayOf(d.f16, evenElems(elems))).$usage('storage') as F16Buffer;
  }
  return root.createBuffer(d.arrayOf(d.f32, elems)).$usage('storage');
}

/** Persistent staging buffer per root, grown to the largest readback seen.
 *  Readbacks run every frame; creating + destroying a multi-MB staging buffer
 *  each time is exactly the allocation churn that tanks iOS WebKit. `busy`
 *  guards overlapping readbacks (rare) — those fall back to a transient
 *  buffer that is destroyed after the map. */
const stagingPerRoot = new WeakMap<TgpuRoot, { buf: GPUBuffer; size: number; busy: boolean }>();

/** A leased MAP_READ staging buffer: encode a copy into `staging` yourself,
 *  submit, then `finish(read)` maps it, hands the mapped bytes to `read`, and
 *  returns the lease to the per-root slot (or destroys a transient one). Lets
 *  the copy ride an existing encoder — the single-submit readback path — while
 *  withStaging() below keeps the standalone encode+submit form. */
export interface StagingLease {
  staging: GPUBuffer;
  finish<T>(read: (mapped: ArrayBuffer) => T): Promise<T>;
}

export function leaseStaging(root: TgpuRoot, byteSize: number): StagingLease {
  const device = root.device;
  let entry = stagingPerRoot.get(root);
  let staging: GPUBuffer;
  let transient = false;
  if (entry === undefined || entry.busy) {
    staging = device.createBuffer({
      size: byteSize,
      usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
    });
    if (entry === undefined) {
      entry = { buf: staging, size: byteSize, busy: true };
      stagingPerRoot.set(root, entry);
    } else {
      transient = true; // a readback is already in flight on the shared buffer
    }
  } else {
    if (entry.size < byteSize) {
      entry.buf.destroy();
      entry.buf = device.createBuffer({
        size: byteSize,
        usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
      });
      entry.size = byteSize;
    }
    entry.busy = true;
    staging = entry.buf;
  }
  const shared = entry;
  return {
    staging,
    async finish<T>(read: (mapped: ArrayBuffer) => T): Promise<T> {
      // Release the lease on every path — a throw from mapAsync or `read`
      // must not leave the persistent slot marked busy (which would push all
      // later readbacks onto transient buffers).
      try {
        await staging.mapAsync(GPUMapMode.READ, 0, byteSize);
        try {
          return read(staging.getMappedRange(0, byteSize));
        } finally {
          staging.unmap();
        }
      } finally {
        if (transient) staging.destroy();
        else shared.busy = false;
      }
    },
  };
}

async function withStaging<T>(
  root: TgpuRoot,
  byteSize: number,
  encode: (enc: GPUCommandEncoder, staging: GPUBuffer) => void,
  read: (mapped: ArrayBuffer) => T,
): Promise<T> {
  const device = root.device;
  const lease = leaseStaging(root, byteSize);
  const enc = device.createCommandEncoder();
  encode(enc, lease.staging);
  device.queue.submit([enc.finish()]);
  return lease.finish(read);
}

/** Read `count` f32 values from a GPUBuffer via the shared staging buffer.
 *  Callers pass `root.unwrap(typedBuffer)`. */
export async function readbackF32(
  root: TgpuRoot,
  src: GPUBuffer,
  count: number,
): Promise<Float32Array> {
  return withStaging(
    root,
    count * 4,
    (enc, staging) => enc.copyBufferToBuffer(src, 0, staging, 0, count * 4),
    (mapped) => new Float32Array(mapped.slice(0, count * 4)),
  );
}

/** One entry of a batched readback: where the bytes are, how many, and how to
 *  widen them to f32 once mapped. */
export interface ReadbackSpan {
  buffer: GPUBuffer;
  bytes: number;
  decode: (mapped: ArrayBuffer, offset: number) => Float32Array;
}

/** Batched readback of MIXED dtypes through ONE staging buffer / submit /
 *  mapAsync — the dtype-aware form of readbackManyF32, which it now backs.
 *  The per-readback cost (encoder + submit + map round-trip) dominates
 *  multi-output readbacks, so this must stay one round-trip however many
 *  values (and whatever their dtypes). */
export async function readbackManySpans(
  root: TgpuRoot,
  spans: readonly ReadbackSpan[],
): Promise<Float32Array[]> {
  const total = spans.reduce((a, s) => a + s.bytes, 0);
  return withStaging(
    root,
    total,
    (enc, staging) => {
      let off = 0;
      for (const s of spans) {
        enc.copyBufferToBuffer(s.buffer, 0, staging, off, s.bytes);
        off += s.bytes;
      }
    },
    (mapped) => {
      const outs: Float32Array[] = [];
      let off = 0;
      for (const s of spans) {
        outs.push(s.decode(mapped, off));
        off += s.bytes;
      }
      return outs;
    },
  );
}

/** Read several f32 buffers through ONE staging buffer / submit / mapAsync.
 *  The fixed per-readback cost (encoder + submit + map round-trip) dominates
 *  multi-output readbacks — yolo26-seg's 4 outputs measured ~4ms as separate
 *  readbackF32 calls vs ~1ms batched. */
export async function readbackManyF32(
  root: TgpuRoot,
  srcs: readonly { buffer: GPUBuffer; count: number }[],
): Promise<Float32Array[]> {
  const total = srcs.reduce((a, s) => a + s.count, 0);
  return withStaging(
    root,
    total * 4,
    (enc, staging) => {
      let off = 0;
      for (const s of srcs) {
        enc.copyBufferToBuffer(s.buffer, 0, staging, off * 4, s.count * 4);
        off += s.count;
      }
    },
    (mapped) => {
      const outs: Float32Array[] = [];
      let off = 0;
      for (const s of srcs) {
        outs.push(new Float32Array(mapped.slice(off * 4, (off + s.count) * 4)));
        off += s.count;
      }
      return outs;
    },
  );
}
