/** Diagnostic instrumentation for the GPU executor. A GpuPerfSink handed to
 *  gpuExecutor() receives one onSubmit per queue.submit with the dispatch
 *  count (synchronously) and, when the device has 'timestamp-query', a
 *  promise resolving to the submitted work's GPU time. `perOp: true` switches
 *  submit() from one pass to one pass PER dispatch with its own timestamp
 *  pair — inflated totals (pass boundaries aren't free) but a faithful
 *  per-kernel ranking. Without a sink the executor's hot path does no perf
 *  work at all. */

export interface GpuOpTime {
  /** Summed GPU ns across this submit's dispatches of the kernel. */
  ns: number;
  count: number;
}

export interface GpuSubmitTiming {
  /** GPU ns from first pass start to last pass end (perOp: summed passes). */
  gpuNs: number;
  /** Per-kernel aggregation — present only in perOp mode. */
  opNs?: Map<string, GpuOpTime>;
}

export interface GpuPerfSink {
  /** One pass per dispatch with per-op timestamps (diagnostic; slower). */
  readonly perOp?: boolean;
  /** Called synchronously at each queue.submit. `timing` is undefined when
   *  the device lacks 'timestamp-query'; otherwise it resolves after the
   *  submitted work completes. Collect the promises and settle them after
   *  the run — never await inside the decode loop. */
  onSubmit(dispatches: number, timing?: Promise<GpuSubmitTiming>): void;
}
