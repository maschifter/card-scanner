/** Caches compiled pipelines keyed by op+dtype+CONFIG. Runtime-dynamic dims
 *  (token counts) travel in UNIFORMS, so the key never includes input shape and
 *  the cache never thrashes — that is the crux of fast eager on WebGPU. The
 *  optional config carries LOAD-TIME constants (weight dims, quant format,
 *  attention geometry) that specialized kernels bake into the shader via
 *  tgpu.accessor; the set of configs is fixed per model, so the pipeline count
 *  stays bounded (one per op-config, compiled on first use). */

export class PipelineCache<P> {
  private cache = new Map<string, P>();

  /** @param build compile a pipeline for (op, dtype, config). Called at most once per key. */
  constructor(
    private readonly build: (op: string, dtype: string, cfg?: Record<string, number>) => P,
  ) {}

  get(op: string, dtype: string, cfg?: Record<string, number>): P {
    const key =
      cfg === undefined
        ? `${op}:${dtype}`
        : `${op}:${dtype}:${Object.entries(cfg)
            .map(([k, v]) => `${k}=${v}`)
            .join(',')}`;
    let p = this.cache.get(key);
    if (p === undefined) {
      p = this.build(op, dtype, cfg);
      this.cache.set(key, p);
    }
    return p;
  }
}
