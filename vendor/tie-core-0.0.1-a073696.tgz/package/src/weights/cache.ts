/** Platform-neutral weight-cache contract: the loaders accept any
 *  implementation (web: OPFS via zoo's createOpfsCache; React Native:
 *  expo-file-system in apps/mobile). Values must be non-empty — zero-byte
 *  entries are treated as misses (crash artifacts of interrupted writes). */
export interface WeightCache {
  get(key: string): Promise<ArrayBuffer | undefined>;
  getOrCompute(key: string, compute: () => Promise<ArrayBufferView>): Promise<ArrayBuffer>;
  clear(): Promise<void>;
}
