/** Safetensors container: header parsing and byte-range access. Format:
 *  [8-byte LE u64 = header length N][N bytes JSON][tensor payload].
 *  JSON maps tensor name -> {dtype, shape, data_offsets:[begin,end]} with
 *  offsets relative to the payload start; `__metadata__` is an optional
 *  string->string map. This module stores ABSOLUTE file offsets. */

import { bf16ToF32, f16ToF32 } from './convert.ts';
import type { WeightCache } from './cache.ts';
import { cachedRangeSource } from './cachedSource.ts';

export type SafeDtype =
  'F64' | 'F32' | 'F16' | 'BF16' | 'U32' | 'I64' | 'I32' | 'I16' | 'I8' | 'U8' | 'BOOL';

export interface SafeTensorInfo {
  dtype: SafeDtype;
  shape: number[];
  begin: number;
  end: number;
}

export interface SafetensorsIndex {
  metadata: Record<string, string>;
  tensors: Map<string, SafeTensorInfo>;
}

/** Bytes [begin, end) of a checkpoint file. Implementations must return a
 *  STANDALONE Uint8Array (byteOffset 0) so callers can view it at any width. */
export interface RangeSource {
  read(begin: number, end: number): Promise<Uint8Array>;
}

export function bufferSource(buf: ArrayBuffer | Uint8Array): RangeSource {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  return {
    read: (begin, end) => {
      if (end > bytes.length) {
        return Promise.reject(
          new Error(`safetensors: read [${begin},${end}) past end ${bytes.length}`),
        );
      }
      // Uint8Array.prototype.slice explicitly: Node's Buffer overrides .slice
      // with a zero-copy VIEW, and callers rely on getting an offset-0 copy.
      return Promise.resolve(Uint8Array.prototype.slice.call(bytes, begin, end));
    },
  };
}

const MAX_HEADER_BYTES = 100 * 1024 * 1024; // matches the reference impl's sanity cap

export async function parseSafetensorsHeader(source: RangeSource): Promise<SafetensorsIndex> {
  const lenBytes = await source.read(0, 8);
  const headerLen = Number(
    new DataView(lenBytes.buffer, lenBytes.byteOffset, lenBytes.byteLength).getBigUint64(0, true),
  );
  if (!Number.isSafeInteger(headerLen) || headerLen <= 0 || headerLen > MAX_HEADER_BYTES) {
    // A missing file often comes back as the dev server's HTML fallback page
    // with status 200; its first bytes ("<!doctype…") decode to a huge u64.
    // Detect text and report the real cause.
    const printable = [...lenBytes].every(
      (b) => b === 0x09 || b === 0x0a || b === 0x0d || (b >= 0x20 && b <= 0x7e),
    );
    if (printable) {
      throw new Error(
        `safetensors: got text starting ${JSON.stringify(new TextDecoder().decode(lenBytes))} ` +
          'instead of a binary header — this is not a safetensors payload. Most likely the ' +
          'file is missing at this URL and the server returned an HTML fallback page.',
      );
    }
    throw new Error(`safetensors: implausible header length ${headerLen}`);
  }
  const headerBytes = await source.read(8, 8 + headerLen);
  let header: Record<string, unknown>;
  try {
    header = JSON.parse(new TextDecoder().decode(headerBytes)) as Record<string, unknown>;
  } catch (err) {
    throw new Error(`safetensors: header is not valid JSON: ${(err as Error).message}`, {
      cause: err,
    });
  }
  // File layout: 8-byte u64 header length, JSON header, then tensor bytes.
  // data_offsets in the header are relative to this payload start.
  const dataStart = 8 + headerLen;
  const tensors = new Map<string, SafeTensorInfo>();
  let metadata: Record<string, string> = {};
  for (const [name, value] of Object.entries(header)) {
    if (name === '__metadata__') {
      metadata = value as Record<string, string>;
      continue;
    }
    const e = value as { dtype: SafeDtype; shape: number[]; data_offsets: [number, number] };
    tensors.set(name, {
      dtype: e.dtype,
      shape: e.shape,
      begin: dataStart + e.data_offsets[0],
      end: dataStart + e.data_offsets[1],
    });
  }
  return { metadata, tensors };
}

/** RangeSource over HTTP. Per-read: `Range: bytes=begin-(end-1)`, 3 attempts
 *  with backoff, exact-size validation (a short 206 body is retried like a
 *  network failure — no silent zeros ever reach a weight buffer). If the
 *  server answers 200 (Range unsupported), the whole file is downloaded once,
 *  memoized, and all reads are served from it. Retry backoff waits 500ms/1s —
 *  tests inject fetchFn and never hit real timers beyond these waits.
 *
 *  Concurrency: the FIRST read runs alone; later reads wait for it to settle
 *  before issuing. Until one response has arrived we can't know whether the
 *  server ignores Range, and two reads racing against such a server would
 *  each download the entire file. Once the first read settles, reads run
 *  fully concurrent. */
export function httpRangeSource(
  url: string,
  opts: { onBytes?: (n: number) => void; fetchFn?: typeof fetch } = {},
): RangeSource {
  const fetchFn = opts.fetchFn ?? fetch;
  let whole: Promise<Uint8Array> | undefined;
  let firstSettled: Promise<void> | undefined;

  const attemptRead = async (begin: number, end: number): Promise<Uint8Array> => {
    if (whole) {
      const file = await whole;
      return file.slice(begin, end);
    }
    const res = await fetchFn(url, { headers: { Range: `bytes=${begin}-${end - 1}` } });
    if (!res.ok) throw new Error(`status ${res.status}`);
    // Dev servers answer a MISSING file with the SPA's index.html and status
    // 200 — refuse it here, before a WeightCache can persist the poison.
    if ((res.headers.get('content-type') ?? '').startsWith('text/html')) {
      throw new Error(
        `got text/html from ${url} — the file is missing and the server returned its HTML fallback page`,
      );
    }
    const body = new Uint8Array(await res.arrayBuffer());
    if (res.status === 200) {
      // Server ignored Range and sent the whole file: keep it, serve slices.
      whole = Promise.resolve(body);
      opts.onBytes?.(body.length);
      return body.slice(begin, end);
    }
    if (body.length !== end - begin) {
      throw new Error(`short body: got ${body.length}, expected ${end - begin}`);
    }
    opts.onBytes?.(body.length);
    return body;
  };

  const readWithRetries = async (begin: number, end: number): Promise<Uint8Array> => {
    let lastErr: Error | undefined;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        return await attemptRead(begin, end);
      } catch (err) {
        lastErr = err as Error;
        if (attempt < 2) await new Promise((r) => setTimeout(r, 500 * (attempt + 1)));
      }
    }
    throw new Error(
      `safetensors range [${begin},${end}) of ${url}: fetch failed after retries (${lastErr?.message})`,
    );
  };

  return {
    async read(begin, end) {
      if (firstSettled) {
        await firstSettled;
        return readWithRetries(begin, end);
      }
      const first = readWithRetries(begin, end);
      firstSettled = first.then(
        () => undefined,
        () => undefined, // gate only orders requests; the error surfaces via `first`
      );
      return first;
    },
  };
}

export const DEFAULT_CHUNK_BYTES = 8 * 1024 * 1024;

/** Wrap a RangeSource so small reads coalesce into aligned `chunkBytes`
 *  windows. Tensors sit adjacent in a safetensors file in state-dict order —
 *  the order the loader consumes them — so one chunk fetch serves many
 *  consecutive tensors and a whole-checkpoint load costs ~ceil(size/chunk)
 *  requests instead of one per tensor.
 *
 *  Chunk fetches are promise-memoized, so concurrent readers of the same
 *  chunk share one request. Only the 2 most recently touched chunks are kept
 *  (sequential access needs the current chunk plus its boundary neighbor), so
 *  peak memory is ~2×chunkBytes regardless of file size. `totalBytes` clamps
 *  the last chunk — an over-the-end range would trip httpRangeSource's
 *  short-body check. */
export function chunkedSource(
  inner: RangeSource,
  totalBytes: number,
  chunkBytes = DEFAULT_CHUNK_BYTES,
): RangeSource {
  const chunks = new Map<number, Promise<Uint8Array>>(); // insertion order = LRU order
  const KEEP = 2;
  const chunk = (i: number): Promise<Uint8Array> => {
    let p = chunks.get(i);
    if (p) {
      chunks.delete(i); // re-insert below to mark most-recently-used
    } else {
      const begin = i * chunkBytes;
      p = inner.read(begin, Math.min(begin + chunkBytes, totalBytes));
      p.catch(() => chunks.delete(i)); // failed fetches must not be memoized
    }
    chunks.set(i, p);
    for (const k of chunks.keys()) {
      if (chunks.size <= KEEP) break;
      chunks.delete(k);
    }
    return p;
  };

  return {
    async read(begin, end) {
      if (end > totalBytes) {
        throw new Error(`safetensors: read [${begin},${end}) past end ${totalBytes}`);
      }
      const first = Math.floor(begin / chunkBytes);
      const last = Math.floor((end - 1) / chunkBytes);
      const parts = await Promise.all(
        Array.from({ length: last - first + 1 }, (_, k) => chunk(first + k)),
      );
      if (parts.length === 1) {
        const offset = begin - first * chunkBytes;
        return parts[0]!.slice(offset, offset + (end - begin)); // slice = standalone copy
      }
      const out = new Uint8Array(end - begin);
      let written = 0;
      for (let i = first; i <= last; i++) {
        const from = i === first ? begin - i * chunkBytes : 0;
        const to = i === last ? end - i * chunkBytes : chunkBytes;
        out.set(parts[i - first]!.subarray(from, to), written);
        written += to - from;
      }
      return out;
    },
  };
}

/** A tensor that may not be fetched/computed yet. Two flavors share this
 *  interface but disagree on what `dtype` means:
 *  - File-backed (fileTensor): `dtype` is the real safetensors dtype read
 *    from the header. `halfWords()` only works when that dtype is F16;
 *    `words()` only works when it's U32; `u16()` only works when it's BF16
 *    or F16 (raw bits, no conversion).
 *  - Derived/eager (derivedTensor/eagerTensor): `dtype` is always the
 *    nominal value 'F32' regardless of what the underlying payload actually
 *    is — it does NOT reflect the payload. `f32()`, `halfWords()` and
 *    `words()` each throw if the computed data turns out to be the other
 *    array kind; `u16()` always throws — a derived tensor never holds raw
 *    unconverted bits. Consumers that don't know which flavor they have must
 *    try `halfWords()` first and fall back to `f32()` on failure (see
 *    materialize() in nn/loadStateDict.ts). */
export interface LazyTensor {
  dtype: SafeDtype;
  shape: number[];
  byteLength: number;
  f32(): Promise<Float32Array>;
  halfWords(): Promise<Uint32Array>;
  /** U32 file tensors, or a derived tensor computed to a Uint32Array. */
  words(): Promise<Uint32Array>;
  /** Raw BF16/F16 bits, unconverted. File tensors only — derived tensors throw. */
  u16(): Promise<Uint16Array>;
}

export interface LazyStateDict {
  metadata: Record<string, string>;
  tensors: Map<string, LazyTensor>;
  totalBytes(): number;
}

/** View `bytes` as u16 halfwords, honoring the view's offset (copies only if
 *  the offset is odd — can't happen for spec-valid safetensors, but cheap). */
function toHalfwords(bytes: Uint8Array): Uint16Array {
  if (bytes.byteOffset % 2 === 0)
    return new Uint16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength / 2);
  return new Uint16Array(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
}

/** View `bytes` as f32, honoring the view's offset; copies when misaligned
 *  (odd-element F16 tensors earlier in the file shift later offsets mod 4). */
function toF32(bytes: Uint8Array): Float32Array {
  if (bytes.byteOffset % 4 === 0)
    return new Float32Array(bytes.buffer, bytes.byteOffset, bytes.byteLength / 4);
  return new Float32Array(
    bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
  );
}

/** Zero-pad `bytes` to a multiple of 4 and view as u32 words, honoring the
 *  view's offset. */
function toWords(bytes: Uint8Array): Uint32Array {
  if (bytes.byteOffset % 4 === 0 && bytes.byteLength % 4 === 0)
    return new Uint32Array(bytes.buffer, bytes.byteOffset, bytes.byteLength / 4);
  const padded = new Uint8Array(Math.ceil(bytes.byteLength / 4) * 4);
  padded.set(bytes);
  return new Uint32Array(padded.buffer);
}

function fileTensor(name: string, info: SafeTensorInfo, source: RangeSource): LazyTensor {
  const fetchBytes = () => source.read(info.begin, info.end);
  return {
    dtype: info.dtype,
    shape: info.shape,
    byteLength: info.end - info.begin,
    async f32() {
      const bytes = await fetchBytes();
      if (info.dtype === 'F32') return toF32(bytes);
      if (info.dtype === 'BF16') return bf16ToF32(toHalfwords(bytes));
      if (info.dtype === 'F16') return f16ToF32(toHalfwords(bytes));
      throw new Error(`tensor ${name}: cannot decode ${info.dtype} to f32`);
    },
    async halfWords() {
      if (info.dtype !== 'F16')
        throw new Error(`tensor ${name}: halfWords() needs F16, got ${info.dtype}`);
      return toWords(await fetchBytes());
    },
    async words() {
      if (info.dtype !== 'U32')
        throw new Error(`tensor ${name}: words() needs U32, got ${info.dtype}`);
      return toWords(await fetchBytes());
    },
    async u16() {
      if (info.dtype !== 'BF16' && info.dtype !== 'F16')
        throw new Error(`tensor ${name}: u16() needs BF16 or F16, got ${info.dtype}`);
      return toHalfwords(await fetchBytes());
    },
  };
}

export function eagerTensor(data: Float32Array | Uint32Array, shape: number[]): LazyTensor {
  return derivedTensor(shape, () => Promise.resolve(data), data.byteLength);
}

/** `byteLength` is the tensor's share of the DOWNLOAD, for progress math —
 *  the file bytes `compute` fetches that no other tensor claims. Transforms
 *  that consume several file tensors (e.g. a BN fold) attribute the sum to
 *  ONE derived output and 0 to the rest, so bytes are never counted twice. */
export function derivedTensor(
  shape: number[],
  compute: () => Promise<Float32Array | Uint16Array | Uint32Array>,
  byteLength = 0,
): LazyTensor {
  let memo: Promise<Float32Array | Uint16Array | Uint32Array> | undefined;
  const get = () => (memo ??= compute());
  /** Shared by halfWords() and words() — both just want the computed data
   *  back as a Uint32Array, whether it holds packed f16 halfs or raw u32s. */
  const asWords = async (): Promise<Uint32Array> => {
    const data = await get();
    if (!(data instanceof Uint32Array))
      throw new Error('derived tensor holds f32 or halfwords, not words');
    return data;
  };
  return {
    dtype: 'F32', // nominal only — see the LazyTensor doc comment above
    shape,
    byteLength,
    async f32() {
      const data = await get();
      if (!(data instanceof Float32Array))
        throw new Error('derived tensor holds raw bits, not f32');
      return data;
    },
    halfWords: asWords,
    words: asWords,
    /** A transform that already produced f16 halfwords (e.g. a conv weight
     *  repack) hands them straight to an f16 parameter, no f32 detour. */
    async u16(): Promise<Uint16Array> {
      const data = await get();
      if (!(data instanceof Uint16Array)) throw new Error('derived tensor has no raw u16 bits');
      return data;
    },
  };
}

/** In-memory LazyStateDict — the loadStateDict entry point for weights that
 *  already sit in RAM (tests, generated weights). Bare arrays get a flat
 *  [length] shape; packed/quant tensors need the object form with their
 *  LOGICAL dims. Uint16Array data is raw bf16 bits (CpuParameter targets,
 *  e.g. nn.Embedding's table). */
export type MemoryStateDict = Record<
  string,
  | Float32Array
  | Uint32Array
  | Uint16Array
  | { data: Float32Array | Uint32Array | Uint16Array; shape: number[] }
>;

export function memoryStateDict(entries: MemoryStateDict): LazyStateDict {
  const tensors = new Map<string, LazyTensor>();
  for (const [name, entry] of Object.entries(entries)) {
    const { data, shape } = ArrayBuffer.isView(entry)
      ? { data: entry, shape: [entry.length] }
      : entry;
    tensors.set(
      name,
      data instanceof Uint16Array ? bf16Tensor(data, shape) : eagerTensor(data, shape),
    );
  }
  return {
    metadata: {},
    tensors,
    totalBytes: () => [...tensors.values()].reduce((sum, t) => sum + t.byteLength, 0),
  };
}

/** In-memory bf16-bits tensor: u16() hands the bits back; f32() expands them
 *  (bf16 is an f32's top half). */
function bf16Tensor(bits: Uint16Array, shape: number[]): LazyTensor {
  return {
    dtype: 'BF16',
    shape,
    byteLength: bits.byteLength,
    u16: () => Promise.resolve(bits),
    f32: () => Promise.resolve(bf16ToF32(bits)),
    halfWords: () => Promise.reject(new Error('bf16 tensor holds raw bits, not packed f16')),
    words: () => Promise.reject(new Error('bf16 tensor holds raw bits, not u32 words')),
  };
}

export async function fromSafetensors(
  src: string | RangeSource,
  opts: {
    onBytes?: (n: number) => void;
    chunkBytes?: number;
    /** Save every fetched byte range to this cache and answer repeat reads
     *  from it — warm loads touch no network. Keys embed `cacheId` (defaults
     *  to the URL's basename for string sources, required for RangeSource
     *  ones). Cached bytes are trusted blindly: if the file's content changes,
     *  its name must change too, or stale ranges get served. */
    cache?: WeightCache;
    cacheId?: string;
  } = {},
): Promise<LazyStateDict> {
  let source = typeof src === 'string' ? httpRangeSource(src, { onBytes: opts.onBytes }) : src;
  if (opts.cache) {
    const cacheId = opts.cacheId ?? (typeof src === 'string' ? src.split('/').pop() : undefined);
    if (!cacheId) {
      throw new Error('fromSafetensors: cache with a RangeSource src needs an explicit cacheId');
    }
    source = cachedRangeSource(source, opts.cache, cacheId);
  }
  // Header reads stay on the raw source (two tiny one-time requests); tensor
  // reads coalesce through chunkedSource, clamped to the payload end, which
  // is only known after the header parse. chunkBytes: 0 opts out — and caching
  // forces it, so cache keys are per-tensor and identical on every load
  // instead of following chunk boundaries.
  let index: SafetensorsIndex;
  try {
    index = await parseSafetensorsHeader(source);
  } catch (err) {
    // A cache that stored an HTML fallback page (missing file at first-load
    // time) replays the garbage forever, even after the file appears. When
    // the header is not a safetensors payload and a cache is in play, wipe
    // it and retry once from a FRESH network source (the old one may have
    // memoized the bad whole-file body).
    if (!opts.cache || typeof src !== 'string' || !(err instanceof Error)) throw err;
    if (!/not a safetensors payload|implausible header/.test(err.message)) throw err;
    await opts.cache.clear();
    const cacheId = opts.cacheId ?? src.split('/').pop()!;
    source = cachedRangeSource(
      httpRangeSource(src, { onBytes: opts.onBytes }),
      opts.cache,
      cacheId,
    );
    index = await parseSafetensorsHeader(source);
  }
  let payloadEnd = 0;
  for (const info of index.tensors.values()) payloadEnd = Math.max(payloadEnd, info.end);
  const chunkBytes = opts.cache ? 0 : (opts.chunkBytes ?? DEFAULT_CHUNK_BYTES);
  const data =
    chunkBytes > 0 && payloadEnd > 0 ? chunkedSource(source, payloadEnd, chunkBytes) : source;
  const tensors = new Map<string, LazyTensor>();
  for (const [name, info] of index.tensors) tensors.set(name, fileTensor(name, info, data));
  return {
    metadata: index.metadata,
    tensors,
    totalBytes: () => [...tensors.values()].reduce((sum, t) => sum + t.byteLength, 0),
  };
}
