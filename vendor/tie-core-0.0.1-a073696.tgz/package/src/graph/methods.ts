/** Method forms of the ops, torch-style: `x.matmul(w).add(bias).softmax()`.
 *  Each method is a one-line delegation to its function in ops.ts — same
 *  pending node, same kernels, just a second calling convention. The set
 *  mirrors torch: only ops that are Tensor methods there appear here; ops
 *  from torch.nn.functional (sdpa, conv*, layerNorm) and torch-level
 *  functions (cat) stay function-only.
 *
 *  This is a separate file so value.ts never imports ops.ts (ops.ts already
 *  imports value.ts — defining the methods inside the class would close an
 *  import cycle). index.ts imports this module for its side effect, which
 *  attaches the methods for every consumer of @tie/core. */

import { Value } from './value.ts';
import {
  add,
  asinh,
  chunk,
  clamp,
  matmul,
  mean,
  mul,
  reshape,
  rsqrt,
  sigmoid,
  slice,
  softmax,
  split,
  sub,
  tanh,
  topk,
  transpose,
  type MatmulOpts,
} from './ops.ts';

declare module './value.ts' {
  interface Value {
    add(b: Value | number): Value;
    sub(b: Value | number): Value;
    mul(b: Value | number): Value;
    matmul(b: Value, opts?: MatmulOpts): Value;
    reshape(newDims: number[]): Value;
    transpose(): Value;
    clamp(lo: number, hi: number): Value;
    slice(dim: number, start: number, end: number): Value;
    chunk(n: number, dim: number): Value[];
    split(sizes: readonly number[], dim: number): Value[];
    softmax(): Value;
    sigmoid(): Value;
    tanh(): Value;
    asinh(): Value;
    mean(): Value;
    rsqrt(): Value;
    topk(k: number): Value;
  }
}

Value.prototype.add = function (b) {
  return add(this, b);
};
Value.prototype.sub = function (b) {
  return sub(this, b);
};
Value.prototype.mul = function (b) {
  return mul(this, b);
};
Value.prototype.matmul = function (b, opts) {
  return matmul(this, b, opts);
};
Value.prototype.reshape = function (newDims) {
  return reshape(this, newDims);
};
Value.prototype.transpose = function () {
  return transpose(this);
};
Value.prototype.clamp = function (lo, hi) {
  return clamp(this, lo, hi);
};
Value.prototype.slice = function (dim, start, end) {
  return slice(this, dim, start, end);
};
Value.prototype.chunk = function (n, dim) {
  return chunk(this, n, dim);
};
Value.prototype.split = function (sizes, dim) {
  return split(this, sizes, dim);
};
Value.prototype.softmax = function () {
  return softmax(this);
};
Value.prototype.sigmoid = function () {
  return sigmoid(this);
};
Value.prototype.tanh = function () {
  return tanh(this);
};
Value.prototype.asinh = function () {
  return asinh(this);
};
Value.prototype.mean = function () {
  return mean(this);
};
Value.prototype.rsqrt = function () {
  return rsqrt(this);
};
Value.prototype.topk = function (k) {
  return topk(this, k);
};
