/** The eval driver (device-agnostic core). Walks the pending sub-DAG, dispatches
 *  each node once in dependency order, releases each produced intermediate after
 *  its last consumer (liveness reuse), and submits ONE batch. Dtype-aware so it
 *  can allocate f32 matrices as well as vec4f arrays.
 *
 *  Deviation from the spec: buffer reuse is a direct liveness pass here rather
 *  than a translation to the trace Graph IR + planBuffers (whose op vocabulary
 *  differs). Same outcome, no cross-engine coupling. */

import type { EagerDtype, GpuBufferRef, ValueMeta, Value } from './value.ts';

/** The activation dtypes the fusion passes apply to. Both conv epilogues
 *  (residual add, concat offset) are written for either storage width, so the
 *  passes are gated on "is a float activation", not on f32. */
const isFloat = (dtype: EagerDtype): boolean => dtype === 'f32' || dtype === 'f16';

/** Per-dispatch hints produced by the eval driver's fusion passes. */
export interface DispatchExtras {
  /** Fused residual: the kernel adds this buffer element-wise in its epilogue
   *  (after bias + activation) — replaces a separate 'add' dispatch. */
  addend?: GpuBufferRef;
  /** Element offset at which the kernel writes into `out` — used when the
   *  node's output is elided into its consumer concat's buffer. */
  outBase?: number;
  /** Total element count of the buffer behind `out` when it belongs to a
   *  consumer concat (the holder). CHW writers don't need it (a channel
   *  concat is flat, the offset says everything); an hwc4 writer derives its
   *  per-pixel channel-block stride from it. */
  outElems?: number;
}

export interface Executor {
  /** Allocate the output buffer for a node of `shape`. */
  acquireOutput(shape: ValueMeta): GpuBufferRef;
  /** Return an intermediate's buffer to the pool once it's dead. */
  releaseOutput(buffer: GpuBufferRef, shape: ValueMeta): void;
  /** Encode one dispatch for `node` (op + shapes via node), reading `inputs`,
   *  writing the already-acquired `out` buffer. */
  dispatch(
    node: Value,
    inputs: readonly GpuBufferRef[],
    out: GpuBufferRef,
    extras?: DispatchExtras,
  ): void;
  /** Optional: encode a flat copy of `elems` elements from src into dst at
   *  element offset dstBase. Enables concat elision — without it, concats
   *  stay full copies (node-test mock executors need no change). */
  copyInto?(
    src: GpuBufferRef,
    dst: GpuBufferRef,
    srcShape: ValueMeta,
    dstShape: ValueMeta,
    dstBase: number,
  ): void;
  /** Encode-then-submit the batch built by prior dispatch() calls. */
  submit(): void;
}

export interface Releaser {
  /** Hand materialized Values' buffers back to the pool once you are done
   *  reading them — eval TARGETS after readback, or uploaded one-shot inputs.
   *  NEVER weights or Values you will use in a later forward: any later use
   *  throws. Without this, a per-frame loop leaks every frame's outputs
   *  (evalValues never releases targets). */
  releaseValues(values: readonly Value[]): void;
}

export interface Readback {
  /** Copy a materialized buffer of `shape` back to CPU (flattened f32). */
  readback(buffer: GpuBufferRef, shape: ValueMeta): Promise<Float32Array>;
  /** Optional batched form: several buffers through one staging buffer /
   *  submit / map — the per-readback fixed cost dominates multi-output reads. */
  readbackMany?(
    items: readonly { buffer: GpuBufferRef; shape: ValueMeta }[],
  ): Promise<Float32Array[]>;
}

/** Post-order DFS from the requested targets over pending nodes only
 *  (materialized nodes are data, not work — recursion stops there). Returns
 *  every op that must run, each exactly once, with inputs always before
 *  their consumers — i.e. a valid dispatch order. */
function collectPending(targets: readonly Value[]): Value[] {
  const order: Value[] = [];
  const seen = new Set<Value>();
  const visit = (v: Value): void => {
    if (v.state === 'released') {
      throw new Error(
        `evalValues: '${v.pending!.op}' output buffer was recycled by a previous eval — it must have been a TARGET of the eval that materialized it (evalValues([primary, v])) to stay alive across evals`,
      );
    }
    if (v.state === 'materialized' || seen.has(v)) return;
    seen.add(v);
    for (const input of v.pending!.inputs) visit(input);
    order.push(v);
  };
  for (const t of targets) visit(t);
  return order;
}

/** Ops whose output ALIASES inputs[0]'s buffer instead of a fresh allocation
 *  (writeRows — in-place row writes into a caller-owned buffer). The driver
 *  skips acquireOutput for them and NEVER pool-releases them: the buffer
 *  belongs to the caller, not the pool. */
const IN_PLACE_OPS = new Set(['writeRows']);

/** Materialize `targets` (and everything they depend on) through `ex`, in one
 *  submitted batch. Per node in dependency order: acquire an output buffer,
 *  queue the dispatch, mark the node materialized; then hand each input's
 *  buffer back to the pool as soon as its LAST consumer has been queued
 *  (precomputed `lastUse` indices) — that's what lets a long chain run in ~2
 *  buffers. Never releases requested targets, pre-existing (non-`produced`)
 *  buffers like weights, or in-place nodes (their buffer is caller-owned).
 *  Releasing before submit() is safe: reuse just aliases a buffer across two
 *  dispatches, and dispatches in one pass run in order. */
export function evalValues(targets: readonly Value[], ex: Executor): void {
  const order = collectPending(targets);
  const produced = new Set<Value>(order);
  const targetSet = new Set<Value>(targets);

  const lastUse = new Map<Value, number>();
  order.forEach((v, i) => {
    for (const input of new Set(v.pending!.inputs)) {
      if (produced.has(input)) lastUse.set(input, i);
    }
  });

  // The fusion passes below only ever match graphs containing their target
  // ops — a decode-loop graph without any conv2d/concatChannels would pay
  // for their bookkeeping (pos/uses maps + two full scans) every eval and
  // get nothing, so gate all of it on one cheap op scan.
  const hasFusableOps = order.some(
    (v) =>
      v.pending!.op === 'concatChannels' ||
      v.pending!.op === 'conv2dHwc4' ||
      v.pending!.op === 'concatChannelsHwc4',
  );

  const pos = new Map<Value, number>();
  const uses = new Map<Value, number>();
  if (hasFusableOps) {
    order.forEach((v, i) => {
      pos.set(v, i);
      for (const input of new Set(v.pending!.inputs)) {
        if (produced.has(input)) uses.set(input, (uses.get(input) ?? 0) + 1);
      }
    });
  }

  const sameShape = (a: Value, b: Value) =>
    a.shape.elems === b.shape.elems &&
    a.shape.dtype === b.shape.dtype &&
    a.shape.layout === b.shape.layout &&
    String(a.shape.dims) === String(b.shape.dims);

  // ---- Pass 1: residual-add fusion. add(x, conv) where the conv's ONLY
  // consumer is this add → the conv's epilogue adds x (after bias+act, i.e.
  // torch's `x + cv2(cv1(x))` order) and the add node just aliases the conv's
  // buffer. Kills one full-tensor read+read+write per bottleneck/SPPF/PSA
  // residual. x must be materialized before the conv dispatches (true for the
  // DFS order of add(x, conv) — x's subtree is visited first).
  const fusedAddend = new Map<Value, Value>(); // conv node → addend value
  const addAlias = new Map<Value, Value>(); // add node → conv it aliases
  const ownedElsewhere = new Set<Value>(); // buffer belongs to an alias/holder — never release via this node
  for (const v of hasFusableOps ? order : []) {
    if (v.pending!.op !== 'add' || !isFloat(v.shape.dtype)) continue;
    const [i0, i1] = v.pending!.inputs;
    if (!i0 || !i1 || i0 === i1) continue;
    if (!sameShape(v, i0) || !sameShape(v, i1)) continue;
    const fusable = (conv: Value, x: Value) =>
      produced.has(conv) &&
      conv.pending!.op === 'conv2dHwc4' &&
      uses.get(conv) === 1 &&
      !targetSet.has(conv) &&
      !fusedAddend.has(conv) &&
      (!produced.has(x) || pos.get(x)! < pos.get(conv)!);
    let conv: Value | undefined;
    let x: Value | undefined;
    if (fusable(i1, i0)) {
      conv = i1;
      x = i0;
    } else if (fusable(i0, i1)) {
      conv = i0;
      x = i1;
    }
    if (conv === undefined) continue;
    fusedAddend.set(conv, x!);
    addAlias.set(v, conv);
    ownedElsewhere.add(conv);
  }

  // ---- Pass 2: concat elision. concatChannels(a, b) is a flat [a | b] copy;
  // when an input's ONLY consumer is the concat, its producer writes directly
  // into the concat's buffer at the right element offset (extras.outBase) and
  // the copy disappears. Nested pairwise concats (SPPF's cat4, C3k2's
  // progressive cat) chain offsets through `concatInto`, so the whole chain
  // lands in ONE buffer. Inputs with other consumers (FPN skips) fall back to
  // ex.copyInto at their offset. Gated on ex.copyInto so mock executors keep
  // working with plain concat copies.
  interface ConcatSlot {
    holder: Value; // root concat whose buffer is written
    base: number; // element offset within the holder's buffer
  }
  const concatInto = new Map<Value, ConcatSlot>(); // writer node → destination slot
  // Layout never mixes inside one concat (the ops validate it), so one set
  // is safe: an hwc4 writer can only appear under an hwc4 concat. The CHW
  // names left are the attention islands' row-major ops.
  const OFFSET_WRITERS = new Set([
    'sliceChannels',
    'reshape',
    'concatChannels',
    'conv2dHwc4',
    'maxPool2dHwc4',
    'upsample2dHwc4',
    'sliceChannelsHwc4',
    'concatChannelsHwc4',
  ]);
  if (ex.copyInto && hasFusableOps) {
    for (let i = order.length - 1; i >= 0; i--) {
      const c = order[i]!;
      const cop = c.pending!.op;
      if ((cop !== 'concatChannels' && cop !== 'concatChannelsHwc4') || !isFloat(c.shape.dtype))
        continue;
      const self = concatInto.get(c) ?? { holder: c, base: 0 };
      const [a, b] = c.pending!.inputs as [Value, Value];
      const offsets = [0, a.shape.elems];
      [a, b].forEach((inp, j) => {
        if (!produced.has(inp) || uses.get(inp) !== 1 || targetSet.has(inp)) return;
        // A fused add aliases its conv — the conv is the actual writer.
        const writer = inp.pending!.op === 'add' ? addAlias.get(inp) : inp;
        if (writer === undefined || concatInto.has(writer)) return;
        if (!OFFSET_WRITERS.has(writer.pending!.op)) return;
        concatInto.set(writer, { holder: self.holder, base: self.base + offsets[j]! });
        ownedElsewhere.add(inp);
        if (writer !== inp)
          concatInto.set(inp, { holder: self.holder, base: self.base + offsets[j]! });
      });
    }
  }

  // Holder buffers are acquired when the FIRST elided writer needs them —
  // always before the concat's own position (writers precede it in topo
  // order).
  const holderBuf = new Map<Value, GpuBufferRef>();
  const bufferFor = (holder: Value) => {
    let buf = holderBuf.get(holder);
    if (buf === undefined) {
      buf = ex.acquireOutput(holder.shape);
      holderBuf.set(holder, buf);
    }
    return buf;
  };

  order.forEach((v, i) => {
    const aliasedConv = addAlias.get(v);
    if (IN_PLACE_OPS.has(v.pending!.op)) {
      // In-place op: writes rows of its first input's caller-owned buffer.
      const out = v.pending!.inputs[0]!.buffer;
      const inputs = v.pending!.inputs.map((input) => input.buffer);
      ex.dispatch(v, inputs, out);
      v.setMaterialized(out);
    } else if (aliasedConv !== undefined) {
      // Fused add: the conv already wrote act(conv)+x — just take its buffer.
      v.setMaterialized(aliasedConv.buffer);
    } else if (
      (v.pending!.op === 'concatChannels' || v.pending!.op === 'concatChannelsHwc4') &&
      concatInto.has(v)
    ) {
      // Elided concat: writers targeted the holder directly; copy only the
      // inputs that couldn't be elided.
      const slot = concatInto.get(v)!;
      const buf = bufferFor(slot.holder);
      const [a, b] = v.pending!.inputs as [Value, Value];
      [a, b].forEach((inp, j) => {
        if (!ownedElsewhere.has(inp)) {
          ex.copyInto!(
            inp.buffer,
            buf,
            inp.shape,
            slot.holder.shape,
            slot.base + (j === 0 ? 0 : a.shape.elems),
          );
        }
      });
      v.setMaterialized(buf);
    } else if (
      (v.pending!.op === 'concatChannels' || v.pending!.op === 'concatChannelsHwc4') &&
      ex.copyInto &&
      holderBuf.has(v)
    ) {
      // Root concat with at least one elided input.
      const buf = bufferFor(v);
      const [a, b] = v.pending!.inputs as [Value, Value];
      [a, b].forEach((inp, j) => {
        if (!ownedElsewhere.has(inp)) {
          ex.copyInto!(inp.buffer, buf, inp.shape, v.shape, j === 0 ? 0 : a.shape.elems);
        }
      });
      v.setMaterialized(buf);
    } else {
      const slot = concatInto.get(v);
      const out = slot !== undefined ? bufferFor(slot.holder) : ex.acquireOutput(v.shape);
      const inputs = v.pending!.inputs.map((input) => input.buffer);
      const addend = fusedAddend.get(v);
      const extras: DispatchExtras | undefined =
        addend !== undefined || slot !== undefined
          ? {
              addend: addend?.buffer,
              outBase: slot?.base ?? 0,
              outElems: slot?.holder.shape.elems,
            }
          : undefined;
      ex.dispatch(v, inputs, out, extras);
      v.setMaterialized(out);
      if (slot !== undefined) ownedElsewhere.add(v);
    }
    // Set-dedupe: an op can list the same input twice (e.g. mul(x, x)) — without
    // it the buffer would be released to the pool twice (silent double-free).
    // ownedElsewhere inputs (fused convs, elided writers) share a buffer that
    // the alias/holder now owns — releasing them here would free it early.
    for (const input of new Set(v.pending!.inputs)) {
      if (
        produced.has(input) &&
        lastUse.get(input) === i &&
        !targetSet.has(input) &&
        !IN_PLACE_OPS.has(input.pending!.op) &&
        !ownedElsewhere.has(input)
      ) {
        ex.releaseOutput(input.buffer, input.shape);
        input.markReleased(); // any later use of this Value now fails loudly
      }
    }
  });
  ex.submit();
}

/** Read a Value's numbers on the CPU, evaluating it first if still pending —
 *  the "force" that makes the lazy DAG feel eager (cf. torch's .numpy()). */
export async function toArray(value: Value, ex: Executor & Readback): Promise<Float32Array> {
  evalValues([value], ex);
  return ex.readback(value.buffer, value.shape);
}
