/** The eager core's array type. A Value is lazy: it holds EITHER a
 *  materialized GPU buffer OR a pending op describing how to compute it.
 *  Ops (see ops.ts) build pending Values; eval() (see eval.ts) turns pending
 *  into materialized. Separate from the trace-time `Tensor` by design. */

import type { F16Buffer, F32Buffer, U32Buffer } from '../kernels/common.ts';

export type EagerDtype = 'f32' | 'f16' | 'quantW';

/** Bytes per element of `dtype`. An element is not always one value: for
 *  quantW `elems` counts u32 WORDS (see the deviation below),
 *  so both are 4. The one place buffer sizes and readback counts are derived,
 *  so a new dtype cannot be half-added. */
export function elemBytes(dtype: EagerDtype): number {
  return dtype === 'f16' ? 2 : 4;
}

/** Everything known about a Value WITHOUT computing it: element count, dtype,
 *  and (for 2D ops like matmul/softmax) the logical dims. Ops use it to
 *  validate inputs and derive output shapes before any GPU work; the executor
 *  uses it to size and pool buffers.
 *
 *  quantW deviation: `dims` are the LOGICAL weight dims
 *  [rows, cols] while `elems` is the u32 WORD count (int8: rows·cols/4; int4:
 *  rows·cols/8); the physical bytes use the blocked-unit layout
 *  (kernels/quantCommon.ts). Upload-only, consumed by matmul's quantW path
 *  and matmulGather. */
export interface ValueMeta {
  /** Element count in units of `dtype` (f32 and f16 = one value each; a
   *  quantW element = one u32 holding several packed ints). Byte size
   *  comes from elemBytes(dtype). */
  readonly elems: number;
  readonly dtype: EagerDtype;
  /** Logical shape for non-flat ops (matmul/softmax), e.g. [rows, cols]. */
  readonly dims?: readonly number[];
  /** Physical storage order when it differs from the row-major default.
   *  'hwc4': an f16 image tensor stored pixel-major as vec4 channel blocks —
   *  element (y·W + x)·ceil(C/4)·4 + c, channels zero-padded to a multiple
   *  of 4, so `elems` = H·W·ceil(C/4)·4 (INCLUDES the padding) while `dims`
   *  stay the logical [C, H, W]. Only the hwc4-aware ops accept a tagged
   *  Value; everything else (and readback) throws rather than reading the
   *  bytes in the wrong order. */
  readonly layout?: 'hwc4';
}

/** Channel blocks of an hwc4 tensor: ceil(c / 4). */
export function c4of(c: number): number {
  return Math.ceil(c / 4);
}

/** Meta for an hwc4-stored [C, H, W] f16 image tensor. */
export function hwc4Meta(c: number, h: number, w: number): ValueMeta {
  return { elems: h * w * c4of(c) * 4, dtype: 'f16', dims: [c, h, w], layout: 'hwc4' };
}

/** Build a row-major f32 matrix shape. */
export function matrix(rows: number, cols: number): ValueMeta {
  return { elems: rows * cols, dtype: 'f32', dims: [rows, cols] };
}

export function tensor3d(c: number, h: number, w: number): ValueMeta {
  const chw = c * h * w;
  return { elems: chw, dtype: 'f32', dims: [c, h, w] };
}

/** A real TypeGPU storage buffer backing a materialized Value — f32, f16, or
 *  u32 (quantW), matching the eager dtypes. `import type` only, so this file
 *  still loads in node tests without a GPU (those stub buffers via
 *  test/helpers.ts). Only the Executor (eval.ts) narrows the union to a
 *  concrete dtype at dispatch. */
export type GpuBufferRef = F32Buffer | F16Buffer | U32Buffer;

/** The recipe for a not-yet-computed Value: which op produces it and from
 *  which input Values. Since inputs are themselves Values (possibly pending),
 *  chained ops form an implicit DAG that eval() later walks. */
export interface PendingOp {
  readonly op: string;
  readonly inputs: readonly Value[];
  /** Optional scalar operand for ops like addScalar (carried to dispatch). */
  readonly scalar?: number;
  /** Optional numeric attributes for layout/scalar ops (e.g. sliceCols
   *  [start, end], clampScalar [lo, hi]). */
  readonly attrs?: readonly number[];
}

/** A tensor, as the eager API sees it — what every op takes and returns, the
 *  analogue of a torch.Tensor / mx.array. Internally it is one node of a lazy
 *  computation DAG in one of two states:
 *  - materialized: `_buffer` holds real GPU data (an uploaded weight/input, or
 *    an op result after eval).
 *  - pending: no data yet; `pending` records the op + input Values that will
 *    produce it. Calling ops just links new pending nodes — no GPU work.
 *  Reading a result (toArray/run) evaluates every pending node it depends on
 *  in one batched submit and flips them to materialized. */
export class Value {
  private constructor(
    readonly shape: ValueMeta,
    /** The GPU memory holding this Value's actual numbers. Present from the
     *  start for uploaded data (weights, inputs); for op results it stays
     *  undefined until eval() runs the op — that absence is what "pending"
     *  means. */
    private _buffer: GpuBufferRef | undefined,
    /** Present when this Value came from an op (matmul, add, ...) instead of
     *  an upload. No GPU work has run at that point: calling an op only
     *  records WHAT to compute (the op + its input Values) here, and eval()
     *  executes it later when someone actually reads a result. Stays set
     *  after eval fills _buffer, but by then it's inert — `state` is
     *  determined by `_buffer` alone. */
    readonly pending: PendingOp | undefined,
  ) {}

  /** Set once the eval driver recycles this Value's buffer back to the pool.
   *  `_buffer` deliberately keeps the stale ref: clearing it would flip state
   *  to 'pending' and eval would silently RE-RUN the recipe against possibly
   *  stale inputs. Instead, any later use must throw. */
  private _released = false;

  get state(): 'materialized' | 'pending' | 'released' {
    if (this._released) return 'released';
    return this._buffer !== undefined ? 'materialized' : 'pending';
  }

  /** The backing buffer; throws if not yet materialized or already recycled. */
  get buffer(): GpuBufferRef {
    if (this._released) {
      throw new Error(
        'Value.buffer: buffer was recycled by eval — it must have been a TARGET of the eval that materialized it (evalValues([primary, v])) to stay alive across evals',
      );
    }
    if (this._buffer === undefined) {
      throw new Error('Value.buffer: not materialized yet — call eval() first');
    }
    return this._buffer;
  }

  /** @internal Called by the eval driver to record the computed buffer. */
  setMaterialized(buffer: GpuBufferRef): void {
    this._buffer = buffer;
  }

  /** @internal Called by the eval driver when it recycles this Value's buffer
   *  to the pool. The recipe is NOT re-runnable — its inputs may themselves be
   *  stale — so any later use of this Value must fail loudly. */
  markReleased(): void {
    this._released = true;
  }

  static materialized(shape: ValueMeta, buffer: GpuBufferRef): Value {
    return new Value(shape, buffer, undefined);
  }

  static pending(
    shape: ValueMeta,
    op: string,
    inputs: readonly Value[],
    scalar?: number,
    attrs?: readonly number[],
  ): Value {
    return new Value(shape, undefined, { op, inputs, scalar, attrs });
  }
}

export const materialized = Value.materialized;
export const pending = Value.pending;
