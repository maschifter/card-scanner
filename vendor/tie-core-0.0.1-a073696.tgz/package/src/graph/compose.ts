/** Higher-level ops composed from core primitives (NOT kernels). This is the
 *  nn-functional layer — mirrors torch.nn.functional.rms_norm / F.linear: things
 *  both torch and mlx define, assembled from tensor primitives rather than baked.
 *  Fusion (S3) collapses these primitive chains into efficient kernels —
 *  layerNorm has already graduated to a fused single-dispatch op (ops.layerNorm).
 *  Model-specific non-primitives (RoPE, attention-with-sinks, MoE) compose in zoo. */

import { add, astype, matmul, mean, meanSquare, mul, rsqrt, sub, transpose } from './ops.ts';
import type { Value } from './value.ts';

/** RMSNorm(x[M,N], weight[N], eps) = x * rsqrt(mean(x², -1) + eps) * weight. */
export function rmsNorm(x: Value, weight: Value, eps = 1e-6): Value {
  const ms = meanSquare(x); // [M,1] f32 — squares AND holds the sum in f32
  // rsqrt stays in f32 too; only the finished scale factor narrows, and that
  // one is small enough to survive (rsqrt(2.9e7) = 1.9e-4).
  const denom = astype(rsqrt(add(ms, eps)), x.shape.dtype === 'f16' ? 'f16' : 'f32');
  return mul(mul(x, denom), weight); // col-broadcast then row-broadcast
}

/** GroupNorm(x[M,N], numGroups, weight[N], bias[N], eps) — torch F.group_norm
 *  restricted to numGroups = 1: statistics are GLOBAL over the whole [M,N]
 *  map (all rows × all columns jointly — NOT per-row LayerNorm), the affine
 *  is per-column. The global mean is exact because rows have equal width, so
 *  the mean of row-means is the full-map mean; variance is biased (1/N),
 *  matching torch. The [1,1] statistics reach [M,N] via scalar broadcast.
 *  13 dispatches. numGroups > 1 would need per-column-block reductions no
 *  model here uses — rejected loudly until one does. */
export function groupNorm(
  x: Value,
  numGroups: number,
  weight: Value,
  bias: Value,
  eps = 1e-5,
): Value {
  if (numGroups !== 1) {
    throw new Error(`groupNorm: only numGroups = 1 is supported, got ${numGroups}`);
  }
  const g = mean(transpose(mean(x))); // [M,1] → [1,M] → [1,1] global mean
  const xc = sub(x, g); // scalar-broadcast centering
  const vG = mean(transpose(mean(mul(xc, xc)))); // [1,1] global biased variance
  const inv = rsqrt(add(vG, eps)); // [1,1]
  return add(mul(mul(xc, inv), weight), bias); // scalar, then row broadcasts
}

/** Linear(x[M,K], weight[K,N], bias[N], addend[M,N]) = x @ weight (+ bias)
 *  (+ addend) — ONE dispatch via the matmul epilogue. Omitting `bias` is
 *  torch's Linear(bias=False); `addend` folds a residual add into the same
 *  kernel (pre-norm transformer sublayers end in exactly this shape). */
export function linear(
  x: Value,
  weight: Value,
  bias?: Value,
  addend?: Value,
  activation?: 'tanh' | 'gelu',
): Value {
  return matmul(x, weight, { bias, addend, activation });
}
