/** HWC4 boundary conversions. HWC4 is an INTERNAL storage format — models
 *  enter it once after upload (toHwc4), run the conv-shaped graph inside it,
 *  and leave it (toChw) before anything row-major: attention math, readback,
 *  decode. Both ops fold the dtype change into the same dispatch, so a
 *  f32-uploaded frame reaches hwc4 f16 in one kernel and a head output
 *  reaches CPU-ready f32 in one kernel. */

import { hwc4Meta, pending, Value } from '../value.ts';
import { isHwc4 } from './shared.ts';

/** CHW [C,H,W] (f32 or f16) → hwc4 f16 storage. */
export function toHwc4(x: Value): Value {
  const dims = x.shape.dims;
  const dtype = x.shape.dtype;
  if (x.shape.layout !== undefined) {
    throw new Error(`toHwc4: input is already stored '${x.shape.layout}'`);
  }
  if (!dims || dims.length !== 3 || (dtype !== 'f32' && dtype !== 'f16')) {
    throw new Error(
      `toHwc4: expected a 3D float CHW tensor, got dims=${JSON.stringify(dims)} dtype=${dtype}`,
    );
  }
  const [c, h, w] = dims as [number, number, number];
  return pending(hwc4Meta(c, h, w), 'toHwc4', [x]);
}

/** hwc4 f16 storage → CHW [C,H,W] in `dtype` (padding lanes dropped). */
export function toChw(x: Value, dtype: 'f32' | 'f16'): Value {
  if (!isHwc4(x)) {
    throw new Error(`toChw: input is not hwc4-stored (layout=${x.shape.layout ?? 'none'})`);
  }
  const [c, h, w] = x.shape.dims! as [number, number, number];
  return pending({ elems: c * h * w, dtype, dims: [c, h, w] }, 'toChw', [x]);
}
