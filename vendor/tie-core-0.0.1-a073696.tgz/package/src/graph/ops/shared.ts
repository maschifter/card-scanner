/** Input-validation helpers shared by the op modules. */

import type { Value } from '../value.ts';

/** Activation name → `act` code, for every op with a fused activation
 *  epilogue. The codes index ACTIVATIONS in kernels/activations.ts; keep the
 *  two in step. Not every entry there is exposed as an op option — conv2d's
 *  silu rides its own boolean flag. */
export const ACT_CODE = { tanh: 1, gelu: 2 } as const;
export type ActName = keyof typeof ACT_CODE;

/** True when x is stored HWC4 (see ValueMeta.layout). The hwc4-aware ops
 *  branch on this BEFORE the want* checks below; everything else refuses a
 *  tagged Value through them — a kernel reading hwc4 bytes in CHW order
 *  produces silent garbage, so the mismatch must throw at graph-build time. */
export function isHwc4(x: Value): boolean {
  return x.shape.layout === 'hwc4';
}

function rejectHwc4(name: string, x: Value): void {
  if (x.shape.layout !== undefined) {
    throw new Error(
      `${name}: input is stored '${x.shape.layout}' — this op reads row-major storage; convert with toChw() first`,
    );
  }
}

/** Require a 2D f32 matrix; returns [rows, cols]. */
export function want2dF32(name: string, x: Value): [number, number] {
  rejectHwc4(name, x);
  const dims = x.shape.dims;
  if (!dims || dims.length !== 2 || x.shape.dtype !== 'f32') {
    throw new Error(`${name}: input must be a 2D f32 matrix (use matrix())`);
  }
  return [dims[0]!, dims[1]!];
}

/** Require a 2D float matrix (f32 or f16); returns [rows, cols, dtype]. The
 *  float dtypes are interchangeable at the op level — a kernel binds ONE
 *  element type, so callers must also check that their operands agree. */
export function want2dFloat(name: string, x: Value): [number, number, 'f32' | 'f16'] {
  rejectHwc4(name, x);
  const dims = x.shape.dims;
  const dtype = x.shape.dtype;
  if (!dims || dims.length !== 2 || (dtype !== 'f32' && dtype !== 'f16')) {
    throw new Error(`${name}: input must be a 2D f32 or f16 matrix (use matrix())`);
  }
  return [dims[0]!, dims[1]!, dtype];
}

/** An n-D activation tensor in either float storage dtype. Callers must
 *  propagate `x.shape.dtype` to the result — an op that hardcoded 'f32' would
 *  mislabel an f16 buffer and the next kernel would read it as f32. */
export function wantNDFloat(name: string, x: Value, n: number): number[] {
  rejectHwc4(name, x);
  const dims = x.shape.dims;
  const dtype = x.shape.dtype;
  if (dims?.length !== n || (dtype !== 'f32' && dtype !== 'f16')) {
    throw new Error(
      `${name}: expected ${n}D f32 or f16 tensor, got dims=${JSON.stringify(dims)} dtype=${dtype}`,
    );
  }
  return [...dims];
}

/** Resolves a possibly-negative dim against rank (torch convention: -1 is the
 *  last dim). Throws when the dim falls outside [0, rank). */
export function normDim(op: string, dim: number, rank: number): number {
  if (!Number.isInteger(dim)) throw new Error(`${op}: dim must be an integer, got ${dim}`);
  const d = dim < 0 ? dim + rank : dim;
  if (d < 0 || d >= rank) {
    throw new Error(`${op}: dim ${dim} out of range for a rank-${rank} operand`);
  }
  return d;
}
