/** Elementwise ops: add/mul/sub with row/col broadcasting and their plain-
 *  number overloads, unary activations, clamp, and the fused SwiGLU variants. */

import { pending, Value, type ValueMeta } from '../value.ts';
import { want2dFloat } from './shared.ts';

function dimsMatch(a?: readonly number[], b?: readonly number[]): boolean {
  return !!a && !!b && a.length === b.length && a.every((v, i) => v === b[i]);
}

/** Describe how `a op b` broadcasts. `full` is the [M,N] operand; `mode`: 0
 *  elementwise, 1 row ([N]/[1,N]), 2 col ([M,1]), 3 scalar ([1]/[1,1] — a
 *  GPU-computed single value; CPU-known constants take add/mul's number
 *  overload instead). Decided from dims when the small operand has them
 *  (unambiguous even for square matrices, where element counts alone can't
 *  tell [M,1] from [N]); element counts remain the fallback for dims-less
 *  values (vec4f legacy path). Returns null if incompatible. */
function broadcastPlan(
  x: Value,
  y: Value,
): { full: Value; other: Value; shape: ValueMeta; mode: 0 | 1 | 2 | 3 } | null {
  if (x.shape.dtype !== y.shape.dtype) return null;
  // Storage layouts must MATCH: an hwc4 and a chw tensor can share an element
  // count while their bytes are ordered differently — elementwise over the
  // pair would silently mix pixels. Same layout on both sides is fine (the
  // padded lanes are 0 + 0), and the spread below carries the tag forward.
  if (x.shape.layout !== y.shape.layout) return null;
  if (x.shape.elems === y.shape.elems) {
    // hwc4's elems is padded to a multiple of 4 channels, so [5,H,W] and
    // [8,H,W] share elems — dims must also match or this silently mixes
    // two different channel counts.
    if (x.shape.layout && !dimsMatch(x.shape.dims, y.shape.dims)) return null;
    return { full: x, other: y, shape: { ...x.shape }, mode: 0 };
  }
  // Row/col/scalar broadcasting is row-major arithmetic — never against hwc4.
  if (x.shape.layout !== undefined) return null;
  const full = x.shape.elems > y.shape.elems ? x : y;
  const other = full === x ? y : x;
  if (other.shape.elems === 1) return { full, other, shape: { ...full.shape }, mode: 3 };
  const fd = full.shape.dims;
  if (!fd || fd.length !== 2) return null;
  const [m, n] = [fd[0]!, fd[1]!];
  const od = other.shape.dims;
  if (od) {
    if (od.length === 2 && od[0] === m && od[1] === 1) {
      return { full, other, shape: { ...full.shape }, mode: 2 }; // col [M,1]
    }
    if ((od.length === 1 && od[0] === n) || (od.length === 2 && od[0] === 1 && od[1] === n)) {
      return { full, other, shape: { ...full.shape }, mode: 1 }; // row [N]/[1,N]
    }
  }
  // Dims-less fallback (vec4f legacy path): guess from element counts.
  if (other.shape.elems === n) return { full, other, shape: { ...full.shape }, mode: 1 }; // row [N]
  if (other.shape.elems === m) return { full, other, shape: { ...full.shape }, mode: 2 }; // col [M]/[M,1]
  return null;
}

/** Shared binary-elementwise builder with row/col broadcasting. The full [M,N]
 *  operand is placed first so the kernel's `a` is always the full tensor; the
 *  broadcast mode travels as attrs[0] — the executor reads it instead of
 *  re-deriving it from element counts. */
function elementwise(name: string, a: Value, b: Value): Value {
  // quantW is weights-only; the equal-dtype check below would happily pair
  // two quantized operands, so reject first.
  if (a.shape.dtype === 'quantW' || b.shape.dtype === 'quantW') {
    throw new Error(
      `${name}: quantW Values are weight-only — only matmul/matmulGather consume them`,
    );
  }
  const plan = broadcastPlan(a, b);
  if (!plan) {
    throw new Error(
      `${name}: incompatible shapes — a=(${a.shape.elems},${a.shape.dtype}) b=(${b.shape.elems},${b.shape.dtype})`,
    );
  }
  return pending(plan.shape, name, [plan.full, plan.other], undefined, [plan.mode]);
}

/** Elementwise add: out[i] = a[i] + b[i] (torch: a + b). A number `b` is a
 *  CPU-known constant folded into the dispatch (no upload). Pure (fresh
 *  output). */
export function add(a: Value, b: Value | number): Value {
  if (typeof b === 'number') return addScalar(a, b);
  return elementwise('add', a, b);
}

/** Elementwise multiply: out[i] = a[i] * b[i] (torch: a * b). A number `b` is
 *  a CPU-known constant folded into the dispatch (no upload). Pure (fresh
 *  output). */
export function mul(a: Value, b: Value | number): Value {
  if (typeof b === 'number') return mulScalar(a, b);
  return elementwise('mul', a, b);
}

/** Elementwise subtract: out[i] = a[i] − b[i] (torch: a - b), with [N]/[1,N]
 *  row or [M,1] col broadcast of b. Non-commutative, so unlike add/mul the
 *  full [M,N] operand must be `a` — the shared builder orders inputs
 *  full-first, which would silently flip the sign if b were the larger one.
 *  A number `b` becomes a scalar add of −b. */
export function sub(a: Value, b: Value | number): Value {
  if (typeof b === 'number') return addScalar(a, -b);
  if (a.shape.dtype !== b.shape.dtype) {
    throw new Error(`sub: dtype mismatch — ${a.shape.dtype} − ${b.shape.dtype}`);
  }
  if (b.shape.elems > a.shape.elems) {
    throw new Error(
      `sub: a must be the full operand — b (${b.shape.elems} elems) exceeds a (${a.shape.elems})`,
    );
  }
  return elementwise('sub', a, b);
}

/** out = x + c, elementwise; add()'s scalar path. */
function addScalar(x: Value, c: number): Value {
  return pending({ ...x.shape }, 'addScalar', [x], c);
}

/** out = x · c, elementwise; mul()'s scalar path. */
function mulScalar(x: Value, c: number): Value {
  return pending({ ...x.shape }, 'mulScalar', [x], c);
}

/** Fused clamped SwiGLU activation: swiglu(glu, lin) = g·σ(1.702·g)·(l+1) with
 *  g = min(glu, 7), l = clamp(lin, ±7) — one kernel instead of the 7-op
 *  clamp/sigmoid/mul/add chain. glu and lin must share shape/dtype (both the
 *  [n, H] pre-activation halves). attrs[0]=0 (always elementwise, no broadcast). */
export function swiglu(glu: Value, lin: Value): Value {
  if (glu.shape.elems !== lin.shape.elems || glu.shape.dtype !== lin.shape.dtype) {
    throw new Error(
      `swiglu: glu/lin must match — glu=(${glu.shape.elems},${glu.shape.dtype}) lin=(${lin.shape.elems},${lin.shape.dtype})`,
    );
  }
  if (glu.shape.dtype !== 'f32' && glu.shape.dtype !== 'f16') {
    throw new Error(`swiglu: needs a float dtype, got ${glu.shape.dtype}`);
  }
  return pending({ ...glu.shape }, 'swiglu', [glu, lin], undefined, [0]);
}

/** Fused SwiGLU chunk: x [t, 2F] → [t, F], out = silu(gate) · hidden with
 *  hidden = first F columns, gate = second (HF fc1(x).chunk(2) order) — the
 *  sliceCols ×2 → silu → mul chain in ONE dispatch. Unclamped; the clamped
 *  gpt-oss variant is `swiglu`. */
export function swigluChunk(x: Value): Value {
  const [t, w, dtype] = want2dFloat('swigluChunk', x);
  if (w % 2 !== 0) throw new Error(`swigluChunk: cols ${w} must be even (hidden|gate halves)`);
  const half = w / 2;
  return pending({ elems: t * half, dtype, dims: [t, half] }, 'swigluChunk', [x]);
}

/** Ops where f(0) !== 0 must refuse hwc4 input — the padded lanes are 0. */
function refuseHwc4(name: string, x: Value): void {
  if (x.shape.layout === 'hwc4') {
    throw new Error(`${name}: refuses hwc4 input — f(0) !== 0 corrupts the zero-padded lanes`);
  }
}

/** out = 1/sqrt(x), elementwise. */
export function rsqrt(x: Value): Value {
  refuseHwc4('rsqrt', x);
  return pending({ ...x.shape }, 'rsqrt', [x]);
}

/** out = 1/(1+e^(−x)), elementwise (torch.sigmoid). */
export function sigmoid(x: Value): Value {
  refuseHwc4('sigmoid', x);
  return pending({ ...x.shape }, 'sigmoid', [x]);
}

/** out = tanh(x), elementwise (torch.tanh). */
export function tanh(x: Value): Value {
  return pending({ ...x.shape }, 'tanh', [x]);
}

/** out = x·Φ(x), elementwise — exact erf GELU (torch F.gelu default). */
export function gelu(x: Value): Value {
  return pending({ ...x.shape }, 'gelu', [x]);
}

/** out = x·σ(x), elementwise (torch F.silu / swish). */
export function silu(x: Value): Value {
  return pending({ ...x.shape }, 'silu', [x]);
}

/** out = asinh(x) = ln(x + √(x²+1)), elementwise (torch.asinh). */
export function asinh(x: Value): Value {
  return pending({ ...x.shape }, 'asinh', [x]);
}

/** out = min(max(x, lo), hi), elementwise (torch.clamp). Use ±Infinity for
 *  one-sided clamps — the executor lowers them to ±FLT_MAX. */
export function clamp(x: Value, lo: number, hi: number): Value {
  if (!(lo <= hi)) throw new Error(`clamp: lo (${lo}) must be <= hi (${hi})`);
  return pending({ ...x.shape }, 'clampScalar', [x], undefined, [lo, hi]);
}
