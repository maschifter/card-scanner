/** Reductions and normalizations over the last dim: mean, softmax, layerNorm,
 *  and the router top-k. */

import { pending, Value } from '../value.ts';
import { want2dFloat } from './shared.ts';

/** mean(x²) over the last axis: [M,N] → [M,1], squaring inside the reduction
 *  in f32. rmsNorm's statistic — composing it as mean(mul(x, x)) would
 *  materialize x² at the activation width, and an f16 x past ~256 overflows
 *  to Inf (see the kernel). */
export function meanSquare(x: Value): Value {
  const [m] = want2dFloat('meanSquare', x);
  // The RESULT stays f32 whatever the input width: mean(x²) is a statistic,
  // not an activation, and it is far larger than the values it summarises —
  // an activation of 5340 (pf block 7) gives 2.9e7, past f16's 65504. Its
  // reciprocal square root IS representable in f16, so rmsNorm narrows there.
  return pending({ elems: m, dtype: 'f32', dims: [m, 1] }, 'meanSquare', [x]);
}

/** Mean over the last axis of a 2D float matrix [M,N] → [M,1]. */
export function mean(x: Value): Value {
  const [m, , dtype] = want2dFloat('mean', x);
  return pending({ elems: m, dtype, dims: [m, 1] }, 'mean', [x]);
}

/** Row-wise softmax over the last dim of a 2D float matrix [rows, cols]. */
export function softmax(x: Value): Value {
  const [m, n, dtype] = want2dFloat('softmax', x);
  return pending({ elems: m * n, dtype, dims: [m, n] }, 'softmax', [x]);
}

/** Fused LayerNorm over the last dim: x[M,N], weight[N] → (x − mean(x, -1)) ·
 *  rsqrt(var(x, -1) + eps) · weight (+ bias[N]) — torch F.layer_norm semantics
 *  (biased 1/N variance), with an optional additive bias like torch's
 *  elementwise affine. ONE kernel; eps rides the uniform (no pipeline key),
 *  carried as the node's scalar like addScalar's constant. */
export function layerNorm(x: Value, weight: Value, eps = 1e-5, bias?: Value): Value {
  const [m, n, dtype] = want2dFloat('layerNorm', x);
  if (weight.shape.dtype !== dtype || weight.shape.elems !== n) {
    throw new Error(
      `layerNorm: weight must be ${dtype} [N] = ${n} elems, got (${weight.shape.elems},${weight.shape.dtype})`,
    );
  }
  if (bias !== undefined && (bias.shape.dtype !== dtype || bias.shape.elems !== n)) {
    throw new Error(
      `layerNorm: bias must be ${dtype} [N] = ${n} elems, got (${bias.shape.elems},${bias.shape.dtype})`,
    );
  }
  if (!(eps > 0)) throw new Error(`layerNorm: eps must be positive, got ${eps}`);
  const inputs = bias !== undefined ? [x, weight, bias] : [x, weight];
  return pending({ elems: m * n, dtype, dims: [m, n] }, 'layerNorm', inputs, eps);
}

/** Router top-k selection (torch.topk parity: strict `>` keeps the lowest
 *  index on ties) PLUS softmax over the selected logits. Packed output
 *  [M, 2k]: cols [0,k) = expert ids (as f32), cols [k,2k) = weights,
 *  descending by logit. Only k=4 is implemented (unrolled kernel). */
export function topk(x: Value, k: number): Value {
  const [m, n] = want2dFloat('topk', x);
  if (k !== 4) throw new Error(`topk: only k=4 is supported, got ${k}`);
  if (n < k) throw new Error(`topk: need at least ${k} columns, got ${n}`);
  return pending({ elems: m * 2 * k, dtype: 'f32', dims: [m, 2 * k] }, 'topk', [x]);
}
