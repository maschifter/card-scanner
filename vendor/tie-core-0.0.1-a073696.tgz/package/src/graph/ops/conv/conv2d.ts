import { hwc4Meta, pending, Value } from '../../value.ts';
import { isHwc4 } from '../shared.ts';

/** 2D convolution over HWC4-stored [C_in,H,W] f16 activations —
 *  torch-shaped surface, hwc4 storage: x enters via toHwc4 (models do it
 *  once at the input boundary), the weight is nn.Conv2d's mat4-tile packing
 *  (meta tagged 'hwc4'), bias is f16 (model.half()), and the output stays
 *  hwc4. Groups are 1 or fully depthwise — the shapes the kernel family
 *  covers. `kernelSize` is an int k (k×k) or [kH, kW] (torch-style),
 *  declared and cross-checked against the weight. `act` fuses a SiLU
 *  epilogue (x·σ(x)). attrs: [kH, kW, stride, padding, groups, hasBias,
 *  hasAct] */
export function conv2d(
  x: Value,
  weight: Value,
  bias: Value | undefined,
  opts: {
    kernelSize: number | [number, number];
    stride: number;
    padding: number;
    groups: number;
    act?: boolean;
  },
): Value {
  if (!isHwc4(x)) {
    throw new Error(
      `conv2d: input must be hwc4-stored (got layout=${x.shape.layout ?? 'row-major'}, dtype=${x.shape.dtype}) — convert with toHwc4() at the model boundary`,
    );
  }
  const [cIn, h, w] = x.shape.dims! as [number, number, number];
  const { kernelSize, stride, padding, groups } = opts;
  const [kH, kW] = typeof kernelSize === 'number' ? [kernelSize, kernelSize] : kernelSize;
  if (!Number.isInteger(kH) || kH < 1 || !Number.isInteger(kW) || kW < 1) {
    throw new Error(`conv2d: kernelSize must be positive integer(s), got ${kH}×${kW}`);
  }
  const dw = groups === cIn;
  if (groups !== 1 && !(dw && weight.shape.dims![0] === cIn)) {
    throw new Error(
      `conv2d: groups=${groups} is neither 1 nor depthwise (cIn=${cIn}, cOut=${weight.shape.dims![0]})`,
    );
  }
  const wd = weight.shape.dims;
  if (weight.shape.dtype !== 'f16' || !wd || wd.length !== 2 || weight.shape.layout !== 'hwc4') {
    throw new Error(
      'conv2d: weight must be the hwc4 mat4-tile packing (nn.Conv2d repacks at load) — an unpacked weight would be read as tiles',
    );
  }
  const [cOut, cin_kk] = wd as [number, number];
  if (cin_kk !== (cIn / groups) * kH * kW) {
    throw new Error(
      `conv2d: weight cols ${cin_kk} != C_in/groups·kH·kW = ${cIn / groups}·${kH}·${kW}`,
    );
  }
  if (bias !== undefined && (bias.shape.dtype !== 'f16' || bias.shape.elems !== cOut)) {
    throw new Error(`conv2d: bias must be f16 with ${cOut} elems (call model.half())`);
  }
  const hOut = Math.floor((h + 2 * padding - kH) / stride) + 1;
  const wOut = Math.floor((w + 2 * padding - kW) / stride) + 1;
  const inputs: Value[] = bias !== undefined ? [x, weight, bias] : [x, weight];
  return pending(hwc4Meta(cOut, hOut, wOut), 'conv2dHwc4', inputs, undefined, [
    kH,
    kW,
    stride,
    padding,
    groups,
    bias !== undefined ? 1 : 0,
    opts.act ? 1 : 0,
  ]);
}
