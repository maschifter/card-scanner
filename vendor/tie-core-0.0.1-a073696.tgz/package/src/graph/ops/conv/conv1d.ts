import { pending, Value } from '../../value.ts';
import { ACT_CODE, want2dFloat } from '../shared.ts';

/** Strided 1-D convolution, time-major: x=[T_in, C_in] (frames as rows,
 *  channels as cols), w=[kernelSize·C_in, C_out] (rows tap-major: row =
 *  tap·C_in + c_in) → [T_out, C_out] with T_out =
 *  floor((T_in + padLeft + padRight − kernelSize)/stride) + 1.
 *  padLeft/padRight (default 0) add that many implicit zero frames before/
 *  after the input; window taps landing on them contribute nothing.
 *  padLeft = kernelSize−1 makes the conv causal — every output frame sees
 *  only its own and earlier inputs (torch: F.pad(x, (k−1, 0)) then conv).
 *  `padding` is torch Conv1d's padding argument: a number p sets
 *  padLeft = padRight = p; 'valid' sets both to 0; 'same' keeps T_out equal
 *  to T_in (stride 1 only, as in torch), with the extra zero on the right
 *  when kernelSize is even. Giving padding together with padLeft/padRight
 *  is an error. Every pad must stay below kernelSize (torch allows more):
 *  an output frame computed from padding alone is a model bug, not a
 *  boundary. torch: F.conv1d on a (1, C_in, T) view with the weight
 *  permuted (C_out,C_in,k) → (k,C_in,C_out) and flattened — time-major
 *  output makes the usual channels↔time permute a no-op in this engine's
 *  2D world.
 *
 *  Optional fused epilogue, like matmul's: `bias` [C_out] folds the
 *  row-broadcast bias add and `activation` a following tanh / exact-GELU
 *  into the same dispatch — `act(conv + bias)`, the conv → add → activation
 *  chain in one kernel. Both are comptime pipeline variants; the extra
 *  operand appends to inputs after w. */
export function conv1d(
  x: Value,
  w: Value,
  opts: {
    kernelSize: number;
    stride: number;
    padding?: number | 'valid' | 'same';
    padLeft?: number;
    padRight?: number;
    bias?: Value;
    activation?: 'tanh' | 'gelu';
  },
): Value {
  const { kernelSize, stride, padding, bias, activation } = opts;
  if (padding !== undefined && (opts.padLeft !== undefined || opts.padRight !== undefined)) {
    throw new Error('conv1d: padding excludes padLeft/padRight — give one form or the other');
  }
  const [tIn, cIn, dtype] = want2dFloat('conv1d', x);
  const [wRows, cOut, wDtype] = want2dFloat('conv1d.w', w);
  if (wDtype !== dtype) {
    throw new Error(`conv1d: weight dtype ${wDtype} must match the input's ${dtype}`);
  }
  if (!Number.isInteger(kernelSize) || kernelSize < 1 || !Number.isInteger(stride) || stride < 1) {
    throw new Error(
      `conv1d: kernelSize ${kernelSize} and stride ${stride} must be positive integers`,
    );
  }
  let padLeft: number;
  let padRight: number;
  if (padding === 'valid') {
    padLeft = 0;
    padRight = 0;
  } else if (padding === 'same') {
    if (stride !== 1) {
      throw new Error(`conv1d: padding 'same' requires stride 1, got ${stride}`);
    }
    padLeft = Math.floor((kernelSize - 1) / 2);
    padRight = kernelSize - 1 - padLeft;
  } else {
    padLeft = padding ?? opts.padLeft ?? 0;
    padRight = padding ?? opts.padRight ?? 0;
  }
  for (const [name, pad] of [
    ['padLeft', padLeft],
    ['padRight', padRight],
  ] as const) {
    if (!Number.isInteger(pad) || pad < 0 || pad >= kernelSize) {
      const given = typeof padding === 'number' ? `padding ${padding}` : `${name} ${pad}`;
      throw new Error(`conv1d: ${given} must be an integer in [0, kernelSize)`);
    }
  }
  if (wRows !== kernelSize * cIn) {
    throw new Error(`conv1d: w rows ${wRows} != kernelSize·C_in = ${kernelSize}·${cIn}`);
  }
  if (tIn + padLeft + padRight < kernelSize) {
    throw new Error(
      `conv1d: padded frames ${tIn}+${padLeft}+${padRight} < kernelSize ${kernelSize} — no output`,
    );
  }
  if (bias && (bias.shape.dtype !== dtype || bias.shape.elems !== cOut)) {
    throw new Error(
      `conv1d: bias must be ${dtype} [C_out] = ${cOut} elems, got (${bias.shape.elems},${bias.shape.dtype})`,
    );
  }
  const act = activation ? ACT_CODE[activation] : 0;
  const tOut = Math.floor((tIn + padLeft + padRight - kernelSize) / stride) + 1;
  return pending(
    { elems: tOut * cOut, dtype, dims: [tOut, cOut] },
    'conv1d',
    [x, w, ...(bias ? [bias] : [])],
    undefined,
    [kernelSize, stride, padLeft, padRight, bias ? 1 : 0, act],
  );
}
