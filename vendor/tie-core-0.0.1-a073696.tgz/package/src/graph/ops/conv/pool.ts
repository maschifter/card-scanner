/** Weightless spatial ops on HWC4-stored image tensors: max pooling and
 *  nearest-neighbor upsampling. Row-major inputs must enter via toHwc4 like
 *  the convs they surround. */

import { hwc4Meta, pending, Value } from '../../value.ts';
import { isHwc4 } from '../shared.ts';

function wantHwc4(name: string, x: Value): [number, number, number] {
  if (!isHwc4(x)) {
    throw new Error(
      `${name}: input must be hwc4-stored (got layout=${x.shape.layout ?? 'row-major'}) — convert with toHwc4() at the model boundary`,
    );
  }
  return x.shape.dims! as [number, number, number];
}

/** 2D max pooling: x=[C,H,W] → [C, H_out, W_out] (torch: max_pool2d).
 *  attrs: [kernelSize, stride, padding] */
export function maxPool2d(
  x: Value,
  opts: { kernelSize: number; stride: number; padding: number },
): Value {
  const [c, h, w] = wantHwc4('maxPool2d', x);
  const { kernelSize, stride, padding } = opts;
  if (kernelSize < 1 || stride < 1 || padding < 0 || padding > kernelSize / 2) {
    throw new Error(
      `maxPool2d: bad geometry k=${kernelSize} stride=${stride} padding=${padding} (torch requires padding <= k/2)`,
    );
  }
  const hOut = Math.floor((h + 2 * padding - kernelSize) / stride) + 1;
  const wOut = Math.floor((w + 2 * padding - kernelSize) / stride) + 1;
  if (hOut < 1 || wOut < 1) {
    throw new Error(`maxPool2d: window k=${kernelSize} larger than padded input ${h}×${w}`);
  }
  return pending(hwc4Meta(c, hOut, wOut), 'maxPool2dHwc4', [x], undefined, [
    kernelSize,
    stride,
    padding,
  ]);
}

/** Nearest-neighbor upsample: x=[C,H,W] → [C, H·scale, W·scale]. Integer scale
 *  only (torch: interpolate(mode='nearest')). attrs: [scale] */
export function upsample2d(x: Value, opts: { scale: number }): Value {
  const [c, h, w] = wantHwc4('upsample2d', x);
  const { scale } = opts;
  if (!Number.isInteger(scale) || scale < 1) {
    throw new Error(`upsample2d: scale must be a positive integer, got ${scale}`);
  }
  return pending(hwc4Meta(c, h * scale, w * scale), 'upsample2dHwc4', [x], undefined, [scale]);
}
