/** Attention ops: banded/causal/cross sdpa with GQA and sinks, and the fused
 *  rotary embedding. */

import { pending, Value } from '../value.ts';
import { want2dFloat } from './shared.ts';

/** Finite stand-in for an unbounded window side (the engine bans ±Inf in
 *  attrs/uniforms); ≤ 2^30 so kernel index arithmetic can't overflow u32. */
const WINDOW_INF = 0x3fffffff;

/** Banded/causal/cross scaled-dot-product attention — torch's
 *  F.scaled_dot_product_attention restricted to the band-mask family, plus
 *  optional attention sinks. q [qLen, qHeads·hd], k/v [kvLen, kvHeads·hd]
 *  with kvLen independent of qLen, optional sinks [qHeads] (log2-space) →
 *  out [qLen, qHeads·hd]. Key j is visible to query row i iff
 *  qPos − windowLeft ≤ j ≤ qPos + windowRight with qPos = qPosOffset + i:
 *  causal = (Infinity, 0), full/cross = (Infinity, Infinity), symmetric band
 *  = (W, W); Infinity lowers to a finite sentinel. Optional `segments` (f32
 *  [qLen, 2], row-major start/end-exclusive key indices, end ≥ 1) further
 *  clips each row's visible keys to its own range — batching mask for
 *  sequences packed row-wise into one tensor: rows of sentence b carry
 *  [start_b, end_b), so attention never crosses sentence boundaries while
 *  every other op treats the pack as one matrix. Head geometry + band are
 *  pipeline-cfg material (attrs[0..4]); qPosOffset rides attrs[5] into the
 *  Dims uniform so incremental decode never mints a pipeline key. attrs[6]
 *  is the hasSinks flag and attrs[7] the hasSegments flag (0|1), each
 *  selecting a comptime kernel variant. `maxSegment` (attrs[8], 0 = unknown)
 *  is the longest segment: with segments no row scans more keys than that,
 *  so the evaluator plans its key split from it instead of the whole pack
 *  length — a pack of short sentences skips the split entirely. */
export function sdpa(
  q: Value,
  k: Value,
  v: Value,
  opts: {
    qHeads: number;
    kvHeads: number;
    headDim: number;
    windowLeft: number;
    windowRight: number;
    qPosOffset?: number;
    sinks?: Value;
    segments?: Value;
    maxSegment?: number;
  },
): Value {
  const { qHeads, kvHeads, headDim, sinks, segments } = opts;
  const qPosOffset = opts.qPosOffset ?? 0;
  const [qLen, qw, dtype] = want2dFloat('sdpa', q);
  if (qw !== qHeads * headDim)
    throw new Error(`sdpa: q cols ${qw} != qHeads*headDim ${qHeads * headDim}`);
  if (kvHeads <= 0 || qHeads % kvHeads !== 0) {
    throw new Error(`sdpa: qHeads ${qHeads} not divisible by kvHeads ${kvHeads}`);
  }
  if (headDim > 128) throw new Error(`sdpa: headDim ${headDim} exceeds the kernel's max (128)`);
  const lowerWindow = (name: string, w: number): number => {
    if (w === Infinity) return WINDOW_INF;
    if (!Number.isInteger(w) || w < 0) {
      throw new Error(`sdpa: ${name} ${w} must be a non-negative integer or Infinity`);
    }
    return Math.min(w, WINDOW_INF);
  };
  const wl = lowerWindow('windowLeft', opts.windowLeft);
  const wr = lowerWindow('windowRight', opts.windowRight);
  if (!Number.isInteger(qPosOffset) || qPosOffset < 0) {
    throw new Error(`sdpa: qPosOffset ${qPosOffset} must be a non-negative integer`);
  }
  const kvw = kvHeads * headDim;
  const [kvLen, kw, kDtype] = want2dFloat('sdpa.k', k);
  if (kw !== kvw) throw new Error(`sdpa: k cols ${kw} != kvHeads*headDim ${kvw}`);
  const [vt, vw, vDtype] = want2dFloat('sdpa.v', v);
  // One element type per kernel: q, k and v must agree. sinks and segments
  // stay f32 in every variant (see attn.ts) — segments carries integer key
  // ranges that f16 stops representing exactly past 2048.
  if (kDtype !== dtype || vDtype !== dtype) {
    throw new Error(`sdpa: q, k and v must share a dtype, got ${dtype}/${kDtype}/${vDtype}`);
  }
  if (vt !== kvLen) throw new Error(`sdpa: v rows ${vt} != k rows ${kvLen}`);
  if (vw !== kvw) throw new Error(`sdpa: v cols ${vw} != kvHeads*headDim ${kvw}`);
  // Under a bounded right window every q position must map into the key axis —
  // rows past kvLen with nothing new to see are a forgotten-offset bug, not a mask.
  // Unbounded-right (full/cross) is exempt: qPos is irrelevant there.
  if (wr !== WINDOW_INF && qPosOffset + qLen > kvLen) {
    throw new Error(`sdpa: qPosOffset+qLen ${qPosOffset + qLen} exceeds key rows kvLen ${kvLen}`);
  }
  if (sinks && (sinks.shape.dtype !== 'f32' || sinks.shape.elems !== qHeads)) {
    throw new Error(`sdpa: sinks must be f32 with ${qHeads} elems, got ${sinks.shape.elems}`);
  }
  if (segments) {
    if (segments.shape.dtype !== 'f32' || segments.shape.elems !== 2 * qLen) {
      throw new Error(
        `sdpa: segments must be f32 [qLen, 2] = ${2 * qLen} elems, got (${segments.shape.elems},${segments.shape.dtype})`,
      );
    }
    // The qLen = 1 route is the decode kernel pair, which has no segment
    // support — and a one-row pack has nothing to mask anyway.
    if (qLen === 1) throw new Error('sdpa: segments need qLen > 1 (decode has no segment route)');
  }
  const maxSegment = opts.maxSegment ?? 0;
  if (maxSegment !== 0) {
    if (!segments) throw new Error('sdpa: maxSegment needs segments');
    if (!Number.isInteger(maxSegment) || maxSegment < 1) {
      throw new Error(`sdpa: maxSegment ${maxSegment} must be a positive integer`);
    }
  }
  return pending(
    { elems: qLen * qw, dtype, dims: [qLen, qw] },
    'attn',
    [q, k, v, ...(sinks ? [sinks] : []), ...(segments ? [segments] : [])],
    undefined,
    [qHeads, kvHeads, headDim, wl, wr, qPosOffset, sinks ? 1 : 0, segments ? 1 : 0, maxSegment],
  );
}

/** sdpa over one fused qkv tensor read in place: [T, (qHeads+2·kvHeads)·hd]
 *  with q | k | v as column blocks — exactly what a fused qkv projection
 *  produces (flash-attn's qkvpacked shape). Self-attention only (kvLen =
 *  qLen); the kernels read the blocks by column offset, so the three
 *  sliceCols copies never run. Same band/sinks/segments rules as sdpa;
 *  attrs[9] = 1 marks the layout. No qLen = 1 route — packs are an encoder
 *  shape. */
export function sdpaPacked(
  qkv: Value,
  opts: {
    qHeads: number;
    kvHeads: number;
    headDim: number;
    windowLeft: number;
    windowRight: number;
    qPosOffset?: number;
    sinks?: Value;
    segments?: Value;
    maxSegment?: number;
  },
): Value {
  const { qHeads, kvHeads, headDim, sinks, segments } = opts;
  const qPosOffset = opts.qPosOffset ?? 0;
  const [t, w, dtype] = want2dFloat('sdpaPacked', qkv);
  const qw = qHeads * headDim;
  const packedW = (qHeads + 2 * kvHeads) * headDim;
  if (w !== packedW) {
    throw new Error(`sdpaPacked: qkv cols ${w} != (qHeads + 2*kvHeads)*headDim = ${packedW}`);
  }
  if (kvHeads <= 0 || qHeads % kvHeads !== 0) {
    throw new Error(`sdpaPacked: qHeads ${qHeads} not divisible by kvHeads ${kvHeads}`);
  }
  if (headDim > 128) {
    throw new Error(`sdpaPacked: headDim ${headDim} exceeds the kernel's max (128)`);
  }
  if (t === 1) throw new Error('sdpaPacked: qLen must be > 1 (decode has no packed route)');
  const lowerWindow = (name: string, win: number): number => {
    if (win === Infinity) return WINDOW_INF;
    if (!Number.isInteger(win) || win < 0) {
      throw new Error(`sdpaPacked: ${name} ${win} must be a non-negative integer or Infinity`);
    }
    return Math.min(win, WINDOW_INF);
  };
  const wl = lowerWindow('windowLeft', opts.windowLeft);
  const wr = lowerWindow('windowRight', opts.windowRight);
  if (!Number.isInteger(qPosOffset) || qPosOffset < 0) {
    throw new Error(`sdpaPacked: qPosOffset ${qPosOffset} must be a non-negative integer`);
  }
  if (wr !== WINDOW_INF && qPosOffset + t > t) {
    throw new Error(`sdpaPacked: qPosOffset+qLen ${qPosOffset + t} exceeds key rows kvLen ${t}`);
  }
  if (sinks && (sinks.shape.dtype !== 'f32' || sinks.shape.elems !== qHeads)) {
    throw new Error(`sdpaPacked: sinks must be f32 with ${qHeads} elems, got ${sinks.shape.elems}`);
  }
  if (segments && (segments.shape.dtype !== 'f32' || segments.shape.elems !== 2 * t)) {
    throw new Error(
      `sdpaPacked: segments must be f32 [qLen, 2] = ${2 * t} elems, got (${segments.shape.elems},${segments.shape.dtype})`,
    );
  }
  const maxSegment = opts.maxSegment ?? 0;
  if (maxSegment !== 0) {
    if (!segments) throw new Error('sdpaPacked: maxSegment needs segments');
    if (!Number.isInteger(maxSegment) || maxSegment < 1) {
      throw new Error(`sdpaPacked: maxSegment ${maxSegment} must be a positive integer`);
    }
  }
  return pending(
    { elems: t * qw, dtype, dims: [t, qw] },
    'attn',
    [qkv, ...(sinks ? [sinks] : []), ...(segments ? [segments] : [])],
    undefined,
    [qHeads, kvHeads, headDim, wl, wr, qPosOffset, sinks ? 1 : 0, segments ? 1 : 0, maxSegment, 1],
  );
}

/** Rotary position embedding over all head sections of x [T, W] in ONE kernel
 *  (W % headDim == 0) — the mx.fast.rope analog. Interleaved-pair rotation per
 *  64-ish-wide head section; cos/sin are [T, headDim] pair-duplicated tables
 *  with any scale pre-folded (see the kernel doc). torch/MLX: a fused rotary
 *  embedding, replacing the per-head slice→(x@P)→mul→add composition.
 *
 *  Optional column window: srcStart + width read a slice of a wider slab
 *  (e.g. the q or k section of a fused [T, 3·qw] qkv) and rope it in the SAME
 *  dispatch — output [T, width]. Both are weight-geometry constants riding
 *  the pipeline config (attrs [headDim, srcStart, width]). */
export function rope(
  x: Value,
  cos: Value,
  sin: Value,
  opts: { headDim: number; srcStart?: number; width?: number },
): Value {
  const { headDim } = opts;
  const [t, xw, dtype] = want2dFloat('rope', x);
  const srcStart = opts.srcStart ?? 0;
  const w = opts.width ?? xw;
  if (!Number.isInteger(headDim) || headDim <= 0 || headDim % 2 !== 0) {
    throw new Error(`rope: headDim ${headDim} must be a positive even integer`);
  }
  if (!Number.isInteger(srcStart) || srcStart < 0 || srcStart % 2 !== 0) {
    throw new Error(`rope: srcStart ${srcStart} must be a non-negative even integer`);
  }
  if (!Number.isInteger(w) || w <= 0 || srcStart + w > xw) {
    throw new Error(`rope: window [${srcStart}, ${srcStart + w}) exceeds ${xw} input cols`);
  }
  if (w % headDim !== 0)
    throw new Error(`rope: width ${w} must be a multiple of headDim ${headDim}`);
  for (const [name, v] of [['cos', cos] as const, ['sin', sin] as const]) {
    if (v.shape.dtype !== 'f32' || v.shape.elems !== t * headDim) {
      throw new Error(
        `rope: ${name} must be f32 [T,headDim] = ${t * headDim} elems, got ${v.shape.elems}`,
      );
    }
  }
  return pending({ elems: t * w, dtype, dims: [t, w] }, 'rope', [x, cos, sin], undefined, [
    headDim,
    srcStart,
    w,
  ]);
}
