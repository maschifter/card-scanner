import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  type F32Buffer,
  flatIndex,
  type KernelHandle,
  makeHandle,
  WORKGROUP_SIZE,
} from '../common.ts';
import { cachedBindGroup, cachedUniform } from '../../gpu/dispatchCache.ts';
import { type Elem, F32_ELEM } from '../elem.ts';

const Dims = d.struct({ rows: d.u32, cols: d.u32 });

/** Row-wise softmax over [rows, cols], row-major. One invocation per row;
 *  (rows,cols) is a uniform → one pipeline for all shapes. Three passes over
 *  the row: running max, sum of exp(x − max), then exp again over the divide.
 *
 *  The second exp is deliberate. MEASURED DUD (2026-08-31): staging pass 2's
 *  exp into `out` and rescaling it in place — one exp per element instead of
 *  two — costs 1.02-1.07x on every shape tried (400x400 real PSA, 100x100,
 *  1024x1024, 4096x256, 64x8192; timestamp-query, 50 dispatches/burst,
 *  median of 7, A/B order alternated). The kernel is memory-bound, so the
 *  extra global write + read outweighs the saved exp. Alias-safety is not a
 *  reason to stage either: pass 3 reads x[base+j] before writing out[base+j]
 *  in the same statement and each thread owns its whole row, so `out`
 *  aliasing `x` is already correct here.
 *
 *  Built per storage dtype: the running max and sum stay f32 in both
 *  variants — they accumulate over a whole row, and an f16 sum saturates
 *  long before the row does. Only the stored quotients round to the storage
 *  dtype. */
function makeSoftmaxVariant(elem: Elem) {
  const layout = tgpu.bindGroupLayout({
    x: { storage: d.arrayOf(elem.scalar), access: 'readonly' },
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' },
    dims: { uniform: Dims },
  });
  const storeScalar = elem.scalar;
  const kernel = tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const rows = layout.$.dims.rows;
    const cols = layout.$.dims.cols;
    const row = flatIndex(gid);
    if (row >= rows) return;
    const base = row * cols;
    let m = d.f32(layout.$.x[base]!);
    for (let j = d.u32(1); j < cols; j++) {
      m = std.max(m, d.f32(layout.$.x[base + j]!));
    }
    let sum = d.f32(0);
    for (let j = d.u32(0); j < cols; j++) {
      sum += std.exp(d.f32(layout.$.x[base + j]!) - m);
    }
    for (let j = d.u32(0); j < cols; j++) {
      layout.$.out[base + j] = storeScalar(std.exp(d.f32(layout.$.x[base + j]!) - m) / sum);
    }
  });
  return { layout, kernel };
}

const variants = new Map<string, ReturnType<typeof makeSoftmaxVariant>>();
export function softmaxVariant(elem: Elem): ReturnType<typeof makeSoftmaxVariant> {
  let v = variants.get(elem.key);
  if (!v) {
    v = makeSoftmaxVariant(elem);
    variants.set(elem.key, v);
  }
  return v;
}

export function createSoftmaxPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: softmaxVariant(elem).kernel });
}

export function softmaxHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createSoftmaxPipeline>,
  rows: number,
  cols: number,
  buffers: { x: F32Buffer; out: F32Buffer },
  elem: Elem = F32_ELEM,
): KernelHandle {
  const dims = cachedUniform(root, Dims, { rows, cols });
  const bindGroup = cachedBindGroup(root, softmaxVariant(elem).layout, { ...buffers, dims });
  return makeHandle(pipeline, 'softmax', bindGroup, Math.ceil(rows / WORKGROUP_SIZE));
}
