import { d, std } from 'typegpu';

/** THE physical layout contract for quantW weight buffers, shared by
 *  packQuantColSlice (producer) and matmulQuantW / matmulGatherQuantW
 *  (consumers). Change it in one place or not at all.
 *
 *  BLOCKED-UNIT layout: the logical [E·K, N] weight is stored as tiles of
 *  16 values — one tile per (expert e, 4-col unit n = cols 4n..4n+3, 4-row
 *  chunk k4 = rows 4k4..4k4+3). Within a tile, values are col-major (col j's
 *  4 values contiguous, low k in low bits) and packed sequentially at `bits`
 *  stride, so a tile spans bits/2 whole u32 words (int8: 4, int4: 2) and a
 *  column's 4 values never straddle a word. Tiles are laid out k4-major per
 *  (e, n): tile word base = ((e·N/4 + n)·K/4 + k4)·(bits/2).
 *
 *  Why: one thread owning a 4-col unit streams its whole weight run
 *  SEQUENTIALLY (K-contiguous) and dots each x vec4 against 4 words — the
 *  legacy moeQuant inner-loop shape, measured 2.4× over the previous
 *  N-contiguous rows at MoE dims. Scales/biases are unaffected: scales stay
 *  [E·KG, N] (a unit's 4 scales adjacent), biases [E, N]. */

/** Sign-extend 4 packed ints of `word` starting at bit `off`, each `bits`
 *  wide (col j's tile lane: off = (j·4·bits) & 31, word = base + (j·4·bits)>>5). */
export const deqVec4 = (word: number, off: number, bits: number) => {
  'use gpu';
  const w = std.bitcastU32toI32(word);
  return d.vec4f(
    d.f32(std.extractBits(w, off, bits)),
    d.f32(std.extractBits(w, off + bits, bits)),
    d.f32(std.extractBits(w, off + 2 * bits, bits)),
    d.f32(std.extractBits(w, off + 3 * bits, bits)),
  );
};
