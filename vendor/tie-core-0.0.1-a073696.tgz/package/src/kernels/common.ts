import { d } from 'typegpu';
import type { StorageFlag, TgpuBindGroup, TgpuBuffer, TgpuComputePipeline } from 'typegpu';

export const WORKGROUP_SIZE = 64;

/** WebGPU's hard cap on workgroups per dispatch dimension (a device limit,
 *  65535 everywhere in practice — assert it against
 *  device.limits.maxComputeWorkgroupsPerDimension if you ever doubt it).
 *  Dispatches above this are REJECTED and their command buffer dropped, so
 *  the executor splits flat 1-D dispatches into a 2-D grid of exactly
 *  MAX_WORKGROUPS_PER_DIM columns; kernels dispatching one workgroup per
 *  work item either stay under it or emit an [x, y] pair themselves. */
export const MAX_WORKGROUPS_PER_DIM = 65535;

/** Threads covered by one y-slice of that split, AT A GIVEN WORKGROUP SIZE.
 *  The executor splits in workgroups, so the thread stride is
 *  MAX_WORKGROUPS_PER_DIM · workgroupSize — a kernel compiled at 256 threads
 *  per workgroup has a 4× wider slice than one at 64, and using the wrong
 *  one folds to the wrong element. Derived, NOT a magic number: it is only
 *  correct because the executor splits at exactly MAX_WORKGROUPS_PER_DIM
 *  columns, so the two are defined together here and used by both sides.
 *  Verified end-to-end in test/gpu/dispatchFold.test.ts. */
export const gridYStride = (workgroupSize: number) => MAX_WORKGROUPS_PER_DIM * workgroupSize;

/** The default-workgroup-size stride, for the kernels (nearly all of them)
 *  compiled at WORKGROUP_SIZE. */
export const GRID_Y_STRIDE = gridYStride(WORKGROUP_SIZE); // 4_194_240

/** THE flat index for a one-thread-per-element kernel: gid.x alone is only
 *  the x-slice, so the executor's 2-D split (see gridYStride) has to be
 *  folded back in or every element past one slice goes unwritten while the
 *  first slice is written twice — silently, since an over-cap dispatch is
 *  legal once split. Every flat kernel calls this instead of reading gid.x,
 *  so the fold is one grep and cannot be forgotten in a new kernel.
 *  The stride is a JS constant, so it inlines as a WGSL literal.
 *
 *  Take the factory when one body is compiled at more than one workgroup
 *  size (conv1x1's v4 body runs at both 64 and 256): the fold must match the
 *  size the pipeline was built with, so parameterize the BODY and pass the
 *  same number to both. `flatIndex` is the WORKGROUP_SIZE instance. */
export const makeFlatIndex = (workgroupSize: number) => {
  const stride = gridYStride(workgroupSize);
  return (gid: d.v3u): number => {
    'use gpu';
    return gid.x + gid.y * stride;
  };
};
export const flatIndex = makeFlatIndex(WORKGROUP_SIZE);

/** THE workgroup index for a one-workgroup-per-tile kernel — the tiled and
 *  channel-blocked convs, which derive their tile from the workgroup rather
 *  than from a per-element index. Same fold as flatIndex, one level up:
 *  gid.x / workgroupSize only numbers the x-slice, so each y adds a full
 *  MAX_WORKGROUPS_PER_DIM columns. gid.x stays below 2^24, so the divide is
 *  exact. Lane-within-workgroup must come from localInvocationIndex, never
 *  from gid.x % workgroupSize, for the same reason. Same factory rule as
 *  flatIndex: the size here must be the pipeline's own.
 *  Verified end-to-end in test/gpu/dispatchFold.test.ts. */
export const makeFlatWorkgroup =
  (workgroupSize: number) =>
  (gid: d.v3u): number => {
    'use gpu';
    return d.u32(gid.x / workgroupSize) + gid.y * MAX_WORKGROUPS_PER_DIM;
  };
export const flatWorkgroup = makeFlatWorkgroup(WORKGROUP_SIZE);

/** INTEGER DIVISION CEILING. TypeGPU has no integer divide: both
 *  `d.u32(a / b)` and `std.div(a, b)` emit `u32(f32(a) / f32(b))`, so the
 *  numerator must stay below f32's exact-integer range, 2^24 = 16_777_216.
 *  Above it `f32(a)` rounds and the quotient can land one off. Every
 *  `d.u32(i / cols)` index split in these kernels inherits that bound.
 *  Flat one-thread-per-element kernels are capped at GRID_Y_STRIDE (4.19M)
 *  well below it, but the 2-D-folded ones (columns.ts, rows.ts, unary.ts,
 *  elementwiseF32.ts) legitimately run past 4.19M and only stop being exact
 *  at 16.7M elements — a 4096x4096 f32 activation sits right on that line. */

export interface KernelHandle {
  pipeline: TgpuComputePipeline;
  bindGroup: TgpuBindGroup;
  /** Workgroup count: an x count, or [x, y] for kernels that spread work
   *  across two grid axes (each axis is limited to 65535). */
  workgroups: number | readonly [number, number];
  /** Kernel family + optional shape detail — keys per-op perf aggregation. */
  name: string;
}

export type V4Buffer = TgpuBuffer<d.WgslArray<d.Vec4f>> & StorageFlag;
export type U32Buffer = TgpuBuffer<d.WgslArray<d.U32>> & StorageFlag;
export type F32Buffer = TgpuBuffer<d.WgslArray<d.F32>> & StorageFlag;
export type F16Buffer = TgpuBuffer<d.WgslArray<d.F16>> & StorageFlag;

/**
 * Assemble the uniform KernelHandle: label the pipeline (Dawn errors then
 * name the kernel) and pair it with its bind group. Callers create the
 * pipeline themselves so accessor/slot `root.with(...)` bindings stay
 * precisely typed.
 * `detail` (when given) becomes the handle's profiling name — e.g. the conv
 * shape — while the pipeline label stays the stable family name.
 */
export function makeHandle(
  pipeline: TgpuComputePipeline,
  name: string,
  bindGroup: TgpuBindGroup,
  workgroups: number | readonly [number, number],
  detail?: string,
): KernelHandle {
  return { pipeline: pipeline.$name(name), bindGroup, workgroups, name: detail ?? name };
}
