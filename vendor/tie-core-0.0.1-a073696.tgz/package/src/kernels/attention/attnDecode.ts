import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { type F32Buffer, type KernelHandle, makeHandle, WORKGROUP_SIZE } from '../common.ts';
import { type Elem, F32_ELEM } from '../elem.ts';

/** Split-K variant of the unified attention kernel (attn.ts) — same
 *  operation (banded GQA SDPA, optional sinks, sm_scale = 1), different
 *  parallelization. One WORKGROUP serves each (q row, head): its threads
 *  stride the visible key range in steps of WORKGROUP_SIZE, each keeping a
 *  private online-softmax state (m, l, acc), and the partials merge through
 *  workgroup memory — the standard flash-decoding shape. The executor picks
 *  this pipeline for qLen = 1 attn nodes (attn.ts serves qLen > 1); the math
 *  is identical to the other attn kernels, only the summation order differs
 *  (f32 results agree to ~1e-6, not bitwise).
 *
 *  Merge math for two online states: M = max(mₐ, m_b); l = lₐ·e^(mₐ−M) +
 *  l_b·e^(m_b−M); acc likewise rescaled — applied once per thread against the
 *  workgroup max, then column-summed. The output tile loops TILE columns at a
 *  time so workgroup memory stays ≤ WORKGROUP_SIZE·TILE floats regardless of
 *  headDim (≤ 128, as in the batch kernel). */

const LN2 = Math.LN2;
const MAX_HEAD_DIM = 128;
const NEG_SEED = -1e30;
/** Output columns merged per workgroup-memory round; bounds shared memory at
 *  WORKGROUP_SIZE·TILE·4 B = 8 KiB (+ 2·WORKGROUP_SIZE floats for m/l). */
const TILE = 32;

const Dims = d.struct({ qLen: d.u32, kvLen: d.u32, qPosOffset: d.u32 });

/** Head geometry and band shape: weight-determined, so it keys the pipeline
 *  and reaches the kernels as PLAIN JS NUMBERS through the factories below.
 *  An accessor Config would not do — TGSL treats accessor fields as runtime
 *  values, so `std.range(headDim)` would not compile and the accumulator
 *  could not be sized to the head. */
export interface AttnDecodeCfg {
  qHeads: number;
  kvHeads: number;
  headDim: number;
  windowLeft: number;
  windowRight: number;
  hasSinks: number; // 0 | 1 — selects the softmax seed
}

/** q/k/v/out ride the model's storage dtype; `sinks` stays f32 in every
 *  variant, exactly as in attn.ts — it is a per-head log2-space constant, not
 *  a tensor, so halving it saves nothing and costs precision at the softmax
 *  seed. The running max/sum and the value accumulator stay f32 too: they are
 *  registers and workgroup scratch, where narrowing buys no bandwidth. */
const makeDecodeLayout = (elem: Elem) =>
  tgpu.bindGroupLayout({
    q: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [qLen, qHeads·headDim]
    k: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [kvLen, kvHeads·headDim]
    v: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [kvLen, kvHeads·headDim]
    sinks: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [qHeads], log2-space; dead when hasSinks=0
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' }, // [qLen, qHeads·headDim]
    dims: { uniform: Dims },
  });

const decodeLayouts = new Map<string, ReturnType<typeof makeDecodeLayout>>();
export function attnDecodeLayoutFor(elem: Elem): ReturnType<typeof makeDecodeLayout> {
  let l = decodeLayouts.get(elem.key);
  if (!l) {
    l = makeDecodeLayout(elem);
    decodeLayouts.set(elem.key, l);
  }
  return l;
}

/** Per-thread softmax partials, merged through workgroup memory. Head-size
 *  independent, so they stay module-level and are shared by both factories. */
const partialM = tgpu.workgroupVar(d.arrayOf(d.f32, WORKGROUP_SIZE));
const partialL = tgpu.workgroupVar(d.arrayOf(d.f32, WORKGROUP_SIZE));

/** Per-kernel scratch, sized to THIS pipeline's head: the value accumulator
 *  (one per thread) and the column-merge tile. Sizing the accumulator at
 *  MAX_HEAD_DIM with a uniform trip count — what this kernel did before —
 *  spills it from registers to thread-private stack memory, and the split
 *  kernel runs 64 threads of it per workgroup. `tileOf` also collapses the
 *  merge to a single round whenever the head fits one tile, which deletes
 *  the outer loop and its std.min. */
const scratchOf = (hd: number) => ({
  acc: tgpu.privateVar(d.arrayOf(d.f32, paddedFor(hd))),
  tile: tgpu.workgroupVar(d.arrayOf(d.f32, WORKGROUP_SIZE * tileFor(hd))),
});

/** Smallest exact divisor worth keeping. Below this the divisor rule idles
 *  most of the workgroup, and one round per remaining element costs more than
 *  the clamp it avoids — see tileFor. */
const MIN_EXACT_TILE = 8;

/** Merge-tile width: the largest divisor of the head that fits TILE, falling
 *  back to a clamped TILE when the head has no divisor that wide.
 *
 *  Dividing EXACTLY is worth preferring — the last round is then as full as
 *  every other one and the per-round width comparison folds away. But sdpa
 *  accepts any headDim <= 128, and a head with no wide divisor collapses the
 *  tile to nothing: 74 = 2*37 gives tile 2 and a prime head gives tile 1, so
 *  62 of 64 threads idle and the merge runs a round per element.
 *
 *  Measured on M-series (256 keys, 8 heads, timestamp-query, median of 5),
 *  divisor rule vs always-clamp:
 *      hd  64 (32)   26.6us / 26.4us     hd  80 (20)   31.9us / 34.2us
 *      hd 128 (32)   37.1us / 36.7us     hd  40 (20)   18.3us / 19.9us
 *      hd  96 (32)   38.4us / 37.8us     hd  74  (2)   52.0us / 37.4us
 *                                        hd  67  (1)   52.6us / 43.6us
 *  So neither rule wins outright: a wide divisor (20 and up) beats the clamp
 *  by ~7%, a narrow one loses to it by up to 1.4x. Take the divisor when it
 *  clears MIN_EXACT_TILE, clamp otherwise. Every head that divides the tile
 *  keeps the exact path, so 32/64/96/128 emit the same merge as before. */
function tileFor(hd: number): number {
  for (let t = Math.min(TILE, hd); t >= MIN_EXACT_TILE; t--) {
    if (hd % t === 0) return t;
  }
  return Math.min(TILE, hd);
}

/** Accumulator length: hd rounded up to whole tiles. Equal to hd whenever
 *  tileFor found an exact divisor, so only the clamped heads pay for a pad. */
function paddedFor(hd: number): number {
  const t = tileFor(hd);
  return Math.ceil(hd / t) * t;
}

function makeAttnDecodeKernel(cfg: AttnDecodeCfg, elem: Elem) {
  const layout = attnDecodeLayoutFor(elem);
  const storeScalar = elem.scalar;
  const { qHeads, kvHeads, headDim: hd, windowLeft, windowRight, hasSinks } = cfg;
  const group = Math.floor(qHeads / kvHeads);
  const qWidth = qHeads * hd;
  const kvWidth = kvHeads * hd;
  const tile = tileFor(hd);
  const padded = paddedFor(hd);
  // Comptime: false whenever the tile divides the head, so the guard
  // folds away and those kernels keep the exact-divisor merge.
  const needsTailGuard = padded !== hd;
  const { acc: accReg, tile: partialAcc } = scratchOf(hd);
  return tgpu.computeFn({
    in: { wid: d.builtin.workgroupId, lid: d.builtin.localInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ wid, lid }) => {
    'use gpu';
    const D = layout.$.dims;
    const tid = lid.x;
    const h = wid.x % qHeads;
    const row = d.u32(wid.x / qHeads); // explicit integer division
    const kvh = d.u32(h / group);
    const qBase = row * qWidth + h * hd;
    const qPos = D.qPosOffset + row;

    // init accumulator to 0 (padded: the tail lanes must read as 0)
    for (const z of std.range(padded)) {
      accReg.$[z] = d.f32(0);
    }

    // Seed exactly one thread with the sink term (the batch kernel's hasSinks=1
    // seed); every other thread starts empty and the merge absorbs it.
    let m = d.f32(NEG_SEED);
    let l = d.f32(0);
    if (hasSinks > 0) {
      if (tid === 0) {
        m = layout.$.sinks[h]! * LN2;
        l = d.f32(1);
      }
    }

    // Visible keys [qPos−WL, qPos+WR] ∩ [0, kvLen), strided across the workgroup:
    // thread tid takes keys lo+tid, lo+tid+WG, ... (same bound arithmetic as
    // the batch kernel — max avoids u32 underflow, WL/WR ≤ 2^30).
    const lo = std.max(qPos, d.u32(windowLeft)) - windowLeft;
    const end = std.min(qPos + windowRight, D.kvLen - 1);
    for (let j = lo + tid; j <= end; j += WORKGROUP_SIZE) {
      const kBase = j * kvWidth + kvh * hd;
      let score = d.f32(0);
      for (const kk of std.range(hd)) {
        score += d.f32(layout.$.q[qBase + kk]!) * d.f32(layout.$.k[kBase + kk]!);
      }

      const mNew = std.max(m, score);
      const correction = std.exp(m - mNew);
      const p = std.exp(score - mNew);
      l = l * correction + p;
      m = mNew;

      const vBase = j * kvWidth + kvh * hd;
      for (const nn of std.range(hd)) {
        accReg.$[nn] = accReg.$[nn]! * correction + d.f32(layout.$.v[vBase + nn]!) * p;
      }
    }

    // Workgroup max M over the per-thread m's (every thread scans the shared
    // array — cheap, and leaves M uniform without a second barrier).
    partialM.$[tid] = m;
    std.workgroupBarrier();
    let M = d.f32(NEG_SEED);
    for (const i of std.range(WORKGROUP_SIZE)) {
      M = std.max(M, partialM.$[i]!);
    }

    // Rescale this thread's state to the workgroup max, then sum the l's.
    // Empty threads carry m = NEG_SEED, l = 0 — their scale is irrelevant.
    const scale = std.exp(m - M);
    partialL.$[tid] = l * scale;
    std.workgroupBarrier();
    let L = d.f32(0);
    for (const i of std.range(WORKGROUP_SIZE)) {
      L += partialL.$[i]!;
    }

    for (const c of std.range(hd)) {
      accReg.$[c] = accReg.$[c]! * scale;
    }

    // Empty band (no keys, no sinks) → L = 0 → zeros, like the batch kernel.
    const invL = std.select(0, 1 / L, L > 0);
    const oBase = row * qWidth + h * hd;

    // Column-sum the accumulators one tile at a time. The round count and the
    // tile width are comptime, so a head that fits one tile (hd <= 32) emits a
    // single straight-line round with no width clamp; the barriers stay in
    // uniform control flow either way.
    for (const base of std.range(0, padded, tile)) {
      std.workgroupBarrier(); // previous round's reads finish before overwrite
      for (const t of std.range(tile)) {
        partialAcc.$[tid * tile + t] = accReg.$[base + t]!;
      }
      std.workgroupBarrier();
      if (tid < tile && (!needsTailGuard || base + tid < hd)) {
        let sum = d.f32(0);
        for (const r of std.range(WORKGROUP_SIZE)) {
          sum += partialAcc.$[r * tile + tid]!;
        }
        layout.$.out[oBase + base + tid] = storeScalar(sum * invL);
      }
    }
  });
}

export function createAttnDecodePipeline(
  root: TgpuRoot,
  cfg: AttnDecodeCfg,
  elem: Elem = F32_ELEM,
) {
  return root.createComputePipeline({ compute: makeAttnDecodeKernel(cfg, elem) });
}

export function attnDecodeHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createAttnDecodePipeline>,
  args: { qLen: number; kvLen: number; qPosOffset: number; qHeads: number },
  buffers: {
    q: F32Buffer;
    k: F32Buffer;
    v: F32Buffer;
    out: F32Buffer;
    sinks?: F32Buffer;
    /** Filler for the dead `sinks` slot. That binding is f32 in every
     *  variant, so an f16 `q` cannot alias it the way the f32 path did. */
    dummyF32?: F32Buffer;
  },
  elem: Elem = F32_ELEM,
): KernelHandle {
  const dims = root
    .createBuffer(Dims, { qLen: args.qLen, kvLen: args.kvLen, qPosOffset: args.qPosOffset })
    .$usage('uniform');
  const filler = buffers.dummyF32 ?? (buffers.q as F32Buffer);
  const { dummyF32: _dummy, ...bound } = buffers;
  const bindGroup = root.createBindGroup(attnDecodeLayoutFor(elem), {
    ...bound,
    sinks: buffers.sinks ?? filler,
    dims,
  });
  // One WORKGROUP per (q row, q head) — not one thread.
  return makeHandle(pipeline, 'attnDecode', bindGroup, args.qLen * args.qHeads);
}

// ── Key-split pair (long key ranges) ─────────────────────────────────────
// During decode the query is one row (qLen = 1), so the kernel above runs
// only one workgroup per head, a handful of workgroups walk ~1250 keys on
// a 30-second clip while the rest of the GPU does no work. Past
// ATTN_DECODE_CHUNK visible keys the executor runs two dispatches instead:
//
//   1. `attnDecodeSplitKernel` — one workgroup per (head, chunk), each
//      scanning its own slice of the key range and writing its raw result
//      to its slot in the `partials` buffer: m (max score), l (sum of
//      exp-weights), acc[headDim] (weighted value sum) — not yet
//      normalized.
//   2. `attnDecodeMergeKernel` — one thread per head rescales the chunk
//      partials to their common max, sums them, divides once, and writes
//      the final row.
//
// All split pairs in a submit share one `partials` buffer: dispatches run
// in encode order, so each merge reads its partials before the next split
// overwrites them. The sink term enters once (chunk 0, thread 0) and rides
// inside that chunk's partial so the merge needs no special case.

/** Keys per chunk — below this the single-workgroup kernel wins (self-attn
 *  stays on it: its window never exceeds maxPositions ≤ CHUNK). */
export const ATTN_DECODE_CHUNK = 256;
export const ATTN_DECODE_MAX_CHUNKS = 8;
/** Scratch floats: per (head, chunk) slot [m, l, acc[MAX_HEAD_DIM]], worst
 *  case — the kernels stride by (2 + headDim) of the live pipeline. */
export const ATTN_SPLIT_SCRATCH_ELEMS = 64 * ATTN_DECODE_MAX_CHUNKS * (2 + MAX_HEAD_DIM);

const SplitDims = d.struct({ kvLen: d.u32, qPosOffset: d.u32, chunks: d.u32 });

/** `partials` stays f32 in every variant, like attn.ts's key-split pair: each
 *  slot holds a running max and sum alongside the value accumulator, and
 *  those are the numbers a half-width round trip would damage. */
const makeSplitLayout = (elem: Elem) =>
  tgpu.bindGroupLayout({
    q: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [1, qHeads·headDim]
    k: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [kvLen, kvHeads·headDim]
    v: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [kvLen, kvHeads·headDim]
    sinks: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [qHeads]; dead when hasSinks=0
    partials: { storage: d.arrayOf(d.f32), access: 'mutable' }, // [(h·MAX_CHUNKS+c)·(2+hd)]
    dims: { uniform: SplitDims },
  });

const splitLayouts = new Map<string, ReturnType<typeof makeSplitLayout>>();
export function attnDecodeSplitLayoutFor(elem: Elem): ReturnType<typeof makeSplitLayout> {
  let l = splitLayouts.get(elem.key);
  if (!l) {
    l = makeSplitLayout(elem);
    splitLayouts.set(elem.key, l);
  }
  return l;
}

function makeAttnDecodeSplitKernel(cfg: AttnDecodeCfg, elem: Elem) {
  // No narrowing store here: this half writes only the f32 `partials` slab.
  const layout = attnDecodeSplitLayoutFor(elem);
  const { qHeads, kvHeads, headDim: hd, windowLeft, windowRight, hasSinks } = cfg;
  const group = Math.floor(qHeads / kvHeads);
  const kvWidth = kvHeads * hd;
  const tile = tileFor(hd);
  const padded = paddedFor(hd);
  // Comptime: false whenever the tile divides the head, so the guard
  // folds away and those kernels keep the exact-divisor merge.
  const needsTailGuard = padded !== hd;
  const { acc: accReg, tile: partialAcc } = scratchOf(hd);
  return tgpu.computeFn({
    in: { wid: d.builtin.workgroupId, lid: d.builtin.localInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ wid, lid }) => {
    'use gpu';
    const D = layout.$.dims;
    const tid = lid.x;
    const chunk = wid.x % D.chunks;
    const h = d.u32(wid.x / D.chunks); // explicit integer division
    const kvh = d.u32(h / group);
    const qBase = h * hd; // qLen = 1 → row 0
    const qPos = D.qPosOffset;

    // padded: the last merge round's tail lanes must read as 0
    for (const z of std.range(padded)) {
      accReg.$[z] = d.f32(0);
    }

    let m = d.f32(NEG_SEED);
    let l = d.f32(0);
    if (hasSinks > 0) {
      if (chunk === 0) {
        if (tid === 0) {
          m = layout.$.sinks[h]! * LN2;
          l = d.f32(1);
        }
      }
    }

    // Visible range [lo, end] (the single-workgroup kernel's bound arithmetic),
    // sliced into `chunks` even pieces; this workgroup strides its piece.
    const lo = std.max(qPos, d.u32(windowLeft)) - windowLeft;
    const end = std.min(qPos + windowRight, D.kvLen - 1);
    const range = end + 1 - std.min(lo, end + 1); // 0 when the band is empty
    // ≥ 1 keeps `myLo + chunkLen − 1` from wrapping; the executor only routes
    // here when the range exceeds ATTN_DECODE_CHUNK, so real ranges never hit
    // the floor.
    const chunkLen = std.max(d.u32((range + D.chunks - 1) / D.chunks), 1);
    const myLo = lo + chunk * chunkLen;
    const myEnd = std.min(myLo + chunkLen - 1, end);
    for (let j = myLo + tid; j <= myEnd; j += WORKGROUP_SIZE) {
      const kBase = j * kvWidth + kvh * hd;
      let score = d.f32(0);
      for (const kk of std.range(hd)) {
        score += d.f32(layout.$.q[qBase + kk]!) * d.f32(layout.$.k[kBase + kk]!);
      }
      const mNew = std.max(m, score);
      const correction = std.exp(m - mNew);
      const p = std.exp(score - mNew);
      l = l * correction + p;
      m = mNew;
      const vBase = j * kvWidth + kvh * hd;
      for (const nn of std.range(hd)) {
        accReg.$[nn] = accReg.$[nn]! * correction + d.f32(layout.$.v[vBase + nn]!) * p;
      }
    }

    // Workgroup merge — identical to the single-workgroup kernel, but the
    // result is written UNNORMALIZED to this (head, chunk)'s scratch slot.
    partialM.$[tid] = m;
    std.workgroupBarrier();
    let M = d.f32(NEG_SEED);
    for (const i of std.range(WORKGROUP_SIZE)) {
      M = std.max(M, partialM.$[i]!);
    }
    const scale = std.exp(m - M);
    partialL.$[tid] = l * scale;
    std.workgroupBarrier();
    let L = d.f32(0);
    for (const i of std.range(WORKGROUP_SIZE)) {
      L += partialL.$[i]!;
    }
    for (const c of std.range(hd)) {
      accReg.$[c] = accReg.$[c]! * scale;
    }

    const slot = (h * ATTN_DECODE_MAX_CHUNKS + chunk) * (2 + hd);
    if (tid === 0) {
      layout.$.partials[slot] = M;
      layout.$.partials[slot + 1] = L;
    }
    for (const base of std.range(0, padded, tile)) {
      std.workgroupBarrier(); // previous round's reads finish before overwrite
      for (const t of std.range(tile)) {
        partialAcc.$[tid * tile + t] = accReg.$[base + t]!;
      }
      std.workgroupBarrier();
      if (tid < tile && (!needsTailGuard || base + tid < hd)) {
        let sum = d.f32(0);
        for (const r of std.range(WORKGROUP_SIZE)) {
          sum += partialAcc.$[r * tile + tid]!;
        }
        layout.$.partials[slot + 2 + base + tid] = sum;
      }
    }
  });
}

const MergeDims = d.struct({ chunks: d.u32 });

const makeMergeLayout = (elem: Elem) =>
  tgpu.bindGroupLayout({
    partials: { storage: d.arrayOf(d.f32), access: 'readonly' },
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' }, // [1, qHeads·headDim]
    dims: { uniform: MergeDims },
  });

const mergeLayouts = new Map<string, ReturnType<typeof makeMergeLayout>>();
export function attnDecodeMergeLayoutFor(elem: Elem): ReturnType<typeof makeMergeLayout> {
  let l = mergeLayouts.get(elem.key);
  if (!l) {
    l = makeMergeLayout(elem);
    mergeLayouts.set(elem.key, l);
  }
  return l;
}

function makeAttnDecodeMergeKernel(cfg: AttnDecodeCfg, elem: Elem) {
  const layout = attnDecodeMergeLayoutFor(elem);
  const storeScalar = elem.scalar;
  const { qHeads, headDim: hd } = cfg;
  const stride = 2 + hd;
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const h = gid.x; // one thread per head — qHeads is far below the grid cap
    if (h >= qHeads) {
      return;
    }
    const chunks = layout.$.dims.chunks;
    const base = h * ATTN_DECODE_MAX_CHUNKS * stride;

    let M = d.f32(NEG_SEED);
    for (let c = d.u32(0); c < chunks; c++) {
      M = std.max(M, layout.$.partials[base + c * stride]!);
    }
    let L = d.f32(0);
    for (let c = d.u32(0); c < chunks; c++) {
      const mc = layout.$.partials[base + c * stride]!;
      L += layout.$.partials[base + c * stride + 1]! * std.exp(mc - M);
    }
    const invL = std.select(0, 1 / L, L > 0);
    for (const dcol of std.range(hd)) {
      let sum = d.f32(0);
      for (let c = d.u32(0); c < chunks; c++) {
        const mc = layout.$.partials[base + c * stride]!;
        sum += layout.$.partials[base + c * stride + 2 + dcol]! * std.exp(mc - M);
      }
      layout.$.out[h * hd + dcol] = storeScalar(sum * invL);
    }
  });
}

export function createAttnDecodeSplitPipeline(
  root: TgpuRoot,
  cfg: AttnDecodeCfg,
  elem: Elem = F32_ELEM,
) {
  return root.createComputePipeline({ compute: makeAttnDecodeSplitKernel(cfg, elem) });
}

export function createAttnDecodeMergePipeline(
  root: TgpuRoot,
  cfg: AttnDecodeCfg,
  elem: Elem = F32_ELEM,
) {
  return root.createComputePipeline({ compute: makeAttnDecodeMergeKernel(cfg, elem) });
}

export function attnDecodeSplitHandles(
  root: TgpuRoot,
  partialPipeline: ReturnType<typeof createAttnDecodeSplitPipeline>,
  mergePipeline: ReturnType<typeof createAttnDecodeMergePipeline>,
  args: { kvLen: number; qPosOffset: number; qHeads: number; chunks: number },
  buffers: {
    q: F32Buffer;
    k: F32Buffer;
    v: F32Buffer;
    out: F32Buffer;
    partials: F32Buffer;
    sinks?: F32Buffer;
    /** Filler for the dead `sinks` slot — see attnDecodeHandle. */
    dummyF32?: F32Buffer;
  },
  elem: Elem = F32_ELEM,
): [KernelHandle, KernelHandle] {
  const dims = root
    .createBuffer(SplitDims, {
      kvLen: args.kvLen,
      qPosOffset: args.qPosOffset,
      chunks: args.chunks,
    })
    .$usage('uniform');
  const partialBind = root.createBindGroup(attnDecodeSplitLayoutFor(elem), {
    q: buffers.q,
    k: buffers.k,
    v: buffers.v,
    sinks: buffers.sinks ?? buffers.dummyF32 ?? buffers.q,
    partials: buffers.partials,
    dims,
  });
  const mergeDims = root.createBuffer(MergeDims, { chunks: args.chunks }).$usage('uniform');
  const mergeBind = root.createBindGroup(attnDecodeMergeLayoutFor(elem), {
    partials: buffers.partials,
    out: buffers.out,
    dims: mergeDims,
  });
  return [
    makeHandle(partialPipeline, 'attnDecodeSplit', partialBind, args.qHeads * args.chunks),
    makeHandle(mergePipeline, 'attnDecodeMerge', mergeBind, 1),
  ];
}
