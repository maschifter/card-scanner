import tgpu, { d } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  type F32Buffer,
  flatIndex,
  type KernelHandle,
  makeHandle,
  WORKGROUP_SIZE,
} from '../common.ts';
import { cachedBindGroup, cachedUniform } from '../../gpu/dispatchCache.ts';
import { type Elem, F32_ELEM } from '../elem.ts';

/** Rotary position embedding over ALL head sections of a [T, W] slab in one
 *  dispatch (W % headDim == 0) — the mx.fast.rope analog. Interleaved-pair
 *  rotation: for pair (2p, 2p+1) within a head section at table column
 *  d = col % headDim,
 *      out[2p]   = x[2p]·cos[t,d] − x[2p+1]·sin[t,d]
 *      out[2p+1] = x[2p+1]·cos[t,d] + x[2p]·sin[t,d]
 *  cos/sin are [T, headDim] pair-duplicated tables (col 2p == col 2p+1), with
 *  any scaling (e.g. QK_SCALE) pre-folded by the caller. One thread per pair.
 *
 *  The input may be a WIDER slab read through a column window: srcCols is the
 *  input's row stride and srcStart the window's first column (both
 *  weight-geometry constants → Config). rope-on-a-fused-qkv-slice becomes one
 *  dispatch instead of sliceCols → rope; the plain full-width case is
 *  srcStart = 0, srcCols = cols. */

const Dims = d.struct({ rows: d.u32 }); // T — the only runtime-dynamic dim

const Config = d.struct({
  cols: d.u32, // output W = heads·headDim (weight-determined)
  headDim: d.u32,
  srcStart: d.u32, // first input column of the window
  srcCols: d.u32, // input row stride (== cols when not slicing)
});
const config = tgpu.accessor(Config, { cols: 0, headDim: 2, srcStart: 0, srcCols: 0 });

/** The cos/sin tables stay f32 in every variant: they are built once on the
 *  CPU (`tensor(root, tables.cos, ...)`), never model parameters, so half()
 *  never reaches them — and a rotation angle rounded to f16 would drift the
 *  whole sequence for no bandwidth saving on a [T, headDim] table. */
function makeRopeVariant(elem: Elem) {
  const layout = tgpu.bindGroupLayout({
    x: { storage: d.arrayOf(elem.scalar), access: 'readonly' },
    cos: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [T, headDim]
    sin: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [T, headDim]
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' },
    dims: { uniform: Dims },
  });
  const storeScalar = elem.scalar;
  const kernel = tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const D = layout.$.dims;
    const C = config.$;
    const pairs = d.u32(C.cols / 2);
    const idx = flatIndex(gid);
    if (idx >= D.rows * pairs) {
      return;
    }
    const row = d.u32(idx / pairs);
    const col0 = (idx % pairs) * 2;
    const dcol = col0 % C.headDim; // table column (pair-duplicated: d == d+1)
    const c = layout.$.cos[row * C.headDim + dcol]!;
    const s = layout.$.sin[row * C.headDim + dcol]!;
    const srcBase = row * C.srcCols + C.srcStart + col0;
    const x0 = d.f32(layout.$.x[srcBase]!);
    const x1 = d.f32(layout.$.x[srcBase + 1]!);
    const oBase = row * C.cols + col0;
    layout.$.out[oBase] = storeScalar(x0 * c - x1 * s);
    layout.$.out[oBase + 1] = storeScalar(x1 * c + x0 * s);
  });
  return { layout, kernel };
}

const variants = new Map<string, ReturnType<typeof makeRopeVariant>>();
export function ropeVariant(elem: Elem): ReturnType<typeof makeRopeVariant> {
  let v = variants.get(elem.key);
  if (!v) {
    v = makeRopeVariant(elem);
    variants.set(elem.key, v);
  }
  return v;
}

export function createRopePipeline(
  root: TgpuRoot,
  cfg: { cols: number; headDim: number; srcStart?: number; srcCols?: number },
  elem: Elem = F32_ELEM,
) {
  return root
    .with(config, {
      cols: cfg.cols,
      headDim: cfg.headDim,
      srcStart: cfg.srcStart ?? 0,
      srcCols: cfg.srcCols ?? cfg.cols,
    })
    .createComputePipeline({ compute: ropeVariant(elem).kernel });
}

export function ropeHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createRopePipeline>,
  args: { rows: number; cols: number },
  buffers: { x: F32Buffer; cos: F32Buffer; sin: F32Buffer; out: F32Buffer },
  elem: Elem = F32_ELEM,
): KernelHandle {
  const dims = cachedUniform(root, Dims, { rows: args.rows });
  const bindGroup = cachedBindGroup(root, ropeVariant(elem).layout, { ...buffers, dims });
  return makeHandle(
    pipeline,
    'rope',
    bindGroup,
    Math.ceil((args.rows * (args.cols / 2)) / WORKGROUP_SIZE),
  );
}
