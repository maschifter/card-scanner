import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  flatIndex,
  type F32Buffer,
  type KernelHandle,
  makeHandle,
  WORKGROUP_SIZE,
} from '../common.ts';
import { type Elem, F32_ELEM } from '../elem.ts';

/** Scaled-dot-product attention, the thread-per-(q row, q head) shape:
 *  independent q and k/v lengths (qLen vs kvLen), an asymmetric visibility
 *  band, and sinks made OPTIONAL via a compile-time Config flag (the untaken
 *  seed branch constant-folds out of the pipeline, so the sink-less variant
 *  never reads the sinks binding). Each thread runs an online softmax over
 *  keys [qPos − windowLeft, qPos + windowRight] ∩ [0, kvLen), qPos =
 *  qPosOffset + row — serial in the key count and re-reading K/V per row, so
 *  the executor prefers the register-resident row kernels below for qLen > 1
 *  (and attnDecode.ts for qLen = 1) and reaches for this one only when their
 *  workgroup count would exceed the one-dimension dispatch limit.
 *  hasSinks=0 seeds m = −1e30 (large negative FINITE — the codebase bans ±Inf
 *  in buffers/uniforms), l = 0: the first visible key takes over exactly.
 *  hasSinks=1 seeds m = sinks[h]·ln2 (log2-space logit, value contribution
 *  zero), l = 1 — the sink joins the softmax as a phantom score. q/k are
 *  pre-scaled upstream (sm_scale = 1). hasSegs=1 (comptime, like sinks)
 *  additionally clips each row's keys to the range segs[2r]..segs[2r+1])
 *  read from the segs binding — packed sequences attend only within their
 *  own segment. Band geometry, head layout, sink-ness and seg-ness are
 *  architecture constants → Config; qLen/kvLen/qPosOffset are per-call →
 *  uniform (qPosOffset changes EVERY incremental-decode step — in the
 *  pipeline key it would compile a shader per token). */

const LN2 = Math.LN2;
const MAX_HEAD_DIM = 128;
const NEG_SEED = -1e30;

const Dims = d.struct({ qLen: d.u32, kvLen: d.u32, qPosOffset: d.u32 });

const Config = d.struct({
  qHeads: d.u32,
  kvHeads: d.u32,
  headDim: d.u32,
  windowLeft: d.u32,
  windowRight: d.u32,
  hasSinks: d.u32,
  hasSegs: d.u32,
  // 0: q/k/v are three separate tensors. 1: all three bindings point at ONE
  // [T, (qHeads+2·kvHeads)·headDim] tensor whose columns are the q|k|v
  // blocks — the kernel reads them by column offset, no slice copies.
  qkvPacked: d.u32,
});
const config = tgpu.accessor(Config, {
  qHeads: 1,
  kvHeads: 1,
  headDim: 2,
  windowLeft: 0,
  windowRight: 0,
  hasSinks: 0,
  hasSegs: 0,
  qkvPacked: 0,
});

/** q/k/v/out carry the model's storage dtype; `sinks` and `segs` stay f32 in
 *  EVERY variant. segs holds integer key ranges and f16 represents integers
 *  exactly only to 2048, so a longer sequence would silently mask the wrong
 *  keys; sinks is [qHeads], too small to be worth halving and the seed of the
 *  softmax. */
const makeAttnLayout = (elem: Elem) =>
  tgpu.bindGroupLayout({
    q: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [qLen, qHeads·headDim]
    k: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [kvLen, kvHeads·headDim]
    v: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [kvLen, kvHeads·headDim]
    sinks: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [qHeads], log2-space; dead when hasSinks=0
    segs: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [qLen, 2] row's key range; dead when hasSegs=0
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' }, // [qLen, qHeads·headDim]
    dims: { uniform: Dims },
  });

const attnLayouts = new Map<string, ReturnType<typeof makeAttnLayout>>();
export function attnLayoutFor(elem: Elem): ReturnType<typeof makeAttnLayout> {
  let l = attnLayouts.get(elem.key);
  if (!l) {
    l = makeAttnLayout(elem);
    attnLayouts.set(elem.key, l);
  }
  return l;
}

export const attnLayout = attnLayoutFor(F32_ELEM);

/** Per-thread running value accumulator (WGSL var<private>). */
const accReg = tgpu.privateVar(d.arrayOf(d.f32, MAX_HEAD_DIM));

function makeAttnKernel(elem: Elem = F32_ELEM) {
  const f16 = elem.key === 'f16';
  const A = attnLayoutFor(elem);
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const D = A.$.dims;
    const C = config.$;
    // This kernel is the OVER-CAP route (eval.ts picks it exactly when the row
    // kernels' workgroup count exceeds the dispatch limit), so the executor's
    // 2-D split is not hypothetical here — it always applies.
    const idx = flatIndex(gid);
    if (idx >= D.qLen * C.qHeads) {
      return;
    }
    const h = idx % C.qHeads;
    const row = d.u32(idx / C.qHeads); // explicit integer division
    const kvh = d.u32(h / d.u32(C.qHeads / C.kvHeads));
    const hd = C.headDim;
    const qWidth = C.qHeads * hd;
    const kvWidth = C.kvHeads * hd;
    // Packed qkv (comptime): a row holds q|k|v side by side — the row stride
    // is the full width and k/v start at their column offsets.
    let qStride = qWidth;
    let kvStride = kvWidth;
    let kOff = d.u32(0);
    let vOff = d.u32(0);
    if (C.qkvPacked > 0) {
      qStride = qWidth + 2 * kvWidth;
      kvStride = qStride;
      kOff = qWidth;
      vOff = qWidth + kvWidth;
    }
    const qBase = row * qStride + h * hd;
    const qPos = D.qPosOffset + row;

    // init accumulator to 0
    for (let z = d.u32(0); z < hd; z++) {
      accReg.$[z] = d.f32(0);
    }

    // Seed: sink variant starts from the sink logit (an exp(0) denominator term
    // whose value contribution is zero); sink-less starts empty. hasSinks is a
    // pipeline constant — the untaken branch folds away.
    let m = d.f32(NEG_SEED);
    let l = d.f32(0);
    if (C.hasSinks > 0) {
      m = A.$.sinks[h]! * LN2;
      l = d.f32(1);
    }

    // Visible keys [qPos−WL, qPos+WR] ∩ [0, kvLen): max(qPos, WL) − WL avoids u32
    // underflow; both bounds saturate long before u32 overflow (WL/WR ≤ 2^30).
    // Segments (hasSegs, comptime) further clip to the row's own key range
    // [segs[2r], segs[2r+1]) so packed sequences never attend across each other.
    let lo = std.max(qPos, C.windowLeft) - C.windowLeft;
    let end = std.min(qPos + C.windowRight, D.kvLen - 1);
    if (C.hasSegs > 0) {
      lo = std.max(lo, d.u32(A.$.segs[2 * row]!));
      end = std.min(end, d.u32(A.$.segs[2 * row + 1]!) - 1);
    }

    for (let j = lo; j <= end; j++) {
      const kBase = j * kvStride + kOff + kvh * hd;
      let score = d.f32(0);
      for (let kk = d.u32(0); kk < hd; kk++) {
        if (f16) {
          score += d.f32(A.$.q[qBase + kk]!) * d.f32(A.$.k[kBase + kk]!);
        } else {
          score += A.$.q[qBase + kk]! * A.$.k[kBase + kk]!;
        }
      }

      const mNew = std.max(m, score);
      const correction = std.exp(m - mNew);
      const p = std.exp(score - mNew);
      l = l * correction + p;
      m = mNew;

      const vBase = j * kvStride + vOff + kvh * hd;
      for (let nn = d.u32(0); nn < hd; nn++) {
        if (f16) {
          accReg.$[nn] = accReg.$[nn]! * correction + d.f32(A.$.v[vBase + nn]!) * p;
        } else {
          accReg.$[nn] = accReg.$[nn]! * correction + A.$.v[vBase + nn]! * p;
        }
      }
    }

    // Empty band (validated away at the op layer, but never divide by 0) → 0s.
    // Unreachable with sinks (l ≥ 1 there).
    const invL = std.select(0, 1 / l, l > 0);
    const oBase = row * qWidth + h * hd;
    for (let o = d.u32(0); o < hd; o++) {
      if (f16) {
        A.$.out[oBase + o] = d.f16(accReg.$[o]! * invL);
      } else {
        A.$.out[oBase + o] = accReg.$[o]! * invL;
      }
    }
  });
}

const attnKernels = new Map<string, ReturnType<typeof makeAttnKernel>>();
function attnKernelFor(elem: Elem) {
  let k = attnKernels.get(elem.key);
  if (!k) {
    k = makeAttnKernel(elem);
    attnKernels.set(elem.key, k);
  }
  return k;
}

export function createAttnPipeline(
  root: TgpuRoot,
  cfg: {
    qHeads: number;
    kvHeads: number;
    headDim: number;
    windowLeft: number;
    windowRight: number;
    hasSinks: number; // 0 | 1 — comptime; selects the softmax seed
    hasSegs: number; // 0 | 1 — comptime; clips each row's keys to its segment
    qkvPacked?: number; // 0 | 1 — comptime; q/k/v as column blocks of one tensor
  },
  elem: Elem = F32_ELEM,
) {
  return root
    .with(config, { ...cfg, qkvPacked: cfg.qkvPacked ?? 0 })
    .createComputePipeline({ compute: attnKernelFor(elem) });
}

export function attnHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createAttnPipeline>,
  args: { qLen: number; kvLen: number; qPosOffset: number; qHeads: number },
  buffers: {
    q: F32Buffer;
    k: F32Buffer;
    v: F32Buffer;
    out: F32Buffer;
    sinks?: F32Buffer;
    segs?: F32Buffer;
    /** Filler for the unread sinks/segs slots. Those bindings are f32 in
     *  EVERY variant, so with f16 q they cannot be aliased to it. */
    dummyF32?: F32Buffer;
  },
  elem: Elem = F32_ELEM,
): KernelHandle {
  const dims = root
    .createBuffer(Dims, { qLen: args.qLen, kvLen: args.kvLen, qPosOffset: args.qPosOffset })
    .$usage('uniform');
  // hasSinks=0/hasSegs=0 pipelines never read their binding, but the layout
  // entry must still be bound — alias q when the dtypes allow it (read-only
  // aliasing is legal WebGPU, zero alloc), else the caller's f32 filler.
  const filler = buffers.dummyF32 ?? (buffers.q as F32Buffer);
  const { dummyF32: _dummy, ...bound } = buffers;
  const bindGroup = root.createBindGroup(attnLayoutFor(elem), {
    ...bound,
    sinks: buffers.sinks ?? filler,
    segs: buffers.segs ?? filler,
    dims,
  });
  // One thread per (q row, q head).
  return makeHandle(
    pipeline,
    'attn',
    bindGroup,
    Math.ceil((args.qLen * args.qHeads) / WORKGROUP_SIZE),
  );
}

// ── Register-resident row kernels (qLen > 1) ──────────────────────────────
// Same operation as the thread-per-(row, head) kernel above, built by a
// FACTORY per pipeline config: headDim (and the rest of the geometry) enter
// the kernel as literals, so each thread's q copy and accumulator are
// exactly-sized arrays (headDim elements, or the lane's slice of them) with
// constant-trip loops — the shader compiler keeps them in registers. The module-level kernel above sizes its
// accumulator at MAX_HEAD_DIM with uniform-driven trip counts, which spills
// the array to thread-private stack memory; on an encoder-sized dispatch
// (thousands of rows x a thousand keys) that stack traffic dominates the
// whole pass. K/V loads need no staging: every thread of a workgroup walks
// its own key sequence through cache-served rows.
//
// Three kernels share the shape:
// - attnRows: one thread per (row, head), full band per thread. Grid:
//   ceil(qLen*qHeads / WORKGROUP_SIZE).
// - attnRowsSplit + attnRowsMerge: a second grid dimension slices each
//   row's own band into `chunks` (grid y); each thread writes an
//   UNNORMALIZED online-softmax partial (m, l, acc[headDim]) to a scratch
//   slot, and the merge folds a row's chunks in fixed order (two passes:
//   max of the m's, then exp-rescaled l/acc sums). The sink seed lives in
//   chunk 0, so it enters each row's softmax exactly once. Scratch slots
//   stride (2 + headDim); capacity is qLen*qHeads*ATTN_ROWS_MAX_CHUNKS slots.
// - attnRowsSubSplit: the subgroup-cooperative partial — 32 lanes share one
//   (row, head, chunk) instead of one serial thread. Same slot format, same
//   merge kernel; the executor routes to it when the device carries wide
//   enough subgroups (see the kernel doc below).

/** Key-chunk granularity for the rows-split pair. Encoder bands are long
 *  (hundreds of keys) and a chunk is one partial's serial key walk (per
 *  thread or per 32-lane workgroup), so the divisor sets the parallelism per
 *  (row, head): chunks = min(MAX, ceil(kvLen / CHUNK)). Distinct from
 *  ATTN_DECODE_CHUNK — the decode split serves one query row, this one
 *  thousands, so the sweet spots differ. */
export const ATTN_ROWS_CHUNK = 96;
export const ATTN_ROWS_MAX_CHUNKS = 16;

const SplitDims = d.struct({ qLen: d.u32, kvLen: d.u32, qPosOffset: d.u32, chunks: d.u32 });

/** Same rule as attnLayout: q/k/v carry the storage dtype, sinks/segs stay
 *  f32 — and so do the PARTIALS. Each chunk publishes a running max, a
 *  running sum and a value accumulator; those are the online softmax's state,
 *  and rounding them to f16 between the partial and merge passes would lose
 *  precision the unsplit kernel never loses. */
const makeAttnSplitLayout = (elem: Elem) =>
  tgpu.bindGroupLayout({
    q: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [qLen, qHeads·headDim]
    k: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [kvLen, kvHeads·headDim]
    v: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [kvLen, kvHeads·headDim]
    sinks: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [qHeads]; dead when hasSinks=0
    segs: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [qLen, 2]; dead when hasSegs=0
    partials: { storage: d.arrayOf(d.f32), access: 'mutable' }, // [qLen·qHeads·MAX_CHUNKS, 2+hd]
    dims: { uniform: SplitDims },
  });

const attnSplitLayouts = new Map<string, ReturnType<typeof makeAttnSplitLayout>>();
export function attnSplitLayoutFor(elem: Elem): ReturnType<typeof makeAttnSplitLayout> {
  let l = attnSplitLayouts.get(elem.key);
  if (!l) {
    l = makeAttnSplitLayout(elem);
    attnSplitLayouts.set(elem.key, l);
  }
  return l;
}

export const attnRowsSplitLayout = attnSplitLayoutFor(F32_ELEM);

interface AttnGeoCfg {
  qHeads: number;
  kvHeads: number;
  headDim: number;
  windowLeft: number;
  windowRight: number;
  hasSinks: number; // 0 | 1 — selects the softmax seed
  hasSegs: number; // 0 | 1 — clips each row's keys to its own segment range
  qkvPacked?: number; // 0 | 1 — q/k/v as column blocks of one tensor
}

function makeAttnRowsKernel(cfg: AttnGeoCfg, elem: Elem = F32_ELEM) {
  const { qHeads, kvHeads, headDim: hd, windowLeft, windowRight, hasSinks, hasSegs } = cfg;
  const f16 = elem.key === 'f16';
  const L = attnLayoutFor(elem);
  const group = Math.floor(qHeads / kvHeads);
  // Packed qkv reads all three blocks from one tensor: full-width row
  // stride, k/v at their column offsets. Baked as literals.
  const qStride = (cfg.qkvPacked ?? 0) > 0 ? (qHeads + 2 * kvHeads) * hd : qHeads * hd;
  const kvStride = (cfg.qkvPacked ?? 0) > 0 ? qStride : kvHeads * hd;
  const kOff = (cfg.qkvPacked ?? 0) > 0 ? qHeads * hd : 0;
  const vOff = (cfg.qkvPacked ?? 0) > 0 ? (qHeads + kvHeads) * hd : 0;
  const qReg = tgpu.privateVar(d.arrayOf(d.f32, hd));
  const acc = tgpu.privateVar(d.arrayOf(d.f32, hd));
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const D = L.$.dims;
    if (gid.x >= D.qLen * qHeads) {
      return;
    }
    const h = gid.x % qHeads;
    const row = d.u32(gid.x / qHeads); // explicit integer division
    const kvh = d.u32(h / group);
    const qBase = row * qStride + h * hd;
    const qPos = D.qPosOffset + row;

    // q lands in f32 registers whatever the storage: the online softmax's
    // running max, sum and value accumulator all stay f32 (an f16 running sum
    // over kvLen keys is exactly the drift the accumulator rule forbids).
    for (const z of std.range(hd)) {
      if (f16) {
        qReg.$[z] = d.f32(L.$.q[qBase + z]!);
      } else {
        qReg.$[z] = L.$.q[qBase + z]!;
      }
      acc.$[z] = d.f32(0);
    }

    let m = d.f32(NEG_SEED);
    let l = d.f32(0);
    if (hasSinks > 0) {
      m = L.$.sinks[h]! * LN2;
      l = d.f32(1);
    }

    // Band [qPos−WL, qPos+WR] ∩ [0, kvLen) — max avoids u32 underflow, WL/WR ≤
    // 2^30. Segments (comptime) clip further to the row's own key range.
    let lo = std.max(qPos, d.u32(windowLeft)) - windowLeft;
    let end = std.min(qPos + windowRight, D.kvLen - 1);
    if (hasSegs > 0) {
      lo = std.max(lo, d.u32(L.$.segs[2 * row]!));
      end = std.min(end, d.u32(L.$.segs[2 * row + 1]!) - 1);
    }
    for (let j = lo; j <= end; j++) {
      const kBase = j * kvStride + kOff + kvh * hd;
      const vBase = j * kvStride + vOff + kvh * hd;
      let score = d.f32(0);
      if (f16) {
        for (const kk of std.range(hd)) {
          score += qReg.$[kk]! * d.f32(L.$.k[kBase + kk]!);
        }
      } else {
        for (const kk of std.range(hd)) {
          score += qReg.$[kk]! * L.$.k[kBase + kk]!;
        }
      }
      const mNew = std.max(m, score);
      const correction = std.exp(m - mNew);
      const p = std.exp(score - mNew);
      l = l * correction + p;
      m = mNew;
      if (f16) {
        for (const nn of std.range(hd)) {
          acc.$[nn] = acc.$[nn]! * correction + d.f32(L.$.v[vBase + nn]!) * p;
        }
      } else {
        for (const nn of std.range(hd)) {
          acc.$[nn] = acc.$[nn]! * correction + L.$.v[vBase + nn]! * p;
        }
      }
    }

    // Empty band → l stays 0 (sink-less) → zeros, like the other kernels.
    const invL = std.select(0, 1 / l, l > 0);
    const oBase = row * qHeads * hd + h * hd;
    for (const o of std.range(hd)) {
      if (f16) {
        L.$.out[oBase + o] = d.f16(acc.$[o]! * invL);
      } else {
        L.$.out[oBase + o] = acc.$[o]! * invL;
      }
    }
  });
}

function makeAttnRowsSplitKernel(cfg: AttnGeoCfg, elem: Elem = F32_ELEM) {
  const { qHeads, kvHeads, headDim: hd, windowLeft, windowRight, hasSinks, hasSegs } = cfg;
  const f16 = elem.key === 'f16';
  const S = attnSplitLayoutFor(elem);
  const group = Math.floor(qHeads / kvHeads);
  const qStride = (cfg.qkvPacked ?? 0) > 0 ? (qHeads + 2 * kvHeads) * hd : qHeads * hd;
  const kvStride = (cfg.qkvPacked ?? 0) > 0 ? qStride : kvHeads * hd;
  const kOff = (cfg.qkvPacked ?? 0) > 0 ? qHeads * hd : 0;
  const vOff = (cfg.qkvPacked ?? 0) > 0 ? (qHeads + kvHeads) * hd : 0;
  const qReg = tgpu.privateVar(d.arrayOf(d.f32, hd));
  const acc = tgpu.privateVar(d.arrayOf(d.f32, hd));
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const D = S.$.dims;
    if (gid.x >= D.qLen * qHeads) {
      return;
    }
    const h = gid.x % qHeads;
    const row = d.u32(gid.x / qHeads); // explicit integer division
    const kvh = d.u32(h / group);
    const qBase = row * qStride + h * hd;
    const qPos = D.qPosOffset + row;

    for (const z of std.range(hd)) {
      if (f16) {
        qReg.$[z] = d.f32(S.$.q[qBase + z]!);
      } else {
        qReg.$[z] = S.$.q[qBase + z]!;
      }
      acc.$[z] = d.f32(0);
    }

    // Sink seed enters each row's softmax exactly once: chunk 0.
    let m = d.f32(NEG_SEED);
    let l = d.f32(0);
    if (hasSinks > 0) {
      if (gid.y === 0) {
        m = S.$.sinks[h]! * LN2;
        l = d.f32(1);
      }
    }

    // An empty band would wrap the u32 slice arithmetic below — publish the
    // seed state (zero acc; sink seed if this is chunk 0) and leave, which
    // merges to the same zeros the unsplit kernels write. Segments (comptime)
    // clip the band to the row's own key range first.
    let lo = std.max(qPos, d.u32(windowLeft)) - windowLeft;
    let end = std.min(qPos + windowRight, D.kvLen - 1);
    if (hasSegs > 0) {
      lo = std.max(lo, d.u32(S.$.segs[2 * row]!));
      end = std.min(end, d.u32(S.$.segs[2 * row + 1]!) - 1);
    }
    if (lo > end) {
      const slot = ((row * qHeads + h) * ATTN_ROWS_MAX_CHUNKS + gid.y) * (2 + hd);
      S.$.partials[slot] = m;
      S.$.partials[slot + 1] = l;
      for (const w of std.range(hd)) {
        S.$.partials[slot + 2 + w] = d.f32(0);
      }
      return;
    }

    // This grid-y slice of the row's band. range ≥ 1 here, and the max
    // guard keeps chunkLen ≥ 1, so the slice arithmetic cannot wrap; slices
    // past the band just run dry.
    const range = end - lo + 1;
    const chunkLen = std.max(d.u32((range + D.chunks - 1) / D.chunks), 1);
    const sliceLo = lo + gid.y * chunkLen;
    const sliceEnd = std.min(sliceLo + chunkLen - 1, end);

    for (let j = sliceLo; j <= sliceEnd; j++) {
      const kBase = j * kvStride + kOff + kvh * hd;
      const vBase = j * kvStride + vOff + kvh * hd;
      let score = d.f32(0);
      for (const kk of std.range(hd)) {
        if (f16) {
          score += qReg.$[kk]! * d.f32(S.$.k[kBase + kk]!);
        } else {
          score += qReg.$[kk]! * S.$.k[kBase + kk]!;
        }
      }
      const mNew = std.max(m, score);
      const correction = std.exp(m - mNew);
      const p = std.exp(score - mNew);
      l = l * correction + p;
      m = mNew;
      for (const nn of std.range(hd)) {
        if (f16) {
          acc.$[nn] = acc.$[nn]! * correction + d.f32(S.$.v[vBase + nn]!) * p;
        } else {
          acc.$[nn] = acc.$[nn]! * correction + S.$.v[vBase + nn]! * p;
        }
      }
    }

    const slot = ((row * qHeads + h) * ATTN_ROWS_MAX_CHUNKS + gid.y) * (2 + hd);
    S.$.partials[slot] = m;
    S.$.partials[slot + 1] = l;
    for (const w of std.range(hd)) {
      S.$.partials[slot + 2 + w] = acc.$[w]!;
    }
  });
}

/** Subgroup-cooperative twin of the rows-split kernel: one 32-lane WORKGROUP
 *  per (row, head) — grid x is qLen·qHeads workgroups (not threads), grid y the
 *  key chunk. Lane i owns head-dim columns {i, i+32, …}: the per-key dot is
 *  each lane's partial product folded by subgroupAdd (all lanes receive the
 *  sum), the online-softmax m/l update runs replicated on identical values,
 *  and each lane keeps only its ceil(hd/32) accumulator slice in registers.
 *  Versus one serial thread per (row, head): the hd-long dot chain becomes a
 *  hardware tree reduction, k/v reads coalesce across lanes, and the register
 *  footprint drops from 2·hd to 2·ceil(hd/32) per thread. Lanes past hd load
 *  a clamped index with a zeroed q value (contributes 0) and skip writeback.
 *  Same partials slot format and merge kernel as the serial split pair. The
 *  executor routes here only when the device's subgroups are ≥ 32 wide and
 *  qLen·qHeads fits one grid dimension; control flow is row-uniform (band
 *  bounds derive from the row), so every subgroupAdd executes fully
 *  converged. */
function makeAttnRowsSubgroupSplitKernel(cfg: AttnGeoCfg, elem: Elem = F32_ELEM) {
  const { qHeads, kvHeads, headDim: hd, windowLeft, windowRight, hasSinks, hasSegs } = cfg;
  const f16 = elem.key === 'f16';
  const S = attnSplitLayoutFor(elem);
  const group = Math.floor(qHeads / kvHeads);
  const qStride = (cfg.qkvPacked ?? 0) > 0 ? (qHeads + 2 * kvHeads) * hd : qHeads * hd;
  const kvStride = (cfg.qkvPacked ?? 0) > 0 ? qStride : kvHeads * hd;
  const kOff = (cfg.qkvPacked ?? 0) > 0 ? qHeads * hd : 0;
  const vOff = (cfg.qkvPacked ?? 0) > 0 ? (qHeads + kvHeads) * hd : 0;
  const LANES = 32;
  const cpl = Math.ceil(hd / LANES); // lane-owned columns
  const qv = tgpu.privateVar(d.arrayOf(d.f32, cpl));
  const acc = tgpu.privateVar(d.arrayOf(d.f32, cpl));
  return tgpu.computeFn({
    in: { wid: d.builtin.workgroupId, lid: d.builtin.localInvocationId },
    workgroupSize: [LANES],
  })(({ wid, lid }) => {
    'use gpu';
    const D = S.$.dims;
    const lane = lid.x;
    const h = wid.x % qHeads;
    const row = d.u32(wid.x / qHeads); // explicit integer division
    const kvh = d.u32(h / group);
    const qBase = row * qStride + h * hd;
    const qPos = D.qPosOffset + row;

    // Lane-owned q values; columns past hd read a clamped index but hold 0,
    // so their per-key products vanish without any per-key branch.
    for (const c of tgpu.unroll(std.range(cpl))) {
      const kk = lane + c * LANES;
      const idx = std.min(kk, d.u32(hd - 1));
      if (f16) {
        qv.$[c] = std.select(d.f32(0), d.f32(S.$.q[qBase + idx]!), kk < hd);
      } else {
        qv.$[c] = std.select(d.f32(0), S.$.q[qBase + idx]!, kk < hd);
      }
      acc.$[c] = d.f32(0);
    }

    // Sink seed enters each row's softmax exactly once: chunk 0. Replicated
    // per lane — every lane tracks identical m/l.
    let m = d.f32(NEG_SEED);
    let l = d.f32(0);
    if (hasSinks > 0) {
      if (wid.y === 0) {
        m = S.$.sinks[h]! * LN2;
        l = d.f32(1);
      }
    }

    const slot = ((row * qHeads + h) * ATTN_ROWS_MAX_CHUNKS + wid.y) * (2 + hd);

    // Empty band: publish the seed state (zero acc; sink seed if chunk 0),
    // exactly like the serial split kernel. Row-uniform (segment bounds
    // derive from the row), so the whole workgroup leaves together.
    let lo = std.max(qPos, d.u32(windowLeft)) - windowLeft;
    let end = std.min(qPos + windowRight, D.kvLen - 1);
    if (hasSegs > 0) {
      lo = std.max(lo, d.u32(S.$.segs[2 * row]!));
      end = std.min(end, d.u32(S.$.segs[2 * row + 1]!) - 1);
    }
    if (lo > end) {
      if (lane === 0) {
        S.$.partials[slot] = m;
        S.$.partials[slot + 1] = l;
      }
      for (const w of tgpu.unroll(std.range(cpl))) {
        const kk = lane + w * LANES;
        if (kk < hd) {
          S.$.partials[slot + 2 + kk] = d.f32(0);
        }
      }
      return;
    }

    // This grid-y slice of the row's band (same arithmetic as the serial
    // kernel; range ≥ 1 here so nothing wraps).
    const range = end - lo + 1;
    const chunkLen = std.max(d.u32((range + D.chunks - 1) / D.chunks), 1);
    const sliceLo = lo + wid.y * chunkLen;
    const sliceEnd = std.min(sliceLo + chunkLen - 1, end);

    for (let j = sliceLo; j <= sliceEnd; j++) {
      const kBase = j * kvStride + kOff + kvh * hd;
      const vBase = j * kvStride + vOff + kvh * hd;
      let partial = d.f32(0);
      for (const cc of tgpu.unroll(std.range(cpl))) {
        const kk = lane + cc * LANES;
        const idx = std.min(kk, d.u32(hd - 1));
        if (f16) {
          partial += qv.$[cc]! * d.f32(S.$.k[kBase + idx]!);
        } else {
          partial += qv.$[cc]! * S.$.k[kBase + idx]!;
        }
      }
      const score = std.subgroupAdd(partial);
      const mNew = std.max(m, score);
      const correction = std.exp(m - mNew);
      const p = std.exp(score - mNew);
      l = l * correction + p;
      m = mNew;
      for (const nn of tgpu.unroll(std.range(cpl))) {
        const kk = lane + nn * LANES;
        const idx = std.min(kk, d.u32(hd - 1));
        if (f16) {
          acc.$[nn] = acc.$[nn]! * correction + d.f32(S.$.v[vBase + idx]!) * p;
        } else {
          acc.$[nn] = acc.$[nn]! * correction + S.$.v[vBase + idx]! * p;
        }
      }
    }

    if (lane === 0) {
      S.$.partials[slot] = m;
      S.$.partials[slot + 1] = l;
    }
    for (const w of tgpu.unroll(std.range(cpl))) {
      const kk = lane + w * LANES;
      if (kk < hd) {
        S.$.partials[slot + 2 + kk] = acc.$[w]!;
      }
    }
  });
}

const MergeDims = d.struct({ qLen: d.u32, chunks: d.u32 });

const makeAttnMergeLayout = (elem: Elem) =>
  tgpu.bindGroupLayout({
    partials: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [qLen·qHeads·MAX_CHUNKS, 2+hd]
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' }, // [qLen, qHeads·headDim]
    dims: { uniform: MergeDims },
  });

const attnMergeLayouts = new Map<string, ReturnType<typeof makeAttnMergeLayout>>();
export function attnMergeLayoutFor(elem: Elem): ReturnType<typeof makeAttnMergeLayout> {
  let l = attnMergeLayouts.get(elem.key);
  if (!l) {
    l = makeAttnMergeLayout(elem);
    attnMergeLayouts.set(elem.key, l);
  }
  return l;
}

export const attnRowsMergeLayout = attnMergeLayoutFor(F32_ELEM);

/** One thread per (row, head): two passes over the row's chunk partials —
 *  global max of the m's, then exp-rescaled l and acc sums in fixed chunk
 *  order — and the normalized output row. */
function makeAttnMergeKernel(cfg: AttnGeoCfg, elem: Elem = F32_ELEM) {
  const { qHeads, headDim: hd } = cfg;
  const f16 = elem.key === 'f16';
  const MERGE = attnMergeLayoutFor(elem);
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const D = MERGE.$.dims;
    if (gid.x >= D.qLen * qHeads) {
      return;
    }
    const h = gid.x % qHeads;
    const row = d.u32(gid.x / qHeads); // explicit integer division
    const stride = 2 + hd;
    const rowBase = (row * qHeads + h) * ATTN_ROWS_MAX_CHUNKS;

    let M = d.f32(NEG_SEED);
    for (let c = d.u32(0); c < D.chunks; c++) {
      M = std.max(M, MERGE.$.partials[(rowBase + c) * stride]!);
    }

    let L = d.f32(0);
    for (let c = d.u32(0); c < D.chunks; c++) {
      const slot = (rowBase + c) * stride;
      L += MERGE.$.partials[slot + 1]! * std.exp(MERGE.$.partials[slot]! - M);
    }

    const invL = std.select(0, 1 / L, L > 0);
    const oBase = row * qHeads * hd + h * hd;
    for (const o of std.range(hd)) {
      let a = d.f32(0);
      for (let c = d.u32(0); c < D.chunks; c++) {
        const slot = (rowBase + c) * stride;
        a += MERGE.$.partials[slot + 2 + o]! * std.exp(MERGE.$.partials[slot]! - M);
      }
      if (f16) {
        MERGE.$.out[oBase + o] = d.f16(a * invL);
      } else {
        MERGE.$.out[oBase + o] = a * invL;
      }
    }
  });
}

export function createAttnRowsPipeline(root: TgpuRoot, cfg: AttnGeoCfg, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: makeAttnRowsKernel(cfg, elem) });
}

export function createAttnRowsSplitPipeline(
  root: TgpuRoot,
  cfg: AttnGeoCfg,
  elem: Elem = F32_ELEM,
) {
  return root.createComputePipeline({ compute: makeAttnRowsSplitKernel(cfg, elem) });
}

export function createAttnRowsSubgroupSplitPipeline(
  root: TgpuRoot,
  cfg: AttnGeoCfg,
  elem: Elem = F32_ELEM,
) {
  return root.createComputePipeline({ compute: makeAttnRowsSubgroupSplitKernel(cfg, elem) });
}

export function createAttnRowsMergePipeline(
  root: TgpuRoot,
  cfg: AttnGeoCfg,
  elem: Elem = F32_ELEM,
) {
  return root.createComputePipeline({ compute: makeAttnMergeKernel(cfg, elem) });
}

export function attnRowsHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createAttnRowsPipeline>,
  args: { qLen: number; kvLen: number; qPosOffset: number; qHeads: number },
  buffers: {
    q: F32Buffer;
    k: F32Buffer;
    v: F32Buffer;
    out: F32Buffer;
    sinks?: F32Buffer;
    segs?: F32Buffer;
    /** Filler for the unread sinks/segs slots. Those bindings are f32 in
     *  EVERY variant, so they cannot alias `q` the way same-dtype dead slots
     *  do — an f16 q would not match the binding's element type. */
    dummyF32: F32Buffer;
  },
  elem: Elem = F32_ELEM,
): KernelHandle {
  const dims = root
    .createBuffer(Dims, { qLen: args.qLen, kvLen: args.kvLen, qPosOffset: args.qPosOffset })
    .$usage('uniform');
  const { dummyF32, ...bound } = buffers;
  const bindGroup = root.createBindGroup(attnLayoutFor(elem), {
    ...bound,
    sinks: buffers.sinks ?? dummyF32,
    segs: buffers.segs ?? dummyF32,
    dims,
  });
  // One thread per (q row, q head), register-resident accumulator.
  return makeHandle(
    pipeline,
    'attnRows',
    bindGroup,
    Math.ceil((args.qLen * args.qHeads) / WORKGROUP_SIZE),
  );
}

export function attnRowsSplitHandles(
  root: TgpuRoot,
  partial:
    | ReturnType<typeof createAttnRowsSplitPipeline>
    | ReturnType<typeof createAttnRowsSubgroupSplitPipeline>,
  merge: ReturnType<typeof createAttnRowsMergePipeline>,
  args: {
    qLen: number;
    kvLen: number;
    qPosOffset: number;
    qHeads: number;
    chunks: number;
    /** Subgroup partial: one 32-lane workgroup per (row, head) instead of one
     *  thread — grid x is qLen·qHeads workgroups. */
    subgroup?: boolean;
  },
  buffers: {
    q: F32Buffer;
    k: F32Buffer;
    v: F32Buffer;
    out: F32Buffer;
    partials: F32Buffer;
    sinks?: F32Buffer;
    segs?: F32Buffer;
    /** Filler for the unread sinks/segs slots — f32 in every variant, so it
     *  cannot alias an f16 `q`. */
    dummyF32: F32Buffer;
  },
  elem: Elem = F32_ELEM,
): KernelHandle[] {
  const splitDims = root
    .createBuffer(SplitDims, {
      qLen: args.qLen,
      kvLen: args.kvLen,
      qPosOffset: args.qPosOffset,
      chunks: args.chunks,
    })
    .$usage('uniform');
  const splitBind = root.createBindGroup(attnSplitLayoutFor(elem), {
    q: buffers.q,
    k: buffers.k,
    v: buffers.v,
    sinks: buffers.sinks ?? buffers.dummyF32,
    segs: buffers.segs ?? buffers.dummyF32,
    partials: buffers.partials,
    dims: splitDims,
  });
  const mergeDims = root
    .createBuffer(MergeDims, { qLen: args.qLen, chunks: args.chunks })
    .$usage('uniform');
  const mergeBind = root.createBindGroup(attnMergeLayoutFor(elem), {
    partials: buffers.partials,
    out: buffers.out,
    dims: mergeDims,
  });
  return [
    // Grid: y = key chunk; x = (row, head) — as workgroups for the subgroup
    // partial (32 cooperating lanes each), as threads for the serial one.
    args.subgroup
      ? makeHandle(partial, 'attnRowsSubSplit', splitBind, [args.qLen * args.qHeads, args.chunks])
      : makeHandle(partial, 'attnRowsSplit', splitBind, [
          Math.ceil((args.qLen * args.qHeads) / WORKGROUP_SIZE),
          args.chunks,
        ]),
    makeHandle(
      merge,
      'attnRowsMerge',
      mergeBind,
      Math.ceil((args.qLen * args.qHeads) / WORKGROUP_SIZE),
    ),
  ];
}
