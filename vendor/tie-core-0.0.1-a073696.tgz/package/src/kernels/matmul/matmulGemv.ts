import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { type F32Buffer, type KernelHandle, makeHandle } from '../common.ts';
import { activationFor, actSlot } from '../activations.ts';
import { type Elem, F32_ELEM } from '../elem.ts';

/** Single-row matmul (GEMV): out[1,N] = a[1,K] · b[K,N] (+ bias[N])
 *  (+ addend[1,N]) — the m == 1 route of the `matmul` op (the executor picks
 *  it by shape; matmul.ts serves every other m). The batch kernel's one
 *  thread per 4-col unit leaves a single row's dispatch with N/4 threads and
 *  a K-deep serial loop; here a WORKGROUP serves TN output columns with the
 *  K axis split across KS lanes: thread (kLane, colLane) accumulates the
 *  j ≡ kLane (mod KS) part of column colLane's dot, partials merge through
 *  workgroup memory in fixed lane order (deterministic per shape), and the
 *  kLane-0 threads apply the epilogue. Adjacent threads read adjacent b
 *  columns — coalesced. Epilogue order matches matmul.ts: dot, then bias,
 *  then addend. K/N are weight-determined → baked per pipeline (matmul.ts
 *  precedent); comptime epilogue flags fold untaken branches out; absent
 *  epilogue operands alias `a`. No runtime uniform — m is 1 by routing. */

const WG = 256;
/** K-split lanes per column; TN = WG / KS output columns per workgroup. */
const KS = 8;
const TN = WG / KS;

const Config = d.struct({
  k: d.u32,
  n: d.u32,
  hasBias: d.u32, // comptime 0|1 — epilogue adds bias[col]
  hasAdd: d.u32, // comptime 0|1 — epilogue adds addend[col] (residual fold)
});
const config = tgpu.accessor(Config, { k: 0, n: 0, hasBias: 0, hasAdd: 0 });

/** Per-column k-lane partials, laid out [kLane, colLane] = tid. They stay
 *  f32 in both variants: workgroup memory is scratch, halving it saves no
 *  bandwidth, and the split-K sum is exactly where an f16 accumulator would
 *  drift. */
const partial = tgpu.workgroupVar(d.arrayOf(d.f32, WG));

function makeGemvVariant(elem: Elem) {
  const layout = tgpu.bindGroupLayout({
    a: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [1, K]
    b: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [K, N]
    bias: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [N]; dead when hasBias=0
    addend: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [1, N]; dead when hasAdd=0
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' }, // [1, N]
  });
  const storeScalar = elem.scalar;
  const kernel = tgpu.computeFn({
    in: { wid: d.builtin.workgroupId, lid: d.builtin.localInvocationId },
    workgroupSize: [WG],
  })(({ wid, lid }) => {
    'use gpu';
    const k = config.$.k;
    const n = config.$.n;
    const tid = lid.x;
    const colLane = tid % TN;
    const kLane = d.u32(tid / TN); // explicit integer division (codebase convention)
    const col = wid.x * TN + colLane;

    let acc = d.f32(0);
    if (col < n) {
      for (let j = kLane; j < k; j += KS) {
        acc += d.f32(layout.$.a[j]!) * d.f32(layout.$.b[j * n + col]!);
      }
    }
    partial.$[tid] = acc;
    std.workgroupBarrier();

    if (kLane === 0) {
      if (col < n) {
        let sum = d.f32(0);
        for (const s of tgpu.unroll(std.range(KS))) {
          sum += partial.$[s * TN + colLane]!;
        }
        if (config.$.hasBias > 0) {
          sum += d.f32(layout.$.bias[col]!);
        }
        if (config.$.hasAdd > 0) {
          sum += d.f32(layout.$.addend[col]!);
        }
        layout.$.out[col] = storeScalar(sum);
      }
    }
  });
  return { layout, kernel };
}

const gemvVariants = new Map<string, ReturnType<typeof makeGemvVariant>>();
export function matmulGemvVariant(elem: Elem): ReturnType<typeof makeGemvVariant> {
  let v = gemvVariants.get(elem.key);
  if (!v) {
    v = makeGemvVariant(elem);
    gemvVariants.set(elem.key, v);
  }
  return v;
}

export function createMatmulGemvPipeline(
  root: TgpuRoot,
  cfg: { k: number; n: number; hasBias?: number; hasAdd?: number },
  elem: Elem = F32_ELEM,
) {
  return root
    .with(config, {
      k: cfg.k,
      n: cfg.n,
      hasBias: cfg.hasBias ?? 0,
      hasAdd: cfg.hasAdd ?? 0,
    })
    .createComputePipeline({ compute: matmulGemvVariant(elem).kernel });
}

export function matmulGemvHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createMatmulGemvPipeline>,
  n: number,
  buffers: { a: F32Buffer; b: F32Buffer; out: F32Buffer; bias?: F32Buffer; addend?: F32Buffer },
  elem: Elem = F32_ELEM,
): KernelHandle {
  // Absent epilogue operands alias `a` — those pipelines never read them.
  const bindGroup = root.createBindGroup(matmulGemvVariant(elem).layout, {
    ...buffers,
    bias: buffers.bias ?? buffers.a,
    addend: buffers.addend ?? buffers.a,
  });
  // One workgroup per TN output columns.
  return makeHandle(pipeline, 'matmulGemv', bindGroup, Math.ceil(n / TN));
}

// ── Subgroup small-m variant (4 ≤ m ≤ MATMUL_SMALL_M_MAX_ROWS, m % 4 == 0) ─

/** Row ceiling for the small-m route (measured crossover): above it the
 *  tiled kernel is faster. */
export const MATMUL_SMALL_M_MAX_ROWS = 32;

/** Threads per workgroup = one hardware subgroup, so one subgroupAdd sums
 *  the whole workgroup. The executor routes here only on devices whose
 *  subgroups are at least 32 wide. */
const SUBGROUP_WIDTH = 32;

/** Rows per workgroup: each lane keeps BLOCK_ROWS accumulators, so one
 *  weight load feeds BLOCK_ROWS rows. The column count per workgroup is 4 —
 *  the width of one vec4f weight load. */
const BLOCK_ROWS = 4;

/** Shape gate for the small-m route. The executor's pipeline key and its
 *  handle routing must agree, so both call this. */
export function matmulSmallMEligible(m: number, n: number, subgroupsOk: boolean): boolean {
  return subgroupsOk && m >= 4 && m % 4 === 0 && m <= MATMUL_SMALL_M_MAX_ROWS && n % 4 === 0;
}

interface SmallMCfg {
  k: number;
  n: number; // n % 4 == 0 (the executor keeps other widths off this route)
  hasBias: number; // 0|1 — epilogue adds bias[col]
  hasAdd: number; // 0|1 — epilogue adds addend[row, col] (residual)
}

/** Few-row matmul: out[M,N] = a[M,K] · b[K,N] (+ bias) (act) (+ addend).
 *  One 32-lane workgroup computes a 4×4 block of out. K splits across
 *  lanes: lane l handles j = l, l+32, l+64, …, so every lane holds a
 *  partial sum of every block cell. Each K step loads b[j, col0..col0+3]
 *  once as a vec4 and feeds all four row accumulators — 16 cells advance
 *  per weight load. Four subgroupAdds sum the lane partials, then lane 0
 *  applies the epilogue and writes the block. Grid is [n/4, m/4]; the
 *  executor keeps other m/n off this route, so no bounds checks. Epilogue
 *  order matches matmul.ts: act(a·b + bias) + addend, with the activation
 *  arriving as a body through activations.ts's actSlot (filled at pipeline
 *  creation), so act = 0 folds to a pass-through. K, N and the bias/addend
 *  flags are plain numbers baked into the shader (untaken epilogue branches
 *  fold out); m only sizes the grid, so one pipeline serves every
 *  row count. The K loop runs a fixed floor(k/32) rounds on every lane;
 *  the k % 32 leftover is a separate tail block whose lane guard rejoins
 *  before the subgroupAdds — so every subgroupAdd runs with all 32 lanes
 *  converged, for any k. */
function makeMatmulSmallMKernel(cfg: SmallMCfg, elem: Elem) {
  const { k, n, hasBias, hasAdd } = cfg;
  const fullSteps = Math.floor(k / SUBGROUP_WIDTH);
  const tailLanes = k % SUBGROUP_WIDTH; // lanes with one extra K element
  const layout = matmulGemvVariant(elem).layout;
  const storeScalar = elem.scalar;
  const f16 = elem.key === 'f16';
  return tgpu.computeFn({
    in: { wid: d.builtin.workgroupId, lid: d.builtin.localInvocationId },
    workgroupSize: [SUBGROUP_WIDTH],
  })(({ wid, lid }) => {
    'use gpu';
    const lane = lid.x;
    const col0 = wid.x * 4;
    const row0 = wid.y * BLOCK_ROWS;

    // Per-row vec4 accumulators; unrolled loops index them with comptime `r`,
    // so they stay in registers.
    const accs = d.arrayOf(d.vec4f, BLOCK_ROWS)();
    for (const step of std.range(fullSteps)) {
      const j = lane + d.u32(step) * SUBGROUP_WIDTH;
      const bBase = j * n + col0;
      const bv = f16
        ? d.vec4f(
            d.vec4h(
              layout.$.b[bBase]!,
              layout.$.b[bBase + 1]!,
              layout.$.b[bBase + 2]!,
              layout.$.b[bBase + 3]!,
            ),
          )
        : d.vec4f(
            layout.$.b[bBase]!,
            layout.$.b[bBase + 1]!,
            layout.$.b[bBase + 2]!,
            layout.$.b[bBase + 3]!,
          );
      const aBase = row0 * k + j;
      for (const r of tgpu.unroll(std.range(BLOCK_ROWS))) {
        accs[r] = accs[r]! + d.f32(layout.$.a[aBase + r * k]!) * bv;
      }
    }
    // k % 32 tail — absent from the shader when k divides evenly.
    if (tailLanes > 0) {
      if (lane < tailLanes) {
        const j = lane + d.u32(fullSteps) * SUBGROUP_WIDTH;
        const bBase = j * n + col0;
        const bv = f16
          ? d.vec4f(
              d.vec4h(
                layout.$.b[bBase]!,
                layout.$.b[bBase + 1]!,
                layout.$.b[bBase + 2]!,
                layout.$.b[bBase + 3]!,
              ),
            )
          : d.vec4f(
              layout.$.b[bBase]!,
              layout.$.b[bBase + 1]!,
              layout.$.b[bBase + 2]!,
              layout.$.b[bBase + 3]!,
            );
        const aBase = row0 * k + j;
        for (const r of tgpu.unroll(std.range(BLOCK_ROWS))) {
          accs[r] = accs[r]! + d.f32(layout.$.a[aBase + r * k]!) * bv;
        }
      }
    }
    for (const r of tgpu.unroll(std.range(BLOCK_ROWS))) {
      accs[r] = std.subgroupAdd(accs[r]!);
    }

    if (lane === 0) {
      if (hasBias > 0) {
        const bias = f16
          ? d.vec4f(
              d.vec4h(
                layout.$.bias[col0]!,
                layout.$.bias[col0 + 1]!,
                layout.$.bias[col0 + 2]!,
                layout.$.bias[col0 + 3]!,
              ),
            )
          : d.vec4f(
              layout.$.bias[col0]!,
              layout.$.bias[col0 + 1]!,
              layout.$.bias[col0 + 2]!,
              layout.$.bias[col0 + 3]!,
            );
        for (const r of tgpu.unroll(std.range(BLOCK_ROWS))) {
          accs[r] = accs[r]! + bias;
        }
      }
      for (const r of tgpu.unroll(std.range(BLOCK_ROWS))) {
        accs[r] = actSlot.$(accs[r]!);
      }
      for (const r of tgpu.unroll(std.range(BLOCK_ROWS))) {
        const oBase = (row0 + r) * n + col0;
        if (hasAdd > 0) {
          accs[r] =
            accs[r]! +
            (f16
              ? d.vec4f(
                  d.vec4h(
                    layout.$.addend[oBase]!,
                    layout.$.addend[oBase + 1]!,
                    layout.$.addend[oBase + 2]!,
                    layout.$.addend[oBase + 3]!,
                  ),
                )
              : d.vec4f(
                  layout.$.addend[oBase]!,
                  layout.$.addend[oBase + 1]!,
                  layout.$.addend[oBase + 2]!,
                  layout.$.addend[oBase + 3]!,
                ));
        }
        layout.$.out[oBase] = storeScalar(accs[r]!.x);
        layout.$.out[oBase + 1] = storeScalar(accs[r]!.y);
        layout.$.out[oBase + 2] = storeScalar(accs[r]!.z);
        layout.$.out[oBase + 3] = storeScalar(accs[r]!.w);
      }
    }
  });
}

export function createMatmulSmallMPipeline(
  root: TgpuRoot,
  cfg: { k: number; n: number; hasBias?: number; hasAdd?: number; act?: number },
  elem: Elem = F32_ELEM,
) {
  return root.with(actSlot, activationFor(cfg.act)).createComputePipeline({
    compute: makeMatmulSmallMKernel(
      {
        k: cfg.k,
        n: cfg.n,
        hasBias: cfg.hasBias ?? 0,
        hasAdd: cfg.hasAdd ?? 0,
      },
      elem,
    ),
  });
}

export function matmulSmallMHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createMatmulSmallMPipeline>,
  m: number,
  n: number,
  buffers: { a: F32Buffer; b: F32Buffer; out: F32Buffer; bias?: F32Buffer; addend?: F32Buffer },
  elem: Elem = F32_ELEM,
): KernelHandle {
  // Absent epilogue operands alias `a` — those pipelines never read them.
  const bindGroup = root.createBindGroup(matmulGemvVariant(elem).layout, {
    ...buffers,
    bias: buffers.bias ?? buffers.a,
    addend: buffers.addend ?? buffers.a,
  });
  // One 32-lane workgroup per (4-col unit, BLOCK_ROWS-row block).
  return makeHandle(pipeline, 'matmulSmallM', bindGroup, [n / 4, m / BLOCK_ROWS]);
}
