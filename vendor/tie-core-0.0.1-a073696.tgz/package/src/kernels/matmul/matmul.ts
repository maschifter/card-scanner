import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  flatIndex,
  type F32Buffer,
  type KernelHandle,
  makeHandle,
  WORKGROUP_SIZE,
} from '../common.ts';
import { cachedBindGroup, cachedUniform } from '../../gpu/dispatchCache.ts';
import { activationFor, actSlot } from '../activations.ts';
import { type Elem, F32_ELEM } from '../elem.ts';

/** Runtime-dynamic row count, plus the MoE row view. `baseRow` offsets into
 *  b's rows (the view is rows [baseRow, baseRow+K)) and MUST stay a uniform:
 *  every expert of a layer shares K and N and differs only in baseRow, so
 *  baking it would compile one pipeline per expert. It is read only when
 *  cfg.hasBaseRow is 1, so every non-MoE matmul keeps its exact old shader. */
const Dims = d.struct({ m: d.u32, baseRow: d.u32 });

/** Weight-determined shape and epilogue form: plain JS numbers, closed over
 *  by the kernel factories below. They used to be a tgpu.accessor Config,
 *  which is NOT comptime to TGSL — accessor fields resolve as runtime values,
 *  so the K loop kept a uniform bound and the N % 4 tail branch survived into
 *  every shader even when N was known to divide by 4. As plain numbers they
 *  are WGSL literals, and the tail block is emitted only when it can run. */
export interface MatmulCfg {
  k: number;
  n: number;
  hasBias: number; // 0 | 1 — epilogue adds bias[col]
  hasAdd: number; // 0 | 1 — epilogue adds addend[row, col] (residual fold)
  /** How the K loop accumulates, f16 storage only (ACC_*). Default f32.
   *  See the MEASURED note on ACC_F16 before switching it on. */
  accum: number;
  /** 1 → b is a row VIEW starting at the uniform's baseRow (MoE experts share
   *  one fused [E·K, N] weight). 0 → b starts at row 0 and the shader never
   *  reads baseRow. */
  hasBaseRow: number;
}

/** MatmulCfg.accum values. Numbers, not strings: the pipeline cache key is a
 *  Record<string, number>.
 *
 *  MEASURED (2026-08-28, M-series Metal, min of 7 passes x 50 dispatches,
 *  3 repeats, arms interleaved, MiniLM-L6 shapes at 197 tokens; drift is max
 *  abs vs the f32 kernel reading the SAME f16-rounded inputs):
 *
 *    shape          accF32 ms/drift    accF16 ms/drift    ratio
 *    197x384x1152   0.0820 / 6.1e-5    0.0740 / 4.6e-3    1.11x
 *    197x384x384    0.0360 / 6.1e-5    0.0340 / 2.1e-3    1.06x
 *    197x384x1536   0.1040 / 1.2e-4    0.0940 / 2.2e-3    1.11x
 *    197x1536x384   0.1320 / 6.1e-5    0.1200 / 4.6e-3    1.10x
 *
 *  So f16 accumulation buys 1.06-1.11x for ~50x the drift — this kernel is
 *  not ALU-bound enough for the f16 FMA rate to pay. DEFAULT STAYS f32. The
 *  flag is kept because A-series is untested and is where the f16 rate
 *  advantage is supposed to be largest.
 *
 *  MEASURED DUD, stripped: a CHUNKED arm (f16 FMAs inside a 64-step run,
 *  promoted to the f32 accumulators each time) ran 1.5-1.8x SLOWER than plain
 *  f32 accumulation (0.1200 vs 0.0820, 0.2360 vs 0.1320) while its drift
 *  (1.8e-3 - 3.5e-3) was no better than full f16. The per-chunk runtime bound
 *  and the extra live vec4h registers cost more than the f16 FMAs saved. A
 *  comptime-unrolled chunk count was not tried. */
export const ACC_F32 = 0;
export const ACC_F16 = 1;

/** Process-wide accumulation mode for f16 matmuls: a JS flag that reaches the
 *  shader through the pipeline CONFIG, so switching it compiles a second
 *  pipeline rather than mutating a live one. f32 matmuls ignore it. */
let matmulAccum = ACC_F32;
export function setMatmulAccum(mode: number): void {
  matmulAccum = mode;
}
export function getMatmulAccum(): number {
  return matmulAccum;
}

const cfgOf = (c: {
  k: number;
  n: number;
  hasBias?: number;
  hasAdd?: number;
  accum?: number;
  hasBaseRow?: number;
}): MatmulCfg => ({
  k: c.k,
  n: c.n,
  hasBias: c.hasBias ?? 0,
  hasAdd: c.hasAdd ?? 0,
  accum: c.accum ?? ACC_F32,
  hasBaseRow: c.hasBaseRow ?? 0,
});

/** Generic row-major f32 matmul with an optional fused epilogue:
 *  out[M,N] = a[M,K] · b[K,N] (+ bias[N]) (+ addend[M,N]). Only M is a
 *  uniform (rows vary per call); K, N and the epilogue flags are JS closure
 *  captures and vanish during transpilation — the K loop gets a literal
 *  bound, the column-unit count folds instead of costing an f32 divide per
 *  thread, and the N % 4 tail block is emitted ONLY for widths that need it.
 *  The activation arrives as a BODY through activations.ts's actSlot, filled
 *  at pipeline creation, so this kernel never enumerates activations and
 *  act = 0 costs a folded pass-through.
 *  bias folds a Linear's bias add, the activation applies to a·b + bias, and
 *  addend a residual add into the same dispatch — order act(a·b + bias) +
 *  addend, matching the
 *  composed chain; results agree with it to ~1 ulp (the backend
 *  compiler may FMA-contract the dot loop differently per variant). Unused
 *  bindings alias `a` (read-only aliasing, zero alloc — the attn-sinks trick).
 *  Register-blocked 4×4: one thread produces a 4-row × 4-col output block.
 *  Per k step it loads b[j, col0..+3] ONCE as a vec4 and feeds four row
 *  accumulators (one a load each) — 16 outputs per b load, and the four
 *  independent accumulator chains overlap where a single chain would
 *  serialize on FMA latency. Rows past M clamp to the last row (loads stay
 *  in bounds; their outputs are discarded by the guarded writeback), so only
 *  the writeback branches on M. A block's last col unit falls back to a
 *  per-col scalar loop when N % 4 != 0 (e.g. the [·,33] unembed), keeping
 *  the hot loop branch-free and all reads in bounds.
 *
 *  MEASURED (2026-08-27, M-series Metal, timestamp-query, min of 11 passes ×
 *  20 dispatches, arms interleaved): the accessor → factory conversion is
 *  PARITY, 1.000-1.006× at m=64 k=768 n=3072, m=64 k=768 n=768 +bias+gelu,
 *  m=197 k=384 n=1152 and the n=33 tail shape. The driver was already folding
 *  the accessor constants, so deleting the dead tail block buys no time. It
 *  is kept for what it does buy: the shader no longer carries a branch that
 *  cannot run, and comptime K/N are the precondition for unrolling here. Do
 *  not redo this expecting a speedup. */
const makeLayout = (elem: Elem) =>
  tgpu.bindGroupLayout({
    a: { storage: d.arrayOf(elem.scalar), access: 'readonly' },
    b: { storage: d.arrayOf(elem.scalar), access: 'readonly' },
    bias: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [N]; dead when hasBias=0
    addend: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [M,N]; dead when hasAdd=0
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' },
    dims: { uniform: Dims },
  });

/** One layout per storage dtype, built once. Bind groups are cached by layout
 *  IDENTITY (gpu/dispatchCache.ts), so the two variants simply occupy two
 *  cache buckets — nothing downstream needs to know there are two. */
const layouts = new Map<string, ReturnType<typeof makeLayout>>();
export function matmulLayoutFor(elem: Elem): ReturnType<typeof makeLayout> {
  let l = layouts.get(elem.key);
  if (!l) {
    l = makeLayout(elem);
    layouts.set(elem.key, l);
  }
  return l;
}

/** The f32 layout, for the callers that predate the dtype split. */
export const matmulLayout = matmulLayoutFor(F32_ELEM);

export function makeMatmulKernel(cfg: MatmulCfg, elem: Elem = F32_ELEM) {
  const { k, n, hasBias, hasAdd, hasBaseRow } = cfg;
  const L = matmulLayoutFor(elem);
  // Accumulation only varies for f16 storage: an f32 buffer has nothing to
  // gain from an f16 accumulator, so the f32 shader keeps its original body.
  const accF16 = elem.key === 'f16' && cfg.accum === ACC_F16;
  /** Comptime: an f16 variant widens every load to f32 and narrows on store,
   *  so the accumulators and the epilogue are dtype-independent. The branches
   *  fold away — each variant's WGSL carries only its own. */
  const f16 = elem.key === 'f16';
  const n4c = Math.ceil(n / 4); // col units per row (tail unit may be partial)
  /** A width that divides by 4 has no partial unit, so the tail block below
   *  is unreachable and never reaches the shader. */
  const hasTail = n % 4 !== 0;
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const m = L.$.dims.m;
    const mQuads = d.u32((m + 3) / 4); // explicit integer division (codebase convention)
    const idx = flatIndex(gid);
    if (idx >= mQuads * n4c) {
      return;
    }
    const r0 = d.u32(idx / n4c) * 4;
    const col0 = (idx % n4c) * 4;
    // Rows past M clamp to the last row: loads stay in bounds, the guarded
    // writeback discards the duplicates.
    const r1 = std.min(r0 + 1, m - 1);
    const r2 = std.min(r0 + 2, m - 1);
    const r3 = std.min(r0 + 3, m - 1);

    if (!hasTail || col0 + 4 <= n) {
      // Full unit: one b vec4 per k step feeds all four row accumulators.
      let acc0 = d.vec4f();
      let acc1 = d.vec4f();
      let acc2 = d.vec4f();
      let acc3 = d.vec4f();
      if (accF16) {
        // Whole K loop in f16: half-width FMAs, one widen at the end.
        let h0 = d.vec4h();
        let h1 = d.vec4h();
        let h2 = d.vec4h();
        let h3 = d.vec4h();
        for (let j = d.u32(0); j < k; j++) {
          const bBase = (hasBaseRow > 0 ? L.$.dims.baseRow + j : j) * n + col0;
          const bv = d.vec4h(
            L.$.b[bBase]!,
            L.$.b[bBase + 1]!,
            L.$.b[bBase + 2]!,
            L.$.b[bBase + 3]!,
          );
          h0 += L.$.a[r0 * k + j]! * bv;
          h1 += L.$.a[r1 * k + j]! * bv;
          h2 += L.$.a[r2 * k + j]! * bv;
          h3 += L.$.a[r3 * k + j]! * bv;
        }
        acc0 = d.vec4f(h0);
        acc1 = d.vec4f(h1);
        acc2 = d.vec4f(h2);
        acc3 = d.vec4f(h3);
      }
      if (!accF16) {
        for (let j = d.u32(0); j < k; j++) {
          const bBase = (hasBaseRow > 0 ? L.$.dims.baseRow + j : j) * n + col0;
          if (f16) {
            // One vec4h -> vec4f conversion per weight quad, not four scalar
            // ones; `a` widens at each use.
            const bv = d.vec4f(
              d.vec4h(L.$.b[bBase]!, L.$.b[bBase + 1]!, L.$.b[bBase + 2]!, L.$.b[bBase + 3]!),
            );
            acc0 += d.f32(L.$.a[r0 * k + j]!) * bv;
            acc1 += d.f32(L.$.a[r1 * k + j]!) * bv;
            acc2 += d.f32(L.$.a[r2 * k + j]!) * bv;
            acc3 += d.f32(L.$.a[r3 * k + j]!) * bv;
          } else {
            const bv = d.vec4f(
              L.$.b[bBase]!,
              L.$.b[bBase + 1]!,
              L.$.b[bBase + 2]!,
              L.$.b[bBase + 3]!,
            );
            acc0 += L.$.a[r0 * k + j]! * bv;
            acc1 += L.$.a[r1 * k + j]! * bv;
            acc2 += L.$.a[r2 * k + j]! * bv;
            acc3 += L.$.a[r3 * k + j]! * bv;
          }
        }
      }
      if (hasBias > 0) {
        const bias = f16
          ? d.vec4f(
              d.vec4h(
                L.$.bias[col0]!,
                L.$.bias[col0 + 1]!,
                L.$.bias[col0 + 2]!,
                L.$.bias[col0 + 3]!,
              ),
            )
          : d.vec4f(L.$.bias[col0]!, L.$.bias[col0 + 1]!, L.$.bias[col0 + 2]!, L.$.bias[col0 + 3]!);
        acc0 += bias;
        acc1 += bias;
        acc2 += bias;
        acc3 += bias;
      }
      acc0 = actSlot.$(acc0);
      acc1 = actSlot.$(acc1);
      acc2 = actSlot.$(acc2);
      acc3 = actSlot.$(acc3);
      // Comptime row index: one straight-line block per accumulator, only the
      // live-row test survives into WGSL.
      for (const r of tgpu.unroll(std.range(4))) {
        const row = r0 + r;
        if (row < m) {
          const oBase = row * n + col0;
          let v = d.vec4f([acc0, acc1, acc2, acc3][r]!);
          if (hasAdd > 0) {
            v += f16
              ? d.vec4f(
                  d.vec4h(
                    L.$.addend[oBase]!,
                    L.$.addend[oBase + 1]!,
                    L.$.addend[oBase + 2]!,
                    L.$.addend[oBase + 3]!,
                  ),
                )
              : d.vec4f(
                  L.$.addend[oBase]!,
                  L.$.addend[oBase + 1]!,
                  L.$.addend[oBase + 2]!,
                  L.$.addend[oBase + 3]!,
                );
          }
          if (f16) {
            const h = d.vec4h(v);
            L.$.out[oBase] = h.x;
            L.$.out[oBase + 1] = h.y;
            L.$.out[oBase + 2] = h.z;
            L.$.out[oBase + 3] = h.w;
          } else {
            L.$.out[oBase] = v.x;
            L.$.out[oBase + 1] = v.y;
            L.$.out[oBase + 2] = v.z;
            L.$.out[oBase + 3] = v.w;
          }
        }
      }
      return;
    }
    // Tail unit (N % 4 != 0): scalar per remaining col for each live row, all
    // reads in bounds. Absent from the shader when N divides by 4.
    if (hasTail) {
      for (const r of tgpu.unroll(std.range(4))) {
        const row = r0 + r;
        if (row >= m) {
          return;
        }
        for (let col = col0; col < n; col++) {
          let acc = d.f32(0);
          if (f16) {
            for (const j of std.range(k)) {
              const bj = hasBaseRow > 0 ? L.$.dims.baseRow + j : j;
              acc += d.f32(L.$.a[row * k + j]!) * d.f32(L.$.b[bj * n + col]!);
            }
          } else {
            for (const j of std.range(k)) {
              const bj = hasBaseRow > 0 ? L.$.dims.baseRow + j : j;
              acc += L.$.a[row * k + j]! * L.$.b[bj * n + col]!;
            }
          }
          if (hasBias > 0) {
            acc += d.f32(L.$.bias[col]!);
          }
          acc = actSlot.$(acc);
          if (hasAdd > 0) {
            acc += d.f32(L.$.addend[row * n + col]!);
          }
          if (f16) {
            L.$.out[row * n + col] = d.f16(acc);
          } else {
            L.$.out[row * n + col] = acc;
          }
        }
      }
    }
  });
}

export function createMatmulPipeline(
  root: TgpuRoot,
  cfg: { k: number; n: number; hasBias?: number; hasAdd?: number; act?: number; accum?: number },
  elem: Elem = F32_ELEM,
) {
  return root
    .with(actSlot, activationFor(cfg.act))
    .createComputePipeline({ compute: makeMatmulKernel(cfgOf(cfg), elem) });
}

export function matmulHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createMatmulPipeline>,
  m: number,
  n: number,
  buffers: { a: F32Buffer; b: F32Buffer; out: F32Buffer; bias?: F32Buffer; addend?: F32Buffer },
  elem: Elem = F32_ELEM,
  baseRow = 0,
): KernelHandle {
  const dims = cachedUniform(root, Dims, { m, baseRow });
  // Absent epilogue operands alias `a` — those pipelines never read them.
  const bindGroup = cachedBindGroup(root, matmulLayoutFor(elem), {
    ...buffers,
    bias: buffers.bias ?? buffers.a,
    addend: buffers.addend ?? buffers.a,
    dims,
  });
  // One thread per 4-row × 4-col block: ceil(m/4) · ceil(n/4).
  return makeHandle(
    pipeline,
    'matmul',
    bindGroup,
    Math.ceil((Math.ceil(m / 4) * Math.ceil(n / 4)) / WORKGROUP_SIZE),
  );
}

// ── Shared-memory tiled variant (M ≥ MATMUL_TILED_MIN_M) ───────────────────
// The kernel above reads each b element from global memory once per 4-row
// block, so with many rows the same weight bytes stream over and over. This
// variant stages a/b tiles in workgroup memory: each weight element is read
// from global once per workgroup (64 output rows) and reused from there.
// 256 threads per workgroup, each producing a 4×4 output block; tiles
// zero-pad past every edge, so the inner loop needs no guards and only the
// writeback checks m/n. Same epilogue (bias, activation, addend) and
// operation order as the kernel above.

/** m threshold for the tiled route: even a single partially-filled 64-row
 *  tile beats the plain per-element kernel down to m=8; below that the
 *  tile's barrier rounds cost more than the plain kernel's serial K loop. */
export const MATMUL_TILED_MIN_M = 8;

const TILE = 64; // output tile side (rows and cols)
const TILE_K = 32; // K-slab depth per barrier round
const TILED_THREADS = 256; // 16×16 logical threads, a 4×4 output block each
const A_LOADS = (TILE * TILE_K) / TILED_THREADS; // co-op loads per thread
const B_LOADS = (TILE_K * TILE) / 4 / TILED_THREADS; // vec4 loads per thread

const aTile = tgpu.workgroupVar(d.arrayOf(d.f32, TILE * TILE_K));
const bTile = tgpu.workgroupVar(d.arrayOf(d.vec4f, (TILE_K * TILE) / 4));

function makeMatmulTiledKernel(cfg: MatmulCfg) {
  const { k, n, hasBias, hasAdd } = cfg;
  /** K-slab count: comptime, so the outer round loop gets a literal bound and
   *  the tail slab's zero-padding predicates fold with it. */
  const tiles = Math.ceil(k / TILE_K);
  return tgpu.computeFn({
    in: { lid: d.builtin.localInvocationId, wid: d.builtin.workgroupId },
    workgroupSize: [TILED_THREADS],
  })(({ lid, wid }) => {
    'use gpu';
    const m = matmulLayout.$.dims.m;
    const tid = lid.x;
    const tr = d.u32(tid / 16); // explicit integer division (codebase convention)
    const tc = tid % 16;
    const rowBase = wid.y * TILE;
    const colBase = wid.x * TILE;
    const r0 = rowBase + tr * 4;
    const c0 = colBase + tc * 4;

    let acc0 = d.vec4f();
    let acc1 = d.vec4f();
    let acc2 = d.vec4f();
    let acc3 = d.vec4f();

    for (const t of std.range(tiles)) {
      const k0 = t * TILE_K;
      // Tile loads: consecutive threads hit consecutive addresses.
      // Out-of-range elements become 0, so the inner loop needs no guards.
      // b stages as vec4 — one shared read serves four output columns.
      for (const i of tgpu.unroll(std.range(A_LOADS))) {
        const e = tid + i * TILED_THREADS;
        const er = d.u32(e / TILE_K);
        const ec = e % TILE_K;
        const ar = rowBase + er;
        const ak = k0 + ec;
        const aIdx = std.min(ar, m - 1) * k + std.min(ak, k - 1);
        aTile.$[e] = std.select(d.f32(0), matmulLayout.$.a[aIdx]!, ar < m && ak < k);
      }
      for (const iv of tgpu.unroll(std.range(B_LOADS))) {
        const e = tid + iv * TILED_THREADS; // vec4 slot: row-major [TILE_K, TILE/4]
        const er = d.u32(e / (TILE / 4));
        const ec = (e % (TILE / 4)) * 4;
        const bk = k0 + er;
        const bc = colBase + ec;
        const rowOk = bk < k;
        const base = std.min(bk, k - 1) * n;
        bTile.$[e] = d.vec4f(
          std.select(d.f32(0), matmulLayout.$.b[base + std.min(bc, n - 1)]!, rowOk && bc < n),
          std.select(
            d.f32(0),
            matmulLayout.$.b[base + std.min(bc + 1, n - 1)]!,
            rowOk && bc + 1 < n,
          ),
          std.select(
            d.f32(0),
            matmulLayout.$.b[base + std.min(bc + 2, n - 1)]!,
            rowOk && bc + 2 < n,
          ),
          std.select(
            d.f32(0),
            matmulLayout.$.b[base + std.min(bc + 3, n - 1)]!,
            rowOk && bc + 3 < n,
          ),
        );
      }
      std.workgroupBarrier();

      for (const kk of std.range(TILE_K)) {
        const bv = bTile.$[kk * (TILE / 4) + tc]!;
        const aBase = tr * 4 * TILE_K + kk;
        acc0 += aTile.$[aBase]! * bv;
        acc1 += aTile.$[aBase + TILE_K]! * bv;
        acc2 += aTile.$[aBase + 2 * TILE_K]! * bv;
        acc3 += aTile.$[aBase + 3 * TILE_K]! * bv;
      }
      std.workgroupBarrier();
    }

    if (hasBias > 0) {
      const bc0 = std.min(c0, n - 1);
      const bias = d.vec4f(
        matmulLayout.$.bias[bc0]!,
        matmulLayout.$.bias[std.min(c0 + 1, n - 1)]!,
        matmulLayout.$.bias[std.min(c0 + 2, n - 1)]!,
        matmulLayout.$.bias[std.min(c0 + 3, n - 1)]!,
      );
      acc0 += bias;
      acc1 += bias;
      acc2 += bias;
      acc3 += bias;
    }
    acc0 = actSlot.$(acc0);
    acc1 = actSlot.$(acc1);
    acc2 = actSlot.$(acc2);
    acc3 = actSlot.$(acc3);

    // Writeback: rows and cols past m/n are dropped. Column guard first — a
    // tail tile's c0 can land past n entirely and row*n + c0 would then point
    // into the next row. The addend adds here (clamped reads for dropped
    // lanes change nothing).
    if (c0 < n) {
      for (const r of tgpu.unroll(std.range(4))) {
        const row = r0 + r;
        if (row < m) {
          const oBase = row * n + c0;
          let v = d.vec4f([acc0, acc1, acc2, acc3][r]!);
          if (hasAdd > 0) {
            v += d.vec4f(
              matmulLayout.$.addend[oBase]!,
              matmulLayout.$.addend[std.min(oBase + 1, m * n - 1)]!,
              matmulLayout.$.addend[std.min(oBase + 2, m * n - 1)]!,
              matmulLayout.$.addend[std.min(oBase + 3, m * n - 1)]!,
            );
          }
          matmulLayout.$.out[oBase] = v.x;
          if (c0 + 1 < n) {
            matmulLayout.$.out[oBase + 1] = v.y;
          }
          if (c0 + 2 < n) {
            matmulLayout.$.out[oBase + 2] = v.z;
          }
          if (c0 + 3 < n) {
            matmulLayout.$.out[oBase + 3] = v.w;
          }
        }
      }
    }
  });
}

export function createMatmulTiledPipeline(
  root: TgpuRoot,
  cfg: { k: number; n: number; hasBias?: number; hasAdd?: number; act?: number },
) {
  return root
    .with(actSlot, activationFor(cfg.act))
    .createComputePipeline({ compute: makeMatmulTiledKernel(cfgOf(cfg)) });
}

export function matmulTiledHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createMatmulTiledPipeline>,
  m: number,
  n: number,
  buffers: { a: F32Buffer; b: F32Buffer; out: F32Buffer; bias?: F32Buffer; addend?: F32Buffer },
): KernelHandle {
  const dims = cachedUniform(root, Dims, { m, baseRow: 0 });
  const bindGroup = cachedBindGroup(root, matmulLayout, {
    ...buffers,
    bias: buffers.bias ?? buffers.a,
    addend: buffers.addend ?? buffers.a,
    dims,
  });
  // One workgroup per 64×64 output tile.
  return makeHandle(pipeline, 'matmulTiled', bindGroup, [Math.ceil(n / TILE), Math.ceil(m / TILE)]);
}
