import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { type F32Buffer, type KernelHandle, makeHandle } from '../common.ts';
import { type Elem, F32_ELEM } from '../elem.ts';

/** Fused gemv + argmax for greedy decoding: w[rows, cols] · x[1, cols] →
 *  out[1] = f32(argmax over rows), lowest index on ties (torch.argmax /
 *  CPU-loop parity). Replaces the sliceRows → transpose → matmul → full-logits
 *  readback chain: the [V, 1] logits vector (131 KB for the Moonshine vocab)
 *  never exists — the per-token readback is 4 bytes.
 *
 *  Two dispatches in the same pass (in-pass ordering makes the partials
 *  visible to the reducer — the same guarantee the eval driver leans on for
 *  chained ops). The whole product is bandwidth- not compute-bound
 *  (~38 MB of weight reads for the Moonshine tiny head), so the layout chases
 *  memory throughput twice over:
 *  - ARGMAX_SPLIT workgroups stride the rows, so the weight reads ride every
 *    GPU core's slice of memory bandwidth; each workgroup writes one
 *    (bestVal, bestIdx) pair and a 1-thread second dispatch merges the pairs
 *    with the index tie-break.
 *  - Within a workgroup, KL adjacent threads share one row: lane l reads
 *    columns l, l+KL, l+2·KL, …, so consecutive threads load consecutive
 *    addresses and each SIMD-group load coalesces into a few wide
 *    transactions. Lane partials meet in workgroup memory in fixed order and
 *    lane 0 of each cluster keeps the row-vs-row running best.
 *  cols is baked per pipeline (weight-determined, like matmul's K); rows
 *  rides the uniform. */

const WG = 256;
/** Column lanes cooperating on one row; KL · RL = WG. */
const KL = 8;
/** Row clusters per workgroup. */
const RL = 32;
/** Workgroups in the partial pass; partials buffer is [SPLIT, 2] f32
 *  (val, idx) pairs. */
export const ARGMAX_SPLIT = 128;
const NEG_SEED = -3.4e38; // ~ -FLT_MAX; every real dot beats it

const Dims = d.struct({ rows: d.u32 });

const Config = d.struct({ cols: d.u32 });
const config = tgpu.accessor(Config, { cols: 1 });

/** `partials` and the workgroup scratch stay f32 in both variants: each slot
 *  is a (bestValue, rowIndex) pair, and a row index past 2048 is not exact in
 *  f16 — it would silently decode the wrong token. The kernel's OUTPUT is a
 *  row index too, so argmaxDot returns f32 whatever its operands are. */
const laneDots = tgpu.workgroupVar(d.arrayOf(d.f32, WG));
const bestVal = tgpu.workgroupVar(d.arrayOf(d.f32, RL));
const bestIdx = tgpu.workgroupVar(d.arrayOf(d.u32, RL));

function makeArgmaxDotVariant(elem: Elem) {
  const layout = tgpu.bindGroupLayout({
    w: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [rows, cols]
    x: { storage: d.arrayOf(elem.scalar), access: 'readonly' }, // [1, cols]
    partials: { storage: d.arrayOf(d.f32), access: 'mutable' }, // [SPLIT, 2] (val, idx)
    dims: { uniform: Dims },
  });
  const kernel = tgpu.computeFn({
    in: {
      lid: d.builtin.localInvocationId,
      wid: d.builtin.workgroupId,
    },
    workgroupSize: [WG],
  })(({ lid, wid }) => {
    'use gpu';
    const rows = layout.$.dims.rows;
    const cols = config.$.cols;
    const tid = lid.x;
    const kl = tid % KL;
    const rl = d.u32(tid / KL);

    // Each cluster scans its rows in increasing order, so strict > keeps the
    // cluster's LOWEST winning index. The step condition only reads
    // workgroup-uniform values — every thread reaches the barriers below the
    // same number of times.
    let v = d.f32(NEG_SEED);
    let idx = d.u32(0);
    for (let stepBase = wid.x * RL; stepBase < rows; stepBase += RL * ARGMAX_SPLIT) {
      const row = stepBase + rl;
      let partial = d.f32(0);
      if (row < rows) {
        const base = row * cols;
        for (let j = kl; j < cols; j += KL) {
          partial += d.f32(layout.$.w[base + j]!) * d.f32(layout.$.x[j]!);
        }
      }
      laneDots.$[tid] = partial;
      std.workgroupBarrier();
      if (kl === 0 && row < rows) {
        let dot = d.f32(0);
        for (const l of tgpu.unroll(std.range(KL))) {
          dot += laneDots.$[rl * KL + l]!;
        }
        if (dot > v) {
          v = dot;
          idx = row;
        }
      }
      std.workgroupBarrier();
    }

    if (kl === 0) {
      bestVal.$[rl] = v;
      bestIdx.$[rl] = idx;
    }
    std.workgroupBarrier();

    // Serial merge by thread 0 with the equal-value tie-break: cluster order is
    // NOT row order across steps (cluster 0's second row trails every cluster's
    // first), so equal values must compare indices explicitly.
    if (tid === 0) {
      let m = bestVal.$[0]!;
      let mi = bestIdx.$[0]!;
      for (const i of std.range(1, RL)) {
        const cv = bestVal.$[i]!;
        const ci = bestIdx.$[i]!;
        if (cv > m) {
          m = cv;
          mi = ci;
        } else if (cv === m) {
          if (ci < mi) {
            mi = ci;
          }
        }
      }
      layout.$.partials[wid.x * 2] = m;
      layout.$.partials[wid.x * 2 + 1] = d.f32(mi);
    }
  });
  return { layout, kernel };
}

const variants = new Map<string, ReturnType<typeof makeArgmaxDotVariant>>();
export function argmaxDotVariant(elem: Elem): ReturnType<typeof makeArgmaxDotVariant> {
  let v = variants.get(elem.key);
  if (!v) {
    v = makeArgmaxDotVariant(elem);
    variants.set(elem.key, v);
  }
  return v;
}

export const argmaxReduceLayout = tgpu.bindGroupLayout({
  partials: { storage: d.arrayOf(d.f32), access: 'readonly' }, // [SPLIT, 2]
  out: { storage: d.arrayOf(d.f32), access: 'mutable' }, // [1] — f32(bestRow)
});

/** SPLIT pairs → one index. One thread; the array is ARGMAX_SPLIT entries. */
export const argmaxDotReduceKernel = tgpu.computeFn({
  in: { gid: d.builtin.globalInvocationId },
  workgroupSize: [1],
})(({ gid }) => {
  'use gpu';
  if (gid.x > 0) return;
  let m = argmaxReduceLayout.$.partials[0]!;
  let mi = argmaxReduceLayout.$.partials[1]!;
  for (const i of std.range(1, ARGMAX_SPLIT)) {
    const cv = argmaxReduceLayout.$.partials[i * 2]!;
    const ci = argmaxReduceLayout.$.partials[i * 2 + 1]!;
    if (cv > m) {
      m = cv;
      mi = ci;
    } else if (cv === m) {
      if (ci < mi) {
        mi = ci;
      }
    }
  }
  argmaxReduceLayout.$.out[0] = mi;
});

export function createArgmaxDotPipeline(
  root: TgpuRoot,
  cfg: { cols: number },
  elem: Elem = F32_ELEM,
) {
  return root.with(config, cfg).createComputePipeline({ compute: argmaxDotVariant(elem).kernel });
}

export function createArgmaxDotReducePipeline(root: TgpuRoot) {
  return root.createComputePipeline({ compute: argmaxDotReduceKernel });
}

export function argmaxDotPartialHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createArgmaxDotPipeline>,
  rows: number,
  buffers: { w: F32Buffer; x: F32Buffer; partials: F32Buffer },
  elem: Elem = F32_ELEM,
): KernelHandle {
  const dims = root.createBuffer(Dims, { rows }).$usage('uniform');
  const bindGroup = root.createBindGroup(argmaxDotVariant(elem).layout, { ...buffers, dims });
  return makeHandle(pipeline, 'argmaxDot', bindGroup, ARGMAX_SPLIT);
}

export function argmaxDotReduceHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createArgmaxDotReducePipeline>,
  buffers: { partials: F32Buffer; out: F32Buffer },
): KernelHandle {
  const bindGroup = root.createBindGroup(argmaxReduceLayout, buffers);
  return makeHandle(pipeline, 'argmaxDotReduce', bindGroup, 1);
}
