/** The storage dtype a kernel's buffers carry, as a JS value a kernel factory
 *  closes over. Captured constants inline as WGSL literals and their branches
 *  fold at transpile time — accessor fields do NOT (see the note in
 *  matmul.ts), so the dtype has to travel this way, never through a
 *  tgpu.accessor or a slot.
 *
 *  Only the STORAGE type varies. Accumulators stay f32 in every variant: an
 *  f16 accumulator over a long reduction drifts by ~sqrt(K)·2^-11, which is
 *  percent-level at K=384 and well past the parity gates. Trading that back
 *  for the f16 FMA rate is a separate, measured change. */
import { d } from 'typegpu';

export interface Elem {
  /** Pipeline-cache key fragment, and the comptime flag kernels branch on. */
  readonly key: 'f32' | 'f16';
  /** Element schema for storage buffers. */
  readonly scalar: d.F32 | d.F16;
  /** The vec4 view of the same storage, for layouts that bind a buffer as
   *  array<vec4> over a contiguous axis (the conv v4 paths). Declared as
   *  Vec4f even for f16 so kernel bodies stay cast-free: the rule there is
   *  that every READ widens with `d.vec4f(...)` (identity on f32) and every
   *  WRITE narrows with `elem.vec4(...)` (identity on f32), so a v4h value
   *  is never handed to something expecting a v4f. */
  readonly vec4: d.Vec4f;
}

export const F32_ELEM: Elem = { key: 'f32', scalar: d.f32, vec4: d.vec4f };
export const F16_ELEM: Elem = {
  key: 'f16',
  scalar: d.f16,
  vec4: d.vec4h as unknown as d.Vec4f,
};

/** The Elem for an EagerDtype that a kernel can read. */
export function elemFor(dtype: string): Elem {
  if (dtype === 'f16') return F16_ELEM;
  if (dtype === 'f32') return F32_ELEM;
  throw new Error(`no kernel element type for dtype '${dtype}'`);
}
