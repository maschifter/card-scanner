import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  type F32Buffer,
  type KernelHandle,
  flatIndex,
  makeHandle,
  WORKGROUP_SIZE,
} from '../common.ts';
import { cachedBindGroup, cachedUniform } from '../../gpu/dispatchCache.ts';
import { gelu } from '../activations.ts';
import { type Elem, F32_ELEM } from '../elem.ts';

/** `a` = scalar operand for addScalar/mulScalar, or clamp lo bound for clampScalar.
 *  `b` = clamp hi bound for clampScalar; 0 when unused. */
const Meta = d.struct({ total: d.u32, a: d.f32, b: d.f32 });

/** Every unary is one thread per element with the same layout and meta; only
 *  the expression differs. Built per storage dtype (kernels/elem.ts): reads
 *  widen to f32 and the result narrows on store, so the math is identical in
 *  both variants and the scalar operands stay f32 in the uniform.
 *
 *  The bodies are written out one by one rather than generated from a shared
 *  `apply(fn)` helper: a helper called from inside a TGSL body resolves to a
 *  WGSL function CALL, which costs real time in this bandwidth-bound family
 *  (see elementwiseF32.ts for the measurement that established the rule). */
function makeUnaryVariant(elem: Elem) {
  const layout = tgpu.bindGroupLayout({
    x: { storage: d.arrayOf(elem.scalar), access: 'readonly' },
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' },
    meta: { uniform: Meta },
  });
  const store = elem.scalar;
  const shell = tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  });

  /** out[i] = 1/sqrt(x[i]). */
  const rsqrt = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    layout.$.out[i] = store(std.inverseSqrt(d.f32(layout.$.x[i]!)));
  });

  /** out[i] = x[i] + a. */
  const addScalar = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    layout.$.out[i] = store(d.f32(layout.$.x[i]!) + layout.$.meta.a);
  });

  /** out[i] = 1/(1+exp(-x[i])). */
  const sigmoid = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    layout.$.out[i] = store(1 / (1 + std.exp(-d.f32(layout.$.x[i]!))));
  });

  /** out[i] = x[i] · a. */
  const mulScalar = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    layout.$.out[i] = store(d.f32(layout.$.x[i]!) * layout.$.meta.a);
  });

  /** out[i] = clamp(x[i], a, b). */
  const clampScalar = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    layout.$.out[i] = store(std.clamp(d.f32(layout.$.x[i]!), layout.$.meta.a, layout.$.meta.b));
  });

  /** out[i] = tanh(x[i]). */
  const tanh = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    layout.$.out[i] = store(std.tanh(d.f32(layout.$.x[i]!)));
  });

  /** out[i] = x·phi(x) — exact GELU, the shared body from activations.ts, so
   *  the standalone op and every fused epilogue are the same code. */
  const geluFn = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    layout.$.out[i] = store(gelu(d.f32(layout.$.x[i]!)));
  });

  /** out[i] = asinh(x[i]) = sign(x)·ln(|x| + sqrt(x²+1)). Evaluated on |x|
   *  with the odd extension rather than the WGSL builtin: ln(x + sqrt(x²+1))
   *  cancels catastrophically for negative x of large magnitude (~1e-3
   *  absolute error at x = -100 on Metal), while the |x| branch is stable
   *  everywhere. */
  const asinh = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    const x = d.f32(layout.$.x[i]!);
    const ax = std.abs(x);
    layout.$.out[i] = store(std.sign(x) * std.log(ax + std.sqrt(ax * ax + 1)));
  });

  /** out[i] = x·sigma(x) = x/(1+exp(-x)) (silu/swish). */
  const silu = shell(({ gid }) => {
    'use gpu';
    const i = flatIndex(gid);
    if (i >= layout.$.meta.total) return;
    const x = d.f32(layout.$.x[i]!);
    layout.$.out[i] = store(x / (1 + std.exp(-x)));
  });

  return {
    layout,
    rsqrt,
    addScalar,
    sigmoid,
    mulScalar,
    clampScalar,
    tanh,
    gelu: geluFn,
    asinh,
    silu,
  };
}

const variants = new Map<string, ReturnType<typeof makeUnaryVariant>>();
export function unaryVariant(elem: Elem): ReturnType<typeof makeUnaryVariant> {
  let v = variants.get(elem.key);
  if (!v) {
    v = makeUnaryVariant(elem);
    variants.set(elem.key, v);
  }
  return v;
}

export function createRsqrtPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).rsqrt });
}
export function createAddScalarPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).addScalar });
}
export function createSigmoidPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).sigmoid });
}
export function createMulScalarPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).mulScalar });
}
export function createClampScalarPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).clampScalar });
}
export function createTanhPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).tanh });
}
export function createGeluPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).gelu });
}
export function createSiluPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).silu });
}
export function createAsinhPipeline(root: TgpuRoot, elem: Elem = F32_ELEM) {
  return root.createComputePipeline({ compute: unaryVariant(elem).asinh });
}

export function unaryHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createRsqrtPipeline>,
  name: string,
  total: number,
  a: number,
  b: number,
  buffers: { x: F32Buffer; out: F32Buffer },
  elem: Elem = F32_ELEM,
): KernelHandle {
  const meta = cachedUniform(root, Meta, { total, a, b });
  const bindGroup = cachedBindGroup(root, unaryVariant(elem).layout, { ...buffers, meta });
  return makeHandle(pipeline, name, bindGroup, Math.ceil(total / WORKGROUP_SIZE));
}
