/** The HWC4 kernel family: conv (generic / 1×1-tiled / depthwise), max pool,
 *  nearest upsample, strided channel-block copy (concat/slice), and the
 *  CHW ↔ HWC4 boundary conversions.
 *
 *  Layout contract (shared with nn.Conv2d's weight repack and the hwc4 ops):
 *  activations are `array<vec4<f16>>`, element (y·W + x)·C4 + cB — four
 *  consecutive channels per vec4, pixel-major, channels zero-padded to a
 *  multiple of 4 (C4 = ceil(C/4)). Every conv load is one aligned 8-byte read
 *  of exactly the channels the inner loop wants next; the math runs native
 *  f16 (accumulators included — parity measured at 0.07-0.16% of range on
 *  yolo26).
 *
 *  Conv weights are mat4-tiles stored as 4 consecutive vec4<f16>s: tile
 *  (oB, iB, tap) at ((oB·CI4 + iB)·kH·kW + tap), entry iL holding the four
 *  OUTPUT lanes for input lane iL — so the inner loop is four vec FMAs:
 *  acc += x.x·w0 + x.y·w1 + x.z·w2 + x.w·w3. Depthwise weights are one
 *  vec4<f16> per (cB, tap). Padded weight lanes are zero, so padded
 *  activation lanes stay exactly 0 through bias(0) and SiLU(0) = 0 — an
 *  elementwise op on the padded array never sees garbage.
 *
 *  Kernels are FACTORIES closing over plain JS numbers, not accessor
 *  structs: a closed-over number is a TypeGPU comptime value, so hasBias/act
 *  branches prune, the 3×3 tap loops unroll (tgpu.unroll — 1.09-1.34× on the
 *  CHW 3×3 family; dw taps stay rolled, unrolling those was a measured dud),
 *  and every kH/kW/stride/padding reaches WGSL as a literal. One kernel per
 *  layer geometry, deduped by eval's PipelineCache. Input h/w stay a runtime
 *  uniform — baking them was a measured warmup dud on the CHW path. */

import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  type F16Buffer,
  type F32Buffer,
  flatIndex,
  type KernelHandle,
  makeFlatIndex,
  makeHandle,
  WORKGROUP_SIZE,
} from '../common.ts';
import { cachedBindGroup, cachedUniform } from '../../gpu/dispatchCache.ts';

/** The 1×1 kernel's workgroup size (the POC's measured choice). */
export const WG_1X1 = 256;
const flatIndex256 = makeFlatIndex(WG_1X1);

/** Runtime-variable dims for the conv/dw kernels: input spatial size, plus
 *  the output channel-block stride and offset — normally (co4, 0), but a
 *  conv elided into a consumer concat writes (holderC4, blockOffset), so the
 *  same pipeline serves both (no recompiles, unlike a baked offset). */
const ConvDims = d.struct({ h: d.u32, w: d.u32, outC4: d.u32, outOffB: d.u32 });

const convLayout = tgpu.bindGroupLayout({
  x: { storage: d.arrayOf(d.vec4h), access: 'readonly' },
  w: { storage: d.arrayOf(d.vec4h), access: 'readonly' },
  bias: { storage: d.arrayOf(d.f16), access: 'readonly' },
  res: { storage: d.arrayOf(d.vec4h), access: 'readonly' }, // residual addend (dummy when hasAdd=0)
  out: { storage: d.arrayOf(d.vec4h), access: 'mutable' },
  dims: { uniform: ConvDims },
});

export interface Conv2dHwc4Cfg {
  cIn: number;
  cOut: number;
  kH: number;
  kW: number;
  stride: number;
  padding: number;
  hasBias: number;
  hasAct: number;
  /** 1 when a residual addend is fused into the epilogue (set by the eval
   *  driver's peephole, not by model code). Baked; part of the pipeline key. */
  hasAdd: number;
  /** 0 generic | 1 one-by-one fast path | 2 depthwise. Decided by the
   *  dispatcher from the layer geometry; part of the pipeline key. */
  kind: number;
  /** 1×1 pixel-tile width (8 when hw % 8 == 0, else 4). Dispatcher-set;
   *  part of the pipeline key. */
  pxT?: number;
}

/** bias + optional SiLU epilogue, all in f16. Comptime-pruned per geometry:
 *  hasBias/act branches vanish, and a 4-aligned cOut (every yolo26 layer)
 *  loads its bias quad unguarded. Misaligned tails clamp the read in-bounds
 *  (WGSL robustness) and select 0 for the padded lanes. */
const makeEpilogue = (cfg: Conv2dHwc4Cfg) => {
  const { cOut, hasBias, hasAct, hasAdd } = cfg;
  const co4 = Math.ceil(cOut / 4);
  const aligned = cOut % 4 === 0;
  return (acc: d.v4h, oB: number, pxOut: number): d.v4h => {
    'use gpu';
    let r = acc * d.f16(1);
    if (hasBias === 1) {
      const c0 = oB * 4;
      if (aligned) {
        r += d.vec4h(
          convLayout.$.bias[c0]!,
          convLayout.$.bias[c0 + 1]!,
          convLayout.$.bias[c0 + 2]!,
          convLayout.$.bias[c0 + 3]!,
        );
      }
      if (!aligned) {
        const zero = d.f16(0);
        r += d.vec4h(
          std.select(zero, convLayout.$.bias[std.min(c0, cOut - 1)]!, c0 < cOut),
          std.select(zero, convLayout.$.bias[std.min(c0 + 1, cOut - 1)]!, c0 + 1 < cOut),
          std.select(zero, convLayout.$.bias[std.min(c0 + 2, cOut - 1)]!, c0 + 2 < cOut),
          std.select(zero, convLayout.$.bias[std.min(c0 + 3, cOut - 1)]!, c0 + 3 < cOut),
        );
      }
    }
    if (hasAct === 1) {
      r = r / (d.vec4h(1) + std.exp(d.vec4h(0) - r));
    }
    if (hasAdd === 1) {
      // torch order x + cv(x): the addend lands AFTER bias+act. The res
      // tensor has the node's own shape — co4 stride, no offset.
      r += d.vec4h(convLayout.$.res[pxOut * co4 + oB]!);
    }
    return r;
  };
};

/** Generic conv: one thread per (output block, output pixel), ox fastest —
 *  neighbouring threads read neighbouring pixels and share every weight
 *  tile. Tap loops unroll (kH·kW ≤ 9 here); the channel loop stays rolled
 *  with a literal bound. */
export const makeConvGenericKernel = (cfg: Conv2dHwc4Cfg) => {
  const { kH, kW, stride, padding } = cfg;
  const ci4 = Math.ceil(cfg.cIn / 4);
  const co4 = Math.ceil(cfg.cOut / 4);
  const kk = kH * kW;
  const epilogue = makeEpilogue(cfg);
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const dims = convLayout.$.dims;
    const hOut = d.u32((dims.h + 2 * padding - kH) / stride) + 1;
    const wOut = d.u32((dims.w + 2 * padding - kW) / stride) + 1;
    const idx = flatIndex(gid);
    if (idx >= co4 * hOut * wOut) {
      return;
    }
    const ox = idx % wOut;
    const oy = d.u32(idx / wOut) % hOut;
    const oB = d.u32(idx / (wOut * hOut));

    let acc = d.vec4h();
    for (const ky of tgpu.unroll(std.range(kH))) {
      // +padding shift keeps the bounds test in u32 (codebase convention).
      const iyP = oy * stride + ky;
      if (iyP >= padding && iyP < dims.h + padding) {
        const iy = iyP - padding;
        for (const kx of tgpu.unroll(std.range(kW))) {
          const ixP = ox * stride + kx;
          if (ixP >= padding && ixP < dims.w + padding) {
            const ix = ixP - padding;
            const pIn = (iy * dims.w + ix) * ci4;
            // comptime literal per unrolled tap; u32-wrapped so the index
            // math stays u32 (a bare JS int would drag it to i32).
            const tap = d.u32(ky * kW + kx);
            for (let iB = d.u32(0); iB < ci4; iB++) {
              const xv = convLayout.$.x[pIn + iB]!;
              const tb = ((oB * ci4 + iB) * kk + tap) * 4;
              acc += xv.x * convLayout.$.w[tb]!;
              acc += xv.y * convLayout.$.w[tb + 1]!;
              acc += xv.z * convLayout.$.w[tb + 2]!;
              acc += xv.w * convLayout.$.w[tb + 3]!;
            }
          }
        }
      }
    }
    const pxOut = oy * wOut + ox;
    convLayout.$.out[pxOut * dims.outC4 + dims.outOffB + oB] = epilogue(acc, oB, pxOut);
  });
};

/** 1×1 conv: pixel register tile — each weight tile read feeds pxT pixel
 *  vecs (without a tile the naive HWC4 1×1 LOSES to CHW, see the handoff's
 *  dud ledger). Block-fastest thread order: a warp's threads share the same
 *  x vecs (broadcast) and stream different weight tiles — the pixel-fastest
 *  alternative (CHW v4's order) measured 2.1× WORSE here, hwc4 x reads of
 *  adjacent pixel groups are ci4 vecs apart so nothing coalesces. pxT is 8
 *  when the map divides evenly (every yolo26 map), else 4. */
export const makeConv1x1Kernel = (cfg: Conv2dHwc4Cfg) => {
  const ci4 = Math.ceil(cfg.cIn / 4);
  const co4 = Math.ceil(cfg.cOut / 4);
  const pxT = cfg.pxT === 8 ? 8 : 4;
  const epilogue = makeEpilogue(cfg);
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WG_1X1],
  })(({ gid }) => {
    'use gpu';
    const dims = convLayout.$.dims;
    const pT = d.u32((dims.h * dims.w) / pxT);
    const idx = flatIndex256(gid);
    if (idx >= pT * co4) {
      return;
    }
    const p0 = d.u32(idx / co4) * pxT;
    const oB = idx % co4;

    const accs = d.arrayOf(d.vec4h, pxT)();
    for (let iB = d.u32(0); iB < ci4; iB++) {
      const tb = (oB * ci4 + iB) * 4;
      const w0 = convLayout.$.w[tb]!;
      const w1 = convLayout.$.w[tb + 1]!;
      const w2 = convLayout.$.w[tb + 2]!;
      const w3 = convLayout.$.w[tb + 3]!;
      for (const k of tgpu.unroll(std.range(pxT))) {
        const xv = convLayout.$.x[(p0 + k) * ci4 + iB]!;
        accs[k] = accs[k]! + xv.x * w0 + xv.y * w1 + xv.z * w2 + xv.w * w3;
      }
    }
    const ob0 = dims.outOffB + oB;
    for (const k of tgpu.unroll(std.range(pxT))) {
      convLayout.$.out[(p0 + k) * dims.outC4 + ob0] = epilogue(accs[k]!, oB, p0 + k);
    }
  });
};

/** Depthwise conv (groups == cIn == cOut): one thread per (channel block,
 *  output pixel); weight is one vec4 per (cB, tap). Tap loops stay ROLLED —
 *  unrolling dw3x3 was a measured dud on the CHW family — but their bounds
 *  are literals, so the driver may still unroll on its own. */
const makeConvDwKernel = (cfg: Conv2dHwc4Cfg) => {
  const { kH, kW, stride, padding } = cfg;
  const c4n = Math.ceil(cfg.cOut / 4);
  const kk = kH * kW;
  const epilogue = makeEpilogue(cfg);
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const dims = convLayout.$.dims;
    const hOut = d.u32((dims.h + 2 * padding - kH) / stride) + 1;
    const wOut = d.u32((dims.w + 2 * padding - kW) / stride) + 1;
    const idx = flatIndex(gid);
    if (idx >= c4n * hOut * wOut) {
      return;
    }
    const ox = idx % wOut;
    const oy = d.u32(idx / wOut) % hOut;
    const cB = d.u32(idx / (wOut * hOut));

    let acc = d.vec4h();
    for (let ky = d.u32(0); ky < kH; ky++) {
      const iyP = oy * stride + ky;
      if (iyP >= padding && iyP < dims.h + padding) {
        const iy = iyP - padding;
        for (let kx = d.u32(0); kx < kW; kx++) {
          const ixP = ox * stride + kx;
          if (ixP >= padding && ixP < dims.w + padding) {
            const ix = ixP - padding;
            acc +=
              convLayout.$.w[cB * kk + ky * kW + kx]! *
              convLayout.$.x[(iy * dims.w + ix) * c4n + cB]!;
          }
        }
      }
    }
    const pxOut = oy * wOut + ox;
    convLayout.$.out[pxOut * dims.outC4 + dims.outOffB + cB] = epilogue(acc, cB, pxOut);
  });
};

export function createConv2dHwc4Pipeline(root: TgpuRoot, cfg: Conv2dHwc4Cfg) {
  const kernel =
    cfg.kind === 1
      ? makeConv1x1Kernel(cfg)
      : cfg.kind === 2
        ? makeConvDwKernel(cfg)
        : makeConvGenericKernel(cfg);
  return root.createComputePipeline({ compute: kernel });
}

export function conv2dHwc4Handle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createConv2dHwc4Pipeline>,
  cfg: Conv2dHwc4Cfg,
  args: { h: number; w: number; outC4?: number; outOffB?: number },
  buffers: { x: F16Buffer; w: F16Buffer; bias: F16Buffer; res: F16Buffer; out: F16Buffer },
): KernelHandle {
  const { h, w } = args;
  const co4 = Math.ceil(cfg.cOut / 4);
  const dims = cachedUniform(root, ConvDims, {
    h,
    w,
    outC4: args.outC4 ?? co4,
    outOffB: args.outOffB ?? 0,
  });
  const bindGroup = cachedBindGroup(root, convLayout, { ...buffers, dims });
  const shape = `${cfg.cIn}>${cfg.cOut}@${h}x${w}`;
  if (cfg.kind === 1) {
    const threads = ((h * w) / (cfg.pxT === 8 ? 8 : 4)) * co4;
    return makeHandle(
      pipeline,
      'conv2d_hwc4_1x1',
      bindGroup,
      Math.ceil(threads / WG_1X1),
      `conv2d_hwc4_1x1 ${shape}`,
    );
  }
  const hOut = Math.floor((h + 2 * cfg.padding - cfg.kH) / cfg.stride) + 1;
  const wOut = Math.floor((w + 2 * cfg.padding - cfg.kW) / cfg.stride) + 1;
  const name = cfg.kind === 2 ? 'conv2d_hwc4_dw' : 'conv2d_hwc4';
  return makeHandle(
    pipeline,
    name,
    bindGroup,
    Math.ceil((co4 * hOut * wOut) / WORKGROUP_SIZE),
    `${name} ${shape}`,
  );
}

// ---------------------------------------------------------------- pool / upsample

/** Runtime dims for the weightless movers: channel blocks + spatial size all
 *  vary per call, only the window/scale geometry keys the pipeline. */
const MoveDims = d.struct({ c4: d.u32, h: d.u32, w: d.u32, outC4: d.u32, outOffB: d.u32 });

const moveLayout = tgpu.bindGroupLayout({
  x: { storage: d.arrayOf(d.vec4h), access: 'readonly' },
  out: { storage: d.arrayOf(d.vec4h), access: 'mutable' },
  dims: { uniform: MoveDims },
});

export interface MaxPool2dHwc4Cfg {
  kernelSize: number;
  stride: number;
  padding: number;
}

/** Max pool over one channel block per thread — the window max is 4 channels
 *  wide per read. Padded taps are skipped (torch's implicit-pad semantics);
 *  padded lanes stay 0 because max(0, 0) = 0 across every input block.
 *  Window geometry is comptime (literal loop bounds); taps stay rolled —
 *  k=5 would be 25 straight-line iterations, past the unroll ceiling. */
const makeMaxPoolHwc4Kernel = (cfg: MaxPool2dHwc4Cfg) => {
  const { kernelSize: k, stride, padding } = cfg;
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const dims = moveLayout.$.dims;
    const hOut = d.u32((dims.h + 2 * padding - k) / stride) + 1;
    const wOut = d.u32((dims.w + 2 * padding - k) / stride) + 1;
    const idx = flatIndex(gid);
    if (idx >= dims.c4 * hOut * wOut) {
      return;
    }
    const ox = idx % wOut;
    const oy = d.u32(idx / wOut) % hOut;
    const cB = d.u32(idx / (wOut * hOut));

    let best = d.vec4h(-65504.0); // f16 lowest; every window has >= 1 valid tap
    for (let ky = d.u32(0); ky < k; ky++) {
      const iyP = oy * stride + ky;
      if (iyP >= padding && iyP < dims.h + padding) {
        const iy = iyP - padding;
        for (let kx = d.u32(0); kx < k; kx++) {
          const ixP = ox * stride + kx;
          if (ixP >= padding && ixP < dims.w + padding) {
            best = std.max(best, moveLayout.$.x[(iy * dims.w + (ixP - padding)) * dims.c4 + cB]!);
          }
        }
      }
    }
    moveLayout.$.out[(oy * wOut + ox) * dims.outC4 + dims.outOffB + cB] = d.vec4h(best);
  });
};

/** Nearest-neighbour upsample — a strided vec4 copy with a comptime scale. */
const makeUpsampleHwc4Kernel = (scale: number) =>
  tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const dims = moveLayout.$.dims;
    const hOut = dims.h * scale;
    const wOut = dims.w * scale;
    const idx = flatIndex(gid);
    if (idx >= dims.c4 * hOut * wOut) {
      return;
    }
    const ox = idx % wOut;
    const oy = d.u32(idx / wOut) % hOut;
    const cB = d.u32(idx / (wOut * hOut));
    moveLayout.$.out[(oy * wOut + ox) * dims.outC4 + dims.outOffB + cB] = d.vec4h(
      moveLayout.$.x[(d.u32(oy / scale) * dims.w + d.u32(ox / scale)) * dims.c4 + cB]!,
    );
  });

export function createMaxPool2dHwc4Pipeline(root: TgpuRoot, cfg: MaxPool2dHwc4Cfg) {
  return root.createComputePipeline({ compute: makeMaxPoolHwc4Kernel(cfg) });
}

export function createUpsample2dHwc4Pipeline(root: TgpuRoot, cfg: { scale: number }) {
  return root.createComputePipeline({ compute: makeUpsampleHwc4Kernel(cfg.scale) });
}

/** moveHwc4Handle serves both maxPool2dHwc4 and upsample2dHwc4 — one pipeline
 *  type would reject the other's dispatch. */
export type MoveHwc4Pipeline =
  ReturnType<typeof createMaxPool2dHwc4Pipeline> | ReturnType<typeof createUpsample2dHwc4Pipeline>;

export function moveHwc4Handle(
  root: TgpuRoot,
  pipeline: MoveHwc4Pipeline,
  name: string,
  args: { c: number; h: number; w: number; outElems: number; outC4?: number; outOffB?: number },
  buffers: { x: F16Buffer; out: F16Buffer },
): KernelHandle {
  const c4 = Math.ceil(args.c / 4);
  const dims = cachedUniform(root, MoveDims, {
    c4,
    h: args.h,
    w: args.w,
    outC4: args.outC4 ?? c4,
    outOffB: args.outOffB ?? 0,
  });
  const bindGroup = cachedBindGroup(root, moveLayout, { ...buffers, dims });
  return makeHandle(
    pipeline,
    name,
    bindGroup,
    Math.ceil(args.outElems / 4 / WORKGROUP_SIZE),
    `${name} ${args.c}@${args.h}x${args.w}`,
  );
}

// ---------------------------------------------------------------- channel copy

/** Everything runtime → ONE pipeline serves every concat/slice at every
 *  shape. One thread per (pixel, block): out[px·dstC4 + dstOff + b] =
 *  x[px·srcC4 + srcOff + b]. */
const CopyDims = d.struct({
  pElems: d.u32,
  srcC4: d.u32,
  dstC4: d.u32,
  srcOffB: d.u32,
  dstOffB: d.u32,
  nB: d.u32,
});

const copyLayout = tgpu.bindGroupLayout({
  x: { storage: d.arrayOf(d.vec4h), access: 'readonly' },
  out: { storage: d.arrayOf(d.vec4h), access: 'mutable' },
  dims: { uniform: CopyDims },
});

const copyChHwc4Kernel = tgpu.computeFn({
  in: { gid: d.builtin.globalInvocationId },
  workgroupSize: [WORKGROUP_SIZE],
})(({ gid }) => {
  'use gpu';
  const dims = copyLayout.$.dims;
  const idx = flatIndex(gid);
  if (idx >= dims.pElems * dims.nB) {
    return;
  }
  const px = d.u32(idx / dims.nB);
  const b = idx % dims.nB;
  copyLayout.$.out[px * dims.dstC4 + dims.dstOffB + b] = d.vec4h(
    copyLayout.$.x[px * dims.srcC4 + dims.srcOffB + b]!,
  );
});

export function createCopyChHwc4Pipeline(root: TgpuRoot) {
  return root.createComputePipeline({ compute: copyChHwc4Kernel });
}

export function copyChHwc4Handle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createCopyChHwc4Pipeline>,
  args: {
    pElems: number;
    srcC4: number;
    dstC4: number;
    srcOffB: number;
    dstOffB: number;
    nB: number;
  },
  buffers: { x: F16Buffer; out: F16Buffer },
): KernelHandle {
  const dims = cachedUniform(root, CopyDims, args);
  const bindGroup = cachedBindGroup(root, copyLayout, { ...buffers, dims });
  return makeHandle(
    pipeline,
    'copyCh_hwc4',
    bindGroup,
    Math.ceil((args.pElems * args.nB) / WORKGROUP_SIZE),
  );
}

// ---------------------------------------------------------------- CHW ↔ HWC4

const ConvertDims = d.struct({ c: d.u32, h: d.u32, w: d.u32 });

/** CHW (f32 or f16) → HWC4 f16. One thread per output vec4: four strided
 *  scalar reads gather one pixel's channel block, lanes past C write 0. */
const makeToHwc4Layout = (srcF16: boolean) =>
  tgpu.bindGroupLayout({
    x: { storage: d.arrayOf(srcF16 ? d.f16 : d.f32), access: 'readonly' },
    out: { storage: d.arrayOf(d.vec4h), access: 'mutable' },
    dims: { uniform: ConvertDims },
  });
const toHwc4Layouts = { f32: makeToHwc4Layout(false), f16: makeToHwc4Layout(true) };

const makeToHwc4Kernel = (srcKey: 'f32' | 'f16') => {
  const layout = toHwc4Layouts[srcKey];
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const dims = layout.$.dims;
    const p = dims.h * dims.w;
    const c4 = d.u32((dims.c + 3) / 4);
    const idx = flatIndex(gid);
    if (idx >= p * c4) {
      return;
    }
    const px = d.u32(idx / c4);
    const cB = idx % c4;
    const c0 = cB * 4;
    const zero = d.f16(0);
    const last = dims.c - 1;
    layout.$.out[px * c4 + cB] = d.vec4h(
      std.select(zero, d.f16(layout.$.x[std.min(c0, last) * p + px]!), c0 < dims.c),
      std.select(zero, d.f16(layout.$.x[std.min(c0 + 1, last) * p + px]!), c0 + 1 < dims.c),
      std.select(zero, d.f16(layout.$.x[std.min(c0 + 2, last) * p + px]!), c0 + 2 < dims.c),
      std.select(zero, d.f16(layout.$.x[std.min(c0 + 3, last) * p + px]!), c0 + 3 < dims.c),
    );
  });
};
const toHwc4Kernels = { f32: makeToHwc4Kernel('f32'), f16: makeToHwc4Kernel('f16') };

/** HWC4 f16 → CHW (f32 or f16). One thread per input vec4: one wide read,
 *  up to four strided scalar writes (lanes past C dropped). */
const makeToChwLayout = (dstF16: boolean) =>
  tgpu.bindGroupLayout({
    x: { storage: d.arrayOf(d.vec4h), access: 'readonly' },
    out: { storage: d.arrayOf(dstF16 ? d.f16 : d.f32), access: 'mutable' },
    dims: { uniform: ConvertDims },
  });
const toChwLayouts = { f32: makeToChwLayout(false), f16: makeToChwLayout(true) };

const makeToChwKernel = (dstKey: 'f32' | 'f16') => {
  const layout = toChwLayouts[dstKey];
  const store = dstKey === 'f16' ? d.f16 : d.f32;
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const dims = layout.$.dims;
    const p = dims.h * dims.w;
    const c4 = d.u32((dims.c + 3) / 4);
    const idx = flatIndex(gid);
    if (idx >= p * c4) {
      return;
    }
    const px = d.u32(idx / c4);
    const cB = idx % c4;
    const v = layout.$.x[px * c4 + cB]!;
    const c0 = cB * 4;
    for (const k of tgpu.unroll(std.range(4))) {
      if (c0 + k < dims.c) {
        layout.$.out[(c0 + k) * p + px] = store(d.f32([v.x, v.y, v.z, v.w][k]!));
      }
    }
  });
};
const toChwKernels = { f32: makeToChwKernel('f32'), f16: makeToChwKernel('f16') };

export function createToHwc4Pipeline(root: TgpuRoot, srcKey: 'f32' | 'f16') {
  return root.createComputePipeline({ compute: toHwc4Kernels[srcKey] });
}

export function createToChwPipeline(root: TgpuRoot, dstKey: 'f32' | 'f16') {
  return root.createComputePipeline({ compute: toChwKernels[dstKey] });
}

export function toHwc4Handle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createToHwc4Pipeline>,
  srcKey: 'f32' | 'f16',
  args: { c: number; h: number; w: number },
  buffers: { x: F32Buffer | F16Buffer; out: F16Buffer },
): KernelHandle {
  const { c, h, w } = args;
  const dims = cachedUniform(root, ConvertDims, { c, h, w });
  const bindGroup = cachedBindGroup(root, toHwc4Layouts[srcKey], { ...buffers, dims });
  const threads = h * w * Math.ceil(c / 4);
  return makeHandle(pipeline, 'toHwc4', bindGroup, Math.ceil(threads / WORKGROUP_SIZE));
}

export function toChwHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createToChwPipeline>,
  dstKey: 'f32' | 'f16',
  args: { c: number; h: number; w: number },
  buffers: { x: F16Buffer; out: F32Buffer | F16Buffer },
): KernelHandle {
  const { c, h, w } = args;
  const dims = cachedUniform(root, ConvertDims, { c, h, w });
  const bindGroup = cachedBindGroup(root, toChwLayouts[dstKey], { ...buffers, dims });
  const threads = h * w * Math.ceil(c / 4);
  return makeHandle(pipeline, 'toChw', bindGroup, Math.ceil(threads / WORKGROUP_SIZE));
}
