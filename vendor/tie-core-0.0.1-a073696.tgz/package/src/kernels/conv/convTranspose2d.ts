import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  type F32Buffer,
  type KernelHandle,
  flatIndex,
  makeHandle,
  type U32Buffer,
  WORKGROUP_SIZE,
} from '../common.ts';
import { cachedBindGroup, cachedUniform } from '../../gpu/dispatchCache.ts';
import type { Elem } from '../elem.ts';

/** Runtime-variable dims: input spatial size only. */
const Dims = d.struct({ h: d.u32, w: d.u32 });

/** Layer geometry — k === stride === upscale factor (the no-overlap case:
 *  each output pixel gets exactly one weight tap, so this is a per-pixel GEMM
 *  with C_out·k² rows, no scatter/atomics). Plain JS numbers closed over by
 *  the kernel factory: cIn's PARITY picks the inner loop shape, which an
 *  accessor field could not do (TGSL sees accessor fields as runtime). */
export interface ConvTranspose2dCfg {
  cIn: number;
  cOut: number;
  k: number;
  hasBias: number; // 0 | 1
}

/** CHW activations in the model's storage dtype; weights are f16 pairs in
 *  u32 words [C_out·k·k, C_in] flat (row co·k²+di·k+dj, C_in contiguous →
 *  sequential pair decode) in every variant; bias in the activation dtype
 *  (1-elem dummy when hasBias=0 — read is comptime-dead then). */
const makeLayout = (elem: Elem) =>
  tgpu.bindGroupLayout({
    x: { storage: d.arrayOf(elem.scalar), access: 'readonly' },
    w: { storage: d.arrayOf(d.u32), access: 'readonly' },
    bias: { storage: d.arrayOf(elem.scalar), access: 'readonly' },
    out: { storage: d.arrayOf(elem.scalar), access: 'mutable' },
    dims: { uniform: Dims },
  });

/** One layout per storage dtype, built once — bind groups cache by layout
 *  identity, so the variants land in separate buckets. */
const layouts = new Map<string, ReturnType<typeof makeLayout>>();
function layoutFor(elem: Elem): ReturnType<typeof makeLayout> {
  let l = layouts.get(elem.key);
  if (!l) {
    l = makeLayout(elem);
    layouts.set(elem.key, l);
  }
  return l;
}

/** One thread per output element, wo fastest → coalesced writes. Each thread
 *  reads one input pixel column and one weight row.
 *
 *  The weight row is f16 pairs in u32 words, and consecutive input channels
 *  are consecutive halves — so when cIn is EVEN (rowBase is then even too)
 *  each word serves exactly two channels. The loop steps by two, unpacks each
 *  word once and uses both halves, instead of re-reading the same word on the
 *  next iteration and picking a half with a select. Deciding that needs cIn's
 *  parity on the CPU, which is what the factory is for.
 *
 *  MEASURED (2026-08-27, M-series Metal, timestamp-query, min of 11 passes ×
 *  20 dispatches, arms interleaved): 1.64× at cIn=256 cOut=128 k=2 @40²,
 *  1.70× at cIn=64 cOut=32 k=2 @160², 1.51× at cIn=128 cOut=64 k=4 @40².
 *  Output bit-identical. The odd-cIn path below is the original loop. */
function makeConvTranspose2dKernel(cfg: ConvTranspose2dCfg, elem: Elem) {
  const { cIn, cOut, k, hasBias } = cfg;
  const paired = cIn % 2 === 0;
  const layout = layoutFor(elem);
  const storeScalar = elem.scalar;
  return tgpu.computeFn({
    in: { gid: d.builtin.globalInvocationId },
    workgroupSize: [WORKGROUP_SIZE],
  })(({ gid }) => {
    'use gpu';
    const dims = layout.$.dims;
    const hOut = dims.h * k;
    const wOut = dims.w * k;
    const idx = flatIndex(gid);
    if (idx >= cOut * hOut * wOut) {
      return;
    }
    const wo = idx % wOut;
    const ho = d.u32(idx / wOut) % hOut;
    const co = d.u32(idx / (wOut * hOut));
    const hi = d.u32(ho / k); // explicit integer division (codebase convention)
    const wi = d.u32(wo / k);
    const di = ho % k;
    const dj = wo % k;
    const rowBase = (co * k * k + di * k + dj) * cIn;
    const xPix = hi * dims.w + wi;
    const plane = dims.h * dims.w;
    let acc = d.f32(0);
    if (paired) {
      const wordBase = d.u32(rowBase / 2); // rowBase is even when cIn is
      for (const c2 of std.range(cIn / 2)) {
        const pair = std.unpack2x16float(layout.$.w[wordBase + c2]!);
        const xb = 2 * c2 * plane + xPix;
        acc += pair.x * d.f32(layout.$.x[xb]!) + pair.y * d.f32(layout.$.x[xb + plane]!);
      }
    } else {
      for (const ci of std.range(cIn)) {
        const flat = rowBase + ci;
        const pair = std.unpack2x16float(layout.$.w[d.u32(flat / 2)]!);
        const wv = std.select(pair.x, pair.y, flat % 2 === 1);
        acc += wv * d.f32(layout.$.x[ci * plane + xPix]!);
      }
    }
    if (hasBias === 1) {
      acc += d.f32(layout.$.bias[co]!);
    }
    layout.$.out[idx] = storeScalar(acc);
  });
}

export function createConvTranspose2dPipeline(root: TgpuRoot, cfg: ConvTranspose2dCfg, elem: Elem) {
  return root.createComputePipeline({ compute: makeConvTranspose2dKernel(cfg, elem) });
}

export function convTranspose2dHandle(
  root: TgpuRoot,
  pipeline: ReturnType<typeof createConvTranspose2dPipeline>,
  cfg: ConvTranspose2dCfg,
  args: { h: number; w: number },
  buffers: { x: F32Buffer; w: U32Buffer; bias: F32Buffer; out: F32Buffer },
  elem: Elem,
): KernelHandle {
  const { h, w } = args;
  const dims = cachedUniform(root, Dims, { h, w });
  const bindGroup = cachedBindGroup(root, layoutFor(elem), { ...buffers, dims });
  const total = cfg.cOut * h * cfg.k * w * cfg.k;
  return makeHandle(pipeline, 'convTranspose2d', bindGroup, Math.ceil(total / WORKGROUP_SIZE));
}
