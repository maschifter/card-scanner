/** Fused-epilogue activations: one body per activation, shared by every
 *  kernel that folds one into its epilogue (matmul, conv1d)
 *  and by the standalone unary kernels. */

import tgpu, { d, std } from 'typegpu';

/** Same type in, same type out, at every lane width a fused epilogue uses:
 *  vec4f (the f32 matmul/conv1d block), vec2f (a decoded weight pair's
 *  column) and f32 (their scalar tails). */
export type Activation = {
  (x: number): number;
  (x: d.v2f): d.v2f;
  (x: d.v4f): d.v4f;
};

/** Each body is typed against ONE concrete width and its maths is purely
 *  component-wise, so TypeGPU re-emits it per call-site type — `gelu`,
 *  `gelu_1`, `gelu_2` all fall out of the single definition below.
 *
 *  The polymorphism has to sit on the DECLARATION like this. A union
 *  parameter (`x: number | d.v2f | d.v4f`) does not typecheck: the erf
 *  polynomial multiplies vector-valued intermediates (`t * (A1 + t * ...)`)
 *  and tsover's operator overloads do not distribute over a union. */

/** No activation. `x * 1` rather than plain `x` because TGSL rejects
 *  returning a parameter by reference.
 *  The multiply is free: 65_536 threads x 4096 applications each measured
 *  0.7147ms through this slot vs 0.7151ms with the call removed entirely
 *  (M-series Metal, timestamp-query, 3 runs) — while filling the same slot
 *  with GELU costs 1.5785ms, so the difference was well within reach. The
 *  shader compiler folds it, as it may: x*1 is exact for every f32
 *  including NaN, +/-Inf and -0. */
export const identityAct = ((x: d.v4f) => {
  'use gpu';
  return x * 1;
}) as Activation;

export const tanhAct = ((x: d.v4f) => {
  'use gpu';
  return std.tanh(x);
}) as Activation;

/** erf approximation constants — Abramowitz & Stegun, "Handbook of
 *  Mathematical Functions", formula 7.1.26:
 *
 *      erf(z) ≈ 1 − (a1·t + a2·t² + a3·t³ + a4·t⁴ + a5·t⁵)·e^(−z²),
 *      t = 1/(1 + P·z),  for z ≥ 0;  erf(−z) = −erf(z).
 *
 *  P and a1..a5 are the PUBLISHED constants of that formula — fixed as a set,
 *  not tunables (change one and the ≤1.5e−7 error bound is void). Chosen over
 *  the cheap x·σ(1.702x) GELU approximation (~2e−2 error) because parity gates
 *  compare against torch's exact-erf GELU; 1.5e−7 is below f32 resolution. */
const INV_SQRT2 = Math.SQRT1_2; // 1/√2
const ERF_P = 0.3275911;
const ERF_A1 = 0.254829592;
const ERF_A2 = -0.284496736;
const ERF_A3 = 1.421413741;
const ERF_A4 = -1.453152027;
const ERF_A5 = 1.061405429;

/** Exact GELU: x·Φ(x) = 0.5·x·(1 + erf(x/√2)). WGSL has no erf, so it is the
 *  A&S 7.1.26 polynomial on |z| with the odd extension. THE definition —
 *  every GELU in the engine, fused or standalone, resolves to this body. */
export const gelu = ((x: d.v4f) => {
  'use gpu';
  const z = x * INV_SQRT2;
  const az = std.abs(z);
  const t = 1 / (1 + az * ERF_P);
  // a1·t + … + a5·t⁵ in Horner form.
  const poly = t * (ERF_A1 + t * (ERF_A2 + t * (ERF_A3 + t * (ERF_A4 + t * ERF_A5))));
  const erf = std.sign(z) * (1 - poly * std.exp(-az * az));
  return 0.5 * x * (1 + erf);
}) as Activation;

/** x·σ(x) (silu/swish) — the fused conv2d epilogue. Every conv family applies
 *  it through the slot below rather than inlining the sigmoid, so a conv with
 *  a different activation needs a table entry here, not a kernel edit. */
export const siluAct = ((x: d.v4f) => {
  'use gpu';
  return x / (1 + std.exp(-x));
}) as Activation;

/** `act` code → body, and THE list of valid codes: 0 none, 1 tanh, 2 exact
 *  GELU, 3 silu. The CODE is what keys the pipeline cache (it takes a
 *  Record<string, number>, so a function cannot go in it); the slot below
 *  carries the body. Append here to add an activation — no kernel changes.
 *  Kernel docs point here rather than restating the codes, so adding one
 *  cannot leave a stale list behind. (conv2d is the exception: its `act` is a
 *  boolean and it fills the slot with siluAct directly.) */
export const ACTIVATIONS: readonly Activation[] = [identityAct, tanhAct, gelu, siluAct];

/** Resolve an `act` code to its body. Every pipeline builder goes through
 *  this rather than indexing ACTIVATIONS with a `!`: an out-of-range code
 *  would otherwise pass `undefined` into `.with(actSlot, ...)` and surface
 *  much later as an unrelated resolution error. */
export function activationFor(code: number | undefined): Activation {
  const body = ACTIVATIONS[code ?? 0];
  if (!body) {
    throw new Error(
      `unknown activation code ${code} — valid codes are 0..${ACTIVATIONS.length - 1}`,
    );
  }
  return body;
}

/** The activation a kernel's epilogue applies. One slot serves every lane
 *  width, and it defaults to a no-op so an unfilled pipeline still resolves.
 *  Fill at pipeline creation: `.with(actSlot, activationFor(cfg.act))`. */
export const actSlot = tgpu.slot<Activation>(identityAct);
