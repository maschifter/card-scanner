/** Stock nn layers. Each holds Parameters and calls the S1e functional form —
 *  exactly like torch.nn.Linear.forward → F.linear. */

import { groupNorm, linear, rmsNorm } from '../graph/compose.ts';
import {
  conv1d,
  conv2d,
  convTranspose2d,
  gatherRows,
  gatherRowsFrom,
  layerNorm,
  sdpa,
  sdpaPacked,
} from '../graph/ops.ts';
import { matrix, type Value } from '../graph/value.ts';
import {
  convToTapMajor,
  packConvHwc4F16,
  packDwHwc4F16,
  permuteConvTransposeF16,
  transposeF32,
} from '../weights/convert.ts';
import { foldBnIntoConv } from '../weights/foldBn.ts';
import { derivedTensor, type LazyStateDict } from '../weights/safetensors.ts';
import { tensor } from '../gpu/buffers.ts';
import { CpuParameter, Module, Parameter, type AnyModule } from './module.ts';

/** Token-id lookup table: ids → rows of a [numEmbeddings, dims] weight —
 *  torch.nn.Embedding, with torch's device/dtype kwargs as the storage knobs.
 *
 *  device 'gpu' (default): the weight is a GPU Parameter and doubles as a
 *  tied LM head — models matmul against the raw [numEmbeddings, dims]
 *  orientation via `weight.value`, so no transposed copy exists and tying is
 *  exact by construction. No logits helper here: a full [t, vocab] projection
 *  is never needed, so consumers matmul the weight against just the rows they
 *  want. Half precision is model.half(), not a per-layer knob.
 *
 *  device 'cpu': the table stays in CPU memory (a CpuParameter); forward()
 *  gathers just the requested rows and uploads a [T, dim] input tensor, so
 *  the GPU never holds the table. Storage follows the checkpoint — a BF16
 *  weight keeps its raw bits (half the RAM; pf's 200064×640 table is ~512MB
 *  in f32), anything else loads as plain f32. No tied-head access on cpu —
 *  the weight never reaches the GPU.
 *
 *  Parameter named `weight` for checkpoint-key parity. */
export class Embedding extends Module<[readonly number[] | Value], Value> {
  readonly weight: Parameter;
  constructor(
    readonly numEmbeddings: number,
    readonly embeddingDim: number,
    opts: { device?: 'gpu' | 'cpu' } = {},
  ) {
    super();
    this.weight =
      opts.device === 'cpu'
        ? new CpuParameter({
            elems: numEmbeddings * embeddingDim,
            dtype: 'f32', // FIXME: this is heresy, the underlying data can be other type and this is just so that the loader counts bytes properly
            dims: [numEmbeddings, embeddingDim],
          })
        : new Parameter(matrix(numEmbeddings, embeddingDim));
  }
  /** CPU gather of the requested rows as f32 — cpu tables only. */
  gather(tokenIds: readonly number[]): Float32Array {
    if (!(this.weight instanceof CpuParameter)) {
      throw new Error('Embedding.gather: cpu-resident tables only');
    }
    const { numEmbeddings: vocab, embeddingDim: dim } = this;
    const table = this.weight.data;
    const out = new Float32Array(tokenIds.length * dim);
    const u32 = new Uint32Array(out.buffer);
    tokenIds.forEach((id, t) => {
      if (!Number.isInteger(id) || id < 0 || id >= vocab) {
        throw new Error(`Embedding: token id ${id} out of range (vocab ${vocab})`);
      }
      const base = id * dim;
      if (table instanceof Float32Array) {
        out.set(table.subarray(base, base + dim), t * dim);
      } else {
        // bf16 bits expand to f32 by shifting into the top half
        for (let i = 0; i < dim; i++) u32[t * dim + i] = table[base + i]! << 16;
      }
    });
    return out;
  }
  /** Token ids → embedded rows [t, dims] (always f32). Ids are either a
   *  CPU-known array or a GPU-resident f32 id vector — the latter is data in
   *  a device buffer, so a captured graph re-runs on new tokens by
   *  overwriting that buffer instead of rebuilding the gather node. cpu
   *  tables take the array form only. */
  forward(ids: readonly number[] | Value): Value {
    if (Array.isArray(ids)) {
      return this.weight instanceof CpuParameter
        ? tensor(this.gather(ids), {
            elems: ids.length * this.embeddingDim,
            dtype: this.weight.shape.dtype,
            dims: [ids.length, this.embeddingDim],
          })
        : gatherRows(this.weight.value, ids as readonly number[]);
    }
    if (this.weight instanceof CpuParameter) {
      throw new Error('Embedding: GPU-resident ids need a gpu table');
    }
    return gatherRowsFrom(this.weight.value, ids as Value);
  }
}

/** y = x @ weight + bias. weight stored [inFeatures, outFeatures] (K,N) in
 *  the model's float dtype (model.half() flips it). Checkpoints store torch's
 *  [out, in]; transformStateDict transposes once at load, so models feed
 *  torch state dicts as-is. `bias: false` skips the bias Parameter
 *  entirely — torch's Linear(bias=False). A per-call `addend` folds a
 *  residual add into the same dispatch (the matmul epilogue) — the
 *  pre-norm sublayer tail `add(x, proj(h))` in one kernel. `activation`
 *  folds a following tanh / exact GELU into the same dispatch (Conv1d has
 *  the same option) — applied to x·W + bias, before any addend. */
export class Linear extends Module {
  readonly weight: Parameter;
  readonly bias?: Parameter;
  readonly activation?: 'tanh' | 'gelu';
  constructor(
    readonly inFeatures: number,
    readonly outFeatures: number,
    opts: { bias?: boolean; activation?: 'tanh' | 'gelu' } = {},
  ) {
    super();
    this.weight = new Parameter(matrix(inFeatures, outFeatures));
    this.activation = opts.activation;
    this.bias =
      opts.bias === false
        ? undefined
        : new Parameter({ elems: outFeatures, dtype: 'f32', dims: [outFeatures] });
  }
  override transformStateDict(sd: LazyStateDict, prefix: string): void {
    const name = prefix ? `${prefix}.weight` : 'weight';
    const tensor = sd.tensors.get(name);
    if (!tensor) return; // missing keys are the strict check's job, not ours
    // Reject anything that is not torch layout [out, in]. Without this check a
    // square wrong-layout weight would load silently transposed.
    if (
      tensor.shape.length !== 2 ||
      tensor.shape[0] !== this.outFeatures ||
      tensor.shape[1] !== this.inFeatures
    ) {
      throw new Error(
        `Linear: ${name} has shape ${JSON.stringify(tensor.shape)}, ` +
          `expected torch layout [${this.outFeatures}, ${this.inFeatures}]`,
      );
    }
    sd.tensors.set(
      name,
      derivedTensor(
        [this.inFeatures, this.outFeatures],
        async () => transposeF32(await tensor.f32(), this.outFeatures, this.inFeatures),
        tensor.byteLength,
      ),
    );
  }
  forward(x: Value, call: { addend?: Value } = {}): Value {
    return linear(x, this.weight.value, this.bias?.value, call.addend, this.activation);
  }
}

/** Strided 1D convolution over time-major [T, inChannels] —
 *  out [(T + padLeft + padRight − kernelSize)/stride + 1, outChannels].
 *  Deviations from torch nn.Conv1d are the conv1d op's surface: 2D time-major
 *  input (no batch dim) and no dilation/groups. `padding` takes torch's
 *  forms — a number (that many zeros on both sides), 'valid' (none), or
 *  'same' (output length = input length, stride 1 only). padLeft/padRight
 *  pad each side independently instead (kernelSize−1 on the left = causal);
 *  everything defaults to 0. The conv1d op validates the combination.
 *  weight is stored tap-major
 *  [kernelSize·inChannels, outChannels] (the kernel's contiguous-inner-loop
 *  layout); checkpoints store torch's (C_out, C_in, k) — transformStateDict
 *  permutes once at load, so models feed torch state dicts as-is. bias [C_out]
 *  folds into the conv dispatch (the conv epilogue), `bias: false` skips it.
 *  `activation` folds a following tanh / exact-GELU into the same dispatch —
 *  a conv → bias → activation stage in one kernel. Parameters named
 *  `weight`/`bias` for checkpoint-key parity. */
export class Conv1d extends Module {
  readonly weight: Parameter;
  readonly bias?: Parameter;
  readonly stride: number;
  readonly padding?: number | 'valid' | 'same';
  readonly padLeft?: number;
  readonly padRight?: number;
  readonly activation?: 'tanh' | 'gelu';
  constructor(
    readonly inChannels: number,
    readonly outChannels: number,
    readonly kernelSize: number,
    opts: {
      stride?: number;
      bias?: boolean;
      padding?: number | 'valid' | 'same';
      padLeft?: number;
      padRight?: number;
      activation?: 'tanh' | 'gelu';
    } = {},
  ) {
    super();
    this.stride = opts.stride ?? 1;
    this.padding = opts.padding;
    this.padLeft = opts.padLeft;
    this.padRight = opts.padRight;
    this.activation = opts.activation;
    const rows = kernelSize * inChannels;
    this.weight = new Parameter(matrix(rows, outChannels));
    this.bias =
      opts.bias === false
        ? undefined
        : new Parameter({ elems: outChannels, dtype: 'f32', dims: [outChannels] });
  }
  override transformStateDict(sd: LazyStateDict, prefix: string): void {
    const name = prefix ? `${prefix}.weight` : 'weight';
    const tensor = sd.tensors.get(name);
    if (!tensor) return; // a missing key is reported by the strict key check
    // Accept only torch layout (C_out, C_in, k) — a weight with equal in/out
    // channels would otherwise load silently scrambled.
    if (
      tensor.shape.length !== 3 ||
      tensor.shape[0] !== this.outChannels ||
      tensor.shape[1] !== this.inChannels ||
      tensor.shape[2] !== this.kernelSize
    ) {
      throw new Error(
        `Conv1d: ${name} has shape ${JSON.stringify(tensor.shape)}, ` +
          `expected torch layout [${this.outChannels}, ${this.inChannels}, ${this.kernelSize}]`,
      );
    }
    sd.tensors.set(
      name,
      derivedTensor(
        [this.kernelSize * this.inChannels, this.outChannels],
        async () =>
          convToTapMajor(await tensor.f32(), this.outChannels, this.inChannels, this.kernelSize),
        tensor.byteLength,
      ),
    );
  }
  forward(x: Value): Value {
    return conv1d(x, this.weight.value, {
      kernelSize: this.kernelSize,
      stride: this.stride,
      padding: this.padding,
      padLeft: this.padLeft,
      padRight: this.padRight,
      bias: this.bias?.value,
      activation: this.activation,
    });
  }
}

/** LayerNorm over the last dim of width `n`, torch's default eps 1e-5.
 *  Weight-only by default (torch nn.LayerNorm(n, bias=False)); `bias: true`
 *  adds the additive beta (torch nn.LayerNorm(n)). Parameters named
 *  `weight`/`bias` for checkpoint-key parity with torch LN. */
export class LayerNorm extends Module {
  readonly weight: Parameter;
  readonly bias?: Parameter;
  constructor(
    readonly n: number,
    readonly eps = 1e-5,
    opts: { bias?: boolean } = {},
  ) {
    super();
    this.weight = new Parameter({ elems: n, dtype: 'f32', dims: [n] });
    if (opts.bias) {
      this.bias = new Parameter({ elems: n, dtype: 'f32', dims: [n] });
    }
  }
  forward(x: Value): Value {
    return layerNorm(x, this.weight.value, this.eps, this.bias?.value);
  }
}

/** GroupNorm over [M, numChannels] with global (rows × channels) statistics
 *  and per-channel affine — torch nn.GroupNorm(numGroups, numChannels), with
 *  weight AND bias, restricted to numGroups = 1 like the composed groupNorm.
 *  Parameters named `weight`/`bias` for checkpoint-key parity. */
export class GroupNorm extends Module {
  readonly weight: Parameter;
  readonly bias: Parameter;
  constructor(
    readonly numGroups: number,
    readonly numChannels: number,
    readonly eps = 1e-5,
  ) {
    super();
    if (numGroups !== 1) {
      throw new Error(`GroupNorm: only numGroups = 1 is supported, got ${numGroups}`);
    }
    this.weight = new Parameter({ elems: numChannels, dtype: 'f32', dims: [numChannels] });
    this.bias = new Parameter({ elems: numChannels, dtype: 'f32', dims: [numChannels] });
  }
  forward(x: Value): Value {
    return groupNorm(x, this.numGroups, this.weight.value, this.bias.value, this.eps);
  }
}

/** 2D convolution over [C_in,H,W] — torch.nn.Conv2d. Runs on the HWC4+f16
 *  kernel family: the checkpoint's f16 OIHW rows repack at load time into
 *  mat4 tiles (depthwise: vec4-per-tap), the weight meta carries the 'hwc4'
 *  tag the conv2d op validates, and forward() expects (and produces)
 *  hwc4-stored activations — models enter the layout once with toHwc4 and
 *  leave with toChw. Groups are 1 or fully depthwise. Needs shader-f16 and a
 *  half()ed model (f16 bias). `kernelSize` is an int k (k×k) or [kH, kW],
 *  torch-style. BN is never a runtime module: the loader folds it into
 *  weight/bias, so `bias: true` is the norm for BN-fused checkpoints. */
export class Conv2d extends Module {
  readonly weight: Parameter;
  readonly bias?: Parameter;
  constructor(
    readonly inChannels: number,
    readonly outChannels: number,
    readonly opts: {
      kernelSize: number | [number, number];
      stride?: number;
      padding?: number;
      groups?: number;
      bias?: boolean;
      /** Fuse a SiLU epilogue into the conv kernel (x·σ(x)). */
      act?: boolean;
    },
  ) {
    super();
    const { kernelSize, groups = 1, bias = true } = opts;
    const [kH, kW] = typeof kernelSize === 'number' ? [kernelSize, kernelSize] : kernelSize;
    const dw = groups === inChannels && inChannels === outChannels;
    if (groups !== 1 && !dw) {
      throw new Error(
        `Conv2d: groups=${groups} is neither 1 nor depthwise (cIn=${inChannels}, cOut=${outChannels})`,
      );
    }
    const kk = (inChannels / groups) * kH * kW;
    this.weight = new Parameter(
      // elems/dims stay the RAW checkpoint size (loadInto's pre-check); the
      // preprocess returns the (larger, padded) packed blob and the upload
      // sizes the buffer from the data, like quantW.
      { elems: outChannels * kk, dtype: 'f16', dims: [outChannels, kk], layout: 'hwc4' },
      (data) => {
        if (!(data instanceof Uint16Array)) {
          throw new Error('Conv2d: weight must arrive as f16 bits (Uint16Array)');
        }
        return dw
          ? packDwHwc4F16(data, outChannels, kH, kW)
          : packConvHwc4F16(data, outChannels, inChannels, kH, kW);
      },
      true, // pinned: the conv kernels only ever read f16 weights
    );
    this.bias = bias
      ? new Parameter({ elems: outChannels, dtype: 'f32', dims: [outChannels] })
      : undefined;
  }
  forward(x: Value): Value {
    const { kernelSize, stride = 1, padding = 0, groups = 1, act = false } = this.opts;
    return conv2d(x, this.weight.value, this.bias?.value, {
      kernelSize,
      stride,
      padding,
      groups,
      act,
    });
  }
}

/** Transposed 2D conv (torch.nn.ConvTranspose2d), no-overlap k === stride
 *  form only — YOLO's Proto upsampler. Checkpoints supply torch's
 *  [C_in, C_out, k, k] layout; the kernel reads rows [C_out·k·k, C_in], so
 *  the weight permutes itself at load (preprocess), like Conv2d's repack. */
export class ConvTranspose2d extends Module {
  readonly weight: Parameter;
  readonly bias?: Parameter;
  constructor(
    readonly inChannels: number,
    readonly outChannels: number,
    readonly opts: { kernelSize: number; stride: number; bias?: boolean },
  ) {
    super();
    const { kernelSize: k, bias = true } = opts;
    this.weight = new Parameter(
      {
        elems: outChannels * k * k * inChannels,
        dtype: 'f16',
        dims: [outChannels * k * k, inChannels],
      },
      (data) =>
        data instanceof Uint16Array
          ? permuteConvTransposeF16(data, inChannels, outChannels, k)
          : data,
      true, // pinned: the conv kernels only ever read f16 weights
    );
    this.bias = bias
      ? new Parameter({ elems: outChannels, dtype: 'f32', dims: [outChannels] })
      : undefined;
  }
  forward(x: Value): Value {
    return convTranspose2d(x, this.weight.value, this.bias?.value, {
      kernelSize: this.opts.kernelSize,
      stride: this.opts.stride,
    });
  }
}

/** torch.nn.BatchNorm2d. Declare it exactly like in PyTorch (same position,
 *  same eps) and it costs nothing at runtime: while weights load, its stats
 *  are folded into the conv declared right before it. Pass `foldInto` only
 *  when that conv isn't the immediately preceding field. Loading throws if
 *  there is no conv to fold into — running BN unfused isn't supported. */
export class BatchNorm2d extends Module {
  constructor(
    readonly numFeatures: number,
    readonly opts: { eps?: number; foldInto?: string } = {},
  ) {
    super();
  }
  // Declares no Parameters: the fold below consumes all bn.* checkpoint keys,
  // so nothing remains to bind and the strict name check stays clean.
  override transformStateDict(sd: LazyStateDict, prefix: string, parent?: AnyModule): void {
    const cut = prefix.lastIndexOf('.');
    const sibling = (name: string) => (cut < 0 ? name : `${prefix.slice(0, cut + 1)}${name}`);
    foldBnIntoConv(
      sd,
      sibling(this.opts.foldInto ?? this.precedingConvName(prefix, parent)),
      prefix,
      this.opts.eps ?? 1e-5,
    );
  }
  /** The Conv2d registered immediately before this bn in the parent. */
  private precedingConvName(prefix: string, parent?: AnyModule): string {
    let prev: readonly [string, AnyModule] | undefined;
    for (const entry of parent?.namedChildren() ?? []) {
      if (entry[1] === this) {
        if (prev && prev[1] instanceof Conv2d && prev[1].outChannels === this.numFeatures) {
          return prev[0];
        }
        break;
      }
      prev = entry;
    }
    throw new Error(
      `BatchNorm2d at '${prefix}': cannot infer its conv — needs a Conv2d with ` +
        `${this.numFeatures} out-channels registered immediately before it, ` +
        `or pass { foldInto: '<convField>' }`,
    );
  }
  /** Identity: by the time forward can run, the fold has already moved this
   *  bn's math into its conv (loadStateDict throws first in every state where
   *  that isn't true), so a faithful PyTorch forward calling bn(conv(x))
   *  costs nothing and stays correct. */
  forward(x: Value): Value {
    return x;
  }
}

/** RMSNorm over the last dim of width `n`. */
export class RMSNorm extends Module {
  readonly scale: Parameter;
  constructor(
    readonly n: number,
    readonly eps = 1e-6,
  ) {
    super();
    this.scale = new Parameter({ elems: n, dtype: 'f32', dims: [n] });
  }
  forward(x: Value): Value {
    return rmsNorm(x, this.scale.value, this.eps);
  }
}

export interface MultiHeadAttentionOpts {
  qHeads: number;
  kvHeads: number;
  headDim: number;
  /** Band mask: key j visible to query at qPos iff qPos − windowLeft ≤ j ≤
   *  qPos + windowRight. Infinity = unbounded side. */
  windowLeft: number;
  windowRight: number;
  /** Register a per-q-head sink-logit Parameter (log2-space, loaded from the
   *  checkpoint under the name `sinks`). Off by default. */
  sinks?: boolean;
}

/** Banded/causal/cross multi-head attention over packed [T, heads·headDim]
 *  slabs — the layer form of the sdpa op, holding the head geometry, the
 *  band, and (optionally) the sink logits as its only Parameter.
 *
 *  The torch analogy (nn.MultiheadAttention → F.scaled_dot_product_attention)
 *  is loose: q/k/v/out projections are NOT part of this layer — models own
 *  them (fused qkv layouts, rope between projection and attention, folded
 *  score scales), so this layer takes already-projected q/k/v and applies
 *  sm_scale = 1 (fold any scale upstream). `qPosOffset` is per-call: in
 *  incremental decode it advances every step and rides the op's uniform, so
 *  no pipeline recompiles. */
export class MultiHeadAttention extends Module<
  [Value, Value, Value, { qPosOffset?: number; segments?: Value; maxSegment?: number }?],
  Value
> {
  readonly sinks?: Parameter;
  constructor(private readonly opts: MultiHeadAttentionOpts) {
    super();
    this.sinks = opts.sinks
      ? new Parameter(
          { elems: opts.qHeads, dtype: 'f32', dims: [opts.qHeads] },
          undefined,
          true, // pinned: attention sinks are f32 in every kernel variant
        )
      : undefined;
  }
  forward(
    q: Value,
    k: Value,
    v: Value,
    call: { qPosOffset?: number; segments?: Value; maxSegment?: number } = {},
  ): Value {
    const { qHeads, kvHeads, headDim, windowLeft, windowRight } = this.opts;
    return sdpa(q, k, v, {
      qHeads,
      kvHeads,
      headDim,
      windowLeft,
      windowRight,
      qPosOffset: call.qPosOffset,
      sinks: this.sinks?.value,
      segments: call.segments,
      maxSegment: call.maxSegment,
    });
  }
  /** Self-attention over one fused qkv tensor read in place —
   *  [T, (qHeads+2·kvHeads)·headDim] with q | k | v as column blocks, no
   *  slice copies. Same result as forward(q, k, v) on the sliced blocks. */
  forwardPacked(
    qkv: Value,
    call: { qPosOffset?: number; segments?: Value; maxSegment?: number } = {},
  ): Value {
    const { qHeads, kvHeads, headDim, windowLeft, windowRight } = this.opts;
    return sdpaPacked(qkv, {
      qHeads,
      kvHeads,
      headDim,
      windowLeft,
      windowRight,
      qPosOffset: call.qPosOffset,
      sinks: this.sinks?.value,
      segments: call.segments,
      maxSegment: call.maxSegment,
    });
  }
}
