/** Streaming state-dict loader: transform hooks -> strict name check (headers
 *  only, nothing fetched) -> per-tensor fetch/adapt/preprocess/upload. Peak
 *  host memory is one tensor's working set. Callers that already hold weight
 *  data in RAM (tests, generated weights) pass a plain name→array record to
 *  Module.loadStateDict and go through this same path. */
import type { TgpuRoot } from 'typegpu';
import { uploadF16, uploadF32, uploadU32 } from '../gpu/buffers.ts';
import { defaultRoot } from '../gpu/context.ts';
import { inGpuErrorScopes } from '../gpu/errorScopes.ts';
import { materialized, type Value, type ValueMeta } from '../graph/value.ts';
import { bf16ToF16Bits, f32ArrayToF16Bits } from '../weights/convert.ts';
import type { LazyStateDict, LazyTensor } from '../weights/safetensors.ts';
import { CpuParameter, type AnyModule } from './module.ts';

export type UploadFn = (data: Float32Array | Uint32Array | Uint16Array, shape: ValueMeta) => Value;

export interface LoadStateDictOpts {
  /** The GPU to upload onto — the normal way to load. */
  root?: TgpuRoot;
  /** Custom sink overriding the default GPU upload (tests, CPU-resident params). */
  upload?: UploadFn;
  /** After each bound tensor: cumulative file bytes done / total. */
  onProgress?: (name: string, doneBytes: number, totalBytes: number) => void;
}

/** The default GPU upload — the closure formerly copy-pasted per loader.
 *
 *  The SHAPE decides the buffer, not the array type: f32 data destined for a
 *  narrower parameter is converted here. That is the contract Parameter.retype
 *  documents ("the CPU-side data stays f32; the upload converts it to match
 *  the dtype"), and it is what makes `model.half()` + `loadStateDict` work
 *  against a loader that only ever produces f32. Uploading f32 words into an
 *  f16 slot would otherwise build an f32 buffer wearing an f16 label — no
 *  error, and every kernel reading it gets garbage. */
export function gpuUpload(root: TgpuRoot): UploadFn {
  return (data, shape) => {
    if (data instanceof Uint16Array) {
      if (shape.dtype !== 'f16') {
        throw new Error(`upload: halfword data needs an f16 shape, got '${shape.dtype}'`);
      }
      return materialized(shape, uploadF16(root, data));
    }
    if (data instanceof Uint32Array) {
      if (shape.dtype !== 'quantW') {
        throw new Error(`upload: word data needs a quantW shape, got '${shape.dtype}'`);
      }
      return materialized(shape, uploadU32(root, data));
    }
    if (shape.dtype === 'f16') {
      return materialized(shape, uploadF16(root, f32ArrayToF16Bits(data).data));
    }
    if (shape.dtype !== 'f32') {
      throw new Error(`upload: cannot fill a '${shape.dtype}' parameter from f32 data`);
    }
    return materialized(shape, uploadF32(root, data));
  };
}

async function materialize(name: string, t: LazyTensor, want: ValueMeta['dtype']) {
  if (want === 'f16') {
    // An F16 checkpoint needs no conversion at all — its bytes ARE the buffer
    // contents. BF16 converts directly (both are f32 prefixes); anything else
    // rounds down from f32.
    if (t.dtype === 'F16') return t.u16();
    if (t.dtype === 'BF16') {
      const { data, clamped } = bf16ToF16Bits(await t.u16());
      if (clamped > 0)
        console.warn(`loadStateDict: '${name}' clamped ${clamped} values to f16 range`);
      return data;
    }
    // Everything else reports dtype 'F32' — including a DERIVED tensor, whose
    // dtype is nominal whatever its compute() returns (see safetensors.ts).
    // A transform that already produced halfwords (the conv weight repacks)
    // is only visible by asking. This must come AFTER the BF16 branch:
    // u16() succeeds on a BF16 file tensor too, and returning those bits
    // unconverted reinterprets bf16 as f16 — same magnitude, wrong values.
    try {
      return await t.u16();
    } catch {
      /* not raw halfwords; fall through to the f32 conversion below */
    }
    const { data, clamped } = f32ArrayToF16Bits(await t.f32());
    if (clamped > 0)
      console.warn(`loadStateDict: '${name}' clamped ${clamped} values to f16 range`);
    return data;
  }
  if (want === 'quantW') return t.words();
  if (want === 'f32') return t.f32();
  throw new Error(`loadStateDict: '${name}' has unsupported param dtype '${want}'`);
}

const list = (names: string[]) =>
  names.slice(0, 8).join(', ') + (names.length > 8 ? ` … (+${names.length - 8})` : '');

export async function loadLazyStateDict(
  model: AnyModule,
  sd: LazyStateDict,
  opts: LoadStateDictOpts = {},
): Promise<void> {
  // Explicit sink > explicit root > the initTie() default (defaultRoot throws
  // its call-initTie-first message when no default exists either). GPU uploads
  // run inside error scopes: OOM/validation errors during upload never throw
  // in JS, so without them a failed load binds silently-zero weights. A custom
  // sink has no device to scope — it runs bare.
  if (opts.upload) return bindStateDict(model, sd, opts.upload, opts);
  const root = opts.root ?? defaultRoot();
  return inGpuErrorScopes(root.device, 'weight upload', () =>
    bindStateDict(model, sd, gpuUpload(root), opts),
  );
}

async function bindStateDict(
  model: AnyModule,
  sd: LazyStateDict,
  upload: UploadFn,
  opts: LoadStateDictOpts,
): Promise<void> {
  model.transformStateDict?.(sd, '');
  const visit = (parent: AnyModule, parentPrefix: string): void => {
    for (const [name, child] of parent.namedChildren()) {
      const prefix = parentPrefix ? `${parentPrefix}.${name}` : name;
      child.transformStateDict?.(sd, prefix, parent);
      visit(child, prefix);
    }
  };
  visit(model, '');

  const params = [...model.namedParameters()];
  const paramNames = new Set(params.map(([n]) => n));
  const missing = params.filter(([n]) => !sd.tensors.has(n)).map(([n]) => n);
  const unexpected = [...sd.tensors.keys()].filter((n) => !paramNames.has(n));
  if (missing.length || unexpected.length) {
    throw new Error(
      'loadStateDict: state dict does not match model.' +
        (missing.length ? ` missing: ${list(missing)}.` : '') +
        (unexpected.length ? ` unexpected: ${list(unexpected)}.` : ''),
    );
  }

  const total = sd.totalBytes();
  let done = 0;
  for (const [name, p] of params) {
    const t = sd.tensors.get(name)!;
    const numel = t.shape.reduce((a, b) => a * b, 1);
    const expected = numel;
    if (expected !== p.shape.elems) {
      throw new Error(
        `loadStateDict: '${name}' checkpoint shape [${t.shape}] (${numel} elems) != model ${JSON.stringify(p.shape.dims)} (${p.shape.elems} ${p.shape.dtype === 'quantW' ? 'words' : 'elems'})`,
      );
    }
    if (p instanceof CpuParameter) {
      // CPU-resident, no GPU upload. BF16 keeps its raw bits (half the RAM);
      // any other checkpoint dtype converts to plain f32.
      p.bindData(t.dtype === 'BF16' ? await t.u16() : await t.f32());
    } else {
      const data = await materialize(name, t, p.shape.dtype);
      p.bind(upload(p.preprocess ? p.preprocess(data) : data, p.shape));
    }
    done += t.byteLength;
    opts.onProgress?.(name, done, total);
  }
  for (const [, b] of model.namedBuffers()) {
    // A Buffer's data is computed CPU-side and always f32 (rope tables,
    // position constants); half() only retyped the slot, so the narrowing
    // happens here — every sink then receives data matching the shape.
    const data = b.shape.dtype === 'f16' ? f32ArrayToF16Bits(b.data).data : b.data;
    b.bind(upload(data, b.shape));
  }
}
