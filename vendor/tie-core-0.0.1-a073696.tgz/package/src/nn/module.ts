/** Eager nn layer: PyTorch-flavored modules whose forward() composes eager ops.
 *  A Parameter is a named slot filled from the checkpoint by loadStateDict(); a
 *  Buffer is a model-computed constant (e.g. rope tables). Module returns a Proxy
 *  from its constructor so assigning a Parameter/Buffer/Module field auto-registers
 *  it (mirrors nn.Module.__setattr__). Distinct from the trace-time src/nn/. */

import type { TgpuRoot } from 'typegpu';
import type { Executor, Readback } from '../graph/evalCore.ts';
import { maybeDefaultRoot, supportsF16 } from '../gpu/context.ts';
import { toArray } from '../gpu/eval.ts';
import { materialized, type EagerDtype, type ValueMeta, type Value } from '../graph/value.ts';
import {
  fromSafetensors,
  memoryStateDict,
  type LazyStateDict,
  type MemoryStateDict,
} from '../weights/safetensors.ts';
import { loadLazyStateDict, type LoadStateDictOpts } from './loadStateDict.ts';

/** A declared slot for a learned weight — torch.nn.Parameter's role here.
 *
 *  Not a Value because at model-construction time (`new Linear(4, 4)`) the
 *  weight DATA doesn't exist yet: only its expected shape is known, and the
 *  numbers arrive later when loadStateDict() matches this slot to a checkpoint
 *  entry by its dotted path (e.g. 'proj.weight'). A Value is immutable
 *  data-or-computation; a Parameter is the named, fillable placeholder that
 *  eventually HOLDS one (`.value` after loading — that's what forward()
 *  reads, and it throws if the model wasn't loaded first). */
export class Parameter {
  qualifiedName = '';
  private _value: Value | undefined;
  private _shape: ValueMeta;
  constructor(
    shape: ValueMeta,
    /** Optional CPU-side transform applied to the raw checkpoint data before
     *  upload (e.g. Conv2d's tap-major weight repack). Same element count in
     *  and out; runs once per load. */
    readonly preprocess?: (
      data: Float32Array | Uint32Array | Uint16Array,
    ) => Float32Array | Uint32Array | Uint16Array,
    /** True when this value's storage dtype is fixed by the kernels that read
     *  it, not by the model's float precision — attention `sinks` (declared
     *  f32 in every kernel variant) and Conv2d/ConvTranspose2d weights
     *  (declared f16 in every kernel variant, packed into a u32 view).
     *  model.half()/float() leave it alone in both directions. */
    readonly pinned = false,
  ) {
    this._shape = shape;
  }
  /** What this slot expects: element count, dtype, logical dims. Mutable only
   *  through retype() (Module.half/float), and only before loading. */
  get shape(): ValueMeta {
    return this._shape;
  }
  get loaded(): boolean {
    return this._value !== undefined;
  }
  get value(): Value {
    if (!this._value) throw new Error(`Parameter ${this.qualifiedName || '(unnamed)'} not loaded`);
    return this._value;
  }
  /** @internal Module.half()/float(): swap the storage dtype, keeping elems
   *  and dims. The loader then materializes the checkpoint into it. */
  retype(dtype: EagerDtype): void {
    this._shape = { ...this._shape, dtype };
  }
  /** @internal bound by loadStateDict. */
  bind(v: Value): void {
    this._value = v;
  }
}

/** A Parameter whose data stays in CPU memory — never uploaded to the GPU.
 *  For weights where forward() only ever reads a few rows, so GPU residency
 *  would waste memory (nn.Embedding's cpu table). Storage follows the
 *  checkpoint: a BF16 tensor keeps its raw bits (Uint16Array, half the RAM),
 *  anything else loads as plain f32. loadStateDict binds the data directly. */
export class CpuParameter extends Parameter {
  private _data: Float32Array | Uint16Array | undefined;
  override get value(): Value {
    throw new Error(
      `Parameter ${this.qualifiedName || '(unnamed)'} is CPU-resident — read .data, it has no GPU Value`,
    );
  }
  get data(): Float32Array | Uint16Array {
    if (!this._data) throw new Error(`Parameter ${this.qualifiedName || '(unnamed)'} not loaded`);
    return this._data;
  }
  /** @internal bound by loadStateDict. */
  bindData(data: Float32Array | Uint16Array): void {
    this._data = data;
  }
}

/** A model-computed constant (e.g. rope cos/sin); never read from the checkpoint. */
export class Buffer {
  qualifiedName = '';
  private _value: Value | undefined;
  private _shape: ValueMeta;
  constructor(
    readonly data: Float32Array,
    shape: ValueMeta,
  ) {
    this._shape = shape;
  }
  get shape(): ValueMeta {
    return this._shape;
  }
  get loaded(): boolean {
    return this._value !== undefined;
  }
  get value(): Value {
    if (!this._value) throw new Error(`Buffer ${this.qualifiedName || '(unnamed)'} not uploaded`);
    return this._value;
  }
  /** @internal Module.half()/float(). The CPU-side `data` stays f32; the
   *  upload converts it to match the dtype. */
  retype(dtype: EagerDtype): void {
    this._shape = { ...this._shape, dtype };
  }
  /** @internal uploaded by loadStateDict. */
  bind(v: Value): void {
    this._value = v;
  }
}

/** Swap every float parameter/buffer of `model` from `from` to `to`. A
 *  module-level function rather than a private method because Module returns
 *  a Proxy from its constructor — private members are unreachable through it.
 *  Only `from` is touched, so quantW weights are left alone — they are not
 *  float tensors and have nothing to halve. Parameters marked `pinned` (a
 *  kernel-fixed dtype like Conv2d's f16 weights) are skipped in both
 *  directions, regardless of their current dtype. */
function retypeFloats(model: AnyModule, from: EagerDtype, to: EagerDtype): void {
  const slots = [...model.namedParameters(), ...model.namedBuffers()] as const;
  for (const [name, slot] of slots) {
    // A CpuParameter's data never reaches the GPU, but its dtype still names
    // the width its layer UPLOADS at (Embedding's cpu table gathers rows into
    // a [T, dim] tensor), so it follows the model like everything else.
    if (slot instanceof Parameter && slot.pinned) continue;
    if (slot instanceof CpuParameter) {
      if (slot.shape.dtype === from) slot.retype(to);
      continue;
    }
    if (slot.loaded) {
      throw new Error(
        `half()/float(): '${name}' is already loaded — retype the model before loadStateDict`,
      );
    }
    if (slot.shape.dtype === from) slot.retype(to);
  }
}

const REGISTRY = Symbol('eagerModuleRegistry');

interface Registry {
  params: Map<string, Parameter>;
  buffers: Map<string, Buffer>;
  modules: Map<string, AnyModule>;
}

/** A Module of any forward signature, for code that stores or walks modules
 *  without running them (the registry, the state-dict loaders). Every Module
 *  subclass is assignable to it; calling `.forward` on it is a compile error
 *  (`never[]` args), so running a module requires its concrete type. */
export type AnyModule = Module<never[], unknown>;

export abstract class Module<In extends unknown[] = [Value], Out = Value> {
  /** @internal symbol-keyed so the Proxy trap skips it. */
  readonly [REGISTRY]: Registry = { params: new Map(), buffers: new Map(), modules: new Map() };

  constructor() {
    // Register on both `[[Set]]` (runtime assignment) and `[[Define]]` (class
    // field initializers under useDefineForClassFields, which ES2022 enables).
    // `_`-prefixed / symbol keys are skipped (internal fields, the registry).
    // Note the filter admits numeric-string keys — subclasses like ModuleList
    // rely on this to register children under their index as the name.
    const record = (target: AnyModule, key: string | symbol, value: unknown): void => {
      if (typeof key !== 'string' || key.startsWith('_')) return;
      const reg = target[REGISTRY];
      if (value instanceof Parameter) reg.params.set(key, value);
      else if (value instanceof Buffer) reg.buffers.set(key, value);
      else if (value instanceof Module) reg.modules.set(key, value);
    };
    return new Proxy(this, {
      set(target, key, value, receiver) {
        record(target, key, value);
        return Reflect.set(target, key, value, receiver);
      },
      defineProperty(target, key, descriptor) {
        if ('value' in descriptor) record(target, key, descriptor.value);
        return Reflect.defineProperty(target, key, descriptor);
      },
    });
  }

  /** The module's computation. Each subclass declares what goes in and out
   *  via `In`/`Out` (defaults: one Value in, one Value out) and implements
   *  forward to match. Pure containers skip it and inherit this throwing
   *  stub — same contract as torch's base forward. */
  forward(..._args: In): Out {
    throw new Error(`${this.constructor.name}: forward() not implemented`);
  }

  /** torch's Module.half(): store every float parameter and buffer as f16.
   *  Storage only — activations follow from the weights, and kernels that
   *  reduce keep f32 accumulators internally.
   *
   *  Call it BEFORE loadStateDict: a Parameter's dtype is what the loader
   *  materializes the checkpoint into, so retyping is a metadata change and
   *  the f16 conversion happens once, on the way in. After loading there is a
   *  GPU buffer whose dtype is baked into every pipeline that read it, so
   *  half() throws instead of silently doing nothing.
   *
   *  Quantized (quantW) weights are left alone — they are not float tensors,
   *  same as torch skipping integer buffers. CPU-resident parameters are
   *  skipped too: their storage follows the checkpoint and never reaches a
   *  shader.
   *
   *  quantW weights are a HARD incompatibility with half(), not just a
   *  skipped tensor: the quant matmul kernels require f32 activations and
   *  f32 scales (one pipeline, no f16 variant), so flipping the rest of the
   *  model to f16 would break the very next quantized matmul. half() throws
   *  up front instead of letting that fail later with a confusing error
   *  inside matmul. */
  half(root?: TgpuRoot): this {
    // The shader-f16 check needs a device; graph-only contexts (node tests
    // building models with mock buffers) have none, and nothing there ever
    // compiles a shader — so check when a root is at hand (given, or the
    // initTie default) and otherwise let the first real dispatch fail.
    const checkRoot = root ?? maybeDefaultRoot();
    if (checkRoot && !supportsF16(checkRoot)) {
      throw new Error(
        "half(): this device has no shader-f16 — check supportsF16() first, and request it with tgpu.init({ device: { optionalFeatures: ['shader-f16'] } })",
      );
    }
    for (const [name, p] of this.namedParameters()) {
      if (p.shape.dtype === 'quantW') {
        throw new Error(
          `half(): '${name}' is a quantized (quantW) weight — quantized models don't support f16 activations, leave this model at f32`,
        );
      }
    }
    retypeFloats(this, 'f32', 'f16');
    return this;
  }

  /** The inverse of half(). Needs no device feature — f32 always works. */
  float(): this {
    retypeFloats(this, 'f16', 'f32');
    return this;
  }

  /** Depth-first dotted walk; assigns each Parameter.qualifiedName as a side effect. */
  *namedParameters(prefix = ''): Generator<readonly [string, Parameter]> {
    const reg = this[REGISTRY];
    for (const [name, p] of reg.params) {
      p.qualifiedName = prefix ? `${prefix}.${name}` : name;
      yield [p.qualifiedName, p] as const;
    }
    for (const [name, m] of reg.modules) {
      yield* m.namedParameters(prefix ? `${prefix}.${name}` : name);
    }
  }

  *namedBuffers(prefix = ''): Generator<readonly [string, Buffer]> {
    const reg = this[REGISTRY];
    for (const [name, b] of reg.buffers) {
      b.qualifiedName = prefix ? `${prefix}.${name}` : name;
      yield [b.qualifiedName, b] as const;
    }
    for (const [name, m] of reg.modules) {
      yield* m.namedBuffers(prefix ? `${prefix}.${name}` : name);
    }
  }

  /** Depth-first dotted walk over submodules (the module itself excluded). */
  *namedModules(prefix = ''): Generator<readonly [string, AnyModule]> {
    for (const [name, m] of this[REGISTRY].modules) {
      const path = prefix ? `${prefix}.${name}` : name;
      yield [path, m] as const;
      yield* m.namedModules(path);
    }
  }

  /** This module's direct submodules, in registration (declaration) order. */
  *namedChildren(): Generator<readonly [string, AnyModule]> {
    yield* this[REGISTRY].modules;
  }

  /** Optional hook: adjust the lazy state dict for this subtree before binding
   *  (fold BN, permute layouts, split fused tensors). Runs root-first, then
   *  depth-first per submodule with its dotted prefix; `parent` is the owning
   *  module (undefined at the root) so a layer can inspect its siblings —
   *  BatchNorm2d uses it to find the conv it folds into. Must be synchronous —
   *  produce lazy derivedTensor entries, never fetch here. */
  transformStateDict?(sd: LazyStateDict, prefix: string, parent?: AnyModule): void;

  /** PyTorch-style entry point: bind every Parameter from a (lazy) state dict,
   *  streaming one tensor at a time. Also accepts a safetensors URL (MLX-style
   *  convenience) or a plain name→array record for RAM-resident weights —
   *  torch's load_state_dict(dict) shape. Record entries that need 2D/packed
   *  shapes use the { data, shape } form (shape in the CHECKPOINT layout, e.g.
   *  torch [out, in] for Linear weights — transform hooks run on this path
   *  exactly like on file loads). */
  async loadStateDict(
    sd: LazyStateDict | string | MemoryStateDict,
    opts: LoadStateDictOpts = {},
  ): Promise<void> {
    const dict =
      typeof sd === 'string'
        ? await fromSafetensors(sd)
        : sd.tensors instanceof Map
          ? (sd as LazyStateDict)
          : memoryStateDict(sd as MemoryStateDict);
    await loadLazyStateDict(this, dict, opts);
  }
}

/** An ordered list of submodules registered under their index as the name, so
 *  the dotted walk yields `block.3.attn.qkv.weight` — matching PyTorch's
 *  nn.ModuleList and the checkpoint key layout. Registration rides the same
 *  Proxy traps as plain fields (numeric-string keys pass the `_` filter). */
export class ModuleList<M extends AnyModule> extends Module {
  constructor(readonly items: readonly M[]) {
    super();
    items.forEach((m, i) => {
      (this as Record<string, unknown>)[String(i)] = m;
    });
  }
  /** Chains items like torch's nn.Sequential. Only call this when every item
   *  is Value→Value — `M` admits any module, so the compiler can't check it
   *  here (hence the cast). */
  override forward(x: Value): Value {
    let y = x;
    for (const m of this.items) y = (m as Module).forward(y);
    return y;
  }
}

/** Run a plain x→y model: forward() builds a lazy Value, then eval+readback.
 *  Runs on the initTie() executor unless one is passed explicitly. */
export async function run(
  model: Module<[Value], Value>,
  x: Value,
  ex?: Executor & Readback,
): Promise<Float32Array> {
  return toArray(model.forward(x), ex);
}

export { materialized };
