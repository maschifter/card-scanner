import { describe, expect, it } from 'vitest';
import { materialized } from '../src/graph/value.ts';
import { mul } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

describe('eager mul', () => {
  it('mul() builds a pending Value linked to both inputs', () => {
    const a = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'a' }));
    const b = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'b' }));
    const c = mul(a, b);
    expect(c.state).toBe('pending');
    expect(c.pending!.op).toBe('mul');
    expect(c.pending!.inputs).toEqual([a, b]);
    expect(c.shape).toEqual({ elems: 8, dtype: 'f16' });
  });

  it('mul() throws on shape mismatch', () => {
    const a = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'a' }));
    const b = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ kind: 'b' }));
    expect(() => mul(a, b)).toThrow(/mul.*8.*4/);
  });
});
