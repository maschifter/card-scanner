import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { cat, slice, transpose } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number, id: string) => materialized(matrix(r, c), fakeGpuBuffer({ id }));

describe('transpose', () => {
  it('[M,N] -> [N,M] pending value', () => {
    const y = transpose(mat(2, 5, 'x'));
    expect(y.state).toBe('pending');
    expect(y.pending!.op).toBe('transpose');
    expect(y.shape).toEqual({ elems: 10, dtype: 'f32', dims: [5, 2] });
    expect(y.pending!.attrs).toBeUndefined();
  });
  it('rejects non-2D input', () => {
    const v = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'v' }));
    expect(() => transpose(v)).toThrow(/transpose/);
  });
});

describe('sliceCols', () => {
  it('[M,N] -> [M,end-start) with attrs recorded', () => {
    const y = slice(mat(3, 8, 'x'), 1, 2, 6);
    expect(y.shape).toEqual({ elems: 12, dtype: 'f32', dims: [3, 4] });
    expect(y.pending!.attrs).toEqual([2, 6]);
  });
  it('rejects bad ranges', () => {
    const x = mat(3, 8, 'x');
    expect(() => slice(x, 1, -1, 4)).toThrow(/slice/);
    expect(() => slice(x, 1, 4, 4)).toThrow(/slice/);
    expect(() => slice(x, 1, 0, 9)).toThrow(/slice/);
    expect(() => slice(x, 1, 1.5, 4)).toThrow(/slice/);
  });
});

describe('concatCols', () => {
  it('[M,A] ++ [M,B] -> [M,A+B]', () => {
    const y = cat([mat(3, 4, 'a'), mat(3, 2, 'b')], 1);
    expect(y.shape).toEqual({ elems: 18, dtype: 'f32', dims: [3, 6] });
    expect(y.pending!.op).toBe('concatCols');
    expect(y.pending!.attrs).toBeUndefined();
  });
  it('rejects row mismatch', () => {
    expect(() => cat([mat(3, 4, 'a'), mat(2, 4, 'b')], 1)).toThrow(/cat/);
  });
});
