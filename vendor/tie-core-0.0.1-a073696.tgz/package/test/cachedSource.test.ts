import { afterEach, describe, expect, it, vi } from 'vitest';
import { bufferSource, cachedRangeSource, fromSafetensors } from '../src/index.ts';
import type { WeightCache } from '../src/index.ts';
import { encodeSafetensors, f32Data } from './safetensorsHelpers.ts';

function memoryCache(): WeightCache & { store: Map<string, ArrayBuffer>; computes: number } {
  const self = {
    store: new Map<string, ArrayBuffer>(),
    computes: 0,
    async get(key: string): Promise<ArrayBuffer | undefined> {
      return self.store.get(key);
    },
    async getOrCompute(key: string, compute: () => Promise<ArrayBufferView>): Promise<ArrayBuffer> {
      const hit = self.store.get(key);
      if (hit) return hit;
      self.computes += 1;
      const view = await compute();
      const buf = (view.buffer as ArrayBuffer).slice(
        view.byteOffset,
        view.byteOffset + view.byteLength,
      );
      self.store.set(key, buf);
      return buf;
    },
    async clear(): Promise<void> {
      self.store.clear();
    },
  };
  return self;
}

describe('cachedRangeSource', () => {
  const bytes = new Uint8Array([10, 11, 12, 13, 14, 15]);

  it('serves from cache on the second read of the same range', async () => {
    const cache = memoryCache();
    const src = cachedRangeSource(bufferSource(bytes), cache, 'pf-f16.safetensors');
    expect([...(await src.read(2, 5))]).toEqual([12, 13, 14]);
    expect([...(await src.read(2, 5))]).toEqual([12, 13, 14]);
    expect(cache.computes).toBe(1);
    expect([...cache.store.keys()]).toEqual(['st/pf-f16.safetensors/2-5']);
  });

  it('different ranges and different fileIds get distinct keys', async () => {
    const cache = memoryCache();
    const a = cachedRangeSource(bufferSource(bytes), cache, 'a');
    const b = cachedRangeSource(bufferSource(bytes), cache, 'b');
    await a.read(0, 2);
    await a.read(2, 4);
    await b.read(0, 2);
    expect(cache.computes).toBe(3);
  });
});

describe('fromSafetensors with cache', () => {
  const file = encodeSafetensors({
    w: { dtype: 'F32', shape: [3], data: f32Data([1, 2, 3]) },
  });

  it('a warm load replays every read (header included) from the cache', async () => {
    const cache = memoryCache();
    const sd1 = await fromSafetensors(bufferSource(file), { cache, cacheId: 'w.safetensors' });
    expect([...(await sd1.tensors.get('w')!.f32())]).toEqual([1, 2, 3]);
    const cold = cache.computes;
    expect(cold).toBeGreaterThan(0);

    // Second load: a source that fails on read proves nothing reaches it.
    const dead = {
      read: (): Promise<Uint8Array> => Promise.reject(new Error('network gone')),
    };
    const sd2 = await fromSafetensors(dead, { cache, cacheId: 'w.safetensors' });
    expect([...(await sd2.tensors.get('w')!.f32())]).toEqual([1, 2, 3]);
    expect(cache.computes).toBe(cold);
  });

  it('requires an explicit cacheId for a RangeSource src', async () => {
    await expect(fromSafetensors(bufferSource(file), { cache: memoryCache() })).rejects.toThrow(
      /cacheId/,
    );
  });
});

describe('poisoned-cache recovery', () => {
  const file = encodeSafetensors({
    w: { dtype: 'F32', shape: [3], data: f32Data([1, 2, 3]) },
  });
  const html = new TextEncoder().encode('<!doctype html><html>fallback page</html>');

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  const fetchServing = (bytes: Uint8Array, contentType: string) =>
    vi.fn(async () => {
      const body = new ArrayBuffer(bytes.byteLength);
      new Uint8Array(body).set(bytes);
      return new Response(body, { status: 200, headers: { 'content-type': contentType } });
    });

  it('a cache holding an HTML fallback page is cleared and refetched once', async () => {
    // Simulate the dev-server 404 poisoning: an earlier load stored the SPA
    // page's bytes under the header-range keys.
    const cache = memoryCache();
    cache.store.set('st/model.safetensors/0-8', html.slice(0, 8).buffer as ArrayBuffer);
    const fetchFn = fetchServing(file, 'application/octet-stream');
    vi.stubGlobal('fetch', fetchFn);

    const sd = await fromSafetensors('http://weights.test/model.safetensors', { cache });
    expect([...sd.tensors.keys()]).toEqual(['w']);
    expect(fetchFn).toHaveBeenCalled();
    // The poison is gone and the good header now sits in the cache.
    const healed = new Uint8Array(cache.store.get('st/model.safetensors/0-8')!);
    expect([...healed]).toEqual([...file.slice(0, 8)]);
  });

  it('an HTML response is refused at the fetch layer, so it never enters the cache', async () => {
    const cache = memoryCache();
    vi.stubGlobal('fetch', fetchServing(html, 'text/html'));
    await expect(
      fromSafetensors('http://weights.test/model.safetensors', { cache }),
    ).rejects.toThrow(/HTML fallback/);
    expect(cache.store.size).toBe(0);
  });
});
