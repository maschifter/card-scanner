import { describe, expect, it } from 'vitest';
import { materialized, type Value } from '../src/graph/value.ts';
import { add } from '../src/graph/ops.ts';
import { evalValues, type Executor } from '../src/graph/evalCore.ts';
import { fakeGpuBuffer } from './helpers.ts';

function fakeExecutor(): Executor & { dispatched: string[]; submits: number } {
  const dispatched: string[] = [];
  let submits = 0;
  return {
    dispatched,
    get submits() {
      return submits;
    },
    acquireOutput: (shape) => fakeGpuBuffer({ kind: 'out', shape }),
    releaseOutput: () => {},
    dispatch: (node: Value) => {
      dispatched.push(`${node.pending!.op}:${node.shape.elems}`);
    },
    submit: () => {
      submits++;
    },
  };
}

describe('eval driver', () => {
  it('materializes a pending add with one dispatch and one submit', () => {
    const a = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'a' }));
    const b = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'b' }));
    const c = add(a, b);
    const ex = fakeExecutor();
    evalValues([c], ex);
    expect(ex.dispatched).toEqual(['add:8']);
    expect(ex.submits).toBe(1);
    expect(c.state).toBe('materialized');
  });

  it('dispatches dependencies before dependents, each once, in one submit', () => {
    const a = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ kind: 'a' }));
    const b = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ kind: 'b' }));
    const ab = add(a, b);
    const abab = add(ab, ab);
    const ex = fakeExecutor();
    evalValues([abab], ex);
    expect(ex.dispatched).toEqual(['add:4', 'add:4']);
    expect(ex.submits).toBe(1);
    expect(ab.state).toBe('released'); // dead intermediate — buffer recycled after its last consumer
    expect(abab.state).toBe('materialized');
  });

  it('is a no-op dispatch for an already-materialized value', () => {
    const a = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ kind: 'a' }));
    const ex = fakeExecutor();
    evalValues([a], ex);
    expect(ex.dispatched).toEqual([]);
    expect(ex.submits).toBe(1);
  });
});
