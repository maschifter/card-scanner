import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { conv1d } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));

describe('conv1d op', () => {
  it('derives T_out = floor((T_in − k)/s) + 1 and records [kernelSize, stride, padLeft, padRight, hasBias, act]', () => {
    // Moonshine stem stage 1 geometry: [48000,1] k=127 s=64 → [749, C_out].
    const y = conv1d(mat(48000, 1), mat(127, 288), { kernelSize: 127, stride: 64 });
    expect(y.pending!.op).toBe('conv1d');
    expect(y.shape.dims).toEqual([749, 288]);
    expect(y.pending!.attrs).toEqual([127, 64, 0, 0, 0, 0]);
  });

  it('padLeft enters T_out = floor((T_in + padLeft − k)/s) + 1 and the attrs', () => {
    // Moonshine v2 causal conv geometry: k=5 s=2 padLeft=4 keeps ceil(T/2).
    const y = conv1d(mat(600, 320), mat(5 * 320, 640), { kernelSize: 5, stride: 2, padLeft: 4 });
    expect(y.shape.dims).toEqual([300, 640]);
    expect(y.pending!.attrs).toEqual([5, 2, 4, 0, 0, 0]);
    const odd = conv1d(mat(149, 320), mat(5 * 320, 640), { kernelSize: 5, stride: 2, padLeft: 4 });
    expect(odd.shape.dims).toEqual([75, 640]);
  });

  it('padRight extends T_out the same way and lands in the attrs', () => {
    const y = conv1d(mat(100, 2), mat(5 * 2, 4), { kernelSize: 5, stride: 2, padRight: 3 });
    expect(y.shape.dims).toEqual([50, 4]); // floor((100+3−5)/2)+1
    expect(y.pending!.attrs).toEqual([5, 2, 0, 3, 0, 0]);
  });

  it('padding expands to symmetric padLeft = padRight (torch Conv1d(padding=p))', () => {
    // k=3 s=1 padding=1: length-preserving conv.
    const y = conv1d(mat(10, 4), mat(3 * 4, 4), { kernelSize: 3, stride: 1, padding: 1 });
    expect(y.shape.dims).toEqual([10, 4]);
    expect(y.pending!.attrs).toEqual([3, 1, 1, 1, 0, 0]);
  });

  it("padding 'valid' is no padding; 'same' preserves length with torch's split", () => {
    const valid = conv1d(mat(10, 4), mat(3 * 4, 4), { kernelSize: 3, stride: 1, padding: 'valid' });
    expect(valid.shape.dims).toEqual([8, 4]);
    expect(valid.pending!.attrs).toEqual([3, 1, 0, 0, 0, 0]);
    const odd = conv1d(mat(10, 4), mat(3 * 4, 4), { kernelSize: 3, stride: 1, padding: 'same' });
    expect(odd.shape.dims).toEqual([10, 4]);
    expect(odd.pending!.attrs).toEqual([3, 1, 1, 1, 0, 0]);
    // Even kernel: the extra zero goes right, torch's 'same' split.
    const even = conv1d(mat(10, 4), mat(4 * 4, 4), { kernelSize: 4, stride: 1, padding: 'same' });
    expect(even.shape.dims).toEqual([10, 4]);
    expect(even.pending!.attrs).toEqual([4, 1, 1, 2, 0, 0]);
  });

  it("rejects padding 'same' with stride > 1 (torch behavior)", () => {
    expect(() =>
      conv1d(mat(10, 4), mat(3 * 4, 4), { kernelSize: 3, stride: 2, padding: 'same' }),
    ).toThrow(/'same' requires stride 1/);
  });

  it('rejects padding combined with padLeft or padRight', () => {
    for (const extra of [{ padLeft: 1 }, { padRight: 1 }]) {
      expect(() =>
        conv1d(mat(10, 4), mat(3 * 4, 4), { kernelSize: 3, stride: 1, padding: 1, ...extra }),
      ).toThrow(/excludes/);
      expect(() =>
        conv1d(mat(10, 4), mat(3 * 4, 4), {
          kernelSize: 3,
          stride: 1,
          padding: 'same',
          ...extra,
        }),
      ).toThrow(/excludes/);
    }
  });

  it('padLeft lets inputs shorter than the kernel produce output', () => {
    const y = conv1d(mat(3, 2), mat(5 * 2, 4), { kernelSize: 5, stride: 2, padLeft: 4 });
    expect(y.shape.dims).toEqual([2, 4]);
  });

  it('rejects padLeft, padRight, and padding outside [0, kernelSize)', () => {
    for (const bad of [-1, 5, 2.5]) {
      expect(() =>
        conv1d(mat(100, 2), mat(5 * 2, 4), { kernelSize: 5, stride: 2, padLeft: bad }),
      ).toThrow(/padLeft/);
      expect(() =>
        conv1d(mat(100, 2), mat(5 * 2, 4), { kernelSize: 5, stride: 2, padRight: bad }),
      ).toThrow(/padRight/);
      expect(() =>
        conv1d(mat(100, 2), mat(5 * 2, 4), { kernelSize: 5, stride: 2, padding: bad }),
      ).toThrow(/padding/);
    }
  });

  it('chains the full Moonshine stem geometry (384× downsample)', () => {
    const c1 = conv1d(mat(48000, 1), mat(127, 288), { kernelSize: 127, stride: 64 });
    const c2 = conv1d(c1, mat(7 * 288, 576), { kernelSize: 7, stride: 3 });
    const c3 = conv1d(c2, mat(3 * 576, 288), { kernelSize: 3, stride: 2 });
    expect(c2.shape.dims).toEqual([248, 576]);
    expect(c3.shape.dims).toEqual([123, 288]);
  });

  it('rejects weight rows != kernel·C_in', () => {
    expect(() => conv1d(mat(100, 2), mat(7, 8), { kernelSize: 7, stride: 3 })).toThrow(/w rows/);
  });

  it('bias appends to inputs and sets hasBias; activation maps to the act attr', () => {
    const bias = materialized({ elems: 8, dtype: 'f32', dims: [8] }, fakeGpuBuffer({ id: 'bias' }));
    const y = conv1d(mat(100, 2), mat(5 * 2, 8), {
      kernelSize: 5,
      stride: 2,
      bias,
      activation: 'gelu',
    });
    expect(y.pending!.inputs.length).toBe(3);
    expect(y.pending!.attrs).toEqual([5, 2, 0, 0, 1, 2]);
    const t = conv1d(mat(100, 2), mat(5 * 2, 8), { kernelSize: 5, stride: 2, activation: 'tanh' });
    expect(t.pending!.inputs.length).toBe(2);
    expect(t.pending!.attrs).toEqual([5, 2, 0, 0, 0, 1]);
  });

  it('rejects a bias whose length is not C_out', () => {
    const bias = materialized({ elems: 7, dtype: 'f32', dims: [7] }, fakeGpuBuffer({ id: 'bias' }));
    expect(() => conv1d(mat(100, 2), mat(5 * 2, 8), { kernelSize: 5, stride: 2, bias })).toThrow(
      /bias/,
    );
  });

  it('rejects input shorter than the kernel', () => {
    expect(() => conv1d(mat(5, 1), mat(7, 8), { kernelSize: 7, stride: 3 })).toThrow(/< kernel/);
  });

  it('rejects non-positive or fractional kernel/stride', () => {
    expect(() => conv1d(mat(100, 1), mat(7, 8), { kernelSize: 7, stride: 0 })).toThrow(/positive/);
    expect(() => conv1d(mat(100, 1), mat(7, 8), { kernelSize: 7.5, stride: 3 })).toThrow(
      /positive/,
    );
  });
});
