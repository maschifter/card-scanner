/** Loading a checkpoint into an f16 model: what materialize() produces for
 *  each source dtype, and that Buffers follow the model's dtype too. */
import { describe, expect, it, vi } from 'vitest';
import { nn } from '../src/index.ts';
import type { ValueMeta } from '../src/index.ts';
import { materialized } from '../src/nn/module.ts';
import { gpuUpload, loadLazyStateDict } from '../src/nn/loadStateDict.ts';
import { bufferSource, fromSafetensors } from '../src/weights/safetensors.ts';
import { f16BitsToF32 } from '../src/weights/convert.ts';
import { fakeGpuBuffer } from './helpers.ts';
import { bf16Data, encodeSafetensors, f16Data, f32Data } from './safetensorsHelpers.ts';

function collector() {
  const calls: Array<{ data: Float32Array | Uint32Array | Uint16Array; shape: ValueMeta }> = [];
  const upload = (data: Float32Array | Uint32Array | Uint16Array, shape: ValueMeta) => {
    calls.push({ data, shape });
    return materialized(shape, fakeGpuBuffer({}));
  };
  return { calls, upload };
}

/** Linear stores [in, out]; the loader transposes torch's [out, in]. */
class TinyLinear extends nn.Module {
  readonly proj = new nn.Linear(2, 2, { bias: false });
  forward(x: never) {
    return x;
  }
}

const halved = () => {
  const m = new TinyLinear();
  m.proj.weight.retype('f16');
  return m;
};

const asFloats = (bits: Uint16Array) => [...bits].map(f16BitsToF32);

describe('loading into f16 parameters', () => {
  it('converts an F32 checkpoint tensor to f16 halfwords', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'F32', shape: [2, 2], data: f32Data([1, 2, 3, 4]) },
        }),
      ),
    );
    const { calls, upload } = collector();
    await loadLazyStateDict(halved(), sd, { upload });
    expect(calls[0]!.data).toBeInstanceOf(Uint16Array);
    expect(calls[0]!.shape.dtype).toBe('f16');
    // transposed torch [out,in] -> [in,out]
    expect(asFloats(calls[0]!.data as Uint16Array)).toEqual([1, 3, 2, 4]);
  });

  it('passes an F16 checkpoint tensor through without converting', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'F16', shape: [2, 2], data: f16Data([1, 2, 3, 4]) },
        }),
      ),
    );
    const { calls, upload } = collector();
    await loadLazyStateDict(halved(), sd, { upload });
    expect(asFloats(calls[0]!.data as Uint16Array)).toEqual([1, 3, 2, 4]);
  });

  it('converts a BF16 checkpoint tensor to f16', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'BF16', shape: [2, 2], data: bf16Data([1, 2, 3, 4]) },
        }),
      ),
    );
    const { calls, upload } = collector();
    await loadLazyStateDict(halved(), sd, { upload });
    expect(asFloats(calls[0]!.data as Uint16Array)).toEqual([1, 3, 2, 4]);
  });

  it('warns and clamps values past the f16 range', async () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'F32', shape: [2, 2], data: f32Data([1e6, 2, 3, 4]) },
        }),
      ),
    );
    const { calls, upload } = collector();
    await loadLazyStateDict(halved(), sd, { upload });
    expect(asFloats(calls[0]!.data as Uint16Array)[0]).toBe(65504);
    expect(warn).toHaveBeenCalledWith(expect.stringMatching(/clamped 1 value/));
    warn.mockRestore();
  });

  it('uploads an f16 Buffer as halfwords', async () => {
    class WithBuffer extends nn.Module {
      readonly table = new nn.Buffer(new Float32Array([1, 2, 3, 4]), {
        elems: 4,
        dtype: 'f32',
      });
      forward(x: never) {
        return x;
      }
    }
    const m = new WithBuffer();
    m.table.retype('f16');
    const { calls, upload } = collector();
    await loadLazyStateDict(m, await fromSafetensors(bufferSource(encodeSafetensors({}))), {
      upload,
    });
    expect(calls[0]!.data).toBeInstanceOf(Uint16Array);
    expect(asFloats(calls[0]!.data as Uint16Array)).toEqual([1, 2, 3, 4]);
  });
});

/** gpuUpload routes on the SHAPE, not the array type. Feeding f32 data to a
 *  halved parameter used to build an f32 buffer wearing an f16 label — no
 *  error, and every kernel reading it got garbage. That is the exact path
 *  `model.half()` + `loadStateDict` takes with any loader that emits f32. */
describe('gpuUpload dtype routing', () => {
  const fakeRoot = () => {
    const created: { schema: unknown }[] = [];
    return {
      created,
      root: {
        createBuffer: (schema: unknown) => {
          created.push({ schema });
          return { $usage: () => ({}) };
        },
        unwrap: () => ({}),
        device: { queue: { writeBuffer: () => {} } },
      } as never,
    };
  };

  it('narrows f32 data into an f16 parameter', () => {
    const { root } = fakeRoot();
    const v = gpuUpload(root)(new Float32Array([1, 2, 3, 4]), {
      elems: 4,
      dtype: 'f16',
      dims: [2, 2],
    });
    expect(v.shape.dtype).toBe('f16');
  });

  it('rejects word data aimed at an f32 parameter', () => {
    const { root } = fakeRoot();
    expect(() =>
      gpuUpload(root)(new Uint32Array([1, 2]), { elems: 2, dtype: 'f32', dims: [1, 2] }),
    ).toThrow(/quantW/);
  });
});
