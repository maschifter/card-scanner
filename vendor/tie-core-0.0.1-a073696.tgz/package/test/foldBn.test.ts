import { describe, expect, it } from 'vitest';
import { foldBnIntoConv } from '../src/weights/foldBn.ts';
import { bufferSource, eagerTensor, fromSafetensors } from '../src/weights/safetensors.ts';
import { encodeSafetensors, f32Data } from './safetensorsHelpers.ts';

/** conv [2,1,1,1] w=[2,10]; bn gamma=[1,2] beta=[0.5,-1] mean=[1,3] var=[3,0.25] eps=1
 *  scale = gamma/sqrt(var+eps) = [1/2, 2/sqrt(1.25)]
 *  w' = [2*0.5, 10*2/sqrt(1.25)]; b' = beta - mean*scale = [0.5-0.5, -1-6/sqrt(1.25)] */
const EPS = 1.0;
const SCALE1 = 2 / Math.sqrt(1.25);

function makeDict() {
  return fromSafetensors(
    bufferSource(
      encodeSafetensors({
        'c.conv.weight': { dtype: 'F32', shape: [2, 1, 1, 1], data: f32Data([2, 10]) },
        'c.bn.weight': { dtype: 'F32', shape: [2], data: f32Data([1, 2]) },
        'c.bn.bias': { dtype: 'F32', shape: [2], data: f32Data([0.5, -1]) },
        'c.bn.running_mean': { dtype: 'F32', shape: [2], data: f32Data([1, 3]) },
        'c.bn.running_var': { dtype: 'F32', shape: [2], data: f32Data([3, 0.25]) },
        'c.bn.num_batches_tracked': { dtype: 'I64', shape: [], data: new Uint8Array(8) },
      }),
    ),
  );
}

describe('foldBnIntoConv', () => {
  it('replaces conv.weight/bias with folded values and deletes bn keys', async () => {
    const sd = await makeDict();
    foldBnIntoConv(sd, 'c.conv', 'c.bn', EPS);
    expect([...sd.tensors.keys()].sort()).toEqual(['c.conv.bias', 'c.conv.weight']);
    const w = await sd.tensors.get('c.conv.weight')!.f32();
    expect(w[0]).toBeCloseTo(1.0, 6);
    expect(w[1]).toBeCloseTo(10 * SCALE1, 5);
    const b = await sd.tensors.get('c.conv.bias')!.f32();
    expect(b[0]).toBeCloseTo(0.0, 6);
    expect(b[1]).toBeCloseTo(-1 - 3 * SCALE1, 5);
  });

  it('accounts for an existing conv bias', async () => {
    const sd = await makeDict();
    sd.tensors.set('c.conv.bias', eagerTensor(new Float32Array([10, 20]), [2]));
    foldBnIntoConv(sd, 'c.conv', 'c.bn', EPS);
    const b = await sd.tensors.get('c.conv.bias')!.f32();
    // b' = beta + (prior - mean) * scale
    expect(b[0]).toBeCloseTo(0.5 + (10 - 1) * 0.5, 6);
    expect(b[1]).toBeCloseTo(-1 + (20 - 3) * SCALE1, 5);
  });

  it('attributes downloaded bytes to the folded weight so progress totals stay real', async () => {
    const sd = await makeDict();
    foldBnIntoConv(sd, 'c.conv', 'c.bn', EPS);
    // weight carries every file byte the fold fetches: conv.weight (8) +
    // gamma/beta/mean/var (4×8); num_batches_tracked is deleted unfetched.
    expect(sd.tensors.get('c.conv.weight')!.byteLength).toBe(40);
    expect(sd.tensors.get('c.conv.bias')!.byteLength).toBe(0); // shares the weight's fetch
    expect(sd.totalBytes()).toBe(40);
  });

  it('is a no-op when bn keys are absent (already-fused checkpoint)', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'c.conv.weight': { dtype: 'F32', shape: [1, 1, 1, 1], data: f32Data([5]) },
        }),
      ),
    );
    foldBnIntoConv(sd, 'c.conv', 'c.bn', EPS);
    expect(Array.from(await sd.tensors.get('c.conv.weight')!.f32())).toEqual([5]);
  });

  it('throws if conv.weight is missing while bn is present', async () => {
    const sd = await makeDict();
    sd.tensors.delete('c.conv.weight');
    expect(() => foldBnIntoConv(sd, 'c.conv', 'c.bn', EPS)).toThrow(/c\.conv\.weight/);
  });
});
