import { describe, expect, it } from 'vitest';
import { materialized, matrix } from '../src/graph/value.ts';
import { gatherRowsFrom } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));

describe('gatherRowsFrom op', () => {
  it('derives [idx elems, cols] from a device-resident index', () => {
    const idx = materialized({ elems: 1, dtype: 'f32', dims: [1, 1] }, fakeGpuBuffer({ id: 'i' }));
    const y = gatherRowsFrom(mat(100, 8), idx);
    expect(y.shape.dims).toEqual([1, 8]);
    expect(y.pending!.op).toBe('gatherRowsFrom');
    expect(y.pending!.inputs).toHaveLength(2);
  });

  it('rejects a non-f32 index', () => {
    const idx = materialized({ elems: 1, dtype: 'f16', dims: [1, 1] }, fakeGpuBuffer({ id: 'i' }));
    expect(() => gatherRowsFrom(mat(100, 8), idx)).toThrow(/f32/);
  });

  it('gathers f16 rows from an f16 table, with an f32 index', () => {
    const idx = materialized({ elems: 1, dtype: 'f32', dims: [1, 1] }, fakeGpuBuffer({ id: 'i' }));
    const table = materialized(
      { elems: 800, dtype: 'f16', dims: [100, 8] },
      fakeGpuBuffer({ id: 'w' }),
    );
    const y = gatherRowsFrom(table, idx);
    expect(y.shape).toEqual({ elems: 8, dtype: 'f16', dims: [1, 8] });
  });
});
