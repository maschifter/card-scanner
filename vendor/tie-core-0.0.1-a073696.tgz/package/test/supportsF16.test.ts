import { describe, expect, it } from 'vitest';
import type { TgpuRoot } from 'typegpu';
import { supportsF16 } from '../src/gpu/context.ts';

const rootWith = (...features: string[]) =>
  ({ enabledFeatures: new Set(features) }) as unknown as TgpuRoot;

describe('supportsF16', () => {
  it('is true when the root enabled shader-f16', () => {
    expect(supportsF16(rootWith('shader-f16', 'subgroups'))).toBe(true);
  });

  it('is false when the root has other features but not shader-f16', () => {
    expect(supportsF16(rootWith('subgroups', 'timestamp-query'))).toBe(false);
  });
});
