import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { softmax } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

describe('softmax op', () => {
  it('preserves shape of a 2D f32 matrix', () => {
    const x = materialized(matrix(2, 5), fakeGpuBuffer({ id: 'x' }));
    const y = softmax(x);
    expect(y.state).toBe('pending');
    expect(y.pending!.op).toBe('softmax');
    expect(y.shape).toEqual({ elems: 10, dtype: 'f32', dims: [2, 5] });
  });

  it('throws on a non-2D-f32 input', () => {
    const v = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'v' }));
    expect(() => softmax(v)).toThrow(/softmax/);
  });
});
