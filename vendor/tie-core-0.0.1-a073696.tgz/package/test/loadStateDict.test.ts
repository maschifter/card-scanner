import { describe, expect, it } from 'vitest';
import { nn, resetTie } from '../src/index.ts';
import type { ValueMeta } from '../src/index.ts';
import { materialized } from '../src/nn/module.ts';
import { loadLazyStateDict } from '../src/nn/loadStateDict.ts';
import { foldBnIntoConv } from '../src/weights/foldBn.ts';
import {
  bufferSource,
  derivedTensor,
  fromSafetensors,
  type LazyStateDict,
} from '../src/weights/safetensors.ts';
import { f32ArrayToF16Bits } from '../src/weights/convert.ts';
import { fakeGpuBuffer } from './helpers.ts';
import { bf16Data, encodeSafetensors, f16Data, f32Data } from './safetensorsHelpers.ts';

/** Collect uploads in call order; return fake Values so bind() succeeds. */
function collector() {
  const calls: Array<{ data: Float32Array | Uint16Array | Uint32Array; shape: ValueMeta }> = [];
  const upload = (data: Float32Array | Uint16Array | Uint32Array, shape: ValueMeta) => {
    calls.push({ data, shape });
    return materialized(shape, fakeGpuBuffer({}));
  };
  return { calls, uploads: calls, upload };
}

class TinyLinear extends nn.Module {
  readonly proj = new nn.Linear(2, 3);
  forward(x: never) {
    return x;
  }
}

describe('loadLazyStateDict', () => {
  it('binds f32 params from an F32 checkpoint, transposing Linear weights from torch layout', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          // torch layout [out=3, in=2]: rows [1,2] [3,4] [5,6]
          'proj.weight': { dtype: 'F32', shape: [3, 2], data: f32Data([1, 2, 3, 4, 5, 6]) },
          'proj.bias': { dtype: 'F32', shape: [3], data: f32Data([7, 8, 9]) },
        }),
      ),
    );
    const model = new TinyLinear();
    const { calls, upload } = collector();
    await loadLazyStateDict(model, sd, { upload });
    expect(calls.length).toBe(2);
    // bound as [in=2, out=3] — the transpose of the checkpoint rows
    expect(calls[0]!.shape.dims).toEqual([2, 3]);
    expect(Array.from(calls[0]!.data as Float32Array)).toEqual([1, 3, 5, 2, 4, 6]);
    expect(Array.from(calls[1]!.data as Float32Array)).toEqual([7, 8, 9]);
    expect(model.proj.weight.value).toBeDefined();
  });

  it('Linear transposes an unprefixed weight when loaded as the root module', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          weight: { dtype: 'F32', shape: [3, 2], data: f32Data([1, 2, 3, 4, 5, 6]) },
          bias: { dtype: 'F32', shape: [3], data: f32Data([7, 8, 9]) },
        }),
      ),
    );
    const { calls, upload } = collector();
    await loadLazyStateDict(new nn.Linear(2, 3), sd, { upload });
    expect(calls[0]!.shape.dims).toEqual([2, 3]);
    expect(Array.from(calls[0]!.data as Float32Array)).toEqual([1, 3, 5, 2, 4, 6]);
  });

  it('binds a Conv1d weight tap-major from a torch (C_out, C_in, k) checkpoint', async () => {
    class TinyConv extends nn.Module {
      readonly conv = new nn.Conv1d(2, 3, 2);
      forward(x: never) {
        return x;
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          // torch layout (C_out=3, C_in=2, k=2), values 1..12 in torch order
          'conv.weight': {
            dtype: 'F32',
            shape: [3, 2, 2],
            data: f32Data([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]),
          },
          'conv.bias': { dtype: 'F32', shape: [3], data: f32Data([13, 14, 15]) },
        }),
      ),
    );
    const { calls, upload } = collector();
    await loadLazyStateDict(new TinyConv(), sd, { upload });
    // bound tap-major [k·C_in=4, C_out=3]: row (tap, cin), col cout
    expect(calls[0]!.shape.dims).toEqual([4, 3]);
    expect(Array.from(calls[0]!.data as Float32Array)).toEqual([
      1, 5, 9, 3, 7, 11, 2, 6, 10, 4, 8, 12,
    ]);
    expect(Array.from(calls[1]!.data as Float32Array)).toEqual([13, 14, 15]);
  });

  it('Conv1d rejects a weight that is not torch layout (C_out, C_in, k)', async () => {
    class TinyConv extends nn.Module {
      readonly conv = new nn.Conv1d(2, 3, 2);
      forward(x: never) {
        return x;
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          // (C_in, C_out, k) instead of (C_out, C_in, k)
          'conv.weight': {
            dtype: 'F32',
            shape: [2, 3, 2],
            data: f32Data([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]),
          },
          'conv.bias': { dtype: 'F32', shape: [3], data: f32Data([13, 14, 15]) },
        }),
      ),
    );
    const { upload } = collector();
    await expect(loadLazyStateDict(new TinyConv(), sd, { upload })).rejects.toThrow(
      /conv\.weight.*\[2,3,2\].*torch layout \[3, 2, 2\]/,
    );
  });

  it('Linear rejects a weight that is not torch layout [out, in]', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          // [in, out] instead of [out, in]
          'proj.weight': { dtype: 'F32', shape: [2, 3], data: f32Data([1, 2, 3, 4, 5, 6]) },
          'proj.bias': { dtype: 'F32', shape: [3], data: f32Data([7, 8, 9]) },
        }),
      ),
    );
    const { upload } = collector();
    await expect(loadLazyStateDict(new TinyLinear(), sd, { upload })).rejects.toThrow(
      /proj\.weight.*\[2,3\].*torch layout \[3, 2\]/,
    );
  });

  it('materializes f16 conv weights from F16 tensors without an f32 detour', async () => {
    class OneConv extends nn.Module {
      readonly conv = new nn.Conv2d(1, 2, { kernelSize: 1 });
      forward(x: never) {
        return x;
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'conv.weight': { dtype: 'F16', shape: [2, 1, 1, 1], data: f16Data([1.5, -2]) },
          'conv.bias': { dtype: 'F32', shape: [2], data: f32Data([0.5, 0.25]) },
        }),
      ),
    );
    const model = new OneConv();
    const { calls, upload } = collector();
    await loadLazyStateDict(model, sd, { upload });
    expect(calls[0]!.data).toBeInstanceOf(Uint16Array); // halfs straight through
    expect(calls[0]!.shape.dtype).toBe('f16');
  });

  it('aggregates missing and unexpected keys into one error, before any fetch', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'F32', shape: [3, 2], data: f32Data([1, 2, 3, 4, 5, 6]) },
          'stray.tensor': { dtype: 'F32', shape: [1], data: f32Data([0]) },
        }),
      ),
    );
    const { upload } = collector();
    await expect(loadLazyStateDict(new TinyLinear(), sd, { upload })).rejects.toThrow(
      /missing.*proj\.bias[\s\S]*unexpected.*stray\.tensor/,
    );
  });

  it('rejects a shape mismatch with the tensor name in the message', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'F32', shape: [2, 2], data: f32Data([1, 2, 3, 4]) },
          'proj.bias': { dtype: 'F32', shape: [3], data: f32Data([7, 8, 9]) },
        }),
      ),
    );
    const { upload } = collector();
    await expect(loadLazyStateDict(new TinyLinear(), sd, { upload })).rejects.toThrow(
      /proj\.weight/,
    );
  });

  it('rejects a rank-1 Linear weight (bare-array in-memory entries need {data, shape})', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'F32', shape: [6], data: f32Data([1, 2, 3, 4, 5, 6]) },
          'proj.bias': { dtype: 'F32', shape: [3], data: f32Data([7, 8, 9]) },
        }),
      ),
    );
    const { upload } = collector();
    await expect(loadLazyStateDict(new TinyLinear(), sd, { upload })).rejects.toThrow(
      /proj\.weight.*torch layout/,
    );
  });

  it('binds an Embedding weight CPU-side as raw bf16 bits, never through upload', async () => {
    class WithEmbedding extends nn.Module {
      readonly embedding = new nn.Embedding(3, 2, { device: 'cpu' });
      forward(x: never) {
        return x;
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'embedding.weight': { dtype: 'BF16', shape: [3, 2], data: bf16Data([1, 2, 3, 4, 5, 6]) },
        }),
      ),
    );
    const model = new WithEmbedding();
    const { calls, upload } = collector();
    await loadLazyStateDict(model, sd, { upload });
    expect(calls.length).toBe(0); // nothing uploaded
    expect((model.embedding.weight as nn.CpuParameter).data.length).toBe(6);
    expect((model.embedding.weight as nn.CpuParameter).data).toBeInstanceOf(Uint16Array);
    // gather round-trips the bf16 bits back to the original (bf16-exact) values
    expect(Array.from(model.embedding.gather([2, 0]))).toEqual([5, 6, 1, 2]);
  });

  it('binds a cpu Embedding weight as plain f32 from an F32 checkpoint', async () => {
    class WithEmbedding extends nn.Module {
      readonly embedding = new nn.Embedding(3, 2, { device: 'cpu' });
      forward(x: never) {
        return x;
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'embedding.weight': { dtype: 'F32', shape: [3, 2], data: f32Data([1, 2, 3, 4, 5, 6]) },
        }),
      ),
    );
    const model = new WithEmbedding();
    const { calls, upload } = collector();
    await loadLazyStateDict(model, sd, { upload });
    expect(calls.length).toBe(0); // nothing uploaded
    expect((model.embedding.weight as nn.CpuParameter).data).toBeInstanceOf(Float32Array);
    expect(Array.from(model.embedding.gather([2, 0]))).toEqual([5, 6, 1, 2]);
  });

  it('runs transformStateDict hooks depth-first before the strict check', async () => {
    class FoldedConv extends nn.Module {
      readonly conv = new nn.Conv2d(1, 1, { kernelSize: 1 });
      forward(x: never) {
        return x;
      }
      override transformStateDict(sd: LazyStateDict, prefix: string): void {
        foldBnIntoConv(sd, prefix ? `${prefix}.conv` : 'conv', prefix ? `${prefix}.bn` : 'bn', 1.0);
      }
    }
    class Wrapper extends nn.Module {
      readonly block = new FoldedConv();
      forward(x: never) {
        return x;
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'block.conv.weight': { dtype: 'F16', shape: [1, 1, 1, 1], data: f16Data([2]) },
          'block.bn.weight': { dtype: 'F32', shape: [1], data: f32Data([1]) },
          'block.bn.bias': { dtype: 'F32', shape: [1], data: f32Data([0]) },
          'block.bn.running_mean': { dtype: 'F32', shape: [1], data: f32Data([0]) },
          'block.bn.running_var': { dtype: 'F32', shape: [1], data: f32Data([3]) },
        }),
      ),
    );
    const model = new Wrapper();
    const { calls, upload } = collector();
    await loadLazyStateDict(model, sd, { upload }); // bn.* consumed -> strict check passes
    // folded weight = 2 * 1/sqrt(3+1) = 1.0, re-packed to f16
    const words = calls[0]!.data as Uint32Array;
    expect(words[0]! & 0xffff).toBe(0x3c00); // f16(1.0)
  });

  it('reports progress with cumulative file bytes (the transpose keeps byteLength)', async () => {
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'F32', shape: [3, 2], data: f32Data([1, 2, 3, 4, 5, 6]) },
          'proj.bias': { dtype: 'F32', shape: [3], data: f32Data([7, 8, 9]) },
        }),
      ),
    );
    const { upload } = collector();
    const seen: Array<[string, number, number]> = [];
    await loadLazyStateDict(new TinyLinear(), sd, {
      upload,
      onProgress: (name, done, total) => seen.push([name, done, total]),
    });
    expect(seen).toEqual([
      ['proj.weight', 24, 36],
      ['proj.bias', 36, 36],
    ]);
  });

  it('materializes a derivedTensor holding f16 halfwords without an f32 detour (Proto26 shape)', async () => {
    // Mirrors the fold-hook test's structure, but the transform substitutes a
    // derivedTensor whose compute resolves to Uint16Array directly (as the
    // Proto26 transform does for an f16 param) instead of routing through an
    // f32 recompute. derivedTensor's dtype is nominally 'F32' regardless of
    // what compute() returns (see safetensors.ts), so materialize must not
    // gate on t.dtype === 'F16' here — it must try halfWords() first.
    const halfs = f32ArrayToF16Bits(new Float32Array([1.5, -2])).data;
    class OneConv extends nn.Module {
      readonly conv = new nn.Conv2d(1, 2, { kernelSize: 1 });
      forward(x: never) {
        return x;
      }
      override transformStateDict(sd: LazyStateDict, prefix: string): void {
        const key = prefix ? `${prefix}.conv.weight` : 'conv.weight';
        const original = sd.tensors.get(key);
        if (!original) return;
        sd.tensors.set(
          key,
          derivedTensor(original.shape, () => Promise.resolve(halfs)),
        );
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          // Placeholder F16 payload — the transform hook replaces this entry
          // with a derivedTensor before the strict check / materialize run.
          'conv.weight': { dtype: 'F16', shape: [2, 1, 1, 1], data: f16Data([0, 0]) },
          'conv.bias': { dtype: 'F32', shape: [2], data: f32Data([0.5, 0.25]) },
        }),
      ),
    );
    const model = new OneConv();
    const { calls, upload } = collector();
    await loadLazyStateDict(model, sd, { upload });
    expect(calls[0]!.data).toBeInstanceOf(Uint16Array);
    expect(calls[0]!.shape.dtype).toBe('f16');
    // Conv2d's preprocess packs the raw halfs into one hwc4 mat4 tile
    // (co=2, ci=1, k=1): output lanes 0/1 of input lane 0, rest zero-padded.
    const packed = calls[0]!.data as Uint16Array;
    expect(packed.length).toBe(16);
    expect(packed[0]).toBe(halfs[0]);
    expect(packed[1]).toBe(halfs[1]);
    expect([...packed].filter((v) => v !== 0).length).toBe(2);
  });

  it('falls back to the initTie default; without one the error names initTie', async () => {
    resetTie();
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'proj.weight': { dtype: 'F32', shape: [3, 2], data: f32Data([1, 2, 3, 4, 5, 6]) },
          'proj.bias': { dtype: 'F32', shape: [3], data: f32Data([7, 8, 9]) },
        }),
      ),
    );
    await expect(loadLazyStateDict(new TinyLinear(), sd, {})).rejects.toThrow(/initTie/);
  });

  it('folds BatchNorm2d into the preceding conv automatically — no hook, no flag', async () => {
    class Net extends nn.Module {
      readonly conv = new nn.Conv2d(1, 1, { kernelSize: 1 });
      readonly bn = new nn.BatchNorm2d(1, { eps: 1.0 });
      forward(x: never) {
        return x;
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'conv.weight': { dtype: 'F16', shape: [1, 1, 1, 1], data: f16Data([2]) },
          'bn.weight': { dtype: 'F32', shape: [1], data: f32Data([1]) },
          'bn.bias': { dtype: 'F32', shape: [1], data: f32Data([0]) },
          'bn.running_mean': { dtype: 'F32', shape: [1], data: f32Data([0]) },
          'bn.running_var': { dtype: 'F32', shape: [1], data: f32Data([3]) },
        }),
      ),
    );
    const { calls, upload } = collector();
    await loadLazyStateDict(new Net(), sd, { upload });
    // folded weight = 2 * 1/sqrt(3+1) = 1.0, re-packed to f16
    expect((calls[0]!.data as Uint32Array)[0]! & 0xffff).toBe(0x3c00);
  });

  it('BatchNorm2d without an inferable conv demands an explicit foldInto', async () => {
    class Headless extends nn.Module {
      readonly bn = new nn.BatchNorm2d(4); // no preceding Conv2d sibling
      forward(x: never) {
        return x;
      }
    }
    const sd = await fromSafetensors(
      bufferSource(
        encodeSafetensors({
          'bn.weight': { dtype: 'F32', shape: [4], data: f32Data([1, 1, 1, 1]) },
        }),
      ),
    );
    const { upload } = collector();
    await expect(loadLazyStateDict(new Headless(), sd, { upload })).rejects.toThrow(/foldInto/);
  });

  it('BatchNorm2d.forward is identity — its math lives in the conv after folding', () => {
    const bn = new nn.BatchNorm2d(4);
    const x = materialized({ elems: 4, dtype: 'f32', dims: [4] }, fakeGpuBuffer({}));
    expect(bn.forward(x)).toBe(x);
  });

  it('binds a flat U32 tensor to a quantW param via words()', async () => {
    const words = new Uint32Array([0x04030201, 0x08070605]);
    class QuantHolder extends nn.Module {
      readonly w = new nn.Parameter({ elems: 2, dtype: 'quantW', dims: [4, 2] });
      forward(x: never) {
        return x;
      }
    }
    const model = new QuantHolder();
    const file = encodeSafetensors({
      w: { dtype: 'U32', shape: [2], data: new Uint8Array(words.buffer.slice(0)) },
    });
    const { upload, uploads } = collector();
    await model.loadStateDict(await fromSafetensors(bufferSource(file)), { upload });
    expect(uploads[0]!.data).toBeInstanceOf(Uint32Array);
    expect([...(uploads[0]!.data as Uint32Array)]).toEqual([...words]);
  });

  it('quantW word-count mismatch names the tensor', async () => {
    class QuantHolder extends nn.Module {
      readonly w = new nn.Parameter({ elems: 3, dtype: 'quantW', dims: [4, 3] });
      forward(x: never) {
        return x;
      }
    }
    const file = encodeSafetensors({
      w: { dtype: 'U32', shape: [2], data: new Uint8Array(8) },
    });
    await expect(
      new QuantHolder().loadStateDict(await fromSafetensors(bufferSource(file)), {
        upload: collector().upload,
      }),
    ).rejects.toThrow(/'w'.*2 elems.*3/);
  });

  it('loadStateDict accepts a plain record and runs transform hooks on it', async () => {
    const model = new TinyLinear();
    const { calls, upload } = collector();
    await model.loadStateDict(
      {
        // torch layout [out=3, in=2]: rows [1,2] [3,4] [5,6]
        'proj.weight': { data: new Float32Array([1, 2, 3, 4, 5, 6]), shape: [3, 2] },
        'proj.bias': new Float32Array([7, 8, 9]),
      },
      { upload },
    );
    // bound as [in=2, out=3] — Linear's transpose hook ran on the record path
    expect(calls[0]!.shape.dims).toEqual([2, 3]);
    expect(Array.from(calls[0]!.data as Float32Array)).toEqual([1, 3, 5, 2, 4, 6]);
  });
});
