import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { layerNorm } from '../src/graph/ops.ts';
import { LayerNorm } from '../src/nn/layers.ts';
import type { ValueMeta } from '../src/graph/value.ts';
import { fakeGpuBuffer } from './helpers.ts';

const fakeUpload = (_data: Float32Array | Uint32Array | Uint16Array, shape: ValueMeta) =>
  materialized(shape, fakeGpuBuffer({ id: 'p' }));

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));
const vec = (n: number) =>
  materialized({ elems: n, dtype: 'f32', dims: [n] }, fakeGpuBuffer({ id: 'w' }));

describe('layerNorm op', () => {
  it('emits ONE pending node carrying eps as the scalar', () => {
    const y = layerNorm(mat(5, 8), vec(8));
    expect(y.shape.dims).toEqual([5, 8]);
    expect(y.pending!.op).toBe('layerNorm');
    expect(y.pending!.inputs).toHaveLength(2);
    expect(y.pending!.scalar).toBe(1e-5);
  });

  it('threads a custom eps through', () => {
    expect(layerNorm(mat(2, 4), vec(4), 1e-6).pending!.scalar).toBe(1e-6);
  });

  it('rejects a weight of the wrong width', () => {
    expect(() => layerNorm(mat(5, 8), vec(7))).toThrow(/weight/);
  });

  it('rejects a non-positive eps', () => {
    expect(() => layerNorm(mat(5, 8), vec(8), 0)).toThrow(/eps/);
  });

  it('carries an optional bias as a third input', () => {
    const y = layerNorm(mat(5, 8), vec(8), 1e-5, vec(8));
    expect(y.pending!.inputs).toHaveLength(3);
    expect(y.pending!.scalar).toBe(1e-5);
  });

  it('rejects a bias of the wrong width', () => {
    expect(() => layerNorm(mat(5, 8), vec(8), 1e-5, vec(7))).toThrow(/bias/);
  });
});

describe('nn.LayerNorm', () => {
  it('registers a single weight parameter under torch naming', () => {
    const ln = new LayerNorm(8);
    const names = [...ln.namedParameters()].map(([n]) => n);
    expect(names).toEqual(['weight']);
    expect(ln.eps).toBe(1e-5); // torch nn.LayerNorm default
  });

  it('loads and forwards through the fused op', async () => {
    const ln = new LayerNorm(8);
    await ln.loadStateDict({ weight: new Float32Array(8).fill(1) }, { upload: fakeUpload });
    const y = ln.forward(mat(3, 8));
    expect(y.shape.dims).toEqual([3, 8]);
    expect(y.pending!.op).toBe('layerNorm');
  });

  it('registers weight AND bias with bias: true (torch naming)', () => {
    const ln = new LayerNorm(8, 1e-12, { bias: true });
    const names = [...ln.namedParameters()].map(([n]) => n);
    expect(names).toEqual(['weight', 'bias']);
  });

  it('threads the bias into the fused op', async () => {
    const ln = new LayerNorm(8, 1e-5, { bias: true });
    await ln.loadStateDict(
      { weight: new Float32Array(8).fill(1), bias: new Float32Array(8) },
      { upload: fakeUpload },
    );
    const y = ln.forward(mat(3, 8));
    expect(y.pending!.op).toBe('layerNorm');
    expect(y.pending!.inputs).toHaveLength(3);
  });
});
