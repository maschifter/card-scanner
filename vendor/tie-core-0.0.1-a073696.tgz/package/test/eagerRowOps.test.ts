import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { cat, gatherRows, slice } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number, id = 'x') => materialized(matrix(r, c), fakeGpuBuffer({ id }));

describe('sliceRows', () => {
  it('[M,N] -> [end-start, N] with attrs', () => {
    const y = slice(mat(8, 3), 0, 2, 6);
    expect(y.shape).toEqual({ elems: 12, dtype: 'f32', dims: [4, 3] });
    expect(y.pending!.attrs).toEqual([2, 6]);
  });
  it('rejects bad ranges', () => {
    expect(() => slice(mat(8, 3), 0, -1, 4)).toThrow(/slice/);
    expect(() => slice(mat(8, 3), 0, 4, 4)).toThrow(/slice/);
    expect(() => slice(mat(8, 3), 0, 0, 9)).toThrow(/slice/);
  });
});

describe('concatRows', () => {
  it('[A,N] ++ [B,N] -> [A+B,N]', () => {
    const y = cat([mat(3, 4, 'a'), mat(2, 4, 'b')], 0);
    expect(y.shape).toEqual({ elems: 20, dtype: 'f32', dims: [5, 4] });
  });
  it('rejects col mismatch', () => {
    expect(() => cat([mat(3, 4, 'a'), mat(3, 2, 'b')], 0)).toThrow(/cat/);
  });
});

describe('gatherRows', () => {
  it('picks rows by index, any count, repeats allowed', () => {
    const y = gatherRows(mat(4, 3), [3, 0, 3]);
    expect(y.shape).toEqual({ elems: 9, dtype: 'f32', dims: [3, 3] });
    expect(y.pending!.attrs).toEqual([3, 0, 3]);
  });
  it('rejects out-of-range and non-integer indices, and empty lists', () => {
    expect(() => gatherRows(mat(4, 3), [4])).toThrow(/gatherRows/);
    expect(() => gatherRows(mat(4, 3), [-1])).toThrow(/gatherRows/);
    expect(() => gatherRows(mat(4, 3), [1.5])).toThrow(/gatherRows/);
    expect(() => gatherRows(mat(4, 3), [])).toThrow(/gatherRows/);
  });
  it('gathers f16 rows from an f16 table', () => {
    const table = materialized(
      { elems: 16, dtype: 'f16', dims: [4, 4] },
      fakeGpuBuffer({ id: 'w' }),
    );
    expect(gatherRows(table, [3, 0]).shape).toEqual({ elems: 8, dtype: 'f16', dims: [2, 4] });
  });
});
