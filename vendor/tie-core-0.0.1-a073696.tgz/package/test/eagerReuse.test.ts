import { describe, expect, it } from 'vitest';
import { materialized, type GpuBufferRef, type ValueMeta } from '../src/graph/value.ts';
import { add } from '../src/graph/ops.ts';
import { evalValues, type Executor } from '../src/graph/evalCore.ts';
import { BufferPool } from '../src/gpu/bufferPool.ts';
import { fakeGpuBuffer } from './helpers.ts';

function poolExecutor(): Executor & { created: number } {
  let created = 0;
  const pool = new BufferPool((s: ValueMeta) => {
    created += 1;
    return fakeGpuBuffer({ ...s, id: created });
  });
  return {
    get created() {
      return created;
    },
    acquireOutput: (shape) => pool.acquire(shape),
    releaseOutput: (buf, shape) => pool.release(buf, shape),
    dispatch: () => {},
    submit: () => {},
  };
}

describe('eval buffer reuse (liveness)', () => {
  it('a long single-use chain reuses buffers instead of allocating one per op', () => {
    const a = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'a' }));
    const c = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'c' }));
    let x = add(a, c);
    for (let i = 0; i < 9; i++) x = add(x, c);
    const ex = poolExecutor();
    evalValues([x], ex);
    expect(ex.created).toBeLessThanOrEqual(2);
    expect(x.state).toBe('materialized');
  });

  it('marks a recycled intermediate as released and its .buffer throws loudly', () => {
    const a = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'a' }));
    const c = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'c' }));
    const mid = add(a, c);
    const out = add(mid, c);
    evalValues([out], poolExecutor());
    expect(mid.state).toBe('released');
    expect(() => mid.buffer).toThrow(/recycled/);
    expect(out.state).toBe('materialized');
  });

  it('evaluating a new op built on a released Value fails loudly', () => {
    const a = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'a' }));
    const c = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'c' }));
    const mid = add(a, c);
    const out = add(mid, c);
    const ex = poolExecutor();
    evalValues([out], ex);
    const late = add(mid, c); // consumes the released intermediate
    expect(() => evalValues([late], ex)).toThrow(/recycled/);
  });

  it('a target Value stays materialized and readable across a second eval (the pin contract)', () => {
    const a = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'a' }));
    const c = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'c' }));
    const mid = add(a, c);
    const out = add(mid, c);
    const ex = poolExecutor();
    evalValues([out, mid], ex); // mid pinned as co-target
    expect(mid.state).toBe('materialized');
    const late = add(mid, c);
    evalValues([late], ex); // second eval consumes mid — must not throw
    expect(mid.state).toBe('materialized');
    expect(() => mid.buffer).not.toThrow();
    expect(late.state).toBe('materialized');
  });

  it('does not release a target buffer', () => {
    const a = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'a' }));
    const b = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ id: 'b' }));
    const t = add(a, b);
    const released: GpuBufferRef[] = [];
    const ex: Executor = {
      acquireOutput: (shape) => fakeGpuBuffer({ ...shape }),
      releaseOutput: (buf) => {
        released.push(buf);
      },
      dispatch: () => {},
      submit: () => {},
    };
    evalValues([t], ex);
    expect(released).toEqual([]);
  });
});
