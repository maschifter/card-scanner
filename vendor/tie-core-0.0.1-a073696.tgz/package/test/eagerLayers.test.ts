import { describe, expect, it } from 'vitest';
import {
  Conv1d,
  Conv2d,
  Embedding,
  GroupNorm,
  Linear,
  MultiHeadAttention,
  RMSNorm,
} from '../src/nn/layers.ts';
import { materialized, matrix, type Value, type ValueMeta } from '../src/graph/value.ts';
import { fakeGpuBuffer } from './helpers.ts';

const fakeUpload = (_d: Float32Array | Uint32Array | Uint16Array, shape: ValueMeta): Value =>
  materialized(shape, fakeGpuBuffer({ id: 'w' }));

describe('eager nn layers', () => {
  it('Linear registers weight [inF,outF] and bias [outF]', () => {
    const lin = new Linear(4, 8);
    const params = Object.fromEntries(Array.from(lin.namedParameters()));
    expect(params.weight!.shape).toEqual({ elems: 32, dtype: 'f32', dims: [4, 8] });
    expect(params.bias!.shape).toEqual({ elems: 8, dtype: 'f32', dims: [8] });
  });

  it('RMSNorm registers a scale [N]', () => {
    const norm = new RMSNorm(8);
    const params = Array.from(norm.namedParameters()).map(([n]) => n);
    expect(params).toEqual(['scale']);
  });

  it('GroupNorm registers weight and bias [C] under torch naming', () => {
    const gn = new GroupNorm(1, 6);
    const params = Object.fromEntries(Array.from(gn.namedParameters()));
    expect(Object.keys(params).sort()).toEqual(['bias', 'weight']);
    expect(params.weight!.shape).toEqual({ elems: 6, dtype: 'f32', dims: [6] });
    expect(params.bias!.shape).toEqual({ elems: 6, dtype: 'f32', dims: [6] });
    expect(gn.eps).toBe(1e-5); // torch nn.GroupNorm default
  });

  it('GroupNorm rejects numGroups other than 1', () => {
    expect(() => new GroupNorm(2, 6)).toThrow(/numGroups = 1/);
  });
});

describe('Embedding', () => {
  it('registers weight [numEmbeddings, dims] under torch naming', () => {
    const emb = new Embedding(100, 16);
    const params = Object.fromEntries(Array.from(emb.namedParameters()));
    expect(Object.keys(params)).toEqual(['weight']);
    expect(params.weight!.shape).toEqual({ elems: 1600, dtype: 'f32', dims: [100, 16] });
  });

  it('forward gathers the id rows', async () => {
    const emb = new Embedding(10, 4);
    await emb.loadStateDict({ weight: new Float32Array(40) }, { upload: fakeUpload });
    const y = emb.forward([3, 7, 3]);
    expect(y.shape.dims).toEqual([3, 4]);
    expect(y.pending!.op).toBe('gatherRows');
    expect(y.pending!.attrs).toEqual([3, 7, 3]);
  });
});

describe('Linear without bias', () => {
  it('registers only the weight and forwards as plain matmul', () => {
    const l = new Linear(4, 2, { bias: false });
    const names = Array.from(l.namedParameters()).map(([n]) => n);
    expect(names).toEqual(['weight']);
  });
});

describe('Conv1d', () => {
  it('registers tap-major weight [k·cIn, cOut] and bias [cOut] under torch naming', () => {
    const conv = new Conv1d(3, 5, 7, { stride: 2 });
    const params = Object.fromEntries(Array.from(conv.namedParameters()));
    expect(Object.keys(params).sort()).toEqual(['bias', 'weight']);
    expect(params.weight!.shape).toEqual({ elems: 21 * 5, dtype: 'f32', dims: [21, 5] });
    expect(params.bias!.shape).toEqual({ elems: 5, dtype: 'f32', dims: [5] });
  });

  it('bias: false registers only the weight', () => {
    const conv = new Conv1d(1, 4, 127, { stride: 64, bias: false });
    expect(Array.from(conv.namedParameters()).map(([n]) => n)).toEqual(['weight']);
  });

  it('forward derives [(T − k)/s + 1, cOut], default stride 1', async () => {
    const fake = (shape: ValueMeta): Value => materialized(shape, fakeGpuBuffer({ id: 'x' }));
    // Torch-layout (C_out, C_in, k) zeros — the Conv1d hook permutes them.
    const bind = (m: Conv1d) =>
      m.loadStateDict(
        {
          weight: {
            data: new Float32Array(m.outChannels * m.inChannels * m.kernelSize),
            shape: [m.outChannels, m.inChannels, m.kernelSize],
          },
          bias: new Float32Array(m.outChannels),
        },
        { upload: fakeUpload },
      );
    const strided = new Conv1d(2, 6, 7, { stride: 3 });
    await bind(strided);
    expect(strided.forward(fake(matrix(100, 2))).shape.dims).toEqual([32, 6]);
    const dense = new Conv1d(4, 4, 3);
    await bind(dense);
    expect(dense.forward(fake(matrix(10, 4))).shape.dims).toEqual([8, 4]);
    const same = new Conv1d(4, 4, 3, { padding: 1 }); // torch Conv1d(padding=1)
    await bind(same);
    expect(same.forward(fake(matrix(10, 4))).shape.dims).toEqual([10, 4]);
    const sameStr = new Conv1d(4, 4, 4, { padding: 'same' }); // even k, torch split
    await bind(sameStr);
    expect(sameStr.forward(fake(matrix(10, 4))).shape.dims).toEqual([10, 4]);
  });
});

describe('MultiHeadAttention', () => {
  const WINDOW_INF = 0x3fffffff; // the op's finite stand-in for Infinity
  const GEO = { qHeads: 4, kvHeads: 2, headDim: 8 };
  const fake = (shape: ValueMeta): Value => materialized(shape, fakeGpuBuffer({ id: 'x' }));
  const q = () => fake(matrix(5, GEO.qHeads * GEO.headDim));
  const kv = () => fake(matrix(7, GEO.kvHeads * GEO.headDim));

  it('registers no parameters without sinks and emits the attn node', () => {
    const mha = new MultiHeadAttention({ ...GEO, windowLeft: Infinity, windowRight: Infinity });
    expect(Array.from(mha.namedParameters())).toHaveLength(0);
    const y = mha.forward(q(), kv(), kv());
    expect(y.pending!.op).toBe('attn');
    expect(y.shape.dims).toEqual([5, GEO.qHeads * GEO.headDim]);
    expect(y.pending!.inputs).toHaveLength(3);
    expect(y.pending!.attrs).toEqual([4, 2, 8, WINDOW_INF, WINDOW_INF, 0, 0, 0, 0]);
  });

  it('threads a per-call qPosOffset into the attrs', () => {
    const mha = new MultiHeadAttention({ ...GEO, windowLeft: Infinity, windowRight: 0 });
    const y = mha.forward(fake(matrix(1, GEO.qHeads * GEO.headDim)), kv(), kv(), {
      qPosOffset: 6,
    });
    expect(y.pending!.attrs).toEqual([4, 2, 8, WINDOW_INF, 0, 6, 0, 0, 0]);
  });

  it('with sinks: registers exactly one Parameter named sinks and passes it', async () => {
    const mha = new MultiHeadAttention({
      ...GEO,
      windowLeft: 3,
      windowRight: 3,
      sinks: true,
    });
    const params = Object.fromEntries(Array.from(mha.namedParameters()));
    expect(Object.keys(params)).toEqual(['sinks']);
    expect(params.sinks!.shape).toEqual({ elems: 4, dtype: 'f32', dims: [4] });
    await mha.loadStateDict({ sinks: new Float32Array(4) }, { upload: fakeUpload });
    const y = mha.forward(q(), kv(), kv());
    expect(y.pending!.inputs).toHaveLength(4);
    expect(y.pending!.attrs).toEqual([4, 2, 8, 3, 3, 0, 1, 0, 0]);
  });

  it('with sinks enabled but unloaded, forward fails loudly', () => {
    const mha = new MultiHeadAttention({ ...GEO, windowLeft: 1, windowRight: 1, sinks: true });
    expect(() => mha.forward(q(), kv(), kv())).toThrow(/not loaded/);
  });
});

describe('Conv2d layer', () => {
  it('registers an f16 weight [C_out, C_in·k·k] and an f32 bias', () => {
    const conv = new Conv2d(4, 8, { kernelSize: 3 });
    const params = Object.fromEntries(Array.from(conv.namedParameters()));
    expect(params.weight!.shape).toEqual({
      elems: 8 * 36,
      dtype: 'f16',
      dims: [8, 36],
      layout: 'hwc4',
    });
    expect(params.bias!.shape).toEqual({ elems: 8, dtype: 'f32', dims: [8] });
  });

  it('bias: false registers only the weight', () => {
    const conv = new Conv2d(4, 8, { kernelSize: 1, bias: false });
    const names = Array.from(conv.namedParameters()).map(([n]) => n);
    expect(names).toEqual(['weight']);
  });

  it('grouped conv shrinks the per-channel weight columns', () => {
    const conv = new Conv2d(8, 8, { kernelSize: 3, groups: 8 }); // depthwise
    const params = Object.fromEntries(Array.from(conv.namedParameters()));
    expect(params.weight!.shape.dims).toEqual([8, 9]);
    expect(params.weight!.shape.elems).toBe(72); // 8·9 f16 values
  });
});
