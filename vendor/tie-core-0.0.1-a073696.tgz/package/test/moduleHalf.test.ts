import { beforeEach, describe, expect, it } from 'vitest';
import type { TgpuRoot } from 'typegpu';
import { Buffer, Module, Parameter } from '../src/nn/module.ts';
import { resetTie } from '../src/gpu/context.ts';
import { setDefaultRoot } from '../src/gpu/context.ts';
import { materialized } from '../src/graph/value.ts';
import { fakeGpuBuffer } from './helpers.ts';

const rootWith = (...features: string[]) =>
  ({ enabledFeatures: new Set(features) }) as unknown as TgpuRoot;

class Tiny extends Module {
  readonly weight = new Parameter({ elems: 8, dtype: 'f32', dims: [2, 4] });
  readonly bias = new Parameter({ elems: 4, dtype: 'f32', dims: [4] });
  readonly table = new Buffer(new Float32Array(4), { elems: 4, dtype: 'f32' });
}

class WithQuant extends Module {
  readonly weight = new Parameter({ elems: 8, dtype: 'quantW', dims: [4, 8] });
  readonly scales = new Parameter({ elems: 4, dtype: 'f32', dims: [4] });
}

/** Mirrors Conv2d: a weight the kernels only ever read as f16. */
class WithPinnedWeight extends Module {
  readonly weight = new Parameter({ elems: 8, dtype: 'f16', dims: [2, 4] }, undefined, true);
  readonly bias = new Parameter({ elems: 4, dtype: 'f32', dims: [4] });
}

/** Mirrors MultiHeadAttention's sinks: a param the kernels only ever read as f32. */
class WithPinnedF32 extends Module {
  readonly sinks = new Parameter({ elems: 4, dtype: 'f32', dims: [4] }, undefined, true);
  readonly bias = new Parameter({ elems: 4, dtype: 'f32', dims: [4] });
}

describe('Module.half', () => {
  beforeEach(() => {
    resetTie();
    setDefaultRoot(rootWith('shader-f16'));
  });

  it('retypes every f32 parameter and buffer to f16', () => {
    const m = new Tiny();
    m.half();
    expect(m.weight.shape.dtype).toBe('f16');
    expect(m.bias.shape.dtype).toBe('f16');
    expect(m.table.shape.dtype).toBe('f16');
  });

  it('keeps elems and dims unchanged', () => {
    const m = new Tiny();
    m.half();
    expect(m.weight.shape.elems).toBe(8);
    expect(m.weight.shape.dims).toEqual([2, 4]);
  });

  it('returns the module so calls chain', () => {
    const m = new Tiny();
    expect(m.half()).toBe(m);
  });

  it('refuses to half() a model with a quantW weight', () => {
    const m = new WithQuant();
    expect(() => m.half()).toThrow(/quantized/);
    // Refused before touching anything.
    expect(m.weight.shape.dtype).toBe('quantW');
    expect(m.scales.shape.dtype).toBe('f32');
  });

  it('float() restores f32', () => {
    const m = new Tiny();
    m.half().float();
    expect(m.weight.shape.dtype).toBe('f32');
    expect(m.table.shape.dtype).toBe('f32');
  });

  it('throws when the device has no shader-f16', () => {
    setDefaultRoot(rootWith('subgroups'));
    expect(() => new Tiny().half()).toThrow(/shader-f16/);
  });

  it('throws when a parameter is already loaded', () => {
    const m = new Tiny();
    m.weight.bind(materialized(m.weight.shape, fakeGpuBuffer({ id: 'w' })));
    expect(() => m.half()).toThrow(/already loaded/);
  });

  it('leaves a pinned f16 weight alone through half() and float()', () => {
    const m = new WithPinnedWeight();
    m.half();
    expect(m.weight.shape.dtype).toBe('f16');
    expect(m.bias.shape.dtype).toBe('f16');
    m.float();
    expect(m.weight.shape.dtype).toBe('f16');
    expect(m.bias.shape.dtype).toBe('f32');
  });

  it('leaves a pinned f32 param (e.g. attention sinks) alone through half()', () => {
    const m = new WithPinnedF32();
    m.half();
    expect(m.sinks.shape.dtype).toBe('f32');
    expect(m.bias.shape.dtype).toBe('f16');
  });
});
