import { describe, expect, it } from 'vitest';

/** Guard: the GPU suite must run on real hardware. With the wrong chromium
 *  launch flags (e.g. '--enable-features=Vulkan' on macOS) WebGPU silently
 *  falls back to SwiftShader — a CPU rasterizer — and every benchmark in the
 *  suite measures software emulation (~100× slower, discovered 2026-07:
 *  yolo26n "2.7s/frame" was 29ms on Metal). This test fails loudly instead. */
describe('webgpu adapter', () => {
  it('is a hardware adapter, not SwiftShader', async () => {
    const adapter = await navigator.gpu.requestAdapter();
    expect(adapter).toBeTruthy();
    const info = adapter!.info;
    console.log(`WebGPU adapter: vendor=${info.vendor} architecture=${info.architecture}`);
    expect(info.architecture).not.toBe('swiftshader');
    expect(info.vendor).not.toBe('google'); // google = SwiftShader on all platforms
  });
});
