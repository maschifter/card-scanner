/** Numeric pins for the eval driver's fusion passes on the HWC4 graph:
 *  residual-add fusion (add(x, conv) folded into the conv epilogue) and
 *  concat elision (producers writing straight into the concat buffer at a
 *  channel-block offset; multi-consumer inputs fall back to the strided
 *  copyCh copy). Same graphs a yolo26 Bottleneck / SPPF / C3k2 build —
 *  verified against plain CPU math. */

import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  add,
  cat,
  conv2d,
  gpuExecutor,
  materialized,
  maxPool2d,
  f32ArrayToF16Bits,
  packConvHwc4F16,
  slice,
  tensor3d,
  toArray,
  toChw,
  toHwc4,
  uploadF32,
  uploadF16,
} from '../../src/index.ts';
import type { Value } from '../../src/index.ts';

const silu = (v: number) => v / (1 + Math.exp(-v));

/** CPU 1×1 conv + bias + optional SiLU over CHW. */
function conv1x1Cpu(
  x: Float32Array,
  w: Float32Array,
  b: Float32Array,
  cIn: number,
  cOut: number,
  hw: number,
  act: boolean,
): Float32Array {
  const out = new Float32Array(cOut * hw);
  for (let co = 0; co < cOut; co++) {
    for (let p = 0; p < hw; p++) {
      let acc = b[co]!;
      for (let ci = 0; ci < cIn; ci++) acc += w[co * cIn + ci]! * x[ci * hw + p]!;
      out[co * hw + p] = act ? silu(acc) : acc;
    }
  }
  return out;
}

const f16 = (v: number) => v; // weights are f16-representable by construction

/** hwc4 1×1 conv node: mat4-tile-packed weight + f16 bias. */
function makeConvValue(
  root: Awaited<ReturnType<typeof tgpu.init>>,
  x: Value,
  w: Float32Array,
  b: Float32Array,
  cIn: number,
  cOut: number,
  act: boolean,
): Value {
  const wPacked = materialized(
    { elems: cOut * cIn, dtype: 'f16', dims: [cOut, cIn], layout: 'hwc4' },
    uploadF16(root, packConvHwc4F16(f32ArrayToF16Bits(w).data, cOut, cIn, 1, 1)),
  );
  const bias = materialized(
    { elems: cOut, dtype: 'f16', dims: [cOut] },
    uploadF16(root, f32ArrayToF16Bits(b).data),
  );
  return conv2d(x, wPacked, bias, { kernelSize: 1, stride: 1, padding: 0, groups: 1, act });
}

const init = () => tgpu.init({ device: { optionalFeatures: ['shader-f16'] } });

describe('eval fusion passes (GPU numerics vs CPU)', () => {
  it('add(x, conv(x)) matches CPU — residual folded into the conv epilogue', async () => {
    const root = await init();
    const exec = gpuExecutor(root);
    const [c, h, w] = [8, 4, 4];
    const hw = h * w;
    const xData = new Float32Array(c * hw).map((_, i) => ((i * 7) % 13) / 13 - 0.5);
    const wData = new Float32Array(c * c).map((_, i) => f16((((i * 3) % 11) - 5) * 0.1));
    const bData = new Float32Array(c).map((_, i) => i * 0.01);

    const x = toHwc4(materialized(tensor3d(c, h, w), uploadF32(root, xData)));
    const y = add(x, makeConvValue(root, x, wData, bData, c, c, true));
    const got = await toArray(toChw(y, 'f32'), exec);

    const conv = conv1x1Cpu(xData, wData, bData, c, c, hw, true);
    for (let i = 0; i < got.length; i++) {
      expect(Math.abs(got[i]! - (xData[i]! + conv[i]!))).toBeLessThan(2e-2);
    }
  });

  it('nested concat of convs and pools matches CPU — SPPF-shaped elision', async () => {
    const root = await init();
    const exec = gpuExecutor(root);
    const [c, h, w] = [4, 4, 4];
    const hw = h * w;
    const xData = new Float32Array(c * hw).map((_, i) => ((i * 5) % 17) / 17 - 0.5);
    const wData = new Float32Array(c * c).map((_, i) => f16((((i * 7) % 9) - 4) * 0.1));
    const bData = new Float32Array(c).fill(0.1);

    const x = toHwc4(materialized(tensor3d(c, h, w), uploadF32(root, xData)));
    // cat(cat(conv(x), pool(conv(x))), x) — conv/pool elide, x (multi-use
    // here: it also feeds the conv) falls back to the strided copyCh copy.
    const cv = makeConvValue(root, x, wData, bData, c, c, false);
    const p = maxPool2d(cv, { kernelSize: 3, stride: 1, padding: 1 });
    const stacked = cat([cv, p, x], 0);
    expect(stacked.shape.dims![0]).toBe(3 * c);
    const got = await toArray(toChw(stacked, 'f32'), exec);

    const convRef = conv1x1Cpu(xData, wData, bData, c, c, hw, false);
    // CPU maxpool 3x3 s1 p1 over the conv output
    const poolRef = new Float32Array(c * hw);
    for (let ch = 0; ch < c; ch++) {
      for (let y0 = 0; y0 < h; y0++) {
        for (let x0 = 0; x0 < w; x0++) {
          let m = -Infinity;
          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              const yy = y0 + dy;
              const xx = x0 + dx;
              if (yy >= 0 && yy < h && xx >= 0 && xx < w) {
                m = Math.max(m, convRef[ch * hw + yy * w + xx]!);
              }
            }
          }
          poolRef[ch * hw + y0 * w + x0] = m;
        }
      }
    }
    const ref = new Float32Array(3 * c * hw);
    ref.set(convRef, 0);
    ref.set(poolRef, c * hw);
    ref.set(xData, 2 * c * hw);
    for (let i = 0; i < got.length; i++) {
      expect(Math.abs(got[i]! - ref[i]!)).toBeLessThan(2e-2);
    }
  });

  it('C3k2-shaped chain (slice → bottleneck-with-residual → progressive cat) matches CPU', async () => {
    const root = await init();
    const exec = gpuExecutor(root);
    const [c2, h, w] = [8, 4, 4]; // cv1 out channels; halves of 4
    const c = c2 / 2;
    const hw = h * w;
    const xData = new Float32Array(c2 * hw).map((_, i) => ((i * 11) % 19) / 19 - 0.5);
    const wData = new Float32Array(c * c).map((_, i) => f16((((i * 5) % 7) - 3) * 0.1));
    const bData = new Float32Array(c).fill(0.05);

    const x = toHwc4(materialized(tensor3d(c2, h, w), uploadF32(root, xData)));
    const a = slice(x, 0, 0, c);
    const b = slice(x, 0, c, c2);
    const m1 = add(b, makeConvValue(root, b, wData, bData, c, c, true)); // bottleneck w/ residual
    const stacked = cat([a, b, m1], 0);
    const got = await toArray(toChw(stacked, 'f32'), exec);

    const aRef = xData.slice(0, c * hw);
    const bRef = xData.slice(c * hw, c2 * hw);
    const convRef = conv1x1Cpu(bRef, wData, bData, c, c, hw, true);
    for (let i = 0; i < c * hw; i++) {
      expect(Math.abs(got[i]! - aRef[i]!)).toBeLessThan(1e-3);
      expect(Math.abs(got[c * hw + i]! - bRef[i]!)).toBeLessThan(1e-3);
      expect(Math.abs(got[2 * c * hw + i]! - (bRef[i]! + convRef[i]!))).toBeLessThan(2e-2);
    }
  });
});
