import { describe, expect, it } from 'vitest';
import tgpu, { d } from 'typegpu';
import {
  GRID_Y_STRIDE,
  gridYStride,
  MAX_WORKGROUPS_PER_DIM,
  WORKGROUP_SIZE,
} from '../../src/kernels/common.ts';
import { makeConv1x1Kernel, makeConvGenericKernel, WG_1X1 } from '../../src/kernels/conv/hwc4.ts';

/** Empirical proof of the 2-D dispatch fold used by the executor:
 *  (1) the 65535 cap is a real device limit, (2) gid.x spans exactly
 *  X·64 values so the y-stride is X·64, (3) the fold enumerates every
 *  index once with no gaps or duplicates across the slice boundary. */
describe('2-D dispatch fold', () => {
  it('GRID_Y_STRIDE matches the device cap and the fold has no gaps', async () => {
    const root = await tgpu.init();

    // (1) the cap is a real, queryable device limit
    // (1) our constant must match the ACTUAL device limit — if a device ever
    // reports a lower cap, the executor's split would still be rejected.
    const cap = root.device.limits.maxComputeWorkgroupsPerDimension;
    console.log(`\n[1] device cap = ${cap}, MAX_WORKGROUPS_PER_DIM = ${MAX_WORKGROUPS_PER_DIM}`);
    expect(MAX_WORKGROUPS_PER_DIM).toBeLessThanOrEqual(cap);

    // (2) GRID_Y_STRIDE must be exactly what one full x-slice covers —
    // this is the invariant that silently breaks if either side is edited.
    expect(GRID_Y_STRIDE).toBe(MAX_WORKGROUPS_PER_DIM * WORKGROUP_SIZE);

    // (3) Use a SMALL stand-in grid so we can read back every value:
    // X=3 workgroups × 64 threads = 192 per y-slice, Y=2 → 384 total.
    const X = 3;
    const WG = 64;
    const STRIDE = X * WG; // the analogue of 65535*64 = 4194240
    const TOTAL = STRIDE * 2;

    const layout = tgpu.bindGroupLayout({
      out: { storage: d.arrayOf(d.u32), access: 'mutable' },
    });
    const kernel = tgpu.computeFn({
      in: { gid: d.builtin.globalInvocationId },
      workgroupSize: [WG],
    })(({ gid }) => {
      'use gpu';
      // the exact expression the flat kernels use
      const i = gid.x + gid.y * STRIDE;
      layout.$.out[i] = i + 1; // +1 so "never written" (0) is distinguishable
    });

    const buf = root.createBuffer(d.arrayOf(d.u32, TOTAL)).$usage('storage');
    const pipeline = root.createComputePipeline({ compute: kernel });
    const bg = root.createBindGroup(layout, { out: buf });
    const enc = root.device.createCommandEncoder();
    const pass = enc.beginComputePass();
    pipeline.with(pass).with(bg).dispatchWorkgroups(X, 2); // <- the 2-D split
    pass.end();
    root.device.queue.submit([enc.finish()]);
    const got = await buf.read();

    // gid.x must span exactly 0..X*64-1 (proves STRIDE = X*64)
    const slice0Max = Math.max(...Array.from(got.slice(0, STRIDE), (v) => v - 1));
    console.log(`[3] y=0 slice covered indices 0..${slice0Max} (stride must be ${STRIDE})`);
    expect(slice0Max).toBe(STRIDE - 1);

    // every index written exactly once, no gaps, no duplicates
    let gaps = 0;
    for (let i = 0; i < TOTAL; i++) if (got[i] !== i + 1) gaps++;
    console.log(`[4] indices 0..${TOTAL - 1}: ${gaps} gaps/duplicates`);
    console.log(
      `    boundary check: out[${STRIDE - 1}]=${got[STRIDE - 1]! - 1}, out[${STRIDE}]=${got[STRIDE]! - 1}`,
    );
    expect(gaps).toBe(0);
  });

  it('the workgroup-index fold numbers every workgroup once', async () => {
    const root = await tgpu.init();

    // Same stand-in grid, one level up: the tiled convs derive their tile
    // from the WORKGROUP index, so their fold adds X (not X*64) per y.
    const X = 3;
    const WG = 64;
    const TOTAL = X * 2 * WG;

    const layout = tgpu.bindGroupLayout({
      out: { storage: d.arrayOf(d.u32), access: 'mutable' },
    });
    const kernel = tgpu.computeFn({
      in: { gid: d.builtin.globalInvocationId, lidx: d.builtin.localInvocationIndex },
      workgroupSize: [WG],
    })(({ gid, lidx }) => {
      'use gpu';
      // the exact expression flatWorkgroup uses
      const wg = d.u32(gid.x / WG) + gid.y * X;
      const i = wg * WG + lidx;
      layout.$.out[i] = i + 1;
    });

    const buf = root.createBuffer(d.arrayOf(d.u32, TOTAL)).$usage('storage');
    const pipeline = root.createComputePipeline({ compute: kernel });
    const bg = root.createBindGroup(layout, { out: buf });
    const enc = root.device.createCommandEncoder();
    const pass = enc.beginComputePass();
    pipeline.with(pass).with(bg).dispatchWorkgroups(X, 2);
    pass.end();
    root.device.queue.submit([enc.finish()]);
    const got = await buf.read();

    let gaps = 0;
    for (let i = 0; i < TOTAL; i++) if (got[i] !== i + 1) gaps++;
    console.log(`[wg fold] workgroups 0..${X * 2 - 1}: ${gaps} gaps/duplicates`);
    expect(gaps).toBe(0);
  });

  it('kernels compiled at different workgroup sizes fold at their own size', () => {
    // The executor splits in WORKGROUPS, so one y-slice covers
    // MAX_WORKGROUPS_PER_DIM * workgroupSize threads: 4x more at 256 than at
    // 64. The hwc4 conv family runs its generic kernel at 64 and its 1x1 at
    // 256 — if the 1x1 baked in the default stride, the 256 pipeline would
    // fold 4x short and overwrite the same elements four times. Read the
    // emitted WGSL rather than dispatching: the 256 case only bites past
    // 16.7M threads.
    const cfg = {
      cIn: 8,
      cOut: 8,
      kH: 1,
      kW: 1,
      stride: 1,
      padding: 0,
      hasBias: 0,
      hasAct: 0,
      hasAdd: 0,
      kind: 1,
    };
    const wgsl64 = tgpu.resolve([makeConvGenericKernel({ ...cfg, kH: 3, kW: 3, kind: 0 })]);
    const wgsl256 = tgpu.resolve([makeConv1x1Kernel(cfg)]);

    expect(wgsl64).toContain(`${GRID_Y_STRIDE}u`);
    expect(wgsl256).toContain(`${gridYStride(WG_1X1)}u`);
    expect(wgsl256).not.toContain(`${GRID_Y_STRIDE}u`);
  });
});
