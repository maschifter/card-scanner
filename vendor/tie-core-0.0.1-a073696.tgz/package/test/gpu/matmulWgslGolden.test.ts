/** Guards the f32 matmul shader against accidental change while f16 variants
 *  are added around it. The snapshot is the WGSL as emitted before any
 *  dtype-parameterisation: if a refactor alters one character of the f32
 *  path, this fails before anything is benched.
 *
 *  Regenerate ONLY with a deliberate f32 change: `vitest -u`, and say why in
 *  the commit. */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { makeMatmulKernel } from '../../src/kernels/matmul/matmul.ts';
import { F16_ELEM, F32_ELEM } from '../../src/kernels/elem.ts';

const wgslOf = (cfg: Parameters<typeof makeMatmulKernel>[0], elem = F32_ELEM) =>
  tgpu.resolve({ externals: { main: makeMatmulKernel(cfg, elem) } });

describe('f32 matmul WGSL', () => {
  it('is unchanged for a plain [k=8,n=8] shape', () => {
    expect(
      wgslOf({ k: 8, n: 8, hasBias: 0, hasAdd: 0, accum: 0, hasBaseRow: 0 }),
    ).toMatchSnapshot();
  });

  it('is unchanged with the bias + addend epilogue', () => {
    expect(
      wgslOf({ k: 8, n: 8, hasBias: 1, hasAdd: 1, accum: 0, hasBaseRow: 0 }),
    ).toMatchSnapshot();
  });

  it('is unchanged for a width that needs the n % 4 tail', () => {
    expect(
      wgslOf({ k: 8, n: 6, hasBias: 0, hasAdd: 0, accum: 0, hasBaseRow: 0 }),
    ).toMatchSnapshot();
  });

  it('carries no f16 type anywhere', () => {
    const wgsl = wgslOf({ k: 8, n: 8, hasBias: 1, hasAdd: 1, accum: 0, hasBaseRow: 0 });
    expect(wgsl).not.toMatch(/f16|vec4h/);
  });
});

describe('f16 matmul WGSL', () => {
  it('binds f16 storage and keeps f32 accumulators by default', () => {
    const wgsl = wgslOf({ k: 8, n: 8, hasBias: 1, hasAdd: 1, accum: 0, hasBaseRow: 0 }, F16_ELEM);
    expect(wgsl).toMatch(/array<f16>/);
    expect(wgsl).toMatch(/var acc0 = vec4f\(\)/);
    expect(wgsl).not.toMatch(/var h0 = vec4h/);
  });

  it('accum=f16 runs the whole K loop in vec4h', () => {
    const wgsl = wgslOf({ k: 8, n: 8, hasBias: 0, hasAdd: 0, accum: 1, hasBaseRow: 0 }, F16_ELEM);
    expect(wgsl).toMatch(/var h0 = vec4h\(\)/);
    // only the promotion at the end, no per-step widening
    expect(wgsl).not.toMatch(/f32\(a\[/);
  });
});
