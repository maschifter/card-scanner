import { describe, expect, it } from 'vitest';
import { getRoot, maxAbsDiff, runHandles } from './harness.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';
import {
  ATTN_DECODE_CHUNK,
  ATTN_DECODE_MAX_CHUNKS,
  ATTN_SPLIT_SCRATCH_ELEMS,
  attnDecodeHandle,
  attnDecodeSplitHandles,
  createAttnDecodeMergePipeline,
  createAttnDecodePipeline,
  createAttnDecodeSplitPipeline,
} from '../../src/kernels/attention/attnDecode.ts';
import { createAttnPipeline, attnHandle } from '../../src/kernels/attention/attn.ts';

/** Kernel-level parity suite for the split-K decode attention variant
 *  (attnDecode.ts) vs an exact f64 reference and vs the batch kernel. Key
 *  ranges deliberately exceed the workgroup size (64) so every thread strides
 *  multiple keys, plus the degenerate cases: fewer keys than threads, empty
 *  band, sinks, GQA, and qLen > 1 rows (the executor only routes qLen = 1 here,
 *  but the kernel is generic). */

/** Seeded RNG so failures reproduce (same generator as zoo's cpuRefs). */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

interface Geo {
  qHeads: number;
  kvHeads: number;
  headDim: number;
}

const BIG = 0x3fffffff; // finite stand-in for an unbounded window side

/** Exact f64 reference — same as the batch kernel suite's. */
function cpuAttn(
  q: Float32Array,
  k: Float32Array,
  v: Float32Array,
  qLen: number,
  kvLen: number,
  geo: Geo,
  wl: number,
  wr: number,
  off: number,
  sinks?: Float32Array,
): Float32Array {
  const { qHeads, kvHeads, headDim: hd } = geo;
  const group = qHeads / kvHeads;
  const out = new Float32Array(qLen * qHeads * hd);
  for (let i = 0; i < qLen; i++) {
    const qPos = off + i;
    for (let h = 0; h < qHeads; h++) {
      const kvh = Math.floor(h / group);
      const lo = Math.max(0, qPos - wl);
      const hi = Math.min(kvLen - 1, qPos + wr);
      const qOff = (i * qHeads + h) * hd;
      const scores: number[] = [];
      for (let j = lo; j <= hi; j++) {
        let sc = 0;
        for (let dd = 0; dd < hd; dd++) {
          sc += q[qOff + dd]! * k[(j * kvHeads + kvh) * hd + dd]!;
        }
        scores.push(sc);
      }
      if (scores.length === 0 && !sinks) continue; // empty band → 0s
      const sinkLogit = sinks ? sinks[h]! * Math.LN2 : -Infinity;
      const m = Math.max(sinkLogit, ...scores);
      let denom = sinks ? Math.exp(sinkLogit - m) : 0;
      for (const sc of scores) denom += Math.exp(sc - m);
      for (let dd = 0; dd < hd; dd++) {
        let acc = 0;
        for (let j = lo; j <= hi; j++) {
          acc += (Math.exp(scores[j - lo]! - m) / denom) * v[(j * kvHeads + kvh) * hd + dd]!;
        }
        out[qOff + dd] = acc;
      }
    }
  }
  return out;
}

async function runDecode(
  qData: Float32Array,
  kData: Float32Array,
  vData: Float32Array,
  qLen: number,
  kvLen: number,
  geo: Geo,
  windowLeft: number,
  windowRight: number,
  qPosOffset = 0,
  sinksData?: Float32Array,
): Promise<Float32Array> {
  const root = await getRoot();
  const q = uploadF32(root, qData);
  const k = uploadF32(root, kData);
  const v = uploadF32(root, vData);
  const out = uploadF32(root, new Float32Array(qLen * geo.qHeads * geo.headDim));
  const sinks = sinksData ? uploadF32(root, sinksData) : undefined;
  const pipeline = createAttnDecodePipeline(root, {
    ...geo,
    windowLeft,
    windowRight,
    hasSinks: sinksData ? 1 : 0,
  });
  const handle = attnDecodeHandle(
    root,
    pipeline,
    { qLen, kvLen, qPosOffset, qHeads: geo.qHeads },
    { q, k, v, out, sinks },
  );
  runHandles(root, [handle]);
  await root.device.queue.onSubmittedWorkDone();
  return Float32Array.from(await out.read());
}

describe('split-K decode attn kernel on GPU', () => {
  const geo: Geo = { qHeads: 8, kvHeads: 8, headDim: 36 }; // Moonshine tiny geometry
  const qw = geo.qHeads * geo.headDim;

  it('cross-attention row over kvLen = 131 keys matches the f64 reference', async () => {
    const kvLen = 131; // > 2 stride rounds of 64
    const q = randArr(qw, 1);
    const [k, v] = [randArr(kvLen * qw, 2), randArr(kvLen * qw, 3)];
    const out = await runDecode(q, k, v, 1, kvLen, geo, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('causal step at qPosOffset = kvLen − 1 over kvLen = 200 keys matches', async () => {
    const kvLen = 200;
    const q = randArr(qw, 4);
    const [k, v] = [randArr(kvLen * qw, 5), randArr(kvLen * qw, 6)];
    const out = await runDecode(q, k, v, 1, kvLen, geo, BIG, 0, kvLen - 1);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, geo, BIG, 0, kvLen - 1))).toBeLessThan(1e-5);
  });

  it('fewer keys than threads (kvLen = 3) still merges correctly', async () => {
    const kvLen = 3;
    const q = randArr(qw, 7);
    const [k, v] = [randArr(kvLen * qw, 8), randArr(kvLen * qw, 9)];
    const out = await runDecode(q, k, v, 1, kvLen, geo, BIG, 0, kvLen - 1);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, geo, BIG, 0, kvLen - 1))).toBeLessThan(1e-5);
  });

  it('GQA 8:2 with a bounded band matches the grouped reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 2, headDim: 16 };
    const kvLen = 100;
    const q = randArr(g.qHeads * g.headDim, 10);
    const [k, v] = [
      randArr(kvLen * g.kvHeads * g.headDim, 11),
      randArr(kvLen * g.kvHeads * g.headDim, 12),
    ];
    const out = await runDecode(q, k, v, 1, kvLen, g, 70, 0, kvLen - 1);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, g, 70, 0, kvLen - 1))).toBeLessThan(1e-5);
  });

  it('sinks seed on one thread matches the sink reference', async () => {
    const g: Geo = { qHeads: 4, kvHeads: 4, headDim: 64 }; // exercises 2 output tiles
    const kvLen = 70;
    const q = randArr(g.qHeads * g.headDim, 13);
    const [k, v] = [
      randArr(kvLen * g.qHeads * g.headDim, 14),
      randArr(kvLen * g.qHeads * g.headDim, 15),
    ];
    const sinks = randArr(g.qHeads, 16);
    const out = await runDecode(q, k, v, 1, kvLen, g, BIG, BIG, 0, sinks);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, g, BIG, BIG, 0, sinks))).toBeLessThan(1e-5);
  });

  it('empty band writes zeros (no NaN/Inf from the L = 0 guard)', async () => {
    const g: Geo = { qHeads: 4, kvHeads: 4, headDim: 8 };
    const w = g.qHeads * g.headDim;
    const out = await runDecode(
      randArr(w, 17),
      randArr(3 * w, 18),
      randArr(3 * w, 19),
      1,
      3,
      g,
      0,
      0,
      5,
    );
    expect(out.every((x) => x === 0)).toBe(true);
  });

  it('qLen = 2 rows across workgroups match the f64 reference', async () => {
    const qLen = 2;
    const kvLen = 90;
    const q = randArr(qLen * qw, 20);
    const [k, v] = [randArr(kvLen * qw, 21), randArr(kvLen * qw, 22)];
    const out = await runDecode(q, k, v, qLen, kvLen, geo, BIG, BIG, 0);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, qLen, kvLen, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('encoder-shaped bidirectional square (qLen = kvLen = 97) matches the f64 reference', async () => {
    const qLen = 97;
    const kvLen = 97;
    const q = randArr(qLen * qw, 26);
    const [k, v] = [randArr(kvLen * qw, 27), randArr(kvLen * qw, 28)];
    const out = await runDecode(q, k, v, qLen, kvLen, geo, BIG, BIG, 0);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, qLen, kvLen, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('agrees with the batch kernel to f32 reassociation tolerance', async () => {
    const kvLen = 150;
    const qData = randArr(qw, 23);
    const [kData, vData] = [randArr(kvLen * qw, 24), randArr(kvLen * qw, 25)];
    const split = await runDecode(qData, kData, vData, 1, kvLen, geo, BIG, 0, kvLen - 1);

    const root = await getRoot();
    const q = uploadF32(root, qData);
    const k = uploadF32(root, kData);
    const v = uploadF32(root, vData);
    const out = uploadF32(root, new Float32Array(qw));
    const pipeline = createAttnPipeline(root, {
      ...geo,
      windowLeft: BIG,
      windowRight: 0,
      hasSinks: 0,
      hasSegs: 0,
    });
    const handle = attnHandle(
      root,
      pipeline,
      { qLen: 1, kvLen, qPosOffset: kvLen - 1, qHeads: geo.qHeads },
      { q, k, v, out },
    );
    runHandles(root, [handle]);
    await root.device.queue.onSubmittedWorkDone();
    const batch = Float32Array.from(await out.read());

    expect(maxAbsDiff(split, batch)).toBeLessThan(1e-5);
  });
});

/** The key-chunked partial + merge pair (the executor's route past
 *  ATTN_DECODE_CHUNK visible keys) vs the same f64 reference — chunk-count
 *  boundaries, the MAX_CHUNKS cap, bounded bands, GQA, and the chunk-0 sink
 *  seed. Chunk counts mirror the executor's formula. */
describe('key-chunked decode attn pair on GPU (kvLen > chunk)', () => {
  const geo: Geo = { qHeads: 8, kvHeads: 8, headDim: 36 }; // Moonshine tiny geometry
  const qw = geo.qHeads * geo.headDim;

  async function runSplitPair(
    qData: Float32Array,
    kData: Float32Array,
    vData: Float32Array,
    kvLen: number,
    g: Geo,
    windowLeft: number,
    windowRight: number,
    qPosOffset = 0,
    sinksData?: Float32Array,
  ): Promise<Float32Array> {
    const root = await getRoot();
    const q = uploadF32(root, qData);
    const k = uploadF32(root, kData);
    const v = uploadF32(root, vData);
    const out = uploadF32(root, new Float32Array(g.qHeads * g.headDim));
    const partials = uploadF32(root, new Float32Array(ATTN_SPLIT_SCRATCH_ELEMS));
    const sinks = sinksData ? uploadF32(root, sinksData) : undefined;
    const cfg = { ...g, windowLeft, windowRight, hasSinks: sinksData ? 1 : 0 };
    const chunks = Math.min(ATTN_DECODE_MAX_CHUNKS, Math.ceil(kvLen / ATTN_DECODE_CHUNK));
    const handles = attnDecodeSplitHandles(
      root,
      createAttnDecodeSplitPipeline(root, cfg),
      createAttnDecodeMergePipeline(root, cfg),
      { kvLen, qPosOffset, qHeads: g.qHeads, chunks },
      { q, k, v, out, partials, sinks },
    );
    runHandles(root, [...handles]);
    await root.device.queue.onSubmittedWorkDone();
    return Float32Array.from(await out.read());
  }

  it('cross-attention over kvLen = 1250 keys (5 chunks) matches the f64 reference', async () => {
    const kvLen = 1250;
    const q = randArr(qw, 30);
    const [k, v] = [randArr(kvLen * qw, 31), randArr(kvLen * qw, 32)];
    const out = await runSplitPair(q, k, v, kvLen, geo, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('chunk boundary kvLen = 257 (2 chunks) matches', async () => {
    const kvLen = 257;
    const q = randArr(qw, 33);
    const [k, v] = [randArr(kvLen * qw, 34), randArr(kvLen * qw, 35)];
    const out = await runSplitPair(q, k, v, kvLen, geo, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('kvLen = 2100 hits the MAX_CHUNKS cap and still matches', async () => {
    const kvLen = 2100;
    const q = randArr(qw, 36);
    const [k, v] = [randArr(kvLen * qw, 37), randArr(kvLen * qw, 38)];
    const out = await runSplitPair(q, k, v, kvLen, geo, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('bounded band inside a long range leaves off-band chunks empty', async () => {
    const kvLen = 600;
    const q = randArr(qw, 39);
    const [k, v] = [randArr(kvLen * qw, 40), randArr(kvLen * qw, 41)];
    const out = await runSplitPair(q, k, v, kvLen, geo, 100, 0, kvLen - 1);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, geo, 100, 0, kvLen - 1))).toBeLessThan(1e-5);
  });

  it('GQA 8:2 over kvLen = 400 matches the grouped reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 2, headDim: 16 };
    const kvLen = 400;
    const q = randArr(g.qHeads * g.headDim, 42);
    const [k, v] = [
      randArr(kvLen * g.kvHeads * g.headDim, 43),
      randArr(kvLen * g.kvHeads * g.headDim, 44),
    ];
    const out = await runSplitPair(q, k, v, kvLen, g, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, g, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('sink seed in chunk 0 matches the sink reference over kvLen = 300', async () => {
    const g: Geo = { qHeads: 4, kvHeads: 4, headDim: 64 };
    const kvLen = 300;
    const q = randArr(g.qHeads * g.headDim, 45);
    const [k, v] = [
      randArr(kvLen * g.qHeads * g.headDim, 46),
      randArr(kvLen * g.qHeads * g.headDim, 47),
    ];
    const sinks = randArr(g.qHeads, 48);
    const out = await runSplitPair(q, k, v, kvLen, g, BIG, BIG, 0, sinks);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, 1, kvLen, g, BIG, BIG, 0, sinks))).toBeLessThan(1e-5);
  });

  it('agrees with the single-workgroup decode kernel to reassociation tolerance', async () => {
    const kvLen = 700;
    const q = randArr(qw, 49);
    const [k, v] = [randArr(kvLen * qw, 50), randArr(kvLen * qw, 51)];
    const pair = await runSplitPair(q, k, v, kvLen, geo, BIG, BIG);
    const single = await runDecode(q, k, v, 1, kvLen, geo, BIG, BIG);
    expect(maxAbsDiff(pair, single)).toBeLessThan(1e-5);
  });
});
