import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { gelu, gpuExecutor, materialized, matmul, matrix, toArray } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';
import type { GpuSubmitTiming } from '../../src/gpu/perf.ts';

/** Subgroup small-m matmul route: correctness against an f64 reference across
 *  the replay-bucket shapes (m = 16/32 on minilm K/N), epilogue combinations,
 *  and the routing edges (m = 1, m past the ceiling, n % 4 != 0). A plain
 *  root runs one identical case through the serial kernels. */

let subRootPromise: Promise<TgpuRoot> | undefined;
function getSubgroupRoot(): Promise<TgpuRoot> {
  subRootPromise ??= tgpu.init({
    device: { optionalFeatures: ['subgroups', 'timestamp-query'] },
  });
  return subRootPromise;
}
let plainRootPromise: Promise<TgpuRoot> | undefined;
function getPlainRoot(): Promise<TgpuRoot> {
  plainRootPromise ??= tgpu.init();
  return plainRootPromise;
}

/** Seeded RNG so failures reproduce. */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

/** f64 reference with the fused-epilogue order: act(a·b + bias) + addend. */
function cpuMatmul(
  a: Float32Array,
  b: Float32Array,
  m: number,
  k: number,
  n: number,
  o: { bias?: Float32Array; addend?: Float32Array; activation?: 'gelu' | 'tanh' },
): Float32Array {
  const out = new Float32Array(m * n);
  for (let r = 0; r < m; r++) {
    for (let c = 0; c < n; c++) {
      let acc = 0;
      for (let j = 0; j < k; j++) acc += a[r * k + j]! * b[j * n + c]!;
      if (o.bias) acc += o.bias[c]!;
      if (o.activation === 'tanh') acc = Math.tanh(acc);
      else if (o.activation === 'gelu') acc = 0.5 * acc * (1 + erf(acc / Math.SQRT2));
      if (o.addend) acc += o.addend[r * n + c]!;
      out[r * n + c] = acc;
    }
  }
  return out;
}

/** Abramowitz–Stegun 7.1.26 erf (~1e-7 absolute error). */
function erf(x: number): number {
  const s = Math.sign(x);
  const ax = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * ax);
  const y =
    1 -
    ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) *
      t *
      Math.exp(-ax * ax);
  return s * y;
}

const maxAbsDiff = (a: Float32Array, b: Float32Array) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

interface CaseOpts {
  m: number;
  k: number;
  n: number;
  withBias?: boolean;
  withAddend?: boolean;
  activation?: 'gelu' | 'tanh';
  seed: number;
  tolerance?: number;
}

/** Run one matmul case on a root; returns the output and the kernel names the
 *  executor dispatched (names only when the device can timestamp). */
async function runCase(
  root: TgpuRoot,
  o: CaseOpts,
): Promise<{ out: Float32Array; ops: Set<string> }> {
  const aData = randArr(o.m * o.k, o.seed);
  const bData = randArr(o.k * o.n, o.seed + 1);
  const biasData = o.withBias ? randArr(o.n, o.seed + 2) : undefined;
  const addendData = o.withAddend ? randArr(o.m * o.n, o.seed + 3) : undefined;
  const a = materialized(matrix(o.m, o.k), uploadF32(root, aData));
  const b = materialized(matrix(o.k, o.n), uploadF32(root, bData));
  const bias = biasData
    ? materialized({ elems: o.n, dtype: 'f32' as const, dims: [o.n] }, uploadF32(root, biasData))
    : undefined;
  const addend = addendData
    ? materialized(matrix(o.m, o.n), uploadF32(root, addendData))
    : undefined;

  const timings: Promise<GpuSubmitTiming>[] = [];
  const ex = gpuExecutor(root, {
    perf: { perOp: true, onSubmit: (_n, t) => t && timings.push(t) },
  });
  const out = await toArray(matmul(a, b, { bias, addend, activation: o.activation }), ex);
  const ops = new Set<string>();
  for (const t of await Promise.all(timings)) {
    for (const name of t.opNs?.keys() ?? []) ops.add(name);
  }
  const ref = cpuMatmul(aData, bData, o.m, o.k, o.n, {
    bias: biasData,
    addend: addendData,
    activation: o.activation,
  });
  expect(out.length).toBe(ref.length);
  expect(maxAbsDiff(out as Float32Array, ref)).toBeLessThan(o.tolerance ?? 1e-4);
  return { out: out as Float32Array, ops };
}

describe('subgroup small-m matmul vs f64 reference', () => {
  it('m=16 qkv shape [16,384]·[384,1152] with bias, routes to matmulSmallM', async () => {
    const root = await getSubgroupRoot();
    expect(root.device.features.has('subgroups')).toBe(true);
    const { ops } = await runCase(root, { m: 16, k: 384, n: 1152, withBias: true, seed: 101 });
    if (ops.size > 0) expect([...ops]).toContain('matmulSmallM');
  });

  it('m=16 up shape [16,384]·[384,1536] with bias + GELU epilogue', async () => {
    const root = await getSubgroupRoot();
    const { ops } = await runCase(root, {
      m: 16,
      k: 384,
      n: 1536,
      withBias: true,
      activation: 'gelu',
      seed: 202,
      // The erf reference approximates to ~1e-7; K=384 f32 dots add noise.
      tolerance: 2e-4,
    });
    if (ops.size > 0) expect([...ops]).toContain('matmulSmallM');
  });

  it('m=16 down shape [16,1536]·[1536,384] with bias + addend (residual fold)', async () => {
    const root = await getSubgroupRoot();
    await runCase(root, {
      m: 16,
      k: 1536,
      n: 384,
      withBias: true,
      withAddend: true,
      seed: 303,
    });
  });

  it('m=32 hits the route ceiling, m=33 falls to tiled', async () => {
    const root = await getSubgroupRoot();
    const at = await runCase(root, { m: 32, k: 384, n: 384, withBias: true, seed: 404 });
    if (at.ops.size > 0) expect([...at.ops]).toContain('matmulSmallM');
    const past = await runCase(root, { m: 33, k: 384, n: 384, withBias: true, seed: 405 });
    if (past.ops.size > 0) {
      expect([...past.ops]).not.toContain('matmulSmallM');
      expect([...past.ops]).toContain('matmulTiled');
    }
  });

  it('m=1 stays on the GEMV route', async () => {
    const root = await getSubgroupRoot();
    const { ops } = await runCase(root, { m: 1, k: 384, n: 384, seed: 505 });
    if (ops.size > 0) {
      expect([...ops]).not.toContain('matmulSmallM');
      expect([...ops]).toContain('matmulGemv');
    }
  });

  it('n % 4 != 0 stays off the route and stays correct', async () => {
    const root = await getSubgroupRoot();
    const { ops } = await runCase(root, { m: 16, k: 96, n: 33, seed: 606 });
    if (ops.size > 0) expect([...ops]).not.toContain('matmulSmallM');
  });

  it('k not divisible by 32 keeps lane tails exact', async () => {
    const root = await getSubgroupRoot();
    const { ops } = await runCase(root, { m: 8, k: 100, n: 64, withBias: true, seed: 707 });
    if (ops.size > 0) expect([...ops]).toContain('matmulSmallM');
  });

  it('m=4 lower edge of the route; m=2 stays off it', async () => {
    const root = await getSubgroupRoot();
    const at = await runCase(root, { m: 4, k: 64, n: 64, seed: 808 });
    if (at.ops.size > 0) expect([...at.ops]).toContain('matmulSmallM');
    const off = await runCase(root, { m: 2, k: 64, n: 64, seed: 809 });
    if (off.ops.size > 0) expect([...off.ops]).not.toContain('matmulSmallM');
  });

  it('matches the plain root on identical inputs', async () => {
    const subRoot = await getSubgroupRoot();
    const plainRoot = await getPlainRoot();
    const o: CaseOpts = { m: 16, k: 384, n: 384, withBias: true, seed: 909 };
    const a = await runCase(subRoot, o);
    const b = await runCase(plainRoot, o);
    // Different dot summation orders (lane tree vs serial walk) — a few ulp
    // of drift is expected, bit-equality is not.
    expect(maxAbsDiff(a.out, b.out)).toBeLessThan(5e-5);
  });

  it('fused GELU route matches the composed matmul → gelu chain', async () => {
    const root = await getSubgroupRoot();
    const m = 16;
    const k = 384;
    const n = 1536;
    const aData = randArr(m * k, 42);
    const bData = randArr(k * n, 43);
    const ex = gpuExecutor(root);
    const up = () => ({
      a: materialized(matrix(m, k), uploadF32(root, aData)),
      b: materialized(matrix(k, n), uploadF32(root, bData)),
    });
    const f = up();
    const fused = await toArray(matmul(f.a, f.b, { activation: 'gelu' }), ex);
    const c = up();
    const composed = await toArray(gelu(matmul(c.a, c.b)), ex);
    expect(maxAbsDiff(fused as Float32Array, composed as Float32Array)).toBeLessThan(1e-5);
  });
});
