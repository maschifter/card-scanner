import { describe, expect, it } from 'vitest';
import tgpu, { d, std } from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { sdpa, materialized, matrix, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';
import type { GpuSubmitTiming } from '../../src/gpu/perf.ts';

/** Root with subgroups (+ timestamps, to assert the route taken). The
 *  executor picks the subgroup-cooperative attention kernels off this root;
 *  a plain root exercises the serial split pair on identical inputs. */
let subRootPromise: Promise<TgpuRoot> | undefined;
function getSubgroupRoot(): Promise<TgpuRoot> {
  subRootPromise ??= tgpu.init({
    device: { optionalFeatures: ['subgroups', 'timestamp-query'] },
  });
  return subRootPromise;
}
let plainRootPromise: Promise<TgpuRoot> | undefined;
function getPlainRoot(): Promise<TgpuRoot> {
  plainRootPromise ??= tgpu.init();
  return plainRootPromise;
}

/** Seeded RNG so failures reproduce. */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

interface RefOpts {
  qLen: number;
  kvLen: number;
  qHeads: number;
  kvHeads: number;
  headDim: number;
  windowLeft: number;
  windowRight: number;
  qPosOffset: number;
  sinks?: Float32Array;
}

/** f64 reference: banded GQA softmax attention, sinks as log2-space extra
 *  denominator terms — the sdpa op's semantics. */
function cpuAttn(q: Float32Array, k: Float32Array, v: Float32Array, o: RefOpts): Float32Array {
  const { qLen, kvLen, qHeads, kvHeads, headDim: hd } = o;
  const group = qHeads / kvHeads;
  const out = new Float32Array(qLen * qHeads * hd);
  for (let row = 0; row < qLen; row++) {
    const qPos = o.qPosOffset + row;
    for (let h = 0; h < qHeads; h++) {
      const kvh = Math.floor(h / group);
      const lo = Math.max(0, qPos - o.windowLeft);
      const hi = Math.min(kvLen - 1, qPos + o.windowRight);
      const scores: number[] = [];
      for (let j = lo; j <= hi; j++) {
        let dot = 0;
        for (let c = 0; c < hd; c++) {
          dot += q[row * qHeads * hd + h * hd + c]! * k[j * kvHeads * hd + kvh * hd + c]!;
        }
        scores.push(dot);
      }
      let m = o.sinks ? o.sinks[h]! * Math.LN2 : -Infinity;
      for (const sc of scores) m = Math.max(m, sc);
      let l = o.sinks ? Math.exp(o.sinks[h]! * Math.LN2 - m) : 0;
      for (const sc of scores) l += Math.exp(sc - m);
      for (let c = 0; c < hd; c++) {
        let acc = 0;
        for (let j = lo; j <= hi; j++) {
          acc += Math.exp(scores[j - lo]! - m) * v[j * kvHeads * hd + kvh * hd + c]!;
        }
        out[row * qHeads * hd + h * hd + c] = l > 0 ? acc / l : 0;
      }
    }
  }
  return out;
}

const maxAbsDiff = (a: Float32Array, b: Float32Array) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

interface CaseOpts {
  qLen: number;
  kvLen: number;
  qHeads: number;
  kvHeads: number;
  headDim: number;
  windowLeft: number;
  windowRight: number;
  qPosOffset?: number;
  withSinks?: boolean;
  seed: number;
}

/** Run one attention case on a root; returns the output and the kernel names
 *  the executor dispatched (names only when the device can timestamp). */
async function runCase(
  root: TgpuRoot,
  o: CaseOpts,
): Promise<{ out: Float32Array; ops: Set<string> }> {
  const { qLen, kvLen, qHeads, kvHeads, headDim } = o;
  const qData = randArr(qLen * qHeads * headDim, o.seed);
  const kData = randArr(kvLen * kvHeads * headDim, o.seed + 1);
  const vData = randArr(kvLen * kvHeads * headDim, o.seed + 2);
  const sinksData = o.withSinks ? randArr(qHeads, o.seed + 3) : undefined;
  const q = materialized(matrix(qLen, qHeads * headDim), uploadF32(root, qData));
  const k = materialized(matrix(kvLen, kvHeads * headDim), uploadF32(root, kData));
  const v = materialized(matrix(kvLen, kvHeads * headDim), uploadF32(root, vData));
  const sinks = sinksData
    ? materialized({ elems: qHeads, dtype: 'f32', dims: [qHeads] }, uploadF32(root, sinksData))
    : undefined;

  const timings: Promise<GpuSubmitTiming>[] = [];
  const ex = gpuExecutor(root, {
    perf: { perOp: true, onSubmit: (_n, t) => t && timings.push(t) },
  });
  const out = await toArray(
    sdpa(q, k, v, {
      qHeads,
      kvHeads,
      headDim,
      windowLeft: o.windowLeft,
      windowRight: o.windowRight,
      qPosOffset: o.qPosOffset,
      sinks,
    }),
    ex,
  );
  const ops = new Set<string>();
  for (const t of await Promise.all(timings)) {
    for (const name of t.opNs?.keys() ?? []) ops.add(name);
  }
  const ref = cpuAttn(qData, kData, vData, {
    qLen,
    kvLen,
    qHeads,
    kvHeads,
    headDim,
    windowLeft: o.windowLeft,
    windowRight: o.windowRight,
    qPosOffset: o.qPosOffset ?? 0,
    sinks: sinksData,
  });
  expect(out.length).toBe(ref.length);
  expect(maxAbsDiff(out, ref)).toBeLessThan(1e-4);
  return { out: out as Float32Array, ops };
}

describe('subgroup ops through TGSL', () => {
  it('subgroupAdd reduces across a 32-lane workgroup', async () => {
    const root = await getSubgroupRoot();
    expect(root.device.features.has('subgroups')).toBe(true);

    const layout = tgpu.bindGroupLayout({
      out: { storage: d.arrayOf(d.f32), access: 'mutable' },
    });
    const kernel = tgpu.computeFn({
      in: { gid: d.builtin.globalInvocationId, lane: d.builtin.subgroupInvocationId },
      workgroupSize: [32],
    })(({ gid, lane }) => {
      'use gpu';
      const total = std.subgroupAdd(d.f32(lane));
      layout.$.out[gid.x] = total;
    });
    const pipeline = root.createComputePipeline({ compute: kernel });
    const out = root.createBuffer(d.arrayOf(d.f32, 32)).$usage('storage');
    pipeline.with(root.createBindGroup(layout, { out })).dispatchWorkgroups(1);
    const vals = await out.read();
    // 0 + 1 + … + 31
    expect(vals.every((v) => v === 496)).toBe(true);
  });
});

/** Every shape exceeds ATTN_ROWS_CHUNK keys so the rows-split route fires;
 *  on the subgroup root that is the subgroup-cooperative partial. Tolerance
 *  1e-4 against an f64 reference (float32 attention over 100+ keys). */
describe('subgroup rows-split attention vs f64 reference', () => {
  it('full attention, headDim 36 (tiny encoder geometry, lane tail)', async () => {
    const root = await getSubgroupRoot();
    const { ops } = await runCase(root, {
      qLen: 150,
      kvLen: 150,
      qHeads: 4,
      kvHeads: 4,
      headDim: 36,
      windowLeft: Infinity,
      windowRight: Infinity,
      seed: 101,
    });
    if (ops.size > 0) expect([...ops]).toContain('attnRowsSubSplit');
  });

  it('full attention, headDim 52 (base encoder geometry)', async () => {
    const root = await getSubgroupRoot();
    await runCase(root, {
      qLen: 130,
      kvLen: 130,
      qHeads: 4,
      kvHeads: 4,
      headDim: 52,
      windowLeft: Infinity,
      windowRight: Infinity,
      seed: 202,
    });
  });

  it('headDim 16 keeps single-column lanes exact (cpl = 1)', async () => {
    const root = await getSubgroupRoot();
    await runCase(root, {
      qLen: 120,
      kvLen: 120,
      qHeads: 3,
      kvHeads: 3,
      headDim: 16,
      windowLeft: Infinity,
      windowRight: Infinity,
      seed: 303,
    });
  });

  it('causal band + qPosOffset + GQA', async () => {
    const root = await getSubgroupRoot();
    await runCase(root, {
      qLen: 110,
      kvLen: 260,
      qHeads: 4,
      kvHeads: 2,
      headDim: 32,
      windowLeft: Infinity,
      windowRight: 0,
      qPosOffset: 150,
      seed: 404,
    });
  });

  it('sinks seed enters once (chunk 0)', async () => {
    const root = await getSubgroupRoot();
    await runCase(root, {
      qLen: 140,
      kvLen: 140,
      qHeads: 4,
      kvHeads: 4,
      headDim: 64,
      windowLeft: Infinity,
      windowRight: 0,
      withSinks: true,
      seed: 505,
    });
  });

  it('matches the serial split pair on identical inputs', async () => {
    const subRoot = await getSubgroupRoot();
    const plainRoot = await getPlainRoot();
    const o: CaseOpts = {
      qLen: 150,
      kvLen: 150,
      qHeads: 4,
      kvHeads: 4,
      headDim: 36,
      windowLeft: Infinity,
      windowRight: Infinity,
      seed: 606,
    };
    const a = await runCase(subRoot, o);
    const b = await runCase(plainRoot, o);
    // Different key-dot summation orders (lane tree vs serial walk) — a few
    // ulp of drift is expected, bit-equality is not.
    expect(maxAbsDiff(a.out, b.out)).toBeLessThan(5e-5);
  });
});
