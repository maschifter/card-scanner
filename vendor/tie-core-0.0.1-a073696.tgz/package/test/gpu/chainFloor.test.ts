/** Dependent-dispatch chain floor: N chained trivial adds on a small tensor,
 *  single pass, timestamped. If GPU-busy scales with N at near-zero work per
 *  node, the per-forward floor is chain latency, not kernel math. Reported,
 *  not asserted. */

import { beforeAll, describe, expect, it } from 'vitest';
import { add, gpuExecutor, initTie, tensor, toArray } from '@tie/core';
import type { GpuSubmitTiming } from '@tie/core';
import type { TgpuRoot } from 'typegpu';
import { getRoot } from './harness.ts';

describe('dependent-dispatch chain floor', () => {
  let root: TgpuRoot;
  beforeAll(async () => {
    root = await getRoot();
    initTie(root);
  });

  it('reports GPU-busy for 54 chained adds on [16,384]', async (ctx) => {
    if (!root.device.features.has('timestamp-query')) return ctx.skip();
    const REPS = 20;
    for (const n of [1, 8, 54]) {
      const timings: Promise<GpuSubmitTiming>[] = [];
      const ex = gpuExecutor(root, {
        perf: {
          onSubmit(_d, timing) {
            if (timing) timings.push(timing);
          },
        },
      });
      const x = tensor(root, new Float32Array(16 * 384).fill(1), [16, 384]);
      const run = () => {
        let v = x;
        for (let i = 0; i < n; i++) v = add(v, x);
        return toArray(v, ex);
      };
      const first = await run();
      expect(first[0]).toBe(n + 1);
      const skip = timings.length;
      const t0 = performance.now();
      for (let i = 0; i < REPS; i++) await run();
      const wall = (performance.now() - t0) / REPS;
      const settled = await Promise.all(timings.slice(skip));
      const gpuMs = settled.reduce((a, t) => a + t.gpuNs, 0) / settled.length / 1e6;
      console.log(
        `chain n=${n}: wall ${wall.toFixed(2)}ms  gpu-busy ${gpuMs.toFixed(3)}ms  (${((gpuMs / n) * 1000).toFixed(1)}µs/dispatch)`,
      );
    }
  }, 300_000);
});
