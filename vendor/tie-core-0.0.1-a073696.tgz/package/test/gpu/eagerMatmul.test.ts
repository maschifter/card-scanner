import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { linear, matmul, matrix, materialized, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

/** Row-major CPU reference matmul. */
function cpuMatmul(
  a: Float32Array,
  b: Float32Array,
  M: number,
  K: number,
  N: number,
): Float32Array {
  const out = new Float32Array(M * N);
  for (let i = 0; i < M; i++) {
    for (let j = 0; j < N; j++) {
      let acc = 0;
      for (let k = 0; k < K; k++) acc += a[i * K + k]! * b[k * N + j]!;
      out[i * N + j] = acc;
    }
  }
  return out;
}

describe('eager matmul on GPU', () => {
  it('matches a CPU reference for [4,5]x[5,3]', async () => {
    const root = await tgpu.init();
    const M = 4;
    const K = 5;
    const N = 3;
    const aData = new Float32Array(M * K).map((_, i) => (i % 7) - 3);
    const bData = new Float32Array(K * N).map((_, i) => ((i * 3) % 5) - 2);
    const a = materialized(matrix(M, K), uploadF32(root, aData));
    const b = materialized(matrix(K, N), uploadF32(root, bData));

    const out = await toArray(matmul(a, b), gpuExecutor(root));
    const ref = cpuMatmul(aData, bData, M, K, N);

    expect(out.length).toBe(M * N);
    for (let i = 0; i < M * N; i++) expect(out[i]).toBeCloseTo(ref[i]!, 4);
  });
});

/** m = 1 routes to the split-K GEMV kernel — cover its tiling edges (column
 *  tails, K < lane count) and both epilogue operands against the same CPU
 *  reference; a batch (m = 3) case with an identical epilogue guards the
 *  two pipelines agreeing. */
describe('eager matmul GEMV route on GPU (m = 1)', () => {
  const fill = (n: number, f: (i: number) => number) =>
    Float32Array.from({ length: n }, (_, i) => f(i));

  async function runCase(M: number, K: number, N: number, withBias: boolean, withAdd: boolean) {
    const root = await tgpu.init();
    const aData = fill(M * K, (i) => ((i * 7) % 11) / 5 - 1);
    const bData = fill(K * N, (i) => ((i * 13) % 17) / 8 - 1);
    const biasData = fill(N, (i) => ((i * 3) % 7) / 3 - 1);
    const addData = fill(M * N, (i) => ((i * 5) % 9) / 4 - 1);
    const a = materialized(matrix(M, K), uploadF32(root, aData));
    const b = materialized(matrix(K, N), uploadF32(root, bData));
    const bias = withBias
      ? materialized({ elems: N, dtype: 'f32', dims: [N] } as const, uploadF32(root, biasData))
      : undefined;
    const addend = withAdd ? materialized(matrix(M, N), uploadF32(root, addData)) : undefined;
    const out = await toArray(linear(a, b, bias, addend), gpuExecutor(root));
    const ref = cpuMatmul(aData, bData, M, K, N);
    for (let i = 0; i < M * N; i++) {
      let want = ref[i]!;
      if (withBias) want += biasData[i % N]!;
      if (withAdd) want += addData[i]!;
      expect(out[i]).toBeCloseTo(want, 4);
    }
  }

  it('matches on the qkv shape [1,288]x[288,864]', () => runCase(1, 288, 864, false, false));
  it('matches on the fc2 shape [1,1152]x[1152,288] with bias + addend', () =>
    runCase(1, 1152, 288, true, true));
  it('handles a column tail (N % 32 != 0) [1,40]x[40,33]', () => runCase(1, 40, 33, true, false));
  it('handles K below the lane count [1,5]x[5,64]', () => runCase(1, 5, 64, false, true));
  it('keeps the batch route intact on [3,64]x[64,96] with bias + addend', () =>
    runCase(3, 64, 96, true, true));
});
