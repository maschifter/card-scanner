import { describe, expect, it } from 'vitest';
import { ACTIVATIONS, activationFor } from '../../src/kernels/activations.ts';
import { ACT_CODE } from '../../src/graph/ops/shared.ts';

/** activationFor is the only door from an `act` code to a body. Before it,
 *  every pipeline builder wrote ACTIVATIONS[cfg.act ?? 0]! — an out-of-range
 *  code passed `undefined` into .with(actSlot, ...) and failed much later
 *  with an unrelated resolution error. */
describe('activation codes', () => {
  it('resolves every code in the table, and undefined as no-op', () => {
    for (let code = 0; code < ACTIVATIONS.length; code++) {
      expect(activationFor(code)).toBe(ACTIVATIONS[code]);
    }
    expect(activationFor(undefined)).toBe(ACTIVATIONS[0]);
  });

  it('throws a named error on a code outside the table', () => {
    const past = ACTIVATIONS.length;
    expect(() => activationFor(past)).toThrow(`unknown activation code ${past}`);
    expect(() => activationFor(-1)).toThrow('unknown activation code -1');
  });

  it('every op-level activation name maps to a real table entry', () => {
    for (const [name, code] of Object.entries(ACT_CODE)) {
      expect(ACTIVATIONS[code], `${name} -> ${code}`).toBeDefined();
    }
  });
});
