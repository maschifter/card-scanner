import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  add,
  matmul,
  matrix,
  mul,
  sub,
  swiglu,
  materialized,
  toArray,
  gpuExecutor,
} from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

describe('eager f32 elementwise on GPU', () => {
  it('adds two f32 matrices elementwise', async () => {
    const root = await tgpu.init();
    const M = 3;
    const N = 4;
    const aData = new Float32Array(M * N).map((_, i) => i);
    const bData = new Float32Array(M * N).map((_, i) => i * 2);
    const a = materialized(matrix(M, N), uploadF32(root, aData));
    const b = materialized(matrix(M, N), uploadF32(root, bData));
    const out = await toArray(add(a, b), gpuExecutor(root));
    for (let i = 0; i < M * N; i++) expect(out[i]).toBeCloseTo(aData[i]! + bData[i]!, 5);
  });

  it('chains matmul then f32 add (composability, no casts)', async () => {
    const root = await tgpu.init();
    const M = 2;
    const K = 3;
    const N = 2;
    const aData = new Float32Array([1, 2, 3, 4, 5, 6]); // [2,3]
    const bData = new Float32Array([1, 0, 0, 1, 1, 1]); // [3,2]
    const cData = new Float32Array([10, 20, 30, 40]); // [2,2]
    const a = materialized(matrix(M, K), uploadF32(root, aData));
    const b = materialized(matrix(K, N), uploadF32(root, bData));
    const c = materialized(matrix(M, N), uploadF32(root, cData));
    const out = await toArray(add(matmul(a, b), c), gpuExecutor(root));
    // A@B = [[4,5],[10,11]]; + C = [[14,25],[40,51]]
    expect(Array.from(out)).toEqual([14, 25, 40, 51]);
  });

  it('fused swiglu matches the clamp/sigmoid/mul/add composition', async () => {
    const root = await tgpu.init();
    // Include values past the ±7 clamp on both halves to exercise the clamps.
    const gluData = new Float32Array([-9, -1, 0, 0.5, 3, 8, 12, -7]);
    const linData = new Float32Array([2, -8, 9, -0.5, 1, -12, 4, 7]);
    const glu = materialized(matrix(2, 4), uploadF32(root, gluData));
    const lin = materialized(matrix(2, 4), uploadF32(root, linData));
    const out = await toArray(swiglu(glu, lin), gpuExecutor(root));
    const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
    const sig = (x: number) => 1 / (1 + Math.exp(-x));
    for (let i = 0; i < gluData.length; i++) {
      const g = clamp(gluData[i]!, -Infinity, 7);
      const l = clamp(linData[i]!, -7, 7);
      expect(out[i]).toBeCloseTo(g * sig(1.702 * g) * (l + 1), 5);
    }
  });

  it('subtracts elementwise and col-broadcasts [M,N] − [M,1] (centering shape)', async () => {
    const root = await tgpu.init();
    const xData = new Float32Array([1, 2, 3, 4, 5, 6]); // [2,3]
    const x = materialized(matrix(2, 3), uploadF32(root, xData));
    const yData = new Float32Array([0.5, 1, 1.5, 2, 2.5, 3]);
    const y = materialized(matrix(2, 3), uploadF32(root, yData));
    const ew = await toArray(sub(x, y), gpuExecutor(root));
    for (let i = 0; i < 6; i++) expect(ew[i]).toBeCloseTo(xData[i]! - yData[i]!, 6);

    const colData = new Float32Array([2, 5]); // per-row mean
    const col = materialized(matrix(2, 1), uploadF32(root, colData));
    const centered = await toArray(sub(x, col), gpuExecutor(root));
    expect(Array.from(centered)).toEqual([-1, 0, 1, -1, 0, 1]);
  });

  it('col-broadcasts square [4,4] * [4,1] (rows === cols, ambiguous by element count)', async () => {
    // Regression: with a square full operand, a [4,1] column has as many
    // elements as a [4] row — the mode must come from dims, or every row gets
    // scaled by the column pattern instead of each row by its own factor.
    const root = await tgpu.init();
    const xData = new Float32Array(16).map((_, i) => i + 1); // rows [1..4],[5..8],...
    const colData = new Float32Array([1, 10, 100, 1000]);
    const x = materialized(matrix(4, 4), uploadF32(root, xData));
    const col = materialized(matrix(4, 1), uploadF32(root, colData));
    const out = await toArray(mul(x, col), gpuExecutor(root));
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        expect(out[r * 4 + c]).toBeCloseTo(xData[r * 4 + c]! * colData[r]!, 5);
      }
    }
  });
});
