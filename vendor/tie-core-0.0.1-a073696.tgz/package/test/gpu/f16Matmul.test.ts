/** f16 matmul parity: the f16 variant against the f32 kernel on the same
 *  inputs. Tolerance is derived from the reduction length — f16 storage has
 *  ~9.8e-4 relative resolution, and with f32 accumulators the error is one
 *  rounding per operand, not a random walk over K. */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { gpuExecutor, matmul, materialized, matrix, toArray } from '../../src/index.ts';
import { uploadF16, uploadF32 } from '../../src/gpu/buffers.ts';
import { f32ArrayToF16Bits } from '../../src/weights/convert.ts';

let rootPromise: Promise<TgpuRoot> | undefined;
const getRoot = (): Promise<TgpuRoot> =>
  (rootPromise ??= tgpu.init({ device: { optionalFeatures: ['shader-f16'] } }));

const f16Meta = (rows: number, cols: number) =>
  ({ elems: rows * cols, dtype: 'f16', dims: [rows, cols] }) as const;

/** Same numbers on both paths: the f32 arm reads the f16-ROUNDED values, so
 *  the comparison isolates the kernel, not the rounding of the inputs. */
function operands(root: TgpuRoot, rows: number, cols: number, seed: number) {
  const raw = new Float32Array(rows * cols).map((_, i) => Math.sin(i * 0.37 + seed) * 0.5);
  const bits = f32ArrayToF16Bits(raw).data;
  const rounded = new Float32Array(bits.length);
  const view = new DataView(new ArrayBuffer(4));
  for (let i = 0; i < bits.length; i++) {
    // widen through the same path the GPU does
    const h = bits[i]!;
    const sign = h >> 15;
    const exp = (h >> 10) & 0x1f;
    const frac = h & 0x3ff;
    let v: number;
    if (exp === 0) v = frac * 2 ** -24;
    else v = (1 + frac / 1024) * 2 ** (exp - 15);
    rounded[i] = sign ? -v : v;
    void view;
  }
  return {
    f16: materialized(f16Meta(rows, cols), uploadF16(root, bits)),
    f32: materialized(matrix(rows, cols), uploadF32(root, rounded)),
  };
}

async function compare(root: TgpuRoot, m: number, k: number, n: number, withBias: boolean) {
  const a = operands(root, m, k, 1);
  const b = operands(root, k, n, 2);
  const bias = withBias ? operands(root, 1, n, 3) : undefined;
  const got = await toArray(
    matmul(a.f16, b.f16, bias ? { bias: bias.f16 } : {}),
    gpuExecutor(root),
  );
  const want = await toArray(
    matmul(a.f32, b.f32, bias ? { bias: bias.f32 } : {}),
    gpuExecutor(root),
  );
  return { got, want };
}

describe('f16 matmul', () => {
  it('matches the f32 kernel on a small shape', async () => {
    const root = await getRoot();
    const { got, want } = await compare(root, 4, 8, 8, false);
    for (let i = 0; i < want.length; i++) expect(got[i]).toBeCloseTo(want[i]!, 2);
  });

  it('matches with a fused bias epilogue', async () => {
    const root = await getRoot();
    const { got, want } = await compare(root, 4, 8, 8, true);
    for (let i = 0; i < want.length; i++) expect(got[i]).toBeCloseTo(want[i]!, 2);
  });

  it('matches at a MiniLM-shaped m', async () => {
    const root = await getRoot();
    const { got, want } = await compare(root, 32, 64, 64, true);
    let maxErr = 0;
    for (let i = 0; i < want.length; i++) maxErr = Math.max(maxErr, Math.abs(got[i]! - want[i]!));
    // one f16 rounding of the output, on top of already-f16 inputs
    expect(maxErr).toBeLessThan(0.01);
  });

  it('handles a width that needs the n % 4 tail', async () => {
    const root = await getRoot();
    const { got, want } = await compare(root, 4, 8, 6, false);
    for (let i = 0; i < want.length; i++) expect(got[i]).toBeCloseTo(want[i]!, 2);
  });

  it('rejects mixing f16 and f32 operands', async () => {
    const root = await getRoot();
    const a = operands(root, 4, 8, 1);
    const b = operands(root, 8, 8, 2);
    expect(() => matmul(a.f16, b.f32)).toThrow(/both f16|both inputs/);
  });
});

describe('f16 matmul with f16 accumulators', () => {
  it('is opt-in: the default keeps f32 accumulators', async () => {
    const { getMatmulAccum, ACC_F32 } = await import('../../src/kernels/matmul/matmul.ts');
    expect(getMatmulAccum()).toBe(ACC_F32);
  });

  it('stays within f16 accumulation drift of the f32 kernel', async () => {
    const root = await getRoot();
    const { setMatmulAccum, ACC_F16, ACC_F32 } = await import('../../src/kernels/matmul/matmul.ts');
    setMatmulAccum(ACC_F16);
    try {
      const { got, want } = await compare(root, 32, 384, 64, false);
      let maxErr = 0;
      for (let i = 0; i < want.length; i++) maxErr = Math.max(maxErr, Math.abs(got[i]! - want[i]!));
      // ~sqrt(K)·2^-11 at K=384, an order looser than the f32-accumulator arm
      expect(maxErr).toBeLessThan(0.05);
    } finally {
      setMatmulAccum(ACC_F32);
    }
  });
});
