import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  gpuExecutor,
  materialized,
  matrix,
  toArray,
  uploadF32,
  writeRows,
} from '../../src/index.ts';

/** In-place row writes on a real device: the KV-cache append pattern — a
 *  preallocated buffer grown one row per eval, earlier rows never copied. */

describe('writeRows on GPU', () => {
  it('appends rows one eval at a time into the same buffer', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const cols = 3;
    const cache = materialized(matrix(4, cols), uploadF32(root, new Float32Array(4 * cols)));

    const row0 = materialized(matrix(1, cols), uploadF32(root, Float32Array.of(1, 2, 3)));
    const view0 = await toArray(writeRows(cache, row0, 0), ex);
    expect(Array.from(view0)).toEqual([1, 2, 3]);

    const row1 = materialized(matrix(1, cols), uploadF32(root, Float32Array.of(4, 5, 6)));
    const view1 = await toArray(writeRows(cache, row1, 1), ex);
    // Row 0 was written by the PREVIOUS eval and never copied since.
    expect(Array.from(view1)).toEqual([1, 2, 3, 4, 5, 6]);
  });

  it('writes a multi-row block at an offset', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const cols = 2;
    const cache = materialized(matrix(5, cols), uploadF32(root, new Float32Array(5 * cols)));
    const block = materialized(matrix(2, cols), uploadF32(root, Float32Array.of(7, 8, 9, 10)));
    const view = await toArray(writeRows(cache, block, 2), ex);
    expect(Array.from(view)).toEqual([0, 0, 0, 0, 7, 8, 9, 10]);
  });
});
