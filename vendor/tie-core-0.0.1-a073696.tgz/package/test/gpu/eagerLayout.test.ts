import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { matrix, materialized } from '../../src/graph/value.ts';
import { cat, slice, transpose } from '../../src/graph/ops.ts';
import { gpuExecutor, toArray } from '../../src/gpu/eval.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

const seq = (n: number) => Float32Array.from({ length: n }, (_, i) => i + 1);

describe('eager layout ops on GPU', () => {
  it('transpose matches CPU for [3,5]', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const data = seq(15);
    const x = materialized(matrix(3, 5), uploadF32(root, data));
    const out = await toArray(transpose(x), ex);
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 5; c++) expect(out[c * 3 + r]).toBe(data[r * 5 + c]!);
    }
  });

  it('sliceCols extracts x[:, 2:6) of [4,8]', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const data = seq(32);
    const x = materialized(matrix(4, 8), uploadF32(root, data));
    const out = await toArray(slice(x, 1, 2, 6), ex);
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) expect(out[r * 4 + c]).toBe(data[r * 8 + 2 + c]!);
    }
  });

  it('concatCols joins [2,3] ++ [2,2]', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const a = materialized(matrix(2, 3), uploadF32(root, seq(6)));
    const b = materialized(matrix(2, 2), uploadF32(root, Float32Array.from([10, 20, 30, 40])));
    const out = await toArray(cat([a, b], 1), ex);
    expect(Array.from(out)).toEqual([1, 2, 3, 10, 20, 4, 5, 6, 30, 40]);
  });

  it('composes: slice(transpose(x)) in one eval', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const data = seq(12);
    const x = materialized(matrix(3, 4), uploadF32(root, data)); // T -> [4,3]
    const out = await toArray(slice(transpose(x), 1, 1, 3), ex); // cols 1..2 of [4,3]
    const expected = [
      data[4]!,
      data[8]!,
      data[5]!,
      data[9]!,
      data[6]!,
      data[10]!,
      data[7]!,
      data[11]!,
    ];
    expect(Array.from(out)).toEqual(expected);
  });
});
