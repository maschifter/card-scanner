import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { add, materialized, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

describe('eager overhead benchmark', () => {
  it('warm eval of a chain is not slower than cold (pipeline cache works)', async () => {
    const root = await tgpu.init();
    const N = 16384;
    const data = () => uploadF32(root, new Float32Array(N).fill(1));
    const CHAIN = 32;

    // ONE executor → the pipeline cache + buffer pool persist across runs, so the
    // first run is cold (builds the 'add' pipeline) and the rest are warm.
    const ex = gpuExecutor(root);
    const run = async () => {
      const a = materialized({ elems: N, dtype: 'f32' }, data());
      const c = materialized({ elems: N, dtype: 'f32' }, data());
      let x = add(a, c);
      for (let i = 0; i < CHAIN - 1; i++) x = add(x, c);
      await toArray(x, ex);
    };

    const t0 = performance.now();
    await run(); // cold: builds the 'add' pipeline
    const cold = performance.now() - t0;

    // Min over trials, not the average: the claim under test is "warm never
    // pays pipeline compilation again", and ONE clean warm run proves it. An
    // average is a load-spike lottery — this assertion flaked twice on a busy
    // machine while the property it checks was trivially true.
    const TRIALS = 10;
    let warm = Infinity;
    for (let i = 0; i < TRIALS; i++) {
      const t1 = performance.now();
      await run();
      warm = Math.min(warm, performance.now() - t1);
    }

    console.log(
      `[eager bench] chain=${CHAIN} N=${N}: cold=${cold.toFixed(2)}ms warm=${warm.toFixed(2)}ms`,
    );
    expect(warm).toBeLessThanOrEqual(cold + 1); // warm shouldn't pay pipeline build again
  });
});
