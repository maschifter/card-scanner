import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { rmsNorm, linear, matrix, materialized, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

describe('composed layers on GPU (primitives only)', () => {
  it('rmsNorm matches CPU reference', async () => {
    const root = await tgpu.init();
    const M = 2;
    const N = 4;
    const eps = 1e-6;
    const xData = new Float32Array([1, 2, 3, 4, -1, -2, -3, -4]);
    const wData = new Float32Array([1, 1, 1, 1]);
    const x = materialized(matrix(M, N), uploadF32(root, xData));
    const w = materialized({ elems: N, dtype: 'f32', dims: [N] }, uploadF32(root, wData));
    const out = await toArray(rmsNorm(x, w, eps), gpuExecutor(root));

    const ref = new Float32Array(M * N);
    for (let i = 0; i < M; i++) {
      let ms = 0;
      for (let j = 0; j < N; j++) ms += xData[i * N + j]! ** 2;
      ms /= N;
      const inv = 1 / Math.sqrt(ms + eps);
      for (let j = 0; j < N; j++) ref[i * N + j] = xData[i * N + j]! * inv * wData[j]!;
    }
    for (let i = 0; i < M * N; i++) expect(out[i]).toBeCloseTo(ref[i]!, 4);
  });

  it('linear matches CPU reference', async () => {
    const root = await tgpu.init();
    const M = 2;
    const K = 3;
    const N = 2;
    const xData = new Float32Array([1, 2, 3, 4, 5, 6]);
    const wData = new Float32Array([1, 0, 0, 1, 1, 1]); // [3,2]
    const bData = new Float32Array([100, 200]);
    const x = materialized(matrix(M, K), uploadF32(root, xData));
    const w = materialized(matrix(K, N), uploadF32(root, wData));
    const b = materialized({ elems: N, dtype: 'f32', dims: [N] }, uploadF32(root, bData));
    const out = await toArray(linear(x, w, b), gpuExecutor(root));
    // x@w = [[4,5],[10,11]]; + b = [[104,205],[110,211]]
    expect(Array.from(out)).toEqual([104, 205, 110, 211]);
  });
});
