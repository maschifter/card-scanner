/** sdpaPacked (fused q|k|v column blocks read in place) vs sdpa on the
 *  sliced blocks — bit-comparable paths through every qLen > 1 route: plain
 *  rows, key-split (kvLen > 96), GQA, segments, and the maxSegment no-split
 *  route. The packed kernel indexes the same numbers at different addresses,
 *  so the gate is a small f32 tolerance, not equality. */

import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  gpuExecutor,
  materialized,
  matrix,
  sdpa,
  sdpaPacked,
  slice,
  toArray,
  uploadF32,
} from '../../src/index.ts';

interface Geo {
  qHeads: number;
  kvHeads: number;
  headDim: number;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

function maxAbsDiff(a: Float32Array, b: Float32Array): number {
  let worst = 0;
  for (let i = 0; i < a.length; i++) worst = Math.max(worst, Math.abs(a[i]! - b[i]!));
  return worst;
}

/** Rows of sentence b carry [start_b, end_b) — same builder as the zoo. */
function segRows(lengths: number[]): Float32Array {
  const total = lengths.reduce((s, l) => s + l, 0);
  const segs = new Float32Array(total * 2);
  let start = 0;
  for (const len of lengths) {
    for (let i = 0; i < len; i++) {
      segs[2 * (start + i)] = start;
      segs[2 * (start + i) + 1] = start + len;
    }
    start += len;
  }
  return segs;
}

async function comparePackedVsSliced(
  t: number,
  geo: Geo,
  windows: { windowLeft: number; windowRight: number },
  opts: { lengths?: number[]; maxSegment?: number } = {},
): Promise<void> {
  const root = await tgpu.init();
  const ex = gpuExecutor(root);
  const qw = geo.qHeads * geo.headDim;
  const kvw = geo.kvHeads * geo.headDim;
  const width = qw + 2 * kvw;
  const data = randArr(t * width, 97);
  const segsData = opts.lengths ? segRows(opts.lengths) : undefined;

  const up = () => ({
    qkv: materialized(matrix(t, width), uploadF32(root, data)),
    segments: segsData ? materialized(matrix(t, 2), uploadF32(root, segsData)) : undefined,
  });

  const p = up();
  const packed = await toArray(
    sdpaPacked(p.qkv, { ...geo, ...windows, segments: p.segments, maxSegment: opts.maxSegment }),
    ex,
  );

  const s = up();
  const q = slice(s.qkv, 1, 0, qw);
  const k = slice(s.qkv, 1, qw, qw + kvw);
  const v = slice(s.qkv, 1, qw + kvw, width);
  const reference = await toArray(
    sdpa(q, k, v, { ...geo, ...windows, segments: s.segments, maxSegment: opts.maxSegment }),
    ex,
  );

  expect(maxAbsDiff(packed, reference)).toBeLessThan(1e-6);
}

const FULL = { windowLeft: Infinity, windowRight: Infinity };

describe('sdpaPacked vs sdpa on sliced blocks', () => {
  it('rows route (T ≤ 96), MHA full attention', async () => {
    await comparePackedVsSliced(24, { qHeads: 4, kvHeads: 4, headDim: 16 }, FULL);
  });

  it('rows route, causal band', async () => {
    await comparePackedVsSliced(
      24,
      { qHeads: 4, kvHeads: 4, headDim: 16 },
      { windowLeft: Infinity, windowRight: 0 },
    );
  });

  it('key-split route (T > 96), GQA 4:2', async () => {
    await comparePackedVsSliced(144, { qHeads: 4, kvHeads: 2, headDim: 16 }, FULL);
  });

  it('segments clip identically on the packed layout', async () => {
    await comparePackedVsSliced(30, { qHeads: 4, kvHeads: 4, headDim: 16 }, FULL, {
      lengths: [9, 13, 8],
    });
  });

  it('segments + maxSegment keep the packed pack off the split route', async () => {
    await comparePackedVsSliced(144, { qHeads: 4, kvHeads: 2, headDim: 16 }, FULL, {
      lengths: [48, 61, 35],
      maxSegment: 61,
    });
  });

  it('rejects a wrong qkv width and the one-row shape', () => {
    const geo = { qHeads: 2, kvHeads: 2, headDim: 4, ...FULL };
    const bad = materialized(matrix(3, 20), null as never);
    expect(() => sdpaPacked(bad, geo)).toThrow(/qkv cols/);
    const oneRow = materialized(matrix(1, 24), null as never);
    expect(() => sdpaPacked(oneRow, geo)).toThrow(/qLen must be > 1/);
  });
});
