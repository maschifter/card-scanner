import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  gpuExecutor,
  layerNorm,
  materialized,
  matrix,
  toArray,
  uploadF32,
} from '../../src/index.ts';

/** Seeded RNG so failures reproduce (same generator as zoo's cpuRefs). */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

/** f64 reference: torch F.layer_norm semantics — biased 1/N variance. */
function cpuLayerNorm(
  x: Float32Array,
  w: Float32Array,
  rows: number,
  cols: number,
  eps: number,
  b?: Float32Array,
): Float32Array {
  const out = new Float32Array(rows * cols);
  for (let r = 0; r < rows; r++) {
    let m = 0;
    for (let c = 0; c < cols; c++) m += x[r * cols + c]!;
    m /= cols;
    let v = 0;
    for (let c = 0; c < cols; c++) v += (x[r * cols + c]! - m) ** 2;
    v /= cols;
    const inv = 1 / Math.sqrt(v + eps);
    for (let c = 0; c < cols; c++) {
      out[r * cols + c] = (x[r * cols + c]! - m) * inv * w[c]! + (b ? b[c]! : 0);
    }
  }
  return out;
}

const maxAbsDiff = (a: Float32Array, b: Float32Array) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

async function runLayerNorm(
  xData: Float32Array,
  wData: Float32Array,
  rows: number,
  cols: number,
  eps = 1e-5,
  bData?: Float32Array,
): Promise<Float32Array> {
  const root = await tgpu.init();
  const x = materialized(matrix(rows, cols), uploadF32(root, xData));
  const w = materialized({ elems: cols, dtype: 'f32', dims: [cols] }, uploadF32(root, wData));
  const b = bData
    ? materialized({ elems: cols, dtype: 'f32', dims: [cols] }, uploadF32(root, bData))
    : undefined;
  return toArray(layerNorm(x, w, eps, b), gpuExecutor(root));
}

describe('eager layerNorm on GPU (fused kernel)', () => {
  it('matches the f64 reference on a [7, 36] block', async () => {
    const [rows, cols] = [7, 36];
    const x = randArr(rows * cols, 1);
    const w = randArr(cols, 2);
    const out = await runLayerNorm(x, w, rows, cols);
    expect(maxAbsDiff(out, cpuLayerNorm(x, w, rows, cols, 1e-5))).toBeLessThan(1e-5);
  });

  it('matches on a single Moonshine-width row [1, 288]', async () => {
    const [rows, cols] = [1, 288];
    const x = randArr(rows * cols, 3);
    const w = randArr(cols, 4);
    const out = await runLayerNorm(x, w, rows, cols);
    expect(maxAbsDiff(out, cpuLayerNorm(x, w, rows, cols, 1e-5))).toBeLessThan(1e-5);
  });

  it('matches past one workgroup of rows [100, 32] (encoder-length shapes)', async () => {
    const [rows, cols] = [100, 32];
    const x = randArr(rows * cols, 5);
    const w = randArr(cols, 6);
    const out = await runLayerNorm(x, w, rows, cols);
    expect(maxAbsDiff(out, cpuLayerNorm(x, w, rows, cols, 1e-5))).toBeLessThan(1e-5);
  });

  it('threads a custom eps into the kernel', async () => {
    const [rows, cols] = [3, 16];
    const x = randArr(rows * cols, 7);
    const w = randArr(cols, 8);
    const out = await runLayerNorm(x, w, rows, cols, 1e-2);
    expect(maxAbsDiff(out, cpuLayerNorm(x, w, rows, cols, 1e-2))).toBeLessThan(1e-5);
    // Distinguishes from the default-eps result — the uniform is actually read.
    expect(maxAbsDiff(out, cpuLayerNorm(x, w, rows, cols, 1e-5))).toBeGreaterThan(1e-4);
  });

  it('adds the bias in the same dispatch (BERT-width [9, 384])', async () => {
    const [rows, cols] = [9, 384];
    const x = randArr(rows * cols, 9);
    const w = randArr(cols, 10);
    const b = randArr(cols, 11);
    const out = await runLayerNorm(x, w, rows, cols, 1e-12, b);
    expect(maxAbsDiff(out, cpuLayerNorm(x, w, rows, cols, 1e-12, b))).toBeLessThan(1e-5);
    // Distinguishes from the bias-free result — the bias binding is actually read.
    expect(maxAbsDiff(out, cpuLayerNorm(x, w, rows, cols, 1e-12))).toBeGreaterThan(1e-3);
  });
});
