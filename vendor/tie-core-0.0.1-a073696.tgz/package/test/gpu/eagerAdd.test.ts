import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { add, evalValues, gpuExecutor, materialized } from '../../src/index.ts';
import type { F32Buffer } from '../../src/kernels/common.ts';
import { readbackF32, uploadF32 } from '../../src/gpu/buffers.ts';

describe('eager add on GPU', () => {
  it('computes out = a + b elementwise and reads it back', async () => {
    const root = await tgpu.init();
    const N = 32;
    const aData = new Float32Array(N).map((_, i) => i);
    const bData = new Float32Array(N).map((_, i) => i * 10);
    const a = materialized({ elems: N, dtype: 'f32' }, uploadF32(root, aData));
    const b = materialized({ elems: N, dtype: 'f32' }, uploadF32(root, bData));

    const c = add(a, b);
    evalValues([c], gpuExecutor(root));

    const got = await readbackF32(root, root.unwrap(c.buffer as F32Buffer), N);
    for (let i = 0; i < N; i++) {
      expect(got[i]).toBeCloseTo(aData[i]! + bData[i]!, 5);
    }
  });
});
