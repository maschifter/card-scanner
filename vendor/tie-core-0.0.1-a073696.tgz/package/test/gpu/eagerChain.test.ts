import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { add, mul, materialized, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

describe('eager chain on GPU', () => {
  it('computes (a + b) * c elementwise and reads it back', async () => {
    const root = await tgpu.init();
    const N = 32;
    const aData = new Float32Array(N).map((_, i) => i);
    const bData = new Float32Array(N).map((_, i) => i + 1);
    const cData = new Float32Array(N).map(() => 2);
    const a = materialized({ elems: N, dtype: 'f32' }, uploadF32(root, aData));
    const b = materialized({ elems: N, dtype: 'f32' }, uploadF32(root, bData));
    const c = materialized({ elems: N, dtype: 'f32' }, uploadF32(root, cData));

    const out = await toArray(mul(add(a, b), c), gpuExecutor(root));

    for (let i = 0; i < N; i++) {
      expect(out[i]).toBeCloseTo((aData[i]! + bData[i]!) * cData[i]!, 5);
    }
  });
});
