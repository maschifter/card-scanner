import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  cat,
  gpuExecutor,
  materialized,
  slice,
  tensor3d,
  toArray,
  uploadF32,
} from '../../src/index.ts';

describe('channel ops GPU', () => {
  it('cat dim 0 [2,2,3] ++ [1,2,3] stacks a then b', async () => {
    const root = await tgpu.init();
    const aData = new Float32Array(12).map((_, i) => i);
    const bData = new Float32Array(6).map((_, i) => 100 + i);
    const a = materialized(tensor3d(2, 2, 3), uploadF32(root, aData));
    const b = materialized(tensor3d(1, 2, 3), uploadF32(root, bData));
    const out = await toArray(cat([a, b], 0), gpuExecutor(root));
    expect(Array.from(out)).toEqual([...Array.from(aData), ...Array.from(bData)]);
  });

  it('sliceChannels [4,2,2] → channels [1:3)', async () => {
    const root = await tgpu.init();
    const data = new Float32Array(16).map((_, i) => i);
    const x = materialized(tensor3d(4, 2, 2), uploadF32(root, data));
    const out = await toArray(slice(x, 0, 1, 3), gpuExecutor(root));
    // channels 1 and 2 → flat elements [4..12)
    expect(Array.from(out)).toEqual([4, 5, 6, 7, 8, 9, 10, 11]);
  });
});
