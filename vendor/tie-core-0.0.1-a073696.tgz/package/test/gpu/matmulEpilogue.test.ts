import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  add,
  gelu,
  gpuExecutor,
  materialized,
  matmul,
  matrix,
  tanh,
  toArray,
  uploadF32,
  f32ArrayToF16Bits,
} from '../../src/index.ts';
import { uploadF16 } from '../../src/gpu/buffers.ts';

/** Epilogue gate: matmul with fused bias/addend vs the composed matmul → add
 *  chain. The source-level operation order is identical, but the two live in
 *  different pipelines and the backend compiler may FMA-contract the dot loop
 *  differently per variant — so the gate is a ~1-ulp tolerance, not equality.
 *  A second suite checks the register-blocked kernel against an f64 reference
 *  across block-boundary shapes (the epilogue gate alone runs the same kernel
 *  on both sides, so it cannot catch an indexing or bounds bug). */

/** Seeded RNG so failures reproduce (same generator as zoo's cpuRefs). */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

async function compareFusedVsComposed(
  m: number,
  k: number,
  n: number,
  which: 'bias' | 'addend' | 'both',
): Promise<void> {
  const root = await tgpu.init();
  const ex = gpuExecutor(root);
  const aData = randArr(m * k, 1);
  const bData = randArr(k * n, 2);
  const biasData = randArr(n, 3);
  const addendData = randArr(m * n, 4);
  const up = () => ({
    a: materialized(matrix(m, k), uploadF32(root, aData)),
    b: materialized(matrix(k, n), uploadF32(root, bData)),
    bias: materialized({ elems: n, dtype: 'f32' as const, dims: [n] }, uploadF32(root, biasData)),
    addend: materialized(matrix(m, n), uploadF32(root, addendData)),
  });

  const f = up();
  const fused = await toArray(
    matmul(f.a, f.b, {
      bias: which !== 'addend' ? f.bias : undefined,
      addend: which !== 'bias' ? f.addend : undefined,
    }),
    ex,
  );

  const c = up();
  let composed = matmul(c.a, c.b);
  if (which !== 'addend') composed = add(composed, c.bias);
  if (which !== 'bias') composed = add(composed, c.addend);
  const reference = await toArray(composed, ex);

  let maxDiff = 0;
  for (let i = 0; i < fused.length; i++) {
    maxDiff = Math.max(maxDiff, Math.abs(fused[i]! - reference[i]!));
  }
  expect(maxDiff).toBeLessThan(1e-6);
}

describe('matmul fused epilogue on GPU', () => {
  it('bias fold matches matmul → add', async () => {
    await compareFusedVsComposed(5, 12, 16, 'bias');
  });

  it('addend fold matches matmul → add', async () => {
    await compareFusedVsComposed(4, 8, 24, 'addend');
  });

  it('bias + addend fold matches the two-add chain', async () => {
    await compareFusedVsComposed(6, 10, 32, 'both');
  });

  it('folds identically on a non-multiple-of-4 N (scalar tail cols)', async () => {
    await compareFusedVsComposed(3, 9, 33, 'both');
  });

  it('folds identically across row-block boundaries', async () => {
    await compareFusedVsComposed(33, 40, 21, 'both');
  });
});

/** Activation-epilogue gate: matmul with a fused tanh/GELU vs the composed
 *  matmul → activation chain (bias before, addend after — the op's documented
 *  order act(a·b + bias) + addend). Covers the f32 kernel (vec4 and scalar
 *  tail paths), the f16 kernel, and M = 1 (which the activation keeps
 *  off the GEMV route — that kernel has no activation epilogue). */
async function compareActVsComposed(
  m: number,
  k: number,
  n: number,
  act: 'tanh' | 'gelu',
  weightDtype: 'f32' | 'f16' = 'f32',
): Promise<void> {
  const root = await tgpu.init();
  const ex = gpuExecutor(root);
  const aData = randArr(m * k, 11);
  const bData = randArr(k * n, 12);
  const biasData = randArr(n, 13);
  const addendData = randArr(m * n, 14);
  // Every operand shares one dtype — the kernel binds a single element type,
  // so an f16 weight needs f16 activations too.
  const half = weightDtype === 'f16';
  const upF = (data: Float32Array, dims: [number, number]) =>
    half
      ? materialized(
          { elems: data.length, dtype: 'f16' as const, dims },
          uploadF16(root, f32ArrayToF16Bits(data).data),
        )
      : materialized(matrix(dims[0], dims[1]), uploadF32(root, data));
  const up = () => ({
    a: upF(aData, [m, k]),
    b: upF(bData, [k, n]),
    bias: upF(biasData, [1, n]),
    addend: upF(addendData, [m, n]),
  });

  const f = up();
  const fused = await toArray(
    matmul(f.a, f.b, { bias: f.bias, addend: f.addend, activation: act }),
    ex,
  );

  const c = up();
  const activated = (act === 'tanh' ? tanh : gelu)(matmul(c.a, c.b, { bias: c.bias }));
  const reference = await toArray(add(activated, c.addend), ex);

  let maxDiff = 0;
  for (let i = 0; i < fused.length; i++) {
    maxDiff = Math.max(maxDiff, Math.abs(fused[i]! - reference[i]!));
  }
  // The f16 arm stores every intermediate at half width, so the fused and
  // composed chains round at different points — compare at f16 resolution.
  expect(maxDiff).toBeLessThan(half ? 5e-3 : 1e-6);
}

describe('matmul fused activation epilogue on GPU', () => {
  it('gelu fold matches matmul → gelu (vec4 path)', async () => {
    await compareActVsComposed(6, 12, 16, 'gelu');
  });

  it('tanh fold matches matmul → tanh', async () => {
    await compareActVsComposed(5, 8, 16, 'tanh');
  });

  it('gelu folds identically on the scalar tail cols (N % 4 != 0)', async () => {
    await compareActVsComposed(3, 9, 34, 'gelu');
  });

  it('M = 1 with activation stays correct (off the GEMV route)', async () => {
    await compareActVsComposed(1, 24, 16, 'gelu');
  });

  it('gelu fold on the f16 kernel', async () => {
    await compareActVsComposed(6, 12, 16, 'gelu', 'f16');
  });

  it('M = 1 f16 with activation stays correct (off the GEMV route)', async () => {
    await compareActVsComposed(1, 24, 16, 'gelu', 'f16');
  });
});

/** f64 reference — independent of every GPU pipeline, so it pins the blocked
 *  kernel's indexing and bounds logic, not just epilogue equivalence. */
function refMatmul(
  m: number,
  k: number,
  n: number,
  a: Float32Array,
  b: Float32Array,
  bias?: Float32Array,
  addend?: Float32Array,
): Float64Array {
  const out = new Float64Array(m * n);
  for (let r = 0; r < m; r++) {
    for (let c = 0; c < n; c++) {
      let acc = 0;
      for (let j = 0; j < k; j++) acc += a[r * k + j]! * b[j * n + c]!;
      if (bias) acc += bias[c]!;
      if (addend) acc += addend[r * n + c]!;
      out[r * n + c] = acc;
    }
  }
  return out;
}

async function compareVsRef(m: number, k: number, n: number, withEpilogue: boolean): Promise<void> {
  const root = await tgpu.init();
  const ex = gpuExecutor(root);
  const aData = randArr(m * k, 11);
  const bData = randArr(k * n, 12);
  const biasData = withEpilogue ? randArr(n, 13) : undefined;
  const addendData = withEpilogue ? randArr(m * n, 14) : undefined;

  const a = materialized(matrix(m, k), uploadF32(root, aData));
  const b = materialized(matrix(k, n), uploadF32(root, bData));
  const bias = biasData
    ? materialized({ elems: n, dtype: 'f32' as const, dims: [n] }, uploadF32(root, biasData))
    : undefined;
  const addend = addendData ? materialized(matrix(m, n), uploadF32(root, addendData)) : undefined;
  const got = await toArray(matmul(a, b, { bias, addend }), ex);
  const want = refMatmul(m, k, n, aData, bData, biasData, addendData);

  let maxDiff = 0;
  for (let i = 0; i < got.length; i++) {
    maxDiff = Math.max(maxDiff, Math.abs(got[i]! - want[i]!));
  }
  // f32 accumulation over k ≤ 64 of unit-range values vs f64.
  expect(maxDiff).toBeLessThan(1e-4);
}

describe('register-blocked matmul vs f64 reference on GPU', () => {
  it('single partial block (all dims below the 4×4 block)', async () => {
    await compareVsRef(7, 5, 3, false);
  });

  it('exact block multiples (no guards taken)', async () => {
    await compareVsRef(32, 32, 32, false);
  });

  it('tails on every dim (clamped rows and scalar tail cols)', async () => {
    await compareVsRef(33, 40, 21, false);
  });

  it('rows just past a block edge, with the full epilogue', async () => {
    await compareVsRef(18, 17, 18, true);
  });

  it('encoder-like shape (M spans many row blocks)', async () => {
    await compareVsRef(96, 64, 48, false);
  });
});
