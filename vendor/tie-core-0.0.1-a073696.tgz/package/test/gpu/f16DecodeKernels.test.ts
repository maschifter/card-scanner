/** f16 parity for the incremental-decode kernels — the moonshine set: rope,
 *  conv1d, the m=1 GEMV and small-m subgroup matmul routes, single-row
 *  attention (attnDecode and its key-split pair), plus the KV-cache movers
 *  writeRows and gatherRowsFrom.
 *
 *  Both arms read the SAME numbers: the f32 arm's operands are pre-rounded
 *  through f16, so the only difference is that the f16 arm stores its result
 *  at half width. Pure element moves must match EXACTLY; anything that
 *  accumulates is compared at f16 resolution. */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  argmaxDot,
  conv1d,
  gpuExecutor,
  materialized,
  matmul,
  matrix,
  mean,
  rope,
  sdpa,
  swigluChunk,
  toArray,
  writeRows,
  type Value,
} from '../../src/index.ts';
import { gatherRowsFrom } from '../../src/graph/ops/shape.ts';
import { uploadF16, uploadF32 } from '../../src/gpu/buffers.ts';
import { f16BitsToF32, f32ArrayToF16Bits } from '../../src/weights/convert.ts';

let rootPromise: Promise<TgpuRoot> | undefined;
const getRoot = (): Promise<TgpuRoot> =>
  (rootPromise ??= tgpu.init({
    device: { optionalFeatures: ['shader-f16', 'subgroups'] },
  }));

/** The same numbers as an f32 Value and an f16 Value. */
function pair(root: TgpuRoot, rows: number, cols: number, seed: number) {
  const raw = new Float32Array(rows * cols).map((_, i) => Math.sin(i * 0.37 + seed) * 0.5);
  const bits = f32ArrayToF16Bits(raw).data;
  const rounded = Float32Array.from(bits, (b) => f16BitsToF32(b));
  return {
    f16: materialized(
      { elems: rows * cols, dtype: 'f16' as const, dims: [rows, cols] },
      uploadF16(root, bits),
    ),
    f32: materialized(matrix(rows, cols), uploadF32(root, rounded)),
  };
}

/** An f32-only operand, identical in both arms (index vectors, rope tables). */
function shared(root: TgpuRoot, rows: number, cols: number, fill: (i: number) => number) {
  const raw = new Float32Array(rows * cols).map((_, i) => fill(i));
  return materialized(matrix(rows, cols), uploadF32(root, raw));
}

const run = (root: TgpuRoot, v: Value) => toArray(v, gpuExecutor(root));

function expectF16Close(got: Float32Array, want: Float32Array, label: string): void {
  expect(got.length).toBe(want.length);
  let worst = 0;
  let at = -1;
  for (let i = 0; i < want.length; i++) {
    const rel = Math.abs(got[i]! - want[i]!) / Math.max(1, Math.abs(want[i]!));
    if (rel > worst) {
      worst = rel;
      at = i;
    }
  }
  expect(worst, `${label}: worst relative diff at ${at} (${got[at]} vs ${want[at]})`).toBeLessThan(
    5e-3,
  );
}

describe('f16 decode kernels', () => {
  it('rope matches the f32 kernel (cos/sin tables stay f32 in both)', async () => {
    const root = await getRoot();
    const [t, heads, headDim] = [6, 3, 8];
    const x = pair(root, t, heads * headDim, 1);
    // Pair-duplicated tables, exactly as the models build them.
    const cos = shared(root, t, headDim, (i) => Math.cos(Math.floor(i % headDim) / 2 + 1));
    const sin = shared(root, t, headDim, (i) => Math.sin(Math.floor(i % headDim) / 2 + 1));
    const opts = { headDim };
    const got = await run(root, rope(x.f16, cos, sin, opts));
    const want = await run(root, rope(x.f32, cos, sin, opts));
    expectF16Close(got, want, 'rope');
  });

  it('rope through a column window matches', async () => {
    const root = await getRoot();
    const [t, headDim] = [5, 8];
    const x = pair(root, t, 3 * headDim, 2);
    const cos = shared(root, t, headDim, (i) => Math.cos((i % headDim) * 0.3));
    const sin = shared(root, t, headDim, (i) => Math.sin((i % headDim) * 0.3));
    const opts = { headDim, srcStart: headDim, width: headDim };
    const got = await run(root, rope(x.f16, cos, sin, opts));
    const want = await run(root, rope(x.f32, cos, sin, opts));
    expectF16Close(got, want, 'rope window');
  });

  it('conv1d matches the f32 kernel on both the quad and tail paths', async () => {
    const root = await getRoot();
    for (const [cIn, cOut, k, stride] of [
      [8, 16, 3, 1],
      [8, 6, 3, 2], // cOut % 4 != 0 → exercises the scalar tail
    ] as const) {
      const x = pair(root, 12, cIn, 3);
      const w = pair(root, k * cIn, cOut, 4);
      const bias = pair(root, 1, cOut, 5);
      const opts = {
        kernelSize: k,
        stride,
        padding: stride === 1 ? ('same' as const) : ('valid' as const),
      };
      const got = await run(root, conv1d(x.f16, w.f16, { ...opts, bias: bias.f16 }));
      const want = await run(root, conv1d(x.f32, w.f32, { ...opts, bias: bias.f32 }));
      expectF16Close(got, want, `conv1d ${cIn}>${cOut} k=${k} s=${stride}`);
    }
  });

  it('matmul takes the m=1 GEMV route in f16 and matches', async () => {
    const root = await getRoot();
    const [k, n] = [128, 64];
    const a = pair(root, 1, k, 6);
    const b = pair(root, k, n, 7);
    const got = await run(root, matmul(a.f16, b.f16));
    const want = await run(root, matmul(a.f32, b.f32));
    expectF16Close(got, want, 'matmul gemv');
  });

  it('matmul takes the small-m subgroup route in f16 and matches', async () => {
    const root = await getRoot();
    const [m, k, n] = [8, 64, 32]; // m % 4 == 0 and n % 4 == 0 → small-m eligible
    const a = pair(root, m, k, 8);
    const b = pair(root, k, n, 9);
    const bias = pair(root, 1, n, 10);
    const got = await run(root, matmul(a.f16, b.f16, { bias: bias.f16 }));
    const want = await run(root, matmul(a.f32, b.f32, { bias: bias.f32 }));
    expectF16Close(got, want, 'matmul small-m');
  });

  it('single-row attention matches the f32 kernel', async () => {
    const root = await getRoot();
    const [qHeads, kvHeads, headDim, kvLen] = [4, 2, 32, 40];
    const q = pair(root, 1, qHeads * headDim, 11);
    const kv = pair(root, kvLen, kvHeads * headDim, 12);
    const v = pair(root, kvLen, kvHeads * headDim, 13);
    const opts = {
      qHeads,
      kvHeads,
      headDim,
      windowLeft: Infinity,
      windowRight: 0,
      qPosOffset: kvLen - 1,
    };
    const got = await run(root, sdpa(q.f16, kv.f16, v.f16, opts));
    const want = await run(root, sdpa(q.f32, kv.f32, v.f32, opts));
    expectF16Close(got, want, 'attnDecode');
  });

  it('single-row attention over a long key range (the split pair) matches', async () => {
    const root = await getRoot();
    const [qHeads, kvHeads, headDim, kvLen] = [4, 4, 32, 2048];
    const q = pair(root, 1, qHeads * headDim, 14);
    const kv = pair(root, kvLen, kvHeads * headDim, 15);
    const v = pair(root, kvLen, kvHeads * headDim, 16);
    const opts = {
      qHeads,
      kvHeads,
      headDim,
      windowLeft: Infinity,
      windowRight: 0,
      qPosOffset: kvLen - 1,
    };
    const got = await run(root, sdpa(q.f16, kv.f16, v.f16, opts));
    const want = await run(root, sdpa(q.f32, kv.f32, v.f32, opts));
    expectF16Close(got, want, 'attnDecode split');
  });

  it('writeRows appends into an f16 cache exactly', async () => {
    const root = await getRoot();
    const cols = 16;
    const dst = pair(root, 8, cols, 17);
    const src = pair(root, 2, cols, 18);
    const got = await run(root, writeRows(dst.f16, src.f16, 3));
    const want = await run(root, writeRows(dst.f32, src.f32, 3));
    // A row copy moves elements without touching them.
    expect(Array.from(got)).toEqual(Array.from(want));
  });

  it('gatherRowsFrom selects f16 rows exactly', async () => {
    const root = await getRoot();
    const [rows, cols] = [12, 8];
    const table = pair(root, rows, cols, 19);
    const idx = shared(root, 3, 1, (i) => [7, 0, 11][i]!);
    const got = await run(root, gatherRowsFrom(table.f16, idx));
    const want = await run(root, gatherRowsFrom(table.f32, idx));
    expect(Array.from(got)).toEqual(Array.from(want));
  });

  it('argmaxDot picks the same token from an f16 table', async () => {
    const root = await getRoot();
    const [vocab, dModel] = [3000, 64]; // vocab > 2048: a row index is NOT exact in f16
    const table = pair(root, vocab, dModel, 21);
    const h = pair(root, 1, dModel, 22);
    const got = await run(root, argmaxDot(table.f16, h.f16));
    const want = await run(root, argmaxDot(table.f32, h.f32));
    // The result is a row index, f32 in both arms — it must be exact, and it
    // must survive a vocabulary past f16's 2048-integer limit.
    expect(got[0]).toBe(want[0]);
    expect(Number.isInteger(got[0])).toBe(true);
  });

  it('argmaxDot keeps the lowest index on ties in f16', async () => {
    const root = await getRoot();
    const [vocab, dModel] = [2600, 32];
    // Every row identical → every dot ties, so the kernel must return row 0.
    const raw = new Float32Array(vocab * dModel).map((_, i) => ((i % dModel) - 16) * 0.05);
    const bits = f32ArrayToF16Bits(raw).data;
    const table = materialized(
      { elems: vocab * dModel, dtype: 'f16' as const, dims: [vocab, dModel] },
      uploadF16(root, bits),
    );
    const h = pair(root, 1, dModel, 23);
    const got = await run(root, argmaxDot(table, h.f16));
    expect(got[0]).toBe(0);
  });

  it('mean and swigluChunk match the f32 kernels', async () => {
    const root = await getRoot();
    const x = pair(root, 6, 16, 20);
    expectF16Close(await run(root, mean(x.f16)), await run(root, mean(x.f32)), 'mean');
    expectF16Close(
      await run(root, swigluChunk(x.f16)),
      await run(root, swigluChunk(x.f32)),
      'swigluChunk',
    );
  });
});
