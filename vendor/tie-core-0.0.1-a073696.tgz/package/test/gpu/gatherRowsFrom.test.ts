import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  argmaxDot,
  gatherRowsFrom,
  gpuExecutor,
  materialized,
  matrix,
  toArray,
  uploadF32,
} from '../../src/index.ts';

/** GPU-resident row selection: an argmax id drives a row gather in the SAME
 *  eval, no CPU readback between them — the decode burst's self-feeding
 *  step. */

describe('gatherRowsFrom on GPU', () => {
  it('selects rows by a device-computed f32 index', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const x = materialized(
      matrix(4, 3),
      uploadF32(root, Float32Array.of(0, 1, 2, 10, 11, 12, 20, 21, 22, 30, 31, 32)),
    );
    const idx = materialized(matrix(2, 1), uploadF32(root, Float32Array.of(2, 0)));
    const out = await toArray(gatherRowsFrom(x, idx), ex);
    expect(Array.from(out)).toEqual([20, 21, 22, 0, 1, 2]);
  });

  it('chains argmaxDot → gatherRowsFrom without a readback in between', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    // "Embedding" rows; row 2 wins the dot against h by construction.
    const emb = materialized(
      matrix(4, 3),
      uploadF32(root, Float32Array.of(1, 0, 0, 0, 1, 0, 5, 5, 5, 0, 0, 1)),
    );
    const h = materialized(matrix(1, 3), uploadF32(root, Float32Array.of(1, 1, 1)));
    const row = await toArray(gatherRowsFrom(emb, argmaxDot(emb, h)), ex);
    expect(Array.from(row)).toEqual([5, 5, 5]);
  });
});
