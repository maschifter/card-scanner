import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { sdpa, materialized, matrix, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

/** Seeded RNG so failures reproduce (same generator as zoo's cpuRefs). */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

interface Geo {
  qHeads: number;
  kvHeads: number;
  headDim: number;
}

/** Exact f64 reference: banded softmax(QKᵀ [∪ sink])·V with GQA, kvLen ≠ qLen,
 *  offset — sm_scale = 1, band [qPos−wl, qPos+wr] ∩ [0,kvLen). When sinks are
 *  given, sinks[h]·ln2 joins the softmax as a phantom score with zero value. */
function cpuAttn(
  q: Float32Array,
  k: Float32Array,
  v: Float32Array,
  qLen: number,
  kvLen: number,
  geo: Geo,
  wl: number,
  wr: number,
  off: number,
  sinks?: Float32Array,
): Float32Array {
  const { qHeads, kvHeads, headDim: hd } = geo;
  const group = qHeads / kvHeads;
  const out = new Float32Array(qLen * qHeads * hd);
  for (let i = 0; i < qLen; i++) {
    const qPos = off + i;
    for (let h = 0; h < qHeads; h++) {
      const kvh = Math.floor(h / group);
      const lo = Math.max(0, qPos - wl);
      const hi = Math.min(kvLen - 1, qPos + wr);
      const qOff = (i * qHeads + h) * hd;
      const scores: number[] = [];
      for (let j = lo; j <= hi; j++) {
        let sc = 0;
        for (let dd = 0; dd < hd; dd++) {
          sc += q[qOff + dd]! * k[(j * kvHeads + kvh) * hd + dd]!;
        }
        scores.push(sc);
      }
      const sinkLogit = sinks ? sinks[h]! * Math.LN2 : -Infinity;
      const m = Math.max(sinkLogit, ...scores);
      let denom = sinks ? Math.exp(sinkLogit - m) : 0;
      for (const sc of scores) denom += Math.exp(sc - m);
      for (let dd = 0; dd < hd; dd++) {
        let acc = 0;
        for (let j = lo; j <= hi; j++) {
          acc += (Math.exp(scores[j - lo]! - m) / denom) * v[(j * kvHeads + kvh) * hd + dd]!;
        }
        out[qOff + dd] = acc;
      }
    }
  }
  return out;
}

const maxAbsDiff = (a: Float32Array, b: Float32Array) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

const INF = Infinity;
const BIG = 0x3fffffff; // the op's finite stand-in, for the CPU reference

async function runAttn(
  qData: Float32Array,
  kData: Float32Array,
  vData: Float32Array,
  qLen: number,
  kvLen: number,
  geo: Geo,
  windowLeft: number,
  windowRight: number,
  qPosOffset = 0,
  sinksData?: Float32Array,
): Promise<Float32Array> {
  const root = await tgpu.init();
  const qw = geo.qHeads * geo.headDim;
  const kvw = geo.kvHeads * geo.headDim;
  const q = materialized(matrix(qLen, qw), uploadF32(root, qData));
  const k = materialized(matrix(kvLen, kvw), uploadF32(root, kData));
  const v = materialized(matrix(kvLen, kvw), uploadF32(root, vData));
  const sinks = sinksData
    ? materialized(
        { elems: geo.qHeads, dtype: 'f32', dims: [geo.qHeads] },
        uploadF32(root, sinksData),
      )
    : undefined;
  return toArray(
    sdpa(q, k, v, { ...geo, windowLeft, windowRight, qPosOffset, sinks }),
    gpuExecutor(root),
  );
}

describe('eager sdpa on GPU', () => {
  const geo: Geo = { qHeads: 4, kvHeads: 4, headDim: 16 };
  const qw = geo.qHeads * geo.headDim;

  it('full bidirectional square matches the f64 reference', async () => {
    const T = 9;
    const [q, k, v] = [randArr(T * qw, 1), randArr(T * qw, 2), randArr(T * qw, 3)];
    const out = await runAttn(q, k, v, T, T, geo, INF, INF);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('causal (∞, 0) masks the future', async () => {
    const T = 8;
    const [q, k, v] = [randArr(T * qw, 4), randArr(T * qw, 5), randArr(T * qw, 6)];
    const out = await runAttn(q, k, v, T, T, geo, INF, 0);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, 0, 0))).toBeLessThan(1e-5);
  });

  it('asymmetric sliding window (2, 1)', async () => {
    const T = 10;
    const [q, k, v] = [randArr(T * qw, 7), randArr(T * qw, 8), randArr(T * qw, 9)];
    const out = await runAttn(q, k, v, T, T, geo, 2, 1);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, 2, 1, 0))).toBeLessThan(1e-5);
  });

  it('cross-attention kvLen ≠ qLen (decoder rows over encoder keys)', async () => {
    const [qLen, kvLen] = [5, 13];
    const q = randArr(qLen * qw, 10);
    const [k, v] = [randArr(kvLen * qw, 11), randArr(kvLen * qw, 12)];
    const out = await runAttn(q, k, v, qLen, kvLen, geo, INF, INF);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, qLen, kvLen, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('GQA 8:2 matches the grouped reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 2, headDim: 8 };
    const T = 6;
    const q = randArr(T * g.qHeads * g.headDim, 13);
    const [k, v] = [randArr(T * g.kvHeads * g.headDim, 14), randArr(T * g.kvHeads * g.headDim, 15)];
    const out = await runAttn(q, k, v, T, T, g, INF, INF);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, g, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('sinks route through the op into the sink-seeded softmax', async () => {
    const T = 8;
    const [q, k, v] = [randArr(T * qw, 19), randArr(T * qw, 20), randArr(T * qw, 21)];
    const sinks = randArr(geo.qHeads, 22);
    const out = await runAttn(q, k, v, T, T, geo, INF, INF, 0, sinks);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, BIG, 0, sinks))).toBeLessThan(1e-5);
  });

  it('incremental decode: per-row qLen=1 + offset equals the full causal pass', async () => {
    // The KV-cache golden property: row t of a full causal run must equal a
    // qLen=1 query at qPosOffset=t over the first t+1 keys.
    const T = 7;
    const [q, k, v] = [randArr(T * qw, 16), randArr(T * qw, 17), randArr(T * qw, 18)];
    const full = await runAttn(q, k, v, T, T, geo, INF, 0);
    for (const t of [0, 3, T - 1]) {
      const qRow = q.slice(t * qw, (t + 1) * qw);
      const kPrefix = k.slice(0, (t + 1) * qw);
      const vPrefix = v.slice(0, (t + 1) * qw);
      const step = await runAttn(qRow, kPrefix, vPrefix, 1, t + 1, geo, INF, 0, t);
      expect(maxAbsDiff(step, full.slice(t * qw, (t + 1) * qw))).toBeLessThan(1e-5);
    }
  });
});
