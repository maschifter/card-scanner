import { describe, expect, it } from 'vitest';
import { createOpfsCache } from '../../src/weights/opfsCache.ts';

describe('opfs cache', () => {
  it('stores and retrieves typed arrays', async () => {
    const cache = await createOpfsCache('test-cache-v1');
    if (!cache) return; // OPFS unavailable in this browser → skip
    await cache.clear();
    expect(await cache.get('k1')).toBeUndefined();

    let computed = 0;
    const make = async () => {
      computed++;
      return new Uint32Array([1, 2, 3]);
    };
    const a = new Uint32Array(await cache.getOrCompute('k1', make));
    const b = new Uint32Array(await cache.getOrCompute('k1', make));
    expect([...a]).toEqual([1, 2, 3]);
    expect([...b]).toEqual([1, 2, 3]);
    expect(computed).toBe(1);
    await cache.clear();
  });

  it('treats a zero-byte entry (crashed write) as a miss and rewrites it', async () => {
    const cache = await createOpfsCache('test-cache-v1');
    if (!cache) return; // OPFS unavailable in this browser → skip
    await cache.clear();
    // Simulate a write interrupted by a tab crash: the file exists but is empty.
    const root = await navigator.storage.getDirectory();
    const dir = await root.getDirectoryHandle('test-cache-v1');
    await dir.getFileHandle('k2', { create: true });

    expect(await cache.get('k2')).toBeUndefined();
    let computed = 0;
    const make = async () => {
      computed++;
      return new Uint32Array([7, 8]);
    };
    expect([...new Uint32Array(await cache.getOrCompute('k2', make))]).toEqual([7, 8]);
    expect(computed).toBe(1);
    // The recomputed value must now be persisted.
    expect((await cache.get('k2'))?.byteLength).toBe(8);
    await cache.clear();
  });
});
