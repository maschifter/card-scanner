import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { reshape, toArray, gpuExecutor, materialized } from '../../src/index.ts';
import { uploadF32 } from '../../src/index.ts';
import { tensor3d } from '../../src/graph/value.ts';

describe('reshape GPU', () => {
  it('[3, 4, 4] -> [3, 16] preserves all values', async () => {
    const root = await tgpu.init();
    const data = new Float32Array(48).map((_, i) => i);
    const x = materialized(tensor3d(3, 4, 4), uploadF32(root, data));
    const out = await toArray(reshape(x, [3, 16]), gpuExecutor(root));
    expect(Array.from(out)).toEqual(Array.from(data));
  });
});
