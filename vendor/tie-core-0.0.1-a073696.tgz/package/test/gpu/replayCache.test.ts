/** createReplayCache: each bucket records its DAG once and every run() only
 *  rewrites the input buffers and re-submits — so the gate is that results
 *  track the inputs across repeated replays, buckets stay independent, and
 *  the lifecycle guards (non-bucket T, dispose) throw instead of misbehaving.
 *  The DAG under capture is a [1,T]×[T,1] matmul (a dot product), small
 *  enough that expected values are exact in f32. */

import { beforeAll, describe, expect, it } from 'vitest';
import type { TgpuRoot } from 'typegpu';
import { createReplayCache, matmul } from '../../src/index.ts';
import { getRoot } from './harness.ts';

let root: TgpuRoot;
beforeAll(async () => {
  root = await getRoot();
});

const makeCache = () =>
  createReplayCache({
    root,
    buckets: [4, 8],
    inputs: (T) => ({ x: [T, 1], scale: [1, T] }) as const,
    // Valid recording data: x = 1s, scale = 1/T → dot = 1 (finite, non-zero).
    captureFill: (T, scratch) => {
      scratch.x.fill(1);
      scratch.scale.fill(1 / T);
    },
    build: (_, inp) => matmul(inp.scale, inp.x),
  });

describe('createReplayCache', () => {
  it('replays track rewritten inputs, per bucket', async () => {
    const cache = makeCache();
    // Same bucket, different inputs on each run — the recording is reused,
    // only the buffers change.
    const first = await cache.run(4, (_, s) => {
      s.x.set([1, 2, 3, 4]);
      s.scale.fill(1);
    });
    expect(Array.from(first)).toEqual([10]);
    const second = await cache.run(4, (_, s) => {
      s.x.set([5, 0, 0, 1]);
      s.scale.fill(2);
    });
    expect(Array.from(second)).toEqual([12]);
    // The other bucket records its own frame at its own length.
    const other = await cache.run(8, (_, s) => {
      s.x.fill(1);
      s.scale.fill(1);
    });
    expect(Array.from(other)).toEqual([8]);
    cache.dispose();
  });

  it('serializes concurrent runs on one bucket', async () => {
    const cache = makeCache();
    // Fired without awaiting: the second fill must not clobber the first
    // replay's buffers (run() chains per bucket).
    const jobs = [1, 2, 3].map((v) =>
      cache.run(4, (_, s) => {
        s.x.fill(v);
        s.scale.fill(1);
      }),
    );
    const results = await Promise.all(jobs);
    expect(results.map((r) => r[0])).toEqual([4, 8, 12]);
    cache.dispose();
  });

  it('warmAll builds every bucket on the captureFill data', async () => {
    const cache = makeCache();
    await cache.warmAll();
    // Buckets already recorded — a run right after must still be correct.
    const out = await cache.run(8, (_, s) => {
      s.x.fill(3);
      s.scale.fill(1);
    });
    expect(Array.from(out)).toEqual([24]);
    cache.dispose();
  });

  it('pick routes to the smallest fitting bucket', () => {
    const cache = makeCache();
    expect(cache.pick(1)).toBe(4);
    expect(cache.pick(4)).toBe(4);
    expect(cache.pick(5)).toBe(8);
    expect(cache.pick(9)).toBeUndefined();
    cache.dispose();
  });

  it('guards: non-bucket T, disposed cache, malformed buckets', () => {
    const cache = makeCache();
    expect(() => cache.run(5, () => {})).toThrow(/not a configured bucket/);
    cache.dispose();
    expect(() => cache.run(4, () => {})).toThrow(/disposed/);
    expect(() =>
      createReplayCache({
        root,
        buckets: [8, 4],
        inputs: (T) => ({ x: [T, 1] }) as const,
        captureFill: () => {},
        build: (_, inp) => inp.x,
      }),
    ).toThrow(/strictly ascending/);
  });
});
