/** f16 parity for the small MiniLM kernels: each f16 variant against its f32
 *  kernel on f16-rounded inputs, so the comparison isolates the kernel rather
 *  than the rounding of the operands.
 *
 *  Slice and gather are pure element moves and must match EXACTLY; add and
 *  layerNorm compute in f32 and round once on store, so they are compared at
 *  f16 resolution (~1e-3 relative). */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  add,
  gatherRows,
  gpuExecutor,
  layerNorm,
  sdpa,
  materialized,
  matrix,
  slice,
  toArray,
  type Value,
} from '../../src/index.ts';
import { uploadF16, uploadF32 } from '../../src/gpu/buffers.ts';
import { f16BitsToF32, f32ArrayToF16Bits } from '../../src/weights/convert.ts';

let rootPromise: Promise<TgpuRoot> | undefined;
const getRoot = (): Promise<TgpuRoot> =>
  (rootPromise ??= tgpu.init({ device: { optionalFeatures: ['shader-f16'] } }));

/** The same numbers as an f32 Value and an f16 Value — the f32 one already
 *  rounded through f16, so only the kernel differs. */
function pair(root: TgpuRoot, rows: number, cols: number, seed: number) {
  const raw = new Float32Array(rows * cols).map((_, i) => Math.sin(i * 0.41 + seed));
  const bits = f32ArrayToF16Bits(raw).data;
  const rounded = Float32Array.from(bits, (b) => f16BitsToF32(b));
  const meta = { elems: rows * cols, dtype: 'f16' as const, dims: [rows, cols] };
  return {
    f16: materialized(meta, uploadF16(root, bits)),
    f32: materialized(matrix(rows, cols), uploadF32(root, rounded)),
  };
}

const run = (root: TgpuRoot, v: Value) => toArray(v, gpuExecutor(root));

describe('f16 kernels', () => {
  it('add matches the f32 kernel', async () => {
    const root = await getRoot();
    const a = pair(root, 8, 16, 1);
    const b = pair(root, 8, 16, 2);
    const got = await run(root, add(a.f16, b.f16));
    const want = await run(root, add(a.f32, b.f32));
    for (let i = 0; i < want.length; i++) expect(got[i]).toBeCloseTo(want[i]!, 2);
  });

  it('add broadcasts a row operand in f16', async () => {
    const root = await getRoot();
    const a = pair(root, 8, 16, 1);
    const b = pair(root, 1, 16, 3);
    const got = await run(root, add(a.f16, b.f16));
    const want = await run(root, add(a.f32, b.f32));
    for (let i = 0; i < want.length; i++) expect(got[i]).toBeCloseTo(want[i]!, 2);
  });

  it('layerNorm matches the f32 kernel', async () => {
    const root = await getRoot();
    const x = pair(root, 8, 64, 1);
    const w = pair(root, 1, 64, 2);
    const b = pair(root, 1, 64, 3);
    const got = await run(root, layerNorm(x.f16, w.f16, 1e-5, b.f16));
    const want = await run(root, layerNorm(x.f32, w.f32, 1e-5, b.f32));
    let maxErr = 0;
    for (let i = 0; i < want.length; i++) maxErr = Math.max(maxErr, Math.abs(got[i]! - want[i]!));
    // f32 reductions inside; the only loss is one rounding on store
    expect(maxErr).toBeLessThan(0.005);
  });

  it('layerNorm without bias matches', async () => {
    const root = await getRoot();
    const x = pair(root, 4, 64, 5);
    const w = pair(root, 1, 64, 6);
    const got = await run(root, layerNorm(x.f16, w.f16));
    const want = await run(root, layerNorm(x.f32, w.f32));
    for (let i = 0; i < want.length; i++) expect(got[i]).toBeCloseTo(want[i]!, 2);
  });

  it('column slice moves f16 elements exactly', async () => {
    const root = await getRoot();
    const x = pair(root, 8, 16, 7);
    const got = await run(root, slice(x.f16, 1, 4, 12));
    const want = await run(root, slice(x.f32, 1, 4, 12));
    expect([...got]).toEqual([...want]);
  });

  it('row slice moves f16 elements exactly', async () => {
    const root = await getRoot();
    const x = pair(root, 8, 16, 8);
    const got = await run(root, slice(x.f16, 0, 2, 6));
    const want = await run(root, slice(x.f32, 0, 2, 6));
    expect([...got]).toEqual([...want]);
  });

  it('attention matches the f32 kernel', async () => {
    const root = await getRoot();
    // MiniLM geometry, shrunk: 12 heads x headDim 32, full bidirectional band.
    const qHeads = 4;
    const headDim = 16;
    const qLen = 24;
    const width = qHeads * headDim;
    const q = pair(root, qLen, width, 1);
    const k = pair(root, qLen, width, 2);
    const v = pair(root, qLen, width, 3);
    const opts = {
      qHeads,
      kvHeads: qHeads,
      headDim,
      windowLeft: Infinity,
      windowRight: Infinity,
    } as const;
    const got = await run(root, sdpa(q.f16, k.f16, v.f16, opts));
    const want = await run(root, sdpa(q.f32, k.f32, v.f32, opts));
    let maxErr = 0;
    for (let i = 0; i < want.length; i++) maxErr = Math.max(maxErr, Math.abs(got[i]! - want[i]!));
    // f32 online softmax inside; the loss is one rounding of q/k/v and one on
    // store, not a random walk over the key count.
    expect(maxErr).toBeLessThan(0.005);
  });

  it('attention matches through the key-split + merge pair', async () => {
    const root = await getRoot();
    // kvLen 128 > ATTN_ROWS_CHUNK (96), so the f32 arm takes the split pair
    // (the subgroup variant where subgroups are available) while f16 stays on
    // the row kernel at every kvLen (measured faster there — see eval.ts's
    // attn `split`/`sub` routing). The split pair's partials stay f32 in
    // both dtypes, so only q/k/v/out rounding separates the two arms here.
    const qHeads = 2;
    const headDim = 16;
    const qLen = 128;
    const width = qHeads * headDim;
    const q = pair(root, qLen, width, 4);
    const k = pair(root, qLen, width, 5);
    const v = pair(root, qLen, width, 6);
    const opts = {
      qHeads,
      kvHeads: qHeads,
      headDim,
      windowLeft: Infinity,
      windowRight: Infinity,
    } as const;
    const got = await run(root, sdpa(q.f16, k.f16, v.f16, opts));
    const want = await run(root, sdpa(q.f32, k.f32, v.f32, opts));
    let maxErr = 0;
    for (let i = 0; i < want.length; i++) maxErr = Math.max(maxErr, Math.abs(got[i]! - want[i]!));
    expect(maxErr).toBeLessThan(0.005);
  });

  it('rejects mixing dtypes across q, k and v', async () => {
    const root = await getRoot();
    const q = pair(root, 8, 32, 1);
    const k = pair(root, 8, 32, 2);
    const opts = { qHeads: 2, kvHeads: 2, headDim: 16, windowLeft: 0, windowRight: 0 } as const;
    expect(() => sdpa(q.f16, k.f32, k.f32, opts)).toThrow(/share a dtype/);
  });

  it('gatherRows moves f16 rows exactly', async () => {
    const root = await getRoot();
    const x = pair(root, 8, 16, 9);
    const idx = [3, 0, 7, 3];
    const got = await run(root, gatherRows(x.f16, idx));
    const want = await run(root, gatherRows(x.f32, idx));
    expect([...got]).toEqual([...want]);
  });
});
