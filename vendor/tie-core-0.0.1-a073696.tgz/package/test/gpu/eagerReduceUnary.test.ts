import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { add, mean, rsqrt, matrix, materialized, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

describe('eager reduce + unary on GPU', () => {
  it('mean over last axis [2,3] -> [2,1]', async () => {
    const root = await tgpu.init();
    const x = materialized(matrix(2, 3), uploadF32(root, new Float32Array([1, 2, 3, 10, 20, 30])));
    const out = await toArray(mean(x), gpuExecutor(root));
    expect(Array.from(out)).toEqual([2, 20]);
  });

  it('rsqrt and scalar add', async () => {
    const root = await tgpu.init();
    const x = materialized(matrix(1, 3), uploadF32(root, new Float32Array([4, 16, 100])));
    const r = await toArray(rsqrt(x), gpuExecutor(root));
    expect(r[0]).toBeCloseTo(0.5, 4);
    expect(r[1]).toBeCloseTo(0.25, 4);
    const s = await toArray(add(x, 1), gpuExecutor(root));
    expect(Array.from(s)).toEqual([5, 17, 101]);
  });
});
