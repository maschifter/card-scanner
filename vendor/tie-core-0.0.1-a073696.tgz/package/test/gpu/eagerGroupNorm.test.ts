import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { gpuExecutor, groupNorm, materialized, matrix, toArray } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

/** GroupNorm(numGroups=1) semantics gate: statistics are GLOBAL over the
 *  whole [T,C] map with per-channel affine — the f64 reference computes one
 *  mean and one variance over all elements, and a dedicated case asserts the
 *  composition does NOT degenerate to per-row LayerNorm. */

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

const EPS = 1e-5;

/** f64 reference: torch GroupNorm(1, C) — global biased stats, per-channel affine. */
function cpuGroupNorm1(
  x: Float32Array,
  w: Float32Array,
  b: Float32Array,
  T: number,
  C: number,
): Float64Array {
  let m = 0;
  for (let i = 0; i < T * C; i++) m += x[i]!;
  m /= T * C;
  let v = 0;
  for (let i = 0; i < T * C; i++) v += (x[i]! - m) ** 2;
  v /= T * C;
  const inv = 1 / Math.sqrt(v + EPS);
  const out = new Float64Array(T * C);
  for (let t = 0; t < T; t++) {
    for (let c = 0; c < C; c++) {
      out[t * C + c] = (x[t * C + c]! - m) * inv * w[c]! + b[c]!;
    }
  }
  return out;
}

const maxAbsDiff = (a: Float32Array, b: Float64Array) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

async function runGroupNorm(
  xData: Float32Array,
  wData: Float32Array,
  bData: Float32Array,
  T: number,
  C: number,
): Promise<Float32Array> {
  const root = await tgpu.init();
  const x = materialized(matrix(T, C), uploadF32(root, xData));
  const w = materialized({ elems: C, dtype: 'f32', dims: [C] }, uploadF32(root, wData));
  const b = materialized({ elems: C, dtype: 'f32', dims: [C] }, uploadF32(root, bData));
  return toArray(groupNorm(x, 1, w, b, EPS), gpuExecutor(root));
}

describe('eager groupNorm (numGroups=1) on GPU', () => {
  it('matches the f64 global-stats reference with affine bias', async () => {
    const [T, C] = [5, 6];
    const x = randArr(T * C, 1);
    const w = randArr(C, 2);
    const b = randArr(C, 3);
    const out = await runGroupNorm(x, w, b, T, C);
    expect(maxAbsDiff(out, cpuGroupNorm1(x, w, b, T, C))).toBeLessThan(1e-5);
  });

  it('handles a single row (T=1: stats over channels only)', async () => {
    const [T, C] = [1, 6];
    const x = randArr(T * C, 4);
    const w = randArr(C, 5);
    const b = randArr(C, 6);
    const out = await runGroupNorm(x, w, b, T, C);
    expect(maxAbsDiff(out, cpuGroupNorm1(x, w, b, T, C))).toBeLessThan(1e-5);
  });

  it('is NOT per-row LayerNorm (global vs per-row stats differ)', async () => {
    const [T, C] = [5, 6];
    const x = randArr(T * C, 7);
    const w = new Float32Array(C).fill(1);
    const b = new Float32Array(C);
    const out = await runGroupNorm(x, w, b, T, C);
    // per-row LayerNorm reference
    const ln = new Float64Array(T * C);
    for (let t = 0; t < T; t++) {
      let m = 0;
      for (let c = 0; c < C; c++) m += x[t * C + c]!;
      m /= C;
      let v = 0;
      for (let c = 0; c < C; c++) v += (x[t * C + c]! - m) ** 2;
      v /= C;
      for (let c = 0; c < C; c++) ln[t * C + c] = (x[t * C + c]! - m) / Math.sqrt(v + EPS);
    }
    expect(maxAbsDiff(out, ln)).toBeGreaterThan(1e-3);
  });
});
