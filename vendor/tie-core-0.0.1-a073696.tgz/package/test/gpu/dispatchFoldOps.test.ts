import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  asinh,
  gatherRowsFrom,
  gelu,
  gpuExecutor,
  materialized,
  matrix,
  maxPool2d,
  toChw,
  toHwc4,
  silu,
  sub,
  swigluChunk,
  tanh,
  tensor3d,
  toArray,
  transpose,
} from '../../src/index.ts';
import { GRID_Y_STRIDE } from '../../src/kernels/common.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

/** Every flat (one-thread-per-element) kernel must fold the executor's 2-D
 *  dispatch split back into its index — see `flatIndex` in kernels/common.ts.
 *  A kernel that reads gid.x alone still RUNS above the 65535-workgroup cap
 *  (the executor splits the grid, so nothing errors); it just writes the
 *  first GRID_Y_STRIDE elements twice and never touches the tail. These
 *  tests are the only thing that catches that: they run each kernel family
 *  on a tensor just past the boundary and check the elements on both sides
 *  of it, plus the last one.
 *
 *  Sizes are deliberately the SMALLEST that clear the cap (GRID_Y_STRIDE +
 *  one workgroup), so each case moves ~17 MB, not hundreds. */

const OVER_CAP = GRID_Y_STRIDE + 64; // 4_194_304 — one workgroup past the split

/** Indices worth checking: start, both sides of the y-slice boundary, end. */
const checkpoints = (n: number) => [
  0,
  1,
  GRID_Y_STRIDE - 1,
  GRID_Y_STRIDE,
  GRID_Y_STRIDE + 1,
  n - 1,
];

/** Cheap deterministic values in a range where the activations stay
 *  well-conditioned; the pattern differs across the boundary so a
 *  "wrote the first slice twice" bug cannot accidentally match. */
const ramp = (n: number) => {
  const a = new Float32Array(n);
  for (let i = 0; i < n; i++) a[i] = ((i % 97) - 48) / 16;
  return a;
};

const geluRef = (x: number) => {
  // erf via the same A&S 7.1.26 polynomial the kernel uses, in f64.
  const z = x * Math.SQRT1_2;
  const az = Math.abs(z);
  const t = 1 / (1 + 0.3275911 * az);
  const poly =
    t *
    (0.254829592 + t * (-0.284496736 + t * (1.421413741 + t * (-1.453152027 + t * 1.061405429))));
  const erf = Math.sign(z) * (1 - poly * Math.exp(-az * az));
  return 0.5 * x * (1 + erf);
};

describe('flat kernels past the 65535-workgroup dispatch cap', () => {
  it('unary: gelu, silu, tanh, asinh write the whole tensor', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const data = ramp(OVER_CAP);
    const x = materialized(matrix(1, OVER_CAP), uploadF32(root, data));

    const g = await toArray(gelu(x), ex);
    const s = await toArray(silu(x), ex);
    const t = await toArray(tanh(x), ex);
    const a = await toArray(asinh(x), ex);

    for (const i of checkpoints(OVER_CAP)) {
      const v = data[i]!;
      expect(g[i]).toBeCloseTo(geluRef(v), 5);
      expect(s[i]).toBeCloseTo(v / (1 + Math.exp(-v)), 5);
      expect(t[i]).toBeCloseTo(Math.tanh(v), 5);
      expect(a[i]).toBeCloseTo(Math.asinh(v), 5);
    }
  });

  it('elementwiseF32: sub writes the whole tensor', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const av = ramp(OVER_CAP);
    const bv = ramp(OVER_CAP).map((v) => v * 0.25);
    const a = materialized(matrix(1, OVER_CAP), uploadF32(root, av));
    const b = materialized(matrix(1, OVER_CAP), uploadF32(root, bv));

    const out = await toArray(sub(a, b), ex);
    for (const i of checkpoints(OVER_CAP)) {
      expect(out[i]).toBeCloseTo(av[i]! - bv[i]!, 5);
    }
  });

  it('shape: transpose writes the whole tensor', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const rows = 2;
    const cols = OVER_CAP / 2;
    const data = ramp(rows * cols);
    const out = await toArray(
      transpose(materialized(matrix(rows, cols), uploadF32(root, data))),
      ex,
    );
    // out is [cols, rows]: out[c*rows + r] === data[r*cols + c]
    for (const i of checkpoints(rows * cols)) {
      const c = Math.floor(i / rows);
      const r = i % rows;
      expect(out[i]).toBe(data[r * cols + c]);
    }
  });

  it('shape: gatherRowsFrom writes the whole tensor', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const cols = 64;
    const outRows = OVER_CAP / cols; // 65536 output rows
    const srcRows = 2;
    const src = ramp(srcRows * cols);
    // Alternate the two source rows so a duplicated first slice is visible.
    const idx = Float32Array.from({ length: outRows }, (_, r) => r % srcRows);
    const out = await toArray(
      gatherRowsFrom(
        materialized(matrix(srcRows, cols), uploadF32(root, src)),
        materialized(matrix(outRows, 1), uploadF32(root, idx)),
      ),
      ex,
    );
    for (const i of checkpoints(outRows * cols)) {
      const r = Math.floor(i / cols);
      const c = i % cols;
      expect(out[i]).toBe(src[(r % srcRows) * cols + c]);
    }
  });

  /** The conv family is the reason the fold exists — a yolo-size 320^2 stage
   *  map needs ~102k workgroups — but every case above is elementwise or a
   *  row gather. maxPool2d is the cheapest kernel in that family: one thread
   *  per output element, no weights, and k=3 s=1 p=1 keeps H_out/W_out equal
   *  to the input so 64 channels at 256^2 land on exactly OVER_CAP. The
   *  reference is evaluated only at the checkpoints — a full CPU pool over
   *  4.19M windows would dominate the test's runtime for no extra signal. */
  it('conv family: maxPool2d writes the whole tensor', async () => {
    const root = await tgpu.init({ device: { optionalFeatures: ['shader-f16'] } });
    const ex = gpuExecutor(root);
    // hwc4 pool runs one thread per (channel BLOCK, pixel), so over-cap needs
    // c/4 · h · w threads past the cap: 64ch at 512² lands exactly on it.
    const [c, h, w] = [64, 512, 512];
    const [k, stride, padding] = [3, 1, 1]; // H_out = h, W_out = w
    expect((c / 4) * h * w).toBe(OVER_CAP);

    // f16-exact integers, so pooled maxima survive the storage round-trip.
    const data = new Float32Array(c * h * w).map((_, i) => (i % 1024) - 512);
    const out = await toArray(
      toChw(
        maxPool2d(toHwc4(materialized(tensor3d(c, h, w), uploadF32(root, data))), {
          kernelSize: k,
          stride,
          padding,
        }),
        'f32',
      ),
      ex,
    );
    expect(out.length).toBe(c * h * w);

    for (const i of checkpoints(c * h * w)) {
      const wo = i % w;
      const ho = Math.floor(i / w) % h;
      const ch = Math.floor(i / (w * h));
      let mx = -Infinity;
      for (let kh = 0; kh < k; kh++) {
        const hi = ho * stride + kh - padding;
        if (hi < 0 || hi >= h) continue;
        for (let kw = 0; kw < k; kw++) {
          const wi = wo * stride + kw - padding;
          if (wi < 0 || wi >= w) continue;
          mx = Math.max(mx, data[ch * h * w + hi * w + wi]!);
        }
      }
      expect(out[i], `index ${i} (c=${ch} ho=${ho} wo=${wo})`).toBe(mx);
    }
  });

  it('swigluChunk writes the whole tensor', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const half = OVER_CAP; // out is [1, half] — the dispatch is over the cap
    const data = ramp(2 * half);
    const out = await toArray(
      swigluChunk(materialized(matrix(1, 2 * half), uploadF32(root, data))),
      ex,
    );
    for (const i of checkpoints(half)) {
      const hidden = data[i]!;
      const gate = data[half + i]!;
      expect(out[i]).toBeCloseTo(hidden * (gate / (1 + Math.exp(-gate))), 4);
    }
  });
});
