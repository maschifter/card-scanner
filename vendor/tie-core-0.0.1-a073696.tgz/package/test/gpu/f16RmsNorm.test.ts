/** RMSNorm on a halved model, at activation magnitudes that break the naive
 *  composition.
 *
 *  The statistic is mean(x²), and BOTH halves of it overflow f16 long before
 *  the activations do: x = 5000 squares to 2.5e7 against a 65504 ceiling. The
 *  first version of this computed mean(mul(x, x)) — the intermediate x²
 *  buffer went Inf, the mean went Inf, rsqrt(Inf) returned 0, and the model
 *  emitted zeros with no NaN anywhere to notice. The privacy filter hit this
 *  at block 7 (peak activation 1.07e4). */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  f16BitsToF32,
  f32ArrayToF16Bits,
  gpuExecutor,
  materialized,
  matrix,
  nn,
  toArray,
  uploadF16,
  uploadF32,
} from '../../src/index.ts';

const round = (x: Float32Array) =>
  Float32Array.from(f32ArrayToF16Bits(x).data, (b) => f16BitsToF32(b));

describe('f16 RMSNorm', () => {
  it('survives activations whose squares overflow f16', async () => {
    const root = await tgpu.init({ device: { optionalFeatures: ['shader-f16'] } });
    const ex = gpuExecutor(root);
    const [T, N] = [4, 640];
    // Peak 5000: representable in f16, but 5000² = 2.5e7 is not.
    const xd = new Float32Array(T * N).map((_, i) => Math.sin(i * 0.31) * 5000);
    const wd = new Float32Array(N).map((_, i) => 1 + Math.cos(i * 0.11) * 0.25);

    const norm32 = new nn.RMSNorm(N);
    const norm16 = new nn.RMSNorm(N);
    norm16.half(root);
    // The default gpuUpload narrows to each Parameter's declared dtype, so
    // norm16's retyped-to-f16 scale converts automatically — no manual
    // conversion needed here.
    for (const m of [norm32, norm16] as const) {
      await m.loadStateDict({ scale: round(wd) }, { root });
    }
    const x32 = materialized(matrix(T, N), uploadF32(root, round(xd)));
    const x16 = materialized(
      { elems: T * N, dtype: 'f16' as const, dims: [T, N] },
      uploadF16(root, f32ArrayToF16Bits(xd).data),
    );

    const want = await toArray(norm32.forward(x32), ex);
    const got = await toArray(norm16.forward(x16), ex);

    let peak = 0;
    for (const v of got) {
      expect(Number.isFinite(v), 'f16 RMSNorm produced a non-finite value').toBe(true);
      peak = Math.max(peak, Math.abs(v));
    }
    // The failure mode was silent zeros, so assert the output is alive.
    expect(peak, 'f16 RMSNorm collapsed to zeros').toBeGreaterThan(0.1);
    let worst = 0;
    for (let i = 0; i < want.length; i++) {
      worst = Math.max(worst, Math.abs(got[i]! - want[i]!) / Math.max(1, Math.abs(want[i]!)));
    }
    expect(worst).toBeLessThan(5e-3);
  }, 300_000);
});
