import { describe, expect, it } from 'vitest';
import { getRoot, maxAbsDiff } from './harness.ts';
import { uploadF32, uploadU32 } from '../../src/gpu/buffers.ts';
import {
  createMatmulGatherQuantWPipeline,
  matmulGatherQuantWHandle,
} from '../../src/kernels/matmul/matmulGatherQuantW.ts';
import { packQuantColSlice } from '../../src/weights/quantPack.ts';

/** Gather (indexed) quant matmul: each of M tokens uses its own expert's weight
 *  block, chosen by a per-row index buffer — verified vs a CPU reference.
 *  Weights go through packQuantColSlice, so this also pins the packer→kernel
 *  blocked-unit layout contract (quantCommon.ts). */
describe('matmulGatherQuantW GPU', () => {
  const run = async (opts: {
    bits: 8 | 4;
    E: number;
    K: number;
    N: number;
    M: number;
    groupSize: number;
  }) => {
    const root = await getRoot();
    const { bits, E, K, N, M, groupSize } = opts;
    const KG = K / groupSize;
    const lim = bits === 8 ? 7 : 7; // keep int4 in range too
    // logical weight [E, K, O=N]
    const wv = (e: number, k: number, o: number) =>
      ((e * 31 + k * 7 + o * 5) % (2 * lim + 1)) - lim;
    const qbytes = new Uint8Array(bits === 8 ? E * K * N : (E * K * N) / 2);
    for (let e = 0; e < E; e++) {
      for (let k = 0; k < K; k++) {
        for (let o = 0; o < N; o++) {
          const s = (e * K + k) * N + o;
          if (bits === 8) qbytes[s] = wv(e, k, o) & 0xff;
          else qbytes[s >> 1] = (qbytes[s >> 1]! | ((wv(e, k, o) & 0xf) << ((s & 1) * 4))) & 0xff;
        }
      }
    }
    // scales [E, KG, O]
    const rawScales = new Float32Array(E * KG * N);
    for (let i = 0; i < rawScales.length; i++) rawScales[i] = 0.1 * ((i % 5) + 1);
    const { qdata, scales } = packQuantColSlice(qbytes, rawScales, bits, groupSize, E, K, N, 0, N);
    const bias = new Float32Array(E * N);
    for (let i = 0; i < bias.length; i++) bias[i] = 0.5 - 0.05 * (i % 11);
    const a = new Float32Array(M * K);
    for (let i = 0; i < a.length; i++) a[i] = 0.25 * (((i * 3) % 7) - 3);
    const expertIdx = new Float32Array(M);
    for (let i = 0; i < M; i++) expertIdx[i] = (i * 2 + 1) % E;

    const ref = new Float32Array(M * N);
    for (let i = 0; i < M; i++) {
      const e = expertIdx[i]!;
      for (let n = 0; n < N; n++) {
        let acc = bias[e * N + n]!;
        for (let k = 0; k < K; k++) {
          const g = Math.floor(k / groupSize);
          acc += a[i * K + k]! * wv(e, k, n) * scales[(e * KG + g) * N + n]!;
        }
        ref[i * N + n] = acc;
      }
    }

    const out = uploadF32(root, new Float32Array(M * N));
    const pipeline = createMatmulGatherQuantWPipeline(root, { k: K, n: N, bits, groupSize });
    const handle = matmulGatherQuantWHandle(
      root,
      pipeline,
      { m: M, n: N },
      {
        a: uploadF32(root, a),
        w: uploadU32(root, qdata),
        scales: uploadF32(root, scales),
        bias: uploadF32(root, bias),
        expertIdx: uploadF32(root, expertIdx),
        out,
      },
    );
    const enc = root.device.createCommandEncoder();
    const pass = enc.beginComputePass();
    handle.pipeline
      .with(pass)
      .with(handle.bindGroup)
      .dispatchWorkgroups(handle.workgroups as number);
    pass.end();
    root.device.queue.submit([enc.finish()]);
    await root.device.queue.onSubmittedWorkDone();

    const got = Float32Array.from(await out.read());
    const diff = maxAbsDiff(got, ref);
    console.log(`matmulGatherQuantW int${bits} maxAbsDiff vs CPU: ${diff}`);
    expect(diff).toBeLessThan(1e-4);
  };

  it('int8: each token uses its expert (per-row index), matches CPU dequant', async () => {
    await run({ bits: 8, E: 3, K: 4, N: 4, M: 5, groupSize: 4 });
  });

  it('int4, multi-group scales: matches CPU dequant', async () => {
    await run({ bits: 4, E: 2, K: 8, N: 8, M: 4, groupSize: 4 });
  });
});
