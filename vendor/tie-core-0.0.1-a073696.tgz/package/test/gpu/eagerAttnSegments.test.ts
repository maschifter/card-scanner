/** sdpa segments: sequences packed row-wise into one tensor attend only
 *  within their own key range. Parity vs the f64 per-segment reference on
 *  both row routes (kvLen ≤ ATTN_ROWS_CHUNK single kernel, > chunked
 *  split+merge pair), with GQA and with a band window on top. */

import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { sdpa, materialized, matrix, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

interface Geo {
  qHeads: number;
  kvHeads: number;
  headDim: number;
}

/** f64 reference over one segment slice: band [qPos−wl, qPos+wr] with GLOBAL
 *  row/key indices (self-attention pack: q and k shift together, so global
 *  band arithmetic equals per-sentence band arithmetic), keys clipped to
 *  [segLo, segHi). */
function cpuSegAttn(
  q: Float32Array,
  k: Float32Array,
  v: Float32Array,
  qLen: number,
  geo: Geo,
  wl: number,
  wr: number,
  bounds: [number, number][],
): Float32Array {
  const { qHeads, kvHeads, headDim: hd } = geo;
  const group = qHeads / kvHeads;
  const out = new Float32Array(qLen * qHeads * hd);
  for (let i = 0; i < qLen; i++) {
    const [segLo, segHi] = bounds[i]!;
    for (let h = 0; h < qHeads; h++) {
      const kvh = Math.floor(h / group);
      const lo = Math.max(segLo, i - wl);
      const hi = Math.min(segHi - 1, i + wr);
      const qOff = (i * qHeads + h) * hd;
      const scores: number[] = [];
      for (let j = lo; j <= hi; j++) {
        let sc = 0;
        for (let dd = 0; dd < hd; dd++) sc += q[qOff + dd]! * k[(j * kvHeads + kvh) * hd + dd]!;
        scores.push(sc);
      }
      const m = Math.max(...scores);
      let denom = 0;
      for (const sc of scores) denom += Math.exp(sc - m);
      for (let dd = 0; dd < hd; dd++) {
        let acc = 0;
        for (let j = lo; j <= hi; j++) {
          acc += (Math.exp(scores[j - lo]! - m) / denom) * v[(j * kvHeads + kvh) * hd + dd]!;
        }
        out[qOff + dd] = acc;
      }
    }
  }
  return out;
}

const maxAbsDiff = (a: Float32Array, b: Float32Array) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

/** Per-row [start, end) pairs from segment lengths. */
function segRows(lengths: number[]): { segs: Float32Array; bounds: [number, number][] } {
  const bounds: [number, number][] = [];
  let start = 0;
  for (const len of lengths) {
    for (let i = 0; i < len; i++) bounds.push([start, start + len]);
    start += len;
  }
  const segs = new Float32Array(bounds.length * 2);
  bounds.forEach(([lo, hi], i) => {
    segs[2 * i] = lo;
    segs[2 * i + 1] = hi;
  });
  return { segs, bounds };
}

const INF = Infinity;
const BIG = 0x3fffffff;

async function runSegAttn(
  qData: Float32Array,
  kData: Float32Array,
  vData: Float32Array,
  qLen: number,
  geo: Geo,
  windowLeft: number,
  windowRight: number,
  segsData: Float32Array,
  maxSegment?: number,
): Promise<Float32Array> {
  const root = await tgpu.init();
  const qw = geo.qHeads * geo.headDim;
  const kvw = geo.kvHeads * geo.headDim;
  const q = materialized(matrix(qLen, qw), uploadF32(root, qData));
  const k = materialized(matrix(qLen, kvw), uploadF32(root, kData));
  const v = materialized(matrix(qLen, kvw), uploadF32(root, vData));
  const segments = materialized(matrix(qLen, 2), uploadF32(root, segsData));
  return toArray(
    sdpa(q, k, v, { ...geo, windowLeft, windowRight, segments, maxSegment }),
    gpuExecutor(root),
  );
}

describe('eager sdpa with segments on GPU', () => {
  it('packed full attention equals the per-segment reference (rows route)', async () => {
    const geo: Geo = { qHeads: 4, kvHeads: 4, headDim: 16 };
    const lengths = [5, 9, 4];
    const T = 18;
    const { segs, bounds } = segRows(lengths);
    const qw = geo.qHeads * geo.headDim;
    const [q, k, v] = [randArr(T * qw, 11), randArr(T * qw, 12), randArr(T * qw, 13)];
    const out = await runSegAttn(q, k, v, T, geo, INF, INF, segs);
    expect(maxAbsDiff(out, cpuSegAttn(q, k, v, T, geo, BIG, BIG, bounds))).toBeLessThan(1e-5);
  });

  it('packed full attention on the chunked split route (kvLen > 96), GQA', async () => {
    const geo: Geo = { qHeads: 4, kvHeads: 2, headDim: 16 };
    const lengths = [48, 61, 35];
    const T = 144;
    const { segs, bounds } = segRows(lengths);
    const qw = geo.qHeads * geo.headDim;
    const kvw = geo.kvHeads * geo.headDim;
    const [q, k, v] = [randArr(T * qw, 21), randArr(T * kvw, 22), randArr(T * kvw, 23)];
    const out = await runSegAttn(q, k, v, T, geo, INF, INF, segs);
    expect(maxAbsDiff(out, cpuSegAttn(q, k, v, T, geo, BIG, BIG, bounds))).toBeLessThan(1e-5);
  });

  it('band window intersects the segment (causal within each sentence)', async () => {
    const geo: Geo = { qHeads: 4, kvHeads: 4, headDim: 16 };
    const lengths = [7, 6, 7];
    const T = 20;
    const { segs, bounds } = segRows(lengths);
    const qw = geo.qHeads * geo.headDim;
    const [q, k, v] = [randArr(T * qw, 31), randArr(T * qw, 32), randArr(T * qw, 33)];
    const out = await runSegAttn(q, k, v, T, geo, INF, 0, segs);
    expect(maxAbsDiff(out, cpuSegAttn(q, k, v, T, geo, BIG, 0, bounds))).toBeLessThan(1e-5);
  });

  it('matches running each segment as its own sdpa call', async () => {
    const geo: Geo = { qHeads: 4, kvHeads: 4, headDim: 16 };
    const lengths = [6, 11];
    const T = 17;
    const { segs } = segRows(lengths);
    const qw = geo.qHeads * geo.headDim;
    const [q, k, v] = [randArr(T * qw, 41), randArr(T * qw, 42), randArr(T * qw, 43)];
    const packed = await runSegAttn(q, k, v, T, geo, INF, INF, segs);

    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    let offset = 0;
    for (const len of lengths) {
      const slice = (d: Float32Array) => d.slice(offset * qw, (offset + len) * qw);
      const single = await toArray(
        sdpa(
          materialized(matrix(len, qw), uploadF32(root, slice(q))),
          materialized(matrix(len, qw), uploadF32(root, slice(k))),
          materialized(matrix(len, qw), uploadF32(root, slice(v))),
          { ...geo, windowLeft: INF, windowRight: INF },
        ),
        ex,
      );
      expect(maxAbsDiff(packed.slice(offset * qw, (offset + len) * qw), single)).toBeLessThan(1e-5);
      offset += len;
    }
  });

  it('maxSegment ≤ chunk size keeps the pack on the unsplit rows route', async () => {
    // Same pack as the split-route case (kvLen 144 > 96), but maxSegment 61
    // routes it to the plain rows kernel — results must not change.
    const geo: Geo = { qHeads: 4, kvHeads: 2, headDim: 16 };
    const lengths = [48, 61, 35];
    const T = 144;
    const { segs, bounds } = segRows(lengths);
    const qw = geo.qHeads * geo.headDim;
    const kvw = geo.kvHeads * geo.headDim;
    const [q, k, v] = [randArr(T * qw, 21), randArr(T * kvw, 22), randArr(T * kvw, 23)];
    const out = await runSegAttn(q, k, v, T, geo, INF, INF, segs, 61);
    expect(maxAbsDiff(out, cpuSegAttn(q, k, v, T, geo, BIG, BIG, bounds))).toBeLessThan(1e-5);
  });

  it('maxSegment > chunk size sizes the chunk count from the segment', async () => {
    // Segments over 96 keys still split, but into ceil(maxSegment/96) chunks
    // (2 here) instead of ceil(kvLen/96) (3) — results must not change.
    const geo: Geo = { qHeads: 4, kvHeads: 4, headDim: 16 };
    const lengths = [120, 110];
    const T = 230;
    const { segs, bounds } = segRows(lengths);
    const qw = geo.qHeads * geo.headDim;
    const [q, k, v] = [randArr(T * qw, 51), randArr(T * qw, 52), randArr(T * qw, 53)];
    const out = await runSegAttn(q, k, v, T, geo, INF, INF, segs, 120);
    expect(maxAbsDiff(out, cpuSegAttn(q, k, v, T, geo, BIG, BIG, bounds))).toBeLessThan(1e-5);
  });

  it('rejects bad segment shapes and the decode shape', () => {
    const geo = { qHeads: 2, kvHeads: 2, headDim: 4, windowLeft: INF, windowRight: INF };
    const q = materialized(matrix(3, 8), null as never);
    const kv = materialized(matrix(3, 8), null as never);
    const badSegs = materialized(matrix(3, 3), null as never);
    expect(() => sdpa(q, kv, kv, { ...geo, segments: badSegs })).toThrow(/segments must be f32/);
    const oneRow = materialized(matrix(1, 8), null as never);
    const oneSeg = materialized(matrix(1, 2), null as never);
    expect(() => sdpa(oneRow, kv, kv, { ...geo, segments: oneSeg })).toThrow(/qLen > 1/);
    const okSegs = materialized(matrix(3, 2), null as never);
    expect(() => sdpa(q, kv, kv, { ...geo, maxSegment: 3 })).toThrow(/needs segments/);
    expect(() => sdpa(q, kv, kv, { ...geo, segments: okSegs, maxSegment: 1.5 })).toThrow(
      /positive integer/,
    );
  });
});
