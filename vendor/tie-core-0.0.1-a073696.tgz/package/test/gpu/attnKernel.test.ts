import { describe, expect, it } from 'vitest';
import { getRoot, maxAbsDiff, runHandles } from './harness.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';
import {
  ATTN_ROWS_MAX_CHUNKS,
  createAttnPipeline,
  createAttnRowsMergePipeline,
  createAttnRowsPipeline,
  createAttnRowsSplitPipeline,
  attnHandle,
  attnRowsHandle,
  attnRowsSplitHandles,
} from '../../src/kernels/attention/attn.ts';

/** Kernel-level parity suite for the unified attention kernel (attn.ts): the
 *  general no-sink cases (causal/cross/banded/offset/GQA) vs an exact f64
 *  reference, and the sinks variant vs the same reference with a sink seed.
 *  Drives pipelines/handles directly — complements the op-level suite
 *  (eagerAttn.test.ts) with the sinks variants and the empty-band guard. */

/** Seeded RNG so failures reproduce (same generator as zoo's cpuRefs). */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

interface Geo {
  qHeads: number;
  kvHeads: number;
  headDim: number;
}

const BIG = 0x3fffffff; // finite stand-in for an unbounded window side

/** Exact f64 reference: banded softmax(QKᵀ [∪ sink])·V with GQA, kvLen ≠ qLen,
 *  offset — sm_scale = 1, band [qPos−wl, qPos+wr] ∩ [0,kvLen). When sinks are
 *  given, sinks[h]·ln2 joins the softmax as a phantom score with zero value. */
function cpuAttn(
  q: Float32Array,
  k: Float32Array,
  v: Float32Array,
  qLen: number,
  kvLen: number,
  geo: Geo,
  wl: number,
  wr: number,
  off: number,
  sinks?: Float32Array,
): Float32Array {
  const { qHeads, kvHeads, headDim: hd } = geo;
  const group = qHeads / kvHeads;
  const out = new Float32Array(qLen * qHeads * hd);
  for (let i = 0; i < qLen; i++) {
    const qPos = off + i;
    for (let h = 0; h < qHeads; h++) {
      const kvh = Math.floor(h / group);
      const lo = Math.max(0, qPos - wl);
      const hi = Math.min(kvLen - 1, qPos + wr);
      const qOff = (i * qHeads + h) * hd;
      const scores: number[] = [];
      for (let j = lo; j <= hi; j++) {
        let sc = 0;
        for (let dd = 0; dd < hd; dd++) {
          sc += q[qOff + dd]! * k[(j * kvHeads + kvh) * hd + dd]!;
        }
        scores.push(sc);
      }
      if (scores.length === 0 && !sinks) continue; // empty band → 0s
      const sinkLogit = sinks ? sinks[h]! * Math.LN2 : -Infinity;
      const m = Math.max(sinkLogit, ...scores);
      let denom = sinks ? Math.exp(sinkLogit - m) : 0;
      for (const sc of scores) denom += Math.exp(sc - m);
      for (let dd = 0; dd < hd; dd++) {
        let acc = 0;
        for (let j = lo; j <= hi; j++) {
          acc += (Math.exp(scores[j - lo]! - m) / denom) * v[(j * kvHeads + kvh) * hd + dd]!;
        }
        out[qOff + dd] = acc;
      }
    }
  }
  return out;
}

async function runAttn(
  qData: Float32Array,
  kData: Float32Array,
  vData: Float32Array,
  qLen: number,
  kvLen: number,
  geo: Geo,
  windowLeft: number,
  windowRight: number,
  qPosOffset = 0,
  sinksData?: Float32Array,
): Promise<Float32Array> {
  const root = await getRoot();
  const q = uploadF32(root, qData);
  const k = uploadF32(root, kData);
  const v = uploadF32(root, vData);
  const out = uploadF32(root, new Float32Array(qLen * geo.qHeads * geo.headDim));
  const sinks = sinksData ? uploadF32(root, sinksData) : undefined;
  const pipeline = createAttnPipeline(root, {
    ...geo,
    windowLeft,
    windowRight,
    hasSinks: sinksData ? 1 : 0,
    hasSegs: 0,
  });
  const handle = attnHandle(
    root,
    pipeline,
    { qLen, kvLen, qPosOffset, qHeads: geo.qHeads },
    { q, k, v, out, sinks },
  );
  runHandles(root, [handle]);
  await root.device.queue.onSubmittedWorkDone();
  return Float32Array.from(await out.read());
}

describe('unified attn kernel on GPU', () => {
  const geo: Geo = { qHeads: 4, kvHeads: 4, headDim: 16 };
  const qw = geo.qHeads * geo.headDim;

  it('full bidirectional square matches the f64 reference', async () => {
    const T = 9;
    const [q, k, v] = [randArr(T * qw, 1), randArr(T * qw, 2), randArr(T * qw, 3)];
    const out = await runAttn(q, k, v, T, T, geo, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('causal (∞, 0) masks the future', async () => {
    const T = 8;
    const [q, k, v] = [randArr(T * qw, 4), randArr(T * qw, 5), randArr(T * qw, 6)];
    const out = await runAttn(q, k, v, T, T, geo, BIG, 0);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, 0, 0))).toBeLessThan(1e-5);
  });

  it('asymmetric sliding window (2, 1)', async () => {
    const T = 10;
    const [q, k, v] = [randArr(T * qw, 7), randArr(T * qw, 8), randArr(T * qw, 9)];
    const out = await runAttn(q, k, v, T, T, geo, 2, 1);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, 2, 1, 0))).toBeLessThan(1e-5);
  });

  it('cross-attention kvLen ≠ qLen (decoder rows over encoder keys)', async () => {
    const [qLen, kvLen] = [5, 13];
    const q = randArr(qLen * qw, 10);
    const [k, v] = [randArr(kvLen * qw, 11), randArr(kvLen * qw, 12)];
    const out = await runAttn(q, k, v, qLen, kvLen, geo, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, qLen, kvLen, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('GQA 8:2 matches the grouped reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 2, headDim: 8 };
    const T = 6;
    const q = randArr(T * g.qHeads * g.headDim, 13);
    const [k, v] = [randArr(T * g.kvHeads * g.headDim, 14), randArr(T * g.kvHeads * g.headDim, 15)];
    const out = await runAttn(q, k, v, T, T, g, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, g, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('incremental decode: per-row qLen=1 + offset equals the full causal pass', async () => {
    // The KV-cache golden property: row t of a full causal run must equal a
    // qLen=1 query at qPosOffset=t over the first t+1 keys.
    const T = 7;
    const [q, k, v] = [randArr(T * qw, 16), randArr(T * qw, 17), randArr(T * qw, 18)];
    const full = await runAttn(q, k, v, T, T, geo, BIG, 0);
    for (const t of [0, 3, T - 1]) {
      const qRow = q.slice(t * qw, (t + 1) * qw);
      const kPrefix = k.slice(0, (t + 1) * qw);
      const vPrefix = v.slice(0, (t + 1) * qw);
      const step = await runAttn(qRow, kPrefix, vPrefix, 1, t + 1, geo, BIG, 0, t);
      expect(maxAbsDiff(step, full.slice(t * qw, (t + 1) * qw))).toBeLessThan(1e-5);
    }
  });

  it('empty band writes zeros (kernel guard, no NaN/Inf)', async () => {
    // qPos = 5, 6 with a (0, 0) band over kvLen = 3 keys: nothing visible.
    const g: Geo = { qHeads: 4, kvHeads: 4, headDim: 8 };
    const qLen = 2;
    const kvLen = 3;
    const w = g.qHeads * g.headDim;
    const out = await runAttn(
      randArr(qLen * w, 19),
      randArr(kvLen * w, 20),
      randArr(kvLen * w, 21),
      qLen,
      kvLen,
      g,
      0,
      0,
      5,
    );
    expect(out.every((x) => x === 0)).toBe(true);
  });

  it('sinks + full window matches the f64 reference', async () => {
    const T = 9;
    const [q, k, v] = [randArr(T * qw, 22), randArr(T * qw, 23), randArr(T * qw, 24)];
    const sinks = randArr(geo.qHeads, 25);
    const out = await runAttn(q, k, v, T, T, geo, BIG, BIG, 0, sinks);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, BIG, 0, sinks))).toBeLessThan(1e-5);
  });

  it('sinks + asymmetric band + GQA matches the f64 reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 2, headDim: 8 };
    const T = 10;
    const q = randArr(T * g.qHeads * g.headDim, 26);
    const [k, v] = [randArr(T * g.kvHeads * g.headDim, 27), randArr(T * g.kvHeads * g.headDim, 28)];
    const sinks = randArr(g.qHeads, 29);
    const out = await runAttn(q, k, v, T, T, g, 3, 1, 0, sinks);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, g, 3, 1, 0, sinks))).toBeLessThan(1e-5);
  });
});

async function runRows(
  qData: Float32Array,
  kData: Float32Array,
  vData: Float32Array,
  qLen: number,
  kvLen: number,
  geo: Geo,
  windowLeft: number,
  windowRight: number,
  qPosOffset = 0,
  sinksData?: Float32Array,
): Promise<Float32Array> {
  const root = await getRoot();
  const q = uploadF32(root, qData);
  const k = uploadF32(root, kData);
  const v = uploadF32(root, vData);
  const out = uploadF32(root, new Float32Array(qLen * geo.qHeads * geo.headDim));
  const sinks = sinksData ? uploadF32(root, sinksData) : undefined;
  const pipeline = createAttnRowsPipeline(root, {
    ...geo,
    windowLeft,
    windowRight,
    hasSinks: sinksData ? 1 : 0,
    hasSegs: 0,
  });
  const handle = attnRowsHandle(
    root,
    pipeline,
    { qLen, kvLen, qPosOffset, qHeads: geo.qHeads },
    { q, k, v, out, sinks, dummyF32: q },
  );
  runHandles(root, [handle]);
  await root.device.queue.onSubmittedWorkDone();
  return Float32Array.from(await out.read());
}

describe('register-resident row attn kernel on GPU (qLen > 1)', () => {
  // Sizes cross both staging boundaries: 150 rows = two full 64-row tiles
  // plus a 22-row tail; at headDim 16 a K/V chunk holds 112 keys, so 150
  // keys also need two chunks.
  const geo: Geo = { qHeads: 4, kvHeads: 4, headDim: 16 };
  const qw = geo.qHeads * geo.headDim;

  it('full bidirectional square over tile and chunk tails matches the f64 reference', async () => {
    const T = 150;
    const [q, k, v] = [randArr(T * qw, 40), randArr(T * qw, 41), randArr(T * qw, 42)];
    const out = await runRows(q, k, v, T, T, geo, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('Moonshine-tiny geometry square matches the f64 reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 8, headDim: 36 }; // 49 keys per chunk
    const T = 130;
    const w = g.qHeads * g.headDim;
    const [q, k, v] = [randArr(T * w, 43), randArr(T * w, 44), randArr(T * w, 45)];
    const out = await runRows(q, k, v, T, T, g, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, g, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('causal band masks the future inside chunks', async () => {
    const T = 100;
    const [q, k, v] = [randArr(T * qw, 46), randArr(T * qw, 47), randArr(T * qw, 48)];
    const out = await runRows(q, k, v, T, T, geo, BIG, 0);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, 0, 0))).toBeLessThan(1e-5);
  });

  it('narrow sliding window leaves off-band chunk keys unused', async () => {
    const T = 90;
    const [q, k, v] = [randArr(T * qw, 49), randArr(T * qw, 50), randArr(T * qw, 51)];
    const out = await runRows(q, k, v, T, T, geo, 2, 1);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, 2, 1, 0))).toBeLessThan(1e-5);
  });

  it('cross-attention with qPosOffset over kvLen ≠ qLen matches', async () => {
    const [qLen, kvLen, off] = [70, 140, 30];
    const q = randArr(qLen * qw, 52);
    const [k, v] = [randArr(kvLen * qw, 53), randArr(kvLen * qw, 54)];
    const out = await runRows(q, k, v, qLen, kvLen, geo, BIG, BIG, off);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, qLen, kvLen, geo, BIG, BIG, off))).toBeLessThan(1e-5);
  });

  it('GQA 8:2 matches the grouped reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 2, headDim: 8 };
    const T = 100;
    const q = randArr(T * g.qHeads * g.headDim, 55);
    const [k, v] = [randArr(T * g.kvHeads * g.headDim, 56), randArr(T * g.kvHeads * g.headDim, 57)];
    const out = await runRows(q, k, v, T, T, g, BIG, BIG);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, g, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('sinks + band matches the f64 reference', async () => {
    const T = 80;
    const [q, k, v] = [randArr(T * qw, 58), randArr(T * qw, 59), randArr(T * qw, 60)];
    const sinks = randArr(geo.qHeads, 61);
    const out = await runRows(q, k, v, T, T, geo, 5, 2, 0, sinks);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, 5, 2, 0, sinks))).toBeLessThan(1e-5);
  });

  it('agrees with the thread-per-row kernel to f32 reassociation tolerance', async () => {
    const T = 96;
    const [q, k, v] = [randArr(T * qw, 62), randArr(T * qw, 63), randArr(T * qw, 64)];
    const rows = await runRows(q, k, v, T, T, geo, BIG, BIG);
    const batch = await runAttn(q, k, v, T, T, geo, BIG, BIG);
    expect(maxAbsDiff(rows, batch)).toBeLessThan(1e-5);
  });
});

async function runRowsSplit(
  qData: Float32Array,
  kData: Float32Array,
  vData: Float32Array,
  qLen: number,
  kvLen: number,
  geo: Geo,
  windowLeft: number,
  windowRight: number,
  chunks: number,
  qPosOffset = 0,
  sinksData?: Float32Array,
): Promise<Float32Array> {
  const root = await getRoot();
  const q = uploadF32(root, qData);
  const k = uploadF32(root, kData);
  const v = uploadF32(root, vData);
  const out = uploadF32(root, new Float32Array(qLen * geo.qHeads * geo.headDim));
  const sinks = sinksData ? uploadF32(root, sinksData) : undefined;
  const partials = uploadF32(
    root,
    new Float32Array(qLen * geo.qHeads * ATTN_ROWS_MAX_CHUNKS * (2 + geo.headDim)),
  );
  const cfg = { ...geo, windowLeft, windowRight, hasSinks: sinksData ? 1 : 0, hasSegs: 0 };
  const handles = attnRowsSplitHandles(
    root,
    createAttnRowsSplitPipeline(root, cfg),
    createAttnRowsMergePipeline(root, cfg),
    { qLen, kvLen, qPosOffset, qHeads: geo.qHeads, chunks },
    { q, k, v, out, partials, sinks, dummyF32: q },
  );
  runHandles(root, handles);
  await root.device.queue.onSubmittedWorkDone();
  return Float32Array.from(await out.read());
}

describe('key-split row attn pair on GPU (qLen > 1, long key ranges)', () => {
  const geo: Geo = { qHeads: 4, kvHeads: 4, headDim: 16 };
  const qw = geo.qHeads * geo.headDim;

  it('full bidirectional square over 4 chunks matches the f64 reference', async () => {
    const T = 300;
    const [q, k, v] = [randArr(T * qw, 70), randArr(T * qw, 71), randArr(T * qw, 72)];
    const out = await runRowsSplit(q, k, v, T, T, geo, BIG, BIG, 4);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('Moonshine-tiny geometry square matches the f64 reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 8, headDim: 36 };
    const T = 200;
    const w = g.qHeads * g.headDim;
    const [q, k, v] = [randArr(T * w, 73), randArr(T * w, 74), randArr(T * w, 75)];
    const out = await runRowsSplit(q, k, v, T, T, g, BIG, BIG, 3);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, g, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('causal band with qPosOffset matches across chunk slices', async () => {
    const [qLen, kvLen, off] = [150, 280, 100];
    const q = randArr(qLen * qw, 76);
    const [k, v] = [randArr(kvLen * qw, 77), randArr(kvLen * qw, 78)];
    const out = await runRowsSplit(q, k, v, qLen, kvLen, geo, BIG, 0, 4, off);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, qLen, kvLen, geo, BIG, 0, off))).toBeLessThan(1e-5);
  });

  it('sink seed in chunk 0 matches the sink reference', async () => {
    const T = 160;
    const [q, k, v] = [randArr(T * qw, 79), randArr(T * qw, 80), randArr(T * qw, 81)];
    const sinks = randArr(geo.qHeads, 82);
    const out = await runRowsSplit(q, k, v, T, T, geo, BIG, BIG, 3, 0, sinks);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, BIG, 0, sinks))).toBeLessThan(1e-5);
  });

  it('GQA 8:2 matches the grouped reference', async () => {
    const g: Geo = { qHeads: 8, kvHeads: 2, headDim: 8 };
    const T = 220;
    const q = randArr(T * g.qHeads * g.headDim, 83);
    const [k, v] = [randArr(T * g.kvHeads * g.headDim, 84), randArr(T * g.kvHeads * g.headDim, 85)];
    const out = await runRowsSplit(q, k, v, T, T, g, BIG, BIG, 4);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, g, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('more chunks than keys leaves the extra slices empty and still matches', async () => {
    const T = 70;
    const [q, k, v] = [randArr(T * qw, 86), randArr(T * qw, 87), randArr(T * qw, 88)];
    const out = await runRowsSplit(q, k, v, T, T, geo, BIG, BIG, ATTN_ROWS_MAX_CHUNKS);
    expect(maxAbsDiff(out, cpuAttn(q, k, v, T, T, geo, BIG, BIG, 0))).toBeLessThan(1e-5);
  });

  it('empty-band rows write zeros through the pair (no u32 slice wrap)', async () => {
    // qPos = 400… with a (0, 0) band over kvLen = 300 keys: nothing visible for
    // any row. Every chunk must publish an empty partial, not a wrapped
    // slice of real keys.
    const [qLen, kvLen, off] = [70, 300, 400];
    const out = await runRowsSplit(
      randArr(qLen * qw, 92),
      randArr(kvLen * qw, 93),
      randArr(kvLen * qw, 94),
      qLen,
      kvLen,
      geo,
      0,
      0,
      4,
      off,
    );
    expect(out.every((x) => x === 0)).toBe(true);
  });

  it('agrees with the unsplit row kernel to f32 reassociation tolerance', async () => {
    const T = 256;
    const [q, k, v] = [randArr(T * qw, 89), randArr(T * qw, 90), randArr(T * qw, 91)];
    const pair = await runRowsSplit(q, k, v, T, T, geo, BIG, BIG, 4);
    const single = await runRows(q, k, v, T, T, geo, BIG, BIG);
    expect(maxAbsDiff(pair, single)).toBeLessThan(1e-5);
  });
});
