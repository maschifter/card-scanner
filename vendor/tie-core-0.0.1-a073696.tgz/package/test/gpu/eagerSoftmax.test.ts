import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { softmax, matrix, materialized, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

function cpuSoftmaxRows(x: Float32Array, rows: number, cols: number): Float32Array {
  const out = new Float32Array(rows * cols);
  for (let i = 0; i < rows; i++) {
    const base = i * cols;
    let m = -Infinity;
    for (let j = 0; j < cols; j++) m = Math.max(m, x[base + j]!);
    let sum = 0;
    for (let j = 0; j < cols; j++) sum += Math.exp(x[base + j]! - m);
    for (let j = 0; j < cols; j++) out[base + j] = Math.exp(x[base + j]! - m) / sum;
  }
  return out;
}

describe('eager softmax on GPU', () => {
  it('matches CPU row-wise softmax for [3,5]', async () => {
    const root = await tgpu.init();
    const R = 3;
    const C = 5;
    const xData = new Float32Array(R * C).map((_, i) => ((i * 7) % 11) - 5);
    const x = materialized(matrix(R, C), uploadF32(root, xData));
    const out = await toArray(softmax(x), gpuExecutor(root));
    const ref = cpuSoftmaxRows(xData, R, C);
    for (let i = 0; i < R * C; i++) expect(out[i]).toBeCloseTo(ref[i]!, 5);
    for (let i = 0; i < R; i++) {
      let s = 0;
      for (let j = 0; j < C; j++) s += out[i * C + j]!;
      expect(s).toBeCloseTo(1, 5);
    }
  });
});
