/** Micro-benchmark for matmulGatherQuantW at realistic MoE dims (M=70 tokens,
 *  K=N=640, E=128, int8/g640). Isolates the gather-matmul kernel so layout /
 *  vectorization experiments can be A/B'd against it WITHOUT full integration.
 *  Timing-only tests use arbitrary weight bits (layout-independent). History of
 *  measured experiments (see git log for the kernels/tests):
 *    - vec4-over-N, N-contiguous rows (original): ~5.7ms per [70,640] gather
 *    - vec4-over-K, 1 col/thread, K-contiguous (WK): ~4.25ms (1.35×)
 *    - batching the 4 top-expert slots into one [280,640] dispatch: 0.96× (dud —
 *      M=70 already saturates; the win is per-thread ILP, not thread count)
 *    - fused switchGlu on N-contiguous layout: 0.89× (dud — fusion without the
 *      right inner loop loses to 96 independent dispatches)
 *    - blocked-unit + 4 cols/thread + x-reuse (WB): ~2.4ms (2.38×) — NOW the
 *      real matmulGatherQuantW layout (kernels/quantCommon.ts).
 *  Reports min/median ms over N warm dispatches. */

import { describe, expect, it } from 'vitest';
import { getRoot } from './harness.ts';
import { uploadF32, uploadU32 } from '../../src/gpu/buffers.ts';
import {
  createMatmulGatherQuantWPipeline,
  matmulGatherQuantWHandle,
} from '../../src/kernels/matmul/matmulGatherQuantW.ts';
import type { KernelHandle } from '../../src/kernels/common.ts';

const M = 70; // tokens
const K = 640; // H
const N = 640;
const E = 128;
const RUNS = 50;

function stats(xs: number[]) {
  const s = [...xs].sort((a, b) => a - b);
  return { min: s[0]!, median: s[Math.floor(s.length / 2)]! };
}

describe('matmulGatherQuantW micro-benchmark (int8, realistic dims)', () => {
  it('times the gather kernel over many dispatches', async () => {
    const root = await getRoot();
    // arbitrary weight bits — timing only, layout-independent.
    const words = new Uint32Array((E * K * N) / 4);
    for (let i = 0; i < words.length; i++) words[i] = (i * 2654435761) >>> 0;
    const scales = new Float32Array(E * N).fill(0.01);
    const bias = new Float32Array(E * N).fill(0);
    const a = new Float32Array(M * K).fill(0.1);
    const expertIdx = new Float32Array(M);
    for (let i = 0; i < M; i++) expertIdx[i] = i % E;

    const pipeline = createMatmulGatherQuantWPipeline(root, {
      k: K,
      n: N,
      bits: 8,
      groupSize: 640,
    });
    const buffers = {
      a: uploadF32(root, a),
      w: uploadU32(root, words),
      scales: uploadF32(root, scales),
      bias: uploadF32(root, bias),
      expertIdx: uploadF32(root, expertIdx),
      out: uploadF32(root, new Float32Array(M * N)),
    };
    const handle: KernelHandle = matmulGatherQuantWHandle(root, pipeline, { m: M, n: N }, buffers);

    // Batch BATCH dispatches into ONE submit (amortizes submit/sync overhead,
    // like the real forward); time the whole thing / BATCH = per-kernel GPU ms.
    const BATCH = 96; // ~ the MoE's gather matmuls per forward (12/block × 8)
    const runBatch = async () => {
      const enc = root.device.createCommandEncoder();
      const pass = enc.beginComputePass();
      for (let i = 0; i < BATCH; i++)
        handle.pipeline
          .with(pass)
          .with(handle.bindGroup)
          .dispatchWorkgroups(handle.workgroups as number);
      pass.end();
      root.device.queue.submit([enc.finish()]);
      await root.device.queue.onSubmittedWorkDone();
    };

    await runBatch(); // warm
    const ms: number[] = [];
    for (let i = 0; i < RUNS; i++) {
      const t = performance.now();
      await runBatch();
      ms.push((performance.now() - t) / BATCH);
    }
    const s = stats(ms);
    console.log(
      `\n=== [blocked-unit, current] matmulGatherQuantW (M=${M},K=${K},N=${N},E=${E}), ${BATCH}/submit ===\n` +
        `per-kernel: min ${s.min.toFixed(3)}ms  median ${s.median.toFixed(3)}ms  (×96 ≈ MoE forward)\n`,
    );
    expect(s.min).toBeGreaterThan(0);
  }, 900_000);

  it('batched gather: M=280 (×24) vs M=70 (×96) — same FLOPs, current kernel', async () => {
    const root = await getRoot();
    const words = new Uint32Array((E * K * N) / 4);
    for (let i = 0; i < words.length; i++) words[i] = (i * 2654435761) >>> 0;
    const scales = new Float32Array(E * N).fill(0.01);
    const bias = new Float32Array(E * N).fill(0);
    const pipeline = createMatmulGatherQuantWPipeline(root, {
      k: K,
      n: N,
      bits: 8,
      groupSize: 640,
    });

    // Build a handle for a given row count Mrows.
    const mkHandle = (Mrows: number): KernelHandle => {
      const a = new Float32Array(Mrows * K).fill(0.1);
      const expertIdx = new Float32Array(Mrows);
      for (let i = 0; i < Mrows; i++) expertIdx[i] = i % E;
      return matmulGatherQuantWHandle(
        root,
        pipeline,
        { m: Mrows, n: N },
        {
          a: uploadF32(root, a),
          w: uploadU32(root, words),
          scales: uploadF32(root, scales),
          bias: uploadF32(root, bias),
          expertIdx: uploadF32(root, expertIdx),
          out: uploadF32(root, new Float32Array(Mrows * N)),
        },
      );
    };

    const timeIt = async (handle: KernelHandle, dispatches: number) => {
      const runBatch = async () => {
        const enc = root.device.createCommandEncoder();
        const pass = enc.beginComputePass();
        for (let i = 0; i < dispatches; i++)
          handle.pipeline
            .with(pass)
            .with(handle.bindGroup)
            .dispatchWorkgroups(handle.workgroups as number);
        pass.end();
        root.device.queue.submit([enc.finish()]);
        await root.device.queue.onSubmittedWorkDone();
      };
      await runBatch();
      const ms: number[] = [];
      for (let i = 0; i < RUNS; i++) {
        const t = performance.now();
        await runBatch();
        ms.push(performance.now() - t);
      }
      return stats(ms);
    };

    // 4T tokens routed = 280 rows. Current: 4 slots × [70,N] = 96 dispatches/fwd.
    // Batched: 1 × [280,N] = 24 dispatches/fwd. Same total rows either way.
    const looped = await timeIt(mkHandle(M), 96); // 96 × [70,640]
    const batched = await timeIt(mkHandle(M * 4), 24); // 24 × [280,640]
    console.log(
      `\n=== batched-gather A/B (MoE-equivalent total work per forward) ===\n` +
        `looped   96×[70,640]:  min ${looped.min.toFixed(2)}ms  median ${looped.median.toFixed(2)}ms\n` +
        `batched  24×[280,640]: min ${batched.min.toFixed(2)}ms  median ${batched.median.toFixed(2)}ms\n` +
        `speedup (min): ${(looped.min / batched.min).toFixed(2)}×\n`,
    );
    expect(batched.min).toBeGreaterThan(0);
  }, 900_000);
});
