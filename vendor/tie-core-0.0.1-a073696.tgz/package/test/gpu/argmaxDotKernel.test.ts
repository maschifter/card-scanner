import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  argmaxDot,
  gpuExecutor,
  materialized,
  matrix,
  toArray,
  uploadF32,
} from '../../src/index.ts';

/** Suite for the fused gemv+argmax kernel, driven through the op + executor
 *  (the incremental-decode path). Cases cover clusters scanning multiple rows
 *  (row counts past one grid step), ties meeting in every merge stage, and a
 *  width the lane count does not divide; ties pin the lowest-index contract
 *  (torch.argmax parity). */

/** Seeded RNG so failures reproduce (same generator as zoo's cpuRefs). */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

/** f64 reference: argmax over w[rows,cols] · x, strict > (lowest index wins). */
function cpuArgmaxDot(w: Float32Array, x: Float32Array, rows: number, cols: number): number {
  let best = -Infinity;
  let bi = 0;
  for (let r = 0; r < rows; r++) {
    let dot = 0;
    for (let j = 0; j < cols; j++) dot += w[r * cols + j]! * x[j]!;
    if (dot > best) {
      best = dot;
      bi = r;
    }
  }
  return bi;
}

async function runArgmaxDot(
  wData: Float32Array,
  xData: Float32Array,
  rows: number,
  cols: number,
): Promise<number> {
  const root = await tgpu.init();
  const w = materialized(matrix(rows, cols), uploadF32(root, wData));
  const x = materialized(matrix(1, cols), uploadF32(root, xData));
  const out = await toArray(argmaxDot(w, x), gpuExecutor(root));
  return out[0]!;
}

describe('fused gemv+argmax on GPU', () => {
  it('matches the f64 reference over 5000 strided rows', async () => {
    const [rows, cols] = [5000, 64];
    const w = randArr(rows * cols, 1);
    const x = randArr(cols, 2);
    expect(await runArgmaxDot(w, x, rows, cols)).toBe(cpuArgmaxDot(w, x, rows, cols));
  });

  it('matches at Moonshine width (d = 288)', async () => {
    const [rows, cols] = [1000, 288];
    const w = randArr(rows * cols, 3);
    const x = randArr(cols, 4);
    expect(await runArgmaxDot(w, x, rows, cols)).toBe(cpuArgmaxDot(w, x, rows, cols));
  });

  it('breaks exact ties toward the LOWEST row index', async () => {
    const [rows, cols] = [600, 16];
    const w = randArr(rows * cols, 5).map((v) => v * 0.01);
    const x = randArr(cols, 6);
    // Same bits → same dot. Rows 100 and 400 land in different workgroups
    // (row / 32 = 3 vs 12), so the equal pair meets in the reduce pass — the
    // tie-break must pick 100.
    const winner = Float32Array.from({ length: cols }, (_, j) => Math.sign(x[j]!) * 10);
    w.set(winner, 100 * cols);
    w.set(winner, 400 * cols);
    expect(await runArgmaxDot(w, x, rows, cols)).toBe(100);
  });

  it('finds winners at both edge rows', async () => {
    const [rows, cols] = [300, 8];
    const x = randArr(cols, 7);
    const boost = Float32Array.from({ length: cols }, (_, j) => Math.sign(x[j]!) * 5);
    for (const target of [0, rows - 1]) {
      const w = randArr(rows * cols, 8 + target);
      w.set(boost, target * cols);
      expect(await runArgmaxDot(w, x, rows, cols)).toBe(target);
    }
  });

  it('breaks ties toward the lowest index when both rows land on ONE thread', async () => {
    // Rows one grid step (4096) apart share a (workgroup, cluster) slot, so
    // the tie resolves inside one thread's strict > scan — increasing row
    // order keeps the lower index — and never reaches either merge stage.
    const [rows, cols] = [5000, 16];
    const w = randArr(rows * cols, 9).map((v) => v * 0.01);
    const x = randArr(cols, 10);
    const winner = Float32Array.from({ length: cols }, (_, j) => Math.sign(x[j]!) * 10);
    w.set(winner, 300 * cols);
    w.set(winner, 4396 * cols);
    expect(await runArgmaxDot(w, x, rows, cols)).toBe(300);
  });

  it('breaks ties toward the lowest index inside one workgroup merge', async () => {
    // Rows 5 and 20 sit in workgroup 0 on clusters 5 and 20, so the equal
    // pair meets in the workgroup's 32-way serial merge — it must pick 5.
    const [rows, cols] = [600, 16];
    const w = randArr(rows * cols, 13).map((v) => v * 0.01);
    const x = randArr(cols, 14);
    const winner = Float32Array.from({ length: cols }, (_, j) => Math.sign(x[j]!) * 10);
    w.set(winner, 5 * cols);
    w.set(winner, 20 * cols);
    expect(await runArgmaxDot(w, x, rows, cols)).toBe(5);
  });

  it('matches the f64 reference at a width no lane count divides', async () => {
    const [rows, cols] = [700, 37];
    const w = randArr(rows * cols, 11);
    const x = randArr(cols, 12);
    expect(await runArgmaxDot(w, x, rows, cols)).toBe(cpuArgmaxDot(w, x, rows, cols));
  });
});
