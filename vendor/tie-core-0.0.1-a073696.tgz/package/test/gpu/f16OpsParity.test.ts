/** f16 parity sweep for the ops that had no per-kernel f16 test: softmax,
 *  mean, topk, astype, transpose, concat, sub, mul, swiglu and every unary
 *  activation. (conv1d, add, layerNorm, matmul, gatherRows and attention are
 *  already covered elsewhere — see f16Kernels/f16DecodeKernels/f16Matmul.)
 *
 *  Both arms read the SAME numbers: the f32 arm's operands are pre-rounded
 *  through f16, so the only difference is that the f16 arm computes and
 *  stores at half width. Pure moves (transpose, astype) must match EXACTLY;
 *  anything that computes is compared at f16 resolution. */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import {
  add,
  asinh,
  astype,
  cat,
  clamp,
  f16BitsToF32,
  f32ArrayToF16Bits,
  gelu,
  gpuExecutor,
  materialized,
  matrix,
  mean,
  mul,
  rsqrt,
  sigmoid,
  silu,
  softmax,
  sub,
  swiglu,
  tanh,
  toArray,
  topk,
  transpose,
  uploadF16,
  uploadF32,
  type Value,
} from '../../src/index.ts';

let rootPromise: Promise<TgpuRoot> | undefined;
const getRoot = (): Promise<TgpuRoot> =>
  (rootPromise ??= tgpu.init({ device: { optionalFeatures: ['shader-f16'] } }));

/** The same numbers as an f32 Value and an f16 Value: fill(i) is rounded
 *  through f16 first, so both arms start from bit-identical operands. */
function pair(root: TgpuRoot, rows: number, cols: number, fill: (i: number) => number) {
  const raw = new Float32Array(rows * cols).map((_, i) => fill(i));
  const bits = f32ArrayToF16Bits(raw).data;
  const rounded = Float32Array.from(bits, (b) => f16BitsToF32(b));
  return {
    f16: materialized(
      { elems: rows * cols, dtype: 'f16' as const, dims: [rows, cols] },
      uploadF16(root, bits),
    ),
    f32: materialized(matrix(rows, cols), uploadF32(root, rounded)),
  };
}

const run = (root: TgpuRoot, v: Value) => toArray(v, gpuExecutor(root));

function expectF16Close(got: Float32Array, want: Float32Array, label: string): void {
  expect(got.length).toBe(want.length);
  let worst = 0;
  let at = -1;
  for (let i = 0; i < want.length; i++) {
    const rel = Math.abs(got[i]! - want[i]!) / Math.max(1, Math.abs(want[i]!));
    if (rel > worst) {
      worst = rel;
      at = i;
    }
  }
  expect(worst, `${label}: worst relative diff at ${at} (${got[at]} vs ${want[at]})`).toBeLessThan(
    5e-3,
  );
}

const wave = (scale: number, seed: number) => (i: number) => Math.sin(i * 0.37 + seed) * scale;
const positive = (seed: number) => (i: number) => Math.sin(i * 0.37 + seed) * 0.4 + 0.6; // stays > 0, safe for rsqrt

interface Case {
  name: string;
  arity: 1 | 2;
  fill: (seed: number) => (i: number) => number;
  build: (v: Value[]) => Value;
}

const CASES: Case[] = [
  { name: 'softmax', arity: 1, fill: wave.bind(null, 3), build: ([x]) => softmax(x!) },
  { name: 'mean', arity: 1, fill: wave.bind(null, 3), build: ([x]) => mean(x!) },
  { name: 'transpose', arity: 1, fill: wave.bind(null, 3), build: ([x]) => transpose(x!) },
  { name: 'sub', arity: 2, fill: wave.bind(null, 3), build: ([a, b]) => sub(a!, b!) },
  { name: 'mul', arity: 2, fill: wave.bind(null, 3), build: ([a, b]) => mul(a!, b!) },
  { name: 'swiglu', arity: 2, fill: wave.bind(null, 3), build: ([g, l]) => swiglu(g!, l!) },
  { name: 'concatRows', arity: 2, fill: wave.bind(null, 3), build: ([a, b]) => cat([a!, b!], 0) },
  { name: 'concatCols', arity: 2, fill: wave.bind(null, 3), build: ([a, b]) => cat([a!, b!], 1) },
  { name: 'rsqrt', arity: 1, fill: positive, build: ([x]) => rsqrt(x!) },
  { name: 'sigmoid', arity: 1, fill: wave.bind(null, 3), build: ([x]) => sigmoid(x!) },
  { name: 'tanh', arity: 1, fill: wave.bind(null, 3), build: ([x]) => tanh(x!) },
  { name: 'gelu', arity: 1, fill: wave.bind(null, 3), build: ([x]) => gelu(x!) },
  { name: 'silu', arity: 1, fill: wave.bind(null, 3), build: ([x]) => silu(x!) },
  { name: 'asinh', arity: 1, fill: wave.bind(null, 3), build: ([x]) => asinh(x!) },
  { name: 'clampScalar', arity: 1, fill: wave.bind(null, 3), build: ([x]) => clamp(x!, -0.3, 0.3) },
  { name: 'addScalar', arity: 1, fill: wave.bind(null, 3), build: ([x]) => add(x!, 0.1) },
  { name: 'mulScalar', arity: 1, fill: wave.bind(null, 3), build: ([x]) => mul(x!, 1.7) },
];

describe('f16 ops parity sweep', () => {
  it.each(CASES)('$name matches the f32 op', async ({ name, arity, fill, build }) => {
    const root = await getRoot();
    const [rows, cols] = [6, 16];
    const a = pair(root, rows, cols, fill(1));
    const b = arity === 2 ? pair(root, rows, cols, fill(2)) : undefined;
    const got = await run(root, build(b ? [a.f16, b.f16] : [a.f16]));
    const want = await run(root, build(b ? [a.f32, b.f32] : [a.f32]));
    expectF16Close(got, want, name);
  });

  it('topk: ids match exactly, weights match at f16 resolution', async () => {
    const root = await getRoot();
    const [T, E] = [12, 8];
    // Columns spaced 2 apart so f16 rounding (~1e-3 relative near these
    // magnitudes) never reorders the top-4 — a routing flip would fail this
    // test for a reason unrelated to the kernel under test.
    const logits = pair(root, T, E, (i) => ((i * 7919) % E) * 2 - E);
    const got = await run(root, topk(logits.f16, 4));
    const want = await run(root, topk(logits.f32, 4));
    const idsGot = got.filter((_, i) => i % 8 < 4);
    const idsWant = want.filter((_, i) => i % 8 < 4);
    expect(idsGot).toEqual(idsWant);
    const wGot = got.filter((_, i) => i % 8 >= 4);
    const wWant = want.filter((_, i) => i % 8 >= 4);
    expectF16Close(Float32Array.from(wGot), Float32Array.from(wWant), 'topk weights');
  });

  it('astype round-trips bit-exactly both ways', async () => {
    const root = await getRoot();
    const p = pair(root, 6, 16, wave(3, 5));
    const narrowed = await run(root, astype(p.f32, 'f16'));
    expect(narrowed).toEqual(await run(root, p.f16));
    const widened = await run(root, astype(p.f16, 'f32'));
    expect(widened).toEqual(await run(root, p.f32));
  });
});
