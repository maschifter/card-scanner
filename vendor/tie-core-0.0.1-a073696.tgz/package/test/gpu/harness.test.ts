import { describe, expect, it } from 'vitest';
import { getRoot, loadCaseMeta, loadCaseTensor } from './harness.ts';

describe('gpu harness', () => {
  it('has a WebGPU device', async () => {
    const root = await getRoot();
    expect(root.device).toBeDefined();
  });
  it('loads fixtures', async () => {
    const meta = await loadCaseMeta('email_short');
    const emb = await loadCaseTensor('email_short', meta, 'embeddings');
    expect(emb.shape[1]).toBe(640);
    expect(emb.data.length).toBe(emb.shape[0]! * 640);
  });
});
