import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { matrix, materialized, topk, gpuExecutor, toArray } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

function cpuTop4(logits: Float32Array, tokens: number, experts: number) {
  const out: { ids: number[]; w: number[] }[] = [];
  for (let t = 0; t < tokens; t++) {
    const vals = [-Infinity, -Infinity, -Infinity, -Infinity];
    const ids = [0, 0, 0, 0];
    for (let e = 0; e < experts; e++) {
      const v = logits[t * experts + e]!;
      if (v > vals[3]!) {
        vals[3] = v;
        ids[3] = e;
        for (let s = 3; s > 0 && vals[s]! > vals[s - 1]!; s--) {
          [vals[s], vals[s - 1]] = [vals[s - 1]!, vals[s]!];
          [ids[s], ids[s - 1]] = [ids[s - 1]!, ids[s]!];
        }
      }
    }
    const m = vals[0]!;
    const exps = vals.map((v) => Math.exp(v - m));
    const z = exps.reduce((s, v) => s + v, 0);
    out.push({ ids, w: exps.map((v) => v / z) });
  }
  return out;
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

describe('eager topk on GPU', () => {
  it('matches CPU top-4 + softmax on random [16,32] logits', async () => {
    const root = await tgpu.init();
    const T = 16,
      E = 32;
    const rng = mulberry32(99);
    const data = Float32Array.from({ length: T * E }, () => (rng() - 0.5) * 8);
    const x = materialized(matrix(T, E), uploadF32(root, data));
    const out = await toArray(topk(x, 4), gpuExecutor(root));
    const ref = cpuTop4(data, T, E);
    for (let t = 0; t < T; t++) {
      for (let s = 0; s < 4; s++) {
        expect(out[t * 8 + s]).toBe(ref[t]!.ids[s]!); // ids exact
        expect(out[t * 8 + 4 + s]).toBeCloseTo(ref[t]!.w[s]!, 5);
      }
    }
  });

  it('breaks ties by lowest index (torch.topk semantics)', async () => {
    const root = await tgpu.init();
    const T = 1,
      E = 8;
    const data = new Float32Array(E).fill(1); // all equal
    const x = materialized(matrix(T, E), uploadF32(root, data));
    const out = await toArray(topk(x, 4), gpuExecutor(root));
    expect(Array.from(out.slice(0, 4))).toEqual([0, 1, 2, 3]);
    for (let s = 0; s < 4; s++) expect(out[4 + s]).toBeCloseTo(0.25, 6);
  });
});
