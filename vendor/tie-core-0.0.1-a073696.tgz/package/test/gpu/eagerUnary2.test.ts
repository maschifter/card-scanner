import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  matrix,
  materialized,
  clamp,
  mul,
  sigmoid,
  sub,
  gpuExecutor,
  toArray,
} from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

describe('eager unary scalar ops on GPU', () => {
  it('sigmoid, scalar mul, clamp match CPU', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const data = Float32Array.from([-9, -1.5, 0, 0.5, 2, 8]);
    const x = materialized(matrix(2, 3), uploadF32(root, data));

    const sig = await toArray(sigmoid(x), ex);
    const scaled = await toArray(mul(x, 1.702), ex);
    const clm = await toArray(clamp(x, -7, 7), ex);
    const shifted = await toArray(sub(x, 0.5), ex);

    for (let i = 0; i < 6; i++) {
      expect(sig[i]).toBeCloseTo(1 / (1 + Math.exp(-data[i]!)), 6);
      expect(scaled[i]).toBeCloseTo(data[i]! * 1.702, 5);
      expect(clm[i]).toBe(Math.min(Math.max(data[i]!, -7), 7));
      expect(shifted[i]).toBeCloseTo(data[i]! - 0.5, 6);
    }
  });

  it('clamp one-sided (SwiGLU: -Infinity lo) clamps only above hi', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    // Values: very negative, negative, zero, just-below, just-above, well-above
    const data = Float32Array.from([-1e30, -8, 0, 6.9, 7.1, 100]);
    const x = materialized(matrix(2, 3), uploadF32(root, data));

    const clm = await toArray(clamp(x, -Infinity, 7), ex);

    // Values at or below 7 must be unchanged (including the very-negative -1e30)
    expect(clm[0]).toBe(data[0]!); // -1e30 unchanged
    expect(clm[1]).toBe(data[1]!); // -8 unchanged
    expect(clm[2]).toBe(data[2]!); // 0 unchanged
    expect(clm[3]).toBe(data[3]!); // 6.9 unchanged
    // Values above 7 must be clamped to 7
    expect(clm[4]).toBe(7); // 7.1 → 7
    expect(clm[5]).toBe(7); // 100 → 7
  });
});
