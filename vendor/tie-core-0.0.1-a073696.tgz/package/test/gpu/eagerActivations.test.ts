import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  asinh,
  gelu,
  materialized,
  matrix,
  silu,
  tanh,
  toArray,
  gpuExecutor,
} from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

const run = async (f: typeof tanh, data: Float32Array) => {
  const root = await tgpu.init();
  const x = materialized(matrix(1, data.length), uploadF32(root, data));
  return toArray(f(x), gpuExecutor(root));
};

describe('eager activation kernels on GPU', () => {
  it('tanh matches Math.tanh', async () => {
    const data = Float32Array.from([-5, -2, -0.5, 0, 0.3, 1, 4]);
    const out = await run(tanh, data);
    data.forEach((v, i) => expect(out[i]).toBeCloseTo(Math.tanh(v), 5));
  });

  it('asinh matches Math.asinh across magnitudes', async () => {
    const data = Float32Array.from([-100, -7.5, -1, -0.75, 0, 0.1, 0.75, 3, 100]);
    const out = await run(asinh, data);
    data.forEach((v, i) => expect(out[i]).toBeCloseTo(Math.asinh(v), 5));
  });

  it('silu matches x·σ(x), saturating cleanly at the tails', async () => {
    const data = Float32Array.from([-30, -4, -1, 0, 0.5, 2, 30]);
    const out = await run(silu, data);
    data.forEach((v, i) => expect(out[i]).toBeCloseTo(v / (1 + Math.exp(-v)), 5));
  });

  it('gelu matches exact x·Φ(x) at known normal-CDF fixture points', async () => {
    // Independent ground truth (standard normal CDF tables), NOT the kernel's
    // own erf polynomial — catches a mistranscribed coefficient.
    const cases: Array<[number, number]> = [
      [-4, -0.00012671], // −4·Φ(−4)
      [-2, -0.04550026],
      [-1, -0.15865525],
      [-0.5, -0.15426877],
      [0, 0],
      [0.5, 0.34573123],
      [1, 0.84134475],
      [2, 1.95449974],
      [4, 3.99987329],
    ];
    const out = await run(gelu, Float32Array.from(cases.map(([x]) => x)));
    cases.forEach(([, want], i) => expect(out[i]).toBeCloseTo(want, 5));
  });

  it('gelu tracks the f64 A&S polynomial across a random sweep', async () => {
    const N = 256;
    const data = Float32Array.from({ length: N }, (_, i) => (i / N) * 12 - 6);
    const out = await run(gelu, data);
    const erf = (z: number) => {
      const t = 1 / (1 + 0.3275911 * Math.abs(z));
      const poly =
        t *
        (0.254829592 +
          t * (-0.284496736 + t * (1.421413741 + t * (-1.453152027 + t * 1.061405429))));
      return Math.sign(z) * (1 - poly * Math.exp(-z * z));
    };
    for (let i = 0; i < N; i++) {
      const x = data[i]!;
      expect(out[i]).toBeCloseTo(0.5 * x * (1 + erf(x / Math.SQRT2)), 5);
    }
  });
});
