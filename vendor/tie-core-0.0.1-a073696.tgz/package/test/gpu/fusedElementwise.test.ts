import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  gpuExecutor,
  materialized,
  matrix,
  mul,
  rope,
  silu,
  swigluChunk,
  slice,
  toArray,
  uploadF32,
} from '../../src/index.ts';

/** Fused-vs-composed gates for the two elementwise fusions: rope through a
 *  column window (vs sliceCols → rope) and swigluChunk (vs sliceCols ×2 →
 *  silu → mul). Tight tolerance, not equality — different pipeline variants
 *  may FMA-contract differently. */

/** Seeded RNG so failures reproduce (same generator as zoo's cpuRefs). */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

const maxAbsDiff = (a: Float32Array, b: Float32Array) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

describe('rope column window on GPU', () => {
  it('windowed rope over the middle third equals sliceCols → rope', async () => {
    const [t, hd, qw] = [7, 12, 36]; // slab [7, 108], window = k section
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const slabData = randArr(t * 3 * qw, 1);
    const cosData = randArr(t * hd, 2);
    const sinData = randArr(t * hd, 3);
    const up = () => ({
      slab: materialized(matrix(t, 3 * qw), uploadF32(root, slabData)),
      cos: materialized(matrix(t, hd), uploadF32(root, cosData)),
      sin: materialized(matrix(t, hd), uploadF32(root, sinData)),
    });

    const f = up();
    const fused = await toArray(
      rope(f.slab, f.cos, f.sin, { headDim: hd, srcStart: qw, width: qw }),
      ex,
    );
    const c = up();
    const composed = await toArray(
      rope(slice(c.slab, 1, qw, 2 * qw), c.cos, c.sin, { headDim: hd }),
      ex,
    );
    expect(maxAbsDiff(fused, composed)).toBeLessThan(1e-6);
  });
});

describe('swigluChunk on GPU', () => {
  it('equals the sliceCols ×2 → silu → mul chain', async () => {
    const [t, ffn] = [5, 48];
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const hData = randArr(t * 2 * ffn, 4);
    const up = () => materialized(matrix(t, 2 * ffn), uploadF32(root, hData));

    const fused = await toArray(swigluChunk(up()), ex);
    const h = up();
    const hidden = slice(h, 1, 0, ffn);
    const gate = slice(h, 1, ffn, 2 * ffn);
    const composed = await toArray(mul(silu(gate), hidden), ex);
    expect(maxAbsDiff(fused, composed)).toBeLessThan(1e-6);
    expect(fused.length).toBe(t * ffn);
  });
});
