import tgpu, { d, type TgpuRoot } from 'typegpu';
import type { KernelHandle } from '../../src/kernels/common.ts';

let rootPromise: Promise<TgpuRoot> | undefined;

/** Shared root with elevated limits (expert buffers are ~105MB each).
 *  Requests subgroups so parity suites cover the executor's
 *  subgroup-cooperative attention route where the device has it, and
 *  timestamp-query so bench suites can read per-kernel GPU times. */
export function getRoot(): Promise<TgpuRoot> {
  rootPromise ??= tgpu.init({
    device: {
      optionalFeatures: ['subgroups', 'timestamp-query', 'shader-f16'],
      requiredLimits: {
        maxStorageBufferBindingSize: 134_217_728,
        maxBufferSize: 268_435_456,
        maxStorageBuffersPerShaderStage: 8,
      },
    },
  });
  return rootPromise;
}

/** Encode and submit a list of kernel dispatches as a single compute pass. */
export function runHandles(root: TgpuRoot, handles: KernelHandle[]): void {
  const encoder = root.device.createCommandEncoder();
  const pass = encoder.beginComputePass();
  for (const h of handles) {
    const p = h.pipeline.with(pass).with(h.bindGroup);
    if (typeof h.workgroups === 'number') p.dispatchWorkgroups(h.workgroups);
    else p.dispatchWorkgroups(h.workgroups[0], h.workgroups[1]);
  }
  pass.end();
  root.device.queue.submit([encoder.finish()]);
}

export interface FixtureTensor {
  shape: number[];
  data: Float32Array;
}

export interface CaseFixture {
  text: string;
  token_ids: number[];
  viterbi_labels: number[];
  spans: { label: string; start: number; end: number; text: string }[];
  expert_idx0: number[][];
  expert_w0: number[][];
  tensors: Record<string, { shape: number[]; file: string }>;
}

export async function loadCaseMeta(name: string): Promise<CaseFixture> {
  const res = await fetch(`/fixtures/cases/${name}/meta.json`);
  if (!res.ok) throw new Error(`fixture meta ${name}: ${res.status}`);
  return res.json();
}

export async function loadCaseTensor(
  name: string,
  meta: CaseFixture,
  tensor: string,
): Promise<FixtureTensor> {
  const entry = meta.tensors[tensor];
  if (!entry) throw new Error(`no tensor ${tensor}`);
  const res = await fetch(`/fixtures/cases/${name}/${entry.file}`);
  if (!res.ok) throw new Error(`fixture ${tensor}: ${res.status}`);
  return { shape: entry.shape, data: new Float32Array(await res.arrayBuffer()) };
}

interface WeightsManifest {
  [name: string]: { dtype: 'BF16' | 'F32'; shape: number[]; file: string };
}

let weightsManifest: Promise<WeightsManifest> | undefined;

export function getWeightsManifest(): Promise<WeightsManifest> {
  weightsManifest ??= fetch('/fixtures/weights/manifest.json').then((r) => {
    if (!r.ok) throw new Error(`weights manifest: ${r.status}`);
    return r.json();
  });
  return weightsManifest;
}

/** Raw checkpoint tensor bytes: BF16 → Uint16Array, F32 → Float32Array. */
export async function loadWeightRaw(
  name: string,
): Promise<{ dtype: 'BF16' | 'F32'; shape: number[]; bits: Uint16Array | Float32Array }> {
  const manifest = await getWeightsManifest();
  const entry = manifest[name];
  if (!entry) throw new Error(`no weight ${name}`);
  const buf = await (await fetch(`/fixtures/weights/${entry.file}`)).arrayBuffer();
  return {
    dtype: entry.dtype,
    shape: entry.shape,
    bits: entry.dtype === 'BF16' ? new Uint16Array(buf) : new Float32Array(buf),
  };
}

/** Upload a flat f32 array (length divisible by 4) as a vec4f storage buffer. */
export function writeVec4(root: TgpuRoot, data: Float32Array) {
  if (data.length % 4 !== 0) throw new Error(`length ${data.length} not divisible by 4`);
  const buf = root.createBuffer(d.arrayOf(d.vec4f, data.length / 4)).$usage('storage');
  // Raw write path needs an ArrayBuffer exactly sized to the buffer.
  buf.write(data.slice().buffer as ArrayBuffer);
  return buf;
}

/** Read a vec4f buffer back as a flat Float32Array, truncated to `length`. */
export async function readFlat(
  buf: { read(): Promise<d.v4f[]> },
  length: number,
): Promise<Float32Array> {
  const vecs = await buf.read();
  const flat = new Float32Array(vecs.length * 4);
  vecs.forEach((v, i) => {
    flat[i * 4] = v.x;
    flat[i * 4 + 1] = v.y;
    flat[i * 4 + 2] = v.z;
    flat[i * 4 + 3] = v.w;
  });
  return flat.subarray(0, length);
}

export function maxAbsDiff(a: ArrayLike<number>, b: ArrayLike<number>): number {
  if (a.length !== b.length) throw new Error(`length ${a.length} vs ${b.length}`);
  let max = 0;
  for (let i = 0; i < a.length; i++) max = Math.max(max, Math.abs(a[i]! - b[i]!));
  return max;
}

/** Mean absolute value — used to scale tolerance to activation magnitude. */
export function meanAbs(a: ArrayLike<number>): number {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += Math.abs(a[i]!);
  return sum / a.length;
}
