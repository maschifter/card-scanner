import { describe, expect, it } from 'vitest';
import tgpu, { d } from 'typegpu';
import { matmul, matrix, materialized, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32, readbackF32 } from '../../src/gpu/buffers.ts';
import type { F32Buffer } from '../../src/kernels/common.ts';
import { createMatmulPipeline, matmulHandle } from '../../src/kernels/matmul/matmul.ts';

describe('eager vs amortized (compile proxy)', () => {
  it('pre-built handle re-submit is not slower than full eager re-eval', async () => {
    const root = await tgpu.init();
    const M = 128;
    const K = 128;
    const N = 128;
    const aData = new Float32Array(M * K).fill(0.5);
    const bData = new Float32Array(K * N).fill(0.25);
    const TRIALS = 30;

    // Eager: rebuild DAG + bind groups + submit every trial.
    const ex = gpuExecutor(root);
    const eager = async () => {
      const a = materialized(matrix(M, K), uploadF32(root, aData));
      const b = materialized(matrix(K, N), uploadF32(root, bData));
      await toArray(matmul(a, b), ex);
    };
    await eager();
    const tE = performance.now();
    for (let i = 0; i < TRIALS; i++) await eager();
    const eagerMs = (performance.now() - tE) / TRIALS;

    // Amortized: build buffers + handle ONCE, re-submit each trial.
    const aBuf = uploadF32(root, aData) as F32Buffer;
    const bBuf = uploadF32(root, bData) as F32Buffer;
    const outBuf = root
      .createBuffer(d.arrayOf(d.f32, M * N))
      .$usage('storage') as unknown as F32Buffer;
    const pipeline = createMatmulPipeline(root, { k: K, n: N });
    const handle = matmulHandle(root, pipeline, M, N, { a: aBuf, b: bBuf, out: outBuf });
    const resubmit = async () => {
      const enc = root.device.createCommandEncoder();
      const pass = enc.beginComputePass();
      const p = handle.pipeline.with(pass).with(handle.bindGroup);
      const wg = handle.workgroups;
      if (typeof wg === 'number') p.dispatchWorkgroups(wg);
      else p.dispatchWorkgroups(wg[0], wg[1]);
      pass.end();
      root.device.queue.submit([enc.finish()]);
      await readbackF32(root, root.unwrap(outBuf), M * N);
    };
    await resubmit();
    const tA = performance.now();
    for (let i = 0; i < TRIALS; i++) await resubmit();
    const amortMs = (performance.now() - tA) / TRIALS;

    console.log(
      `[compile proxy] ${M}x${K}x${N}: eager=${eagerMs.toFixed(3)}ms amortized=${amortMs.toFixed(3)}ms overhead=${(eagerMs - amortMs).toFixed(3)}ms`,
    );
    expect(amortMs).toBeLessThanOrEqual(eagerMs + 0.5);
  });
});
