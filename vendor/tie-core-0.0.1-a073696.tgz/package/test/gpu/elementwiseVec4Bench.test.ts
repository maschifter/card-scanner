/** Scalar vs vec4 IO for a bandwidth-bound elementwise add — settles "should
 *  we vectorize the elementwise kernels" with a measurement. Coalesced scalar
 *  access should already sit on the bandwidth floor; vec4 only buys
 *  instruction-issue headroom. Raw WGSL to keep the two variants minimal. */

import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';

const SCALAR = /* wgsl */ `
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read_write> outb: array<f32>;
@group(0) @binding(3) var<uniform> total: u32;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= total) { return; }
  outb[i] = a[i] + b[i];
}`;

const VEC4 = /* wgsl */ `
@group(0) @binding(0) var<storage, read> a: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> b: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> outb: array<vec4<f32>>;
@group(0) @binding(3) var<uniform> total4: u32;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= total4) { return; }
  outb[i] = a[i] + b[i];
}`;

describe('elementwise add: scalar vs vec4 IO', () => {
  it('measures the per-kernel ratio at real tensor sizes', async () => {
    const root = await tgpu.init();
    const device = root.device;
    const S = GPUBufferUsage.STORAGE;
    // attention-map (yolo), LLM hidden row, big feature map
    const sizes = [51_200, 432_128, 3_276_800];
    const maxN = sizes[sizes.length - 1]!;
    const aBuf = device.createBuffer({ size: maxN * 4, usage: S | GPUBufferUsage.COPY_DST });
    const bBuf = device.createBuffer({ size: maxN * 4, usage: S | GPUBufferUsage.COPY_DST });
    const oBuf = device.createBuffer({ size: maxN * 4, usage: S });
    device.queue.writeBuffer(aBuf, 0, new Float32Array(1024).fill(1.5));
    device.queue.writeBuffer(bBuf, 0, new Float32Array(1024).fill(0.25));

    const mkPipe = async (code: string, totalVal: number) => {
      const pipe = await device.createComputePipelineAsync({
        layout: 'auto',
        compute: { module: device.createShaderModule({ code }), entryPoint: 'main' },
      });
      const tBuf = device.createBuffer({
        size: 4,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
      });
      device.queue.writeBuffer(tBuf, 0, new Uint32Array([totalVal]));
      const bg = device.createBindGroup({
        layout: pipe.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: { buffer: aBuf } },
          { binding: 1, resource: { buffer: bBuf } },
          { binding: 2, resource: { buffer: oBuf } },
          { binding: 3, resource: { buffer: tBuf } },
        ],
      });
      return { pipe, bg };
    };

    const time = async (p: Awaited<ReturnType<typeof mkPipe>>, workgroups: number) => {
      const runBatch = async (batch: number) => {
        const enc = device.createCommandEncoder();
        const pass = enc.beginComputePass();
        pass.setPipeline(p.pipe);
        pass.setBindGroup(0, p.bg);
        for (let i = 0; i < batch; i++) pass.dispatchWorkgroups(workgroups);
        pass.end();
        device.queue.submit([enc.finish()]);
        await device.queue.onSubmittedWorkDone();
      };
      await runBatch(10);
      const ms: number[] = [];
      for (let r = 0; r < 9; r++) {
        const t0 = performance.now();
        await runBatch(50);
        ms.push((performance.now() - t0) / 50);
      }
      return ms.sort((x, y) => x - y)[4]!;
    };

    let report = '\n=== elementwise add: scalar vs vec4 (median per-dispatch ms) ===\n';
    for (const n of sizes) {
      const sc = await mkPipe(SCALAR, n);
      const v4 = await mkPipe(VEC4, n / 4);
      const s1 = await time(sc, Math.ceil(n / 64));
      const w1 = await time(v4, Math.ceil(n / 4 / 64));
      const s2 = await time(sc, Math.ceil(n / 64));
      const w2 = await time(v4, Math.ceil(n / 4 / 64));
      const s = Math.min(s1, s2);
      const w = Math.min(w1, w2);
      const gbps = ((n * 12) / (s / 1000) / 1e9).toFixed(0);
      report += `${(n / 1000).toFixed(0)}k elems: scalar ${s.toFixed(4)}ms (${gbps} GB/s)  vec4 ${w.toFixed(4)}ms  ratio ${(s / w).toFixed(2)}×\n`;
    }
    console.log(report);
    expect(true).toBe(true);
  });
});
