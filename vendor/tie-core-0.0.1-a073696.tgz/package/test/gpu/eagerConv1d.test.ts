import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  add,
  conv1d,
  gelu,
  materialized,
  matrix,
  tanh,
  toArray,
  gpuExecutor,
} from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

/** Seeded RNG so failures reproduce (same generator as zoo's cpuRefs). */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const randArr = (n: number, seed: number) => {
  const r = mulberry32(seed);
  return Float32Array.from({ length: n }, () => r() * 2 - 1);
};

/** Exact f64 reference: time-major direct conv, w rows tap-major, zero
 *  padding on either side via skipped taps. */
function cpuConv1d(
  x: Float32Array,
  w: Float32Array,
  tIn: number,
  cIn: number,
  cOut: number,
  kernelSize: number,
  stride: number,
  padLeft = 0,
  padRight = 0,
): Float32Array {
  const tOut = Math.floor((tIn + padLeft + padRight - kernelSize) / stride) + 1;
  const out = new Float32Array(tOut * cOut);
  for (let f = 0; f < tOut; f++) {
    for (let ch = 0; ch < cOut; ch++) {
      let acc = 0;
      for (let tap = 0; tap < kernelSize; tap++) {
        const t = f * stride + tap - padLeft;
        if (t < 0 || t >= tIn) continue;
        for (let c = 0; c < cIn; c++) {
          acc += x[t * cIn + c]! * w[(tap * cIn + c) * cOut + ch]!;
        }
      }
      out[f * cOut + ch] = acc;
    }
  }
  return out;
}

const maxAbsDiff = (a: Float32Array, b: Float32Array) => {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i]! - b[i]!));
  return m;
};

describe('eager conv1d on GPU', () => {
  it('multi-channel k=5 s=2 matches the f64 reference', async () => {
    const root = await tgpu.init();
    const [tIn, cIn, cOut, kernelSize, stride] = [50, 3, 8, 5, 2];
    const xData = randArr(tIn * cIn, 11);
    const wData = randArr(kernelSize * cIn * cOut, 12);
    const x = materialized(matrix(tIn, cIn), uploadF32(root, xData));
    const w = materialized(matrix(kernelSize * cIn, cOut), uploadF32(root, wData));
    const out = await toArray(conv1d(x, w, { kernelSize, stride }), gpuExecutor(root));
    const ref = cpuConv1d(xData, wData, tIn, cIn, cOut, kernelSize, stride);
    expect(out.length).toBe(ref.length);
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-4);
  });

  it('single-channel k=127 s=64 (Moonshine conv1 geometry) matches', async () => {
    const root = await tgpu.init();
    const [tIn, cOut, kernelSize, stride] = [1000, 8, 127, 64];
    const xData = randArr(tIn, 21);
    const wData = randArr(kernelSize * cOut, 22);
    const x = materialized(matrix(tIn, 1), uploadF32(root, xData));
    const w = materialized(matrix(kernelSize, cOut), uploadF32(root, wData));
    const out = await toArray(conv1d(x, w, { kernelSize, stride }), gpuExecutor(root));
    const ref = cpuConv1d(xData, wData, tIn, 1, cOut, kernelSize, stride);
    expect(out.length).toBe(14 * cOut); // floor((1000-127)/64)+1
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-4);
  });

  it('causal k=5 s=2 padLeft=4 (Moonshine v2 conv geometry) matches', async () => {
    const root = await tgpu.init();
    const [tIn, cIn, cOut, kernelSize, stride, padLeft] = [149, 6, 12, 5, 2, 4];
    const xData = randArr(tIn * cIn, 41);
    const wData = randArr(kernelSize * cIn * cOut, 42);
    const x = materialized(matrix(tIn, cIn), uploadF32(root, xData));
    const w = materialized(matrix(kernelSize * cIn, cOut), uploadF32(root, wData));
    const out = await toArray(conv1d(x, w, { kernelSize, stride, padLeft }), gpuExecutor(root));
    const ref = cpuConv1d(xData, wData, tIn, cIn, cOut, kernelSize, stride, padLeft);
    expect(out.length).toBe(75 * cOut); // ceil(149/2) — causal stride-2 keeps ceil(T/s)
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-4);
  });

  it('padLeft window never reads x out of bounds at the right edge', async () => {
    // tIn chosen so the LAST output frame's window ends exactly at tIn−1.
    const root = await tgpu.init();
    const [tIn, cIn, cOut, kernelSize, stride, padLeft] = [7, 3, 4, 4, 3, 3];
    const xData = randArr(tIn * cIn, 51);
    const wData = randArr(kernelSize * cIn * cOut, 52);
    const x = materialized(matrix(tIn, cIn), uploadF32(root, xData));
    const w = materialized(matrix(kernelSize * cIn, cOut), uploadF32(root, wData));
    const out = await toArray(conv1d(x, w, { kernelSize, stride, padLeft }), gpuExecutor(root));
    const ref = cpuConv1d(xData, wData, tIn, cIn, cOut, kernelSize, stride, padLeft);
    expect(out.length).toBe(ref.length);
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-5);
  });

  it('C_out % 4 != 0 splits a frame into vec4 units plus a scalar tail', async () => {
    const root = await tgpu.init();
    const [tIn, cIn, cOut, kernelSize, stride, padLeft] = [40, 3, 10, 5, 2, 2];
    const xData = randArr(tIn * cIn, 61);
    const wData = randArr(kernelSize * cIn * cOut, 62);
    const x = materialized(matrix(tIn, cIn), uploadF32(root, xData));
    const w = materialized(matrix(kernelSize * cIn, cOut), uploadF32(root, wData));
    const out = await toArray(conv1d(x, w, { kernelSize, stride, padLeft }), gpuExecutor(root));
    const ref = cpuConv1d(xData, wData, tIn, cIn, cOut, kernelSize, stride, padLeft);
    expect(out.length).toBe(ref.length);
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-4);
  });

  it('symmetric padding=2 k=5 s=1 preserves length and matches (torch Conv1d(padding=2))', async () => {
    const root = await tgpu.init();
    const [tIn, cIn, cOut, kernelSize] = [30, 3, 6, 5];
    const xData = randArr(tIn * cIn, 63);
    const wData = randArr(kernelSize * cIn * cOut, 64);
    const x = materialized(matrix(tIn, cIn), uploadF32(root, xData));
    const w = materialized(matrix(kernelSize * cIn, cOut), uploadF32(root, wData));
    const out = await toArray(
      conv1d(x, w, { kernelSize, stride: 1, padding: 2 }),
      gpuExecutor(root),
    );
    const ref = cpuConv1d(xData, wData, tIn, cIn, cOut, kernelSize, 1, 2, 2);
    expect(out.length).toBe(tIn * cOut); // length-preserving
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-4);
  });

  it("padding 'same' with an even kernel (asymmetric split) preserves length and matches", async () => {
    const root = await tgpu.init();
    const [tIn, cIn, cOut, kernelSize] = [20, 3, 5, 4];
    const xData = randArr(tIn * cIn, 81);
    const wData = randArr(kernelSize * cIn * cOut, 82);
    const x = materialized(matrix(tIn, cIn), uploadF32(root, xData));
    const w = materialized(matrix(kernelSize * cIn, cOut), uploadF32(root, wData));
    const out = await toArray(
      conv1d(x, w, { kernelSize, stride: 1, padding: 'same' }),
      gpuExecutor(root),
    );
    const ref = cpuConv1d(xData, wData, tIn, cIn, cOut, kernelSize, 1, 1, 2);
    expect(out.length).toBe(tIn * cOut);
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-4);
  });

  it('padRight-only windows read zeros past the last frame and match', async () => {
    const root = await tgpu.init();
    const [tIn, cIn, cOut, kernelSize, stride, padRight] = [23, 4, 5, 5, 2, 4];
    const xData = randArr(tIn * cIn, 65);
    const wData = randArr(kernelSize * cIn * cOut, 66);
    const x = materialized(matrix(tIn, cIn), uploadF32(root, xData));
    const w = materialized(matrix(kernelSize * cIn, cOut), uploadF32(root, wData));
    const out = await toArray(conv1d(x, w, { kernelSize, stride, padRight }), gpuExecutor(root));
    const ref = cpuConv1d(xData, wData, tIn, cIn, cOut, kernelSize, stride, 0, padRight);
    expect(out.length).toBe(ref.length);
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-4);
  });

  it('kernelSize == stride == 1 degenerates to a plain matmul', async () => {
    const root = await tgpu.init();
    const xData = randArr(6 * 4, 31);
    const wData = randArr(4 * 5, 32);
    const x = materialized(matrix(6, 4), uploadF32(root, xData));
    const w = materialized(matrix(4, 5), uploadF32(root, wData));
    const out = await toArray(conv1d(x, w, { kernelSize: 1, stride: 1 }), gpuExecutor(root));
    const ref = cpuConv1d(xData, wData, 6, 4, 5, 1, 1);
    expect(maxAbsDiff(out, ref)).toBeLessThan(1e-5);
  });
});

/** Epilogue gate: fused bias/activation vs the composed conv → add → act op
 *  chain. Same math and order (`act(conv + bias)`), different pipelines, so
 *  FMA contraction differs per variant — 1e-6 admits those few ulp while
 *  still catching a wrong operand or order. Shapes cover both the vec4 unit
 *  and the scalar tail. */
describe('conv1d fused epilogue on GPU', () => {
  const run = async (
    cOut: number,
    which: 'bias' | 'tanh' | 'gelu' | 'bias+gelu',
  ): Promise<void> => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const [tIn, cIn, kernelSize, stride, padLeft] = [40, 3, 5, 2, 2];
    const xData = randArr(tIn * cIn, 71);
    const wData = randArr(kernelSize * cIn * cOut, 72);
    const biasData = randArr(cOut, 73);
    const up = () => ({
      x: materialized(matrix(tIn, cIn), uploadF32(root, xData)),
      w: materialized(matrix(kernelSize * cIn, cOut), uploadF32(root, wData)),
      bias: materialized(
        { elems: cOut, dtype: 'f32' as const, dims: [cOut] },
        uploadF32(root, biasData),
      ),
    });
    const wantBias = which === 'bias' || which === 'bias+gelu';
    const activation =
      which === 'tanh' ? ('tanh' as const) : which.includes('gelu') ? ('gelu' as const) : undefined;

    const f = up();
    const fused = await toArray(
      conv1d(f.x, f.w, {
        kernelSize,
        stride,
        padLeft,
        bias: wantBias ? f.bias : undefined,
        activation,
      }),
      ex,
    );

    const c = up();
    let composed = conv1d(c.x, c.w, { kernelSize, stride, padLeft });
    if (wantBias) composed = add(composed, c.bias);
    if (activation === 'tanh') composed = tanh(composed);
    if (activation === 'gelu') composed = gelu(composed);
    const reference = await toArray(composed, ex);

    expect(maxAbsDiff(fused, reference)).toBeLessThan(1e-6);
  };

  it('bias fold matches conv → add', async () => {
    await run(8, 'bias');
  });

  it('tanh fold matches conv → tanh', async () => {
    await run(8, 'tanh');
  });

  it('gelu fold matches conv → gelu (identical erf polynomial)', async () => {
    await run(8, 'gelu');
  });

  it('bias + gelu fold matches the full composed chain', async () => {
    await run(8, 'bias+gelu');
  });

  it('folds identically on the scalar tail (C_out % 4 != 0)', async () => {
    await run(10, 'bias+gelu');
  });
});
