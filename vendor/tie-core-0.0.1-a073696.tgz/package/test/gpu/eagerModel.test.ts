import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { Value } from '../../src/graph/value.ts';
import { initTie, tensor } from '../../src/index.ts';
import { Module, Linear, RMSNorm, run } from '../../src/nn/index.ts';

/** norm → linear, a mini transformer-ish block. */
class Block extends Module {
  readonly norm = new RMSNorm(4);
  readonly proj = new Linear(4, 4);
  forward(x: Value): Value {
    return this.proj.forward(this.norm.forward(x));
  }
}

function cpuRms(x: Float32Array, w: Float32Array, M: number, N: number, eps: number): Float32Array {
  const o = new Float32Array(M * N);
  for (let i = 0; i < M; i++) {
    let ms = 0;
    for (let j = 0; j < N; j++) ms += x[i * N + j]! ** 2;
    ms /= N;
    const inv = 1 / Math.sqrt(ms + eps);
    for (let j = 0; j < N; j++) o[i * N + j] = x[i * N + j]! * inv * w[j]!;
  }
  return o;
}
function cpuLinear(
  x: Float32Array,
  w: Float32Array,
  b: Float32Array,
  M: number,
  K: number,
  N: number,
): Float32Array {
  const o = new Float32Array(M * N);
  for (let i = 0; i < M; i++)
    for (let j = 0; j < N; j++) {
      let acc = b[j]!;
      for (let k = 0; k < K; k++) acc += x[i * K + k]! * w[k * N + j]!;
      o[i * N + j] = acc;
    }
  return o;
}

describe('eager nn model on GPU', () => {
  it('build → load → run a norm→linear block matches CPU', async () => {
    const root = await tgpu.init();
    initTie(root);
    const M = 2;
    const N = 4;
    const eps = 1e-6;
    const model = new Block();

    const scale = new Float32Array([1, 1, 1, 1]);
    const weight = new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); // [4,4] identity
    const bias = new Float32Array([10, 20, 30, 40]);

    await model.loadStateDict({
      'norm.scale': scale,
      // Linear demands torch layout [out, in]; identity is its own transpose
      'proj.weight': { data: weight, shape: [4, 4] },
      'proj.bias': bias,
    });

    const xData = new Float32Array([1, 2, 3, 4, -1, -2, -3, -4]);
    const x = tensor(xData, [M, N]);
    const out = await run(model, x);

    const normed = cpuRms(xData, scale, M, N, eps);
    const ref = cpuLinear(normed, weight, bias, M, N, N);
    for (let i = 0; i < M * N; i++) expect(out[i]).toBeCloseTo(ref[i]!, 4);
  });
});
