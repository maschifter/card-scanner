/** f16 storage buffers: upload raw halfwords, read them back as f32, and
 *  size a pooled buffer from its dtype. */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { createStorageFor, readbackF16, uploadF16, uploadF32 } from '../../src/gpu/buffers.ts';
import { materialized } from '../../src/graph/value.ts';
import { gpuExecutor, toArray } from '../../src/gpu/eval.ts';
import { f32ToF16Bits } from '../../src/weights/convert.ts';

let rootPromise: Promise<TgpuRoot> | undefined;
const getRoot = (): Promise<TgpuRoot> =>
  (rootPromise ??= tgpu.init({ device: { optionalFeatures: ['shader-f16'] } }));

const bitsOf = (values: readonly number[]): Uint16Array =>
  Uint16Array.from(values, (v) => f32ToF16Bits(v));

describe('f16 buffers', () => {
  it('round-trips values that f16 represents exactly', async () => {
    const root = await getRoot();
    const values = [0, 1, -1, 0.5, -0.25, 2048, -3.75];
    const buf = uploadF16(root, bitsOf(values));
    const out = await readbackF16(root, root.unwrap(buf), values.length);
    expect([...out]).toEqual(values);
  });

  it('reads back f16-rounded values, not the f32 originals', async () => {
    const root = await getRoot();
    const buf = uploadF16(root, bitsOf([0.1]));
    const out = await readbackF16(root, root.unwrap(buf), 1);
    expect(out[0]).toBe(0.0999755859375); // nearest f16 to 0.1
    expect(out[0]).not.toBe(0.1);
  });

  it('allocates two bytes per element for an f16 shape', async () => {
    const root = await getRoot();
    const buf = createStorageFor(root, { elems: 64, dtype: 'f16' });
    expect(root.unwrap(buf).size).toBe(128);
  });

  it('allocates four bytes per element for an f32 shape', async () => {
    const root = await getRoot();
    const buf = createStorageFor(root, { elems: 64, dtype: 'f32' });
    expect(root.unwrap(buf).size).toBe(256);
  });

  it('reads an f16 Value back through toArray as f32', async () => {
    const root = await getRoot();
    const values = [1, 0.5, -2, 8];
    const v = materialized({ elems: 4, dtype: 'f16' }, uploadF16(root, bitsOf(values)));
    expect([...(await toArray(v, gpuExecutor(root)))]).toEqual(values);
  });

  it('reads f16 and f32 Values together in ONE batched readback', async () => {
    const root = await getRoot();
    const ex = gpuExecutor(root);
    const outs = await ex.readbackMany!([
      {
        buffer: uploadF16(root, bitsOf([1, 2, 3, 4])),
        shape: { elems: 4, dtype: 'f16' },
      },
      {
        buffer: uploadF32(root, new Float32Array([5, 6])),
        shape: { elems: 2, dtype: 'f32' },
      },
    ]);
    expect([...outs[0]!]).toEqual([1, 2, 3, 4]);
    expect([...outs[1]!]).toEqual([5, 6]);
  });

  it('refuses to allocate an upload-only weight dtype', async () => {
    const root = await getRoot();
    expect(() => createStorageFor(root, { elems: 8, dtype: 'quantW' })).toThrow(/upload-only/);
  });
});

/** A storage buffer past maxStorageBufferBindingSize is created happily and
 *  only fails when a bind group reaches for it — inside an error scope nobody
 *  reads. The privacy filter's fused expert weight is 209.7 MB in f32 against
 *  a 134.2 MB cap, and the model ran at full speed returning ~1e7 garbage
 *  logits. These check the allocation refuses instead. */
describe('storage binding limit', () => {
  it('refuses an upload no shader could bind, and names the way out', async () => {
    const root = await getRoot();
    const cap = root.device.limits.maxStorageBufferBindingSize;
    const tooMany = Math.floor(cap / 4) + 1024; // f32 elements just past the cap
    expect(() => uploadF32(root, new Float32Array(tooMany))).toThrow(
      /exceeds this device's maxStorageBufferBindingSize/,
    );
    expect(() => uploadF32(root, new Float32Array(tooMany))).toThrow(/half\(\)/);
  });

  it('accepts the same element count at half width', async () => {
    const root = await getRoot();
    const cap = root.device.limits.maxStorageBufferBindingSize;
    const n = Math.floor(cap / 4) + 1024; // over the cap as f32, under it as f16
    expect(() => uploadF16(root, new Uint16Array(n))).not.toThrow();
  });

  it('refuses an op output that could not be bound', async () => {
    const root = await getRoot();
    const cap = root.device.limits.maxStorageBufferBindingSize;
    expect(() =>
      createStorageFor(root, { elems: Math.floor(cap / 4) + 1024, dtype: 'f32' }),
    ).toThrow(/maxStorageBufferBindingSize/);
  });
});
