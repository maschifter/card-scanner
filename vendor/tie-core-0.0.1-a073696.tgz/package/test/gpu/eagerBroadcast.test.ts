import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import { add, mul, matrix, materialized, toArray, gpuExecutor } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

describe('eager broadcast on GPU', () => {
  it('row-broadcast add: [2,3] + [3]', async () => {
    const root = await tgpu.init();
    const x = materialized(matrix(2, 3), uploadF32(root, new Float32Array([1, 2, 3, 4, 5, 6])));
    const b = materialized(
      { elems: 3, dtype: 'f32', dims: [3] },
      uploadF32(root, new Float32Array([10, 20, 30])),
    );
    const out = await toArray(add(x, b), gpuExecutor(root));
    expect(Array.from(out)).toEqual([11, 22, 33, 14, 25, 36]);
  });

  it('col-broadcast mul: [2,3] * [2,1]', async () => {
    const root = await tgpu.init();
    const x = materialized(matrix(2, 3), uploadF32(root, new Float32Array([1, 2, 3, 4, 5, 6])));
    const f = materialized(
      { elems: 2, dtype: 'f32', dims: [2, 1] },
      uploadF32(root, new Float32Array([10, 100])),
    );
    const out = await toArray(mul(x, f), gpuExecutor(root));
    expect(Array.from(out)).toEqual([10, 20, 30, 400, 500, 600]);
  });
});
