/** captureFrame parity: a replayed frame must produce the same numbers as a
 *  fresh eval of the same graph — including after the input buffer is
 *  overwritten in place (the demo-loop pattern), and with the fusion passes
 *  active inside the captured graph. */

import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  add,
  cat,
  conv2d,
  evalValues,
  gpuExecutor,
  materialized,
  f32ArrayToF16Bits,
  packConvHwc4F16,
  tensor3d,
  toChw,
  toHwc4,
  uploadF32,
  uploadF16,
  writeF32,
} from '../../src/index.ts';
import type { Value } from '../../src/index.ts';

describe('gpuExecutor.captureFrame', () => {
  it('replay matches fresh eval across input rewrites', async () => {
    const root = await tgpu.init({ device: { optionalFeatures: ['shader-f16'] } });
    const [c, h, w] = [8, 8, 8];
    const hw = h * w;
    const wData = new Float32Array(c * c).map((_, i) => (((i * 3) % 11) - 5) * 0.1);
    const bData = new Float32Array(c).map((_, i) => i * 0.01);
    const wPacked = packConvHwc4F16(f32ArrayToF16Bits(wData).data, c, c, 1, 1);
    const bPacked = f32ArrayToF16Bits(bData).data;
    const frames = [
      new Float32Array(c * hw).map((_, i) => ((i * 7) % 13) / 13 - 0.5),
      new Float32Array(c * hw).map((_, i) => ((i * 5) % 23) / 23 - 0.5),
    ];

    // Graph: cat(conv(x)+x, conv2(x)) — exercises add fusion + concat elision.
    const build = (rootExec: ReturnType<typeof gpuExecutor>, input: Value) => {
      const xh = toHwc4(input);
      const mkConv = () =>
        conv2d(
          xh,
          materialized(
            { elems: c * c, dtype: 'f16', dims: [c, c], layout: 'hwc4' },
            uploadF16(root, wPacked),
          ),
          materialized({ elems: c, dtype: 'f16', dims: [c] }, uploadF16(root, bPacked)),
          { kernelSize: 1, stride: 1, padding: 0, groups: 1, act: true },
        );
      const y = toChw(cat([add(xh, mkConv()), mkConv()], 0), 'f32');
      evalValues([y], rootExec);
      return y;
    };

    // Captured executor: capture with frame 0, replay for both frames.
    const execA = gpuExecutor(root);
    const inputBuf = uploadF32(root, frames[0]!);
    const input = materialized(tensor3d(c, h, w), inputBuf);
    const cap = execA.captureFrame(() => build(execA, input));

    for (const frame of frames) {
      writeF32(root, inputBuf, frame);
      cap.replay();
      const got = await execA.readback(cap.targets.buffer, cap.targets.shape);

      // Reference: a fresh executor + fresh graph on the same frame data.
      const execB = gpuExecutor(root);
      const refInput = materialized(tensor3d(c, h, w), uploadF32(root, frame));
      const ref = build(execB, refInput);
      const want = await execB.readback(ref.buffer, ref.shape);

      expect(got.length).toBe(want.length);
      for (let i = 0; i < got.length; i++) {
        // Replay and fresh eval run the identical f16 dispatch list, so the
        // gate stays exact-ish even at half precision.
        expect(Math.abs(got[i]! - want[i]!)).toBeLessThan(1e-6);
      }
    }

    // Replay-only contract: further evals on the captured executor throw.
    expect(() => build(execA, input)).toThrow(/replay-only/);
  });
});
