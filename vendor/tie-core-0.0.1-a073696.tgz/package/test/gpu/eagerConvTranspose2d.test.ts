import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  convTranspose2d,
  gpuExecutor,
  materialized,
  f32ArrayToF16Bits,
  tensor3d,
  toArray,
  uploadF32,
  uploadF16,
} from '../../src/index.ts';

/** CPU reference over TORCH weight layout [cIn, cOut, k, k], k = stride,
 *  padding 0 (exactly what nn.ConvTranspose2d(c, c, 2, 2) computes). */
function cpuConvT(
  x: Float32Array,
  w: Float32Array,
  bias: Float32Array | null,
  cIn: number,
  cOut: number,
  h: number,
  wIn: number,
  k: number,
): Float32Array {
  const out = new Float32Array(cOut * h * k * wIn * k);
  const [hOut, wOut] = [h * k, wIn * k];
  for (let co = 0; co < cOut; co++) {
    for (let ho = 0; ho < hOut; ho++) {
      for (let wo = 0; wo < wOut; wo++) {
        const [hi, wi, di, dj] = [Math.floor(ho / k), Math.floor(wo / k), ho % k, wo % k];
        let acc = bias ? bias[co]! : 0;
        for (let ci = 0; ci < cIn; ci++) {
          acc +=
            x[ci * h * wIn + hi * wIn + wi]! * w[ci * cOut * k * k + co * k * k + di * k + dj]!;
        }
        out[co * hOut * wOut + ho * wOut + wo] = acc;
      }
    }
  }
  return out;
}

/** Torch [cIn, cOut, k, k] → kernel layout [cOut·k·k, cIn] (what the exporter does). */
function permuteConvTWeight(w: Float32Array, cIn: number, cOut: number, k: number): Float32Array {
  const out = new Float32Array(cOut * k * k * cIn);
  for (let ci = 0; ci < cIn; ci++)
    for (let co = 0; co < cOut; co++)
      for (let di = 0; di < k; di++)
        for (let dj = 0; dj < k; dj++)
          out[(co * k * k + di * k + dj) * cIn + ci] =
            w[ci * cOut * k * k + co * k * k + di * k + dj]!;
  return out;
}

describe('convTranspose2d GPU kernel', () => {
  it('k=2 s=2 with bias matches CPU reference', async () => {
    const root = await tgpu.init();
    const [cIn, cOut, h, w, k] = [6, 4, 5, 7, 2]; // even cIn -> paired-word branch; odd h/w
    const xData = new Float32Array(cIn * h * w).map((_, i) => ((i % 7) - 3) * 0.5);
    const wData = new Float32Array(cIn * cOut * k * k).map((_, i) => (((i * 3) % 5) - 2) * 0.25);
    const bData = new Float32Array(cOut).map((_, i) => (i - 2) * 0.5);
    const ref = cpuConvT(xData, wData, bData, cIn, cOut, h, w, k);

    const xVal = materialized(tensor3d(cIn, h, w), uploadF32(root, xData));
    const kk = permuteConvTWeight(wData, cIn, cOut, k);
    const wVal = materialized(
      { elems: kk.length, dtype: 'f16', dims: [cOut * k * k, cIn] },
      uploadF16(root, f32ArrayToF16Bits(kk).data),
    );
    const bVal = materialized({ elems: cOut, dtype: 'f32', dims: [cOut] }, uploadF32(root, bData));

    const out = await toArray(
      convTranspose2d(xVal, wVal, bVal, { kernelSize: k, stride: k }),
      gpuExecutor(root),
    );
    expect(out.length).toBe(cOut * h * k * w * k);
    for (let i = 0; i < out.length; i++) expect(out[i]).toBeCloseTo(ref[i]!, 2);
  });

  /** cIn odd is the ONLY route to the scalar fallback: the kernel takes the
   *  paired-word branch whenever cIn % 2 == 0, and every other case here is
   *  even. Odd cIn makes rowBase alternate parity too, so the `flat % 2`
   *  half-word select fires in both directions. k is 3 rather than 2 so that
   *  cOut*k*k*cIn comes out odd — k = 2 makes it a multiple of 4, and the
   *  packed weight buffer would never end on a half-used word. */
  it('odd cIn takes the scalar fallback and matches CPU reference', async () => {
    const root = await tgpu.init();
    const [cIn, cOut, h, w, k] = [5, 3, 4, 5, 3];
    const xData = new Float32Array(cIn * h * w).map((_, i) => ((i % 7) - 3) * 0.5);
    const wData = new Float32Array(cIn * cOut * k * k).map((_, i) => (((i * 3) % 5) - 2) * 0.25);
    const bData = new Float32Array(cOut).map((_, i) => (i - 1) * 0.5);
    const ref = cpuConvT(xData, wData, bData, cIn, cOut, h, w, k);

    const xVal = materialized(tensor3d(cIn, h, w), uploadF32(root, xData));
    const kk = permuteConvTWeight(wData, cIn, cOut, k);
    expect(kk.length % 2).toBe(1); // guards the half-used tail word above
    const wVal = materialized(
      { elems: kk.length, dtype: 'f16', dims: [cOut * k * k, cIn] },
      uploadF16(root, f32ArrayToF16Bits(kk).data),
    );
    const bVal = materialized({ elems: cOut, dtype: 'f32', dims: [cOut] }, uploadF32(root, bData));

    const out = await toArray(
      convTranspose2d(xVal, wVal, bVal, { kernelSize: k, stride: k }),
      gpuExecutor(root),
    );
    expect(out.length).toBe(cOut * h * k * w * k);
    for (let i = 0; i < out.length; i++) expect(out[i]).toBeCloseTo(ref[i]!, 2);
  });

  it('k=2 s=2 without bias matches CPU reference', async () => {
    const root = await tgpu.init();
    const [cIn, cOut, h, w, k] = [8, 8, 4, 4, 2];
    const xData = new Float32Array(cIn * h * w).map((_, i) => ((i % 11) - 5) * 0.5);
    const wData = new Float32Array(cIn * cOut * k * k).map((_, i) => (((i * 7) % 9) - 4) * 0.125);
    const ref = cpuConvT(xData, wData, null, cIn, cOut, h, w, k);

    const xVal = materialized(tensor3d(cIn, h, w), uploadF32(root, xData));
    const kk = permuteConvTWeight(wData, cIn, cOut, k);
    const wVal = materialized(
      { elems: kk.length, dtype: 'f16', dims: [cOut * k * k, cIn] },
      uploadF16(root, f32ArrayToF16Bits(kk).data),
    );
    const out = await toArray(
      convTranspose2d(xVal, wVal, undefined, { kernelSize: k, stride: k }),
      gpuExecutor(root),
    );
    for (let i = 0; i < out.length; i++) expect(out[i]).toBeCloseTo(ref[i]!, 2);
  });
});
