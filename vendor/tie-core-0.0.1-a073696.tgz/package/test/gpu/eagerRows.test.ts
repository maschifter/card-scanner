import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  matrix,
  materialized,
  cat,
  gatherRows,
  slice,
  gpuExecutor,
  toArray,
} from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';

const seq = (n: number) => Float32Array.from({ length: n }, (_, i) => i + 1);

describe('eager row ops on GPU', () => {
  it('sliceRows extracts x[2:5, :] of [6,3]', async () => {
    const root = await tgpu.init();
    const out = await toArray(
      slice(materialized(matrix(6, 3), uploadF32(root, seq(18))), 0, 2, 5),
      gpuExecutor(root),
    );
    expect(Array.from(out)).toEqual([7, 8, 9, 10, 11, 12, 13, 14, 15]);
  });
  it('sliceRows handles tensors past the 65535-workgroup dispatch cap', async () => {
    // 80×65536 = 5.24M elements: the slice output (79 rows = 5.17M elems)
    // needs 80896 workgroups — over WebGPU's 65535/dim cap, so the executor
    // splits the grid 2-D and the kernel folds gid.y back into the index.
    // Values are checked at the start, the y-slice boundary (4,194,240), and
    // the end — a dropped or unsplit dispatch fails all three.
    const root = await tgpu.init();
    const rows = 80;
    const cols = 65536;
    const data = new Float32Array(rows * cols);
    for (let i = 0; i < data.length; i++) data[i] = (i % 1000) + Math.floor(i / 1000000);
    const out = await toArray(
      slice(materialized(matrix(rows, cols), uploadF32(root, data)), 0, 1, rows),
      gpuExecutor(root),
    );
    expect(out.length).toBe((rows - 1) * cols);
    const checkpoints = [0, 4194239, 4194240, 4194241, out.length - 1];
    for (const i of checkpoints) {
      expect(out[i]).toBe(data[cols + i]!); // slice starts at row 1
    }
  });

  it('concatRows stacks [2,3] on [1,3]', async () => {
    const root = await tgpu.init();
    const ex = gpuExecutor(root);
    const a = materialized(matrix(2, 3), uploadF32(root, seq(6)));
    const b = materialized(matrix(1, 3), uploadF32(root, Float32Array.from([10, 20, 30])));
    expect(Array.from(await toArray(cat([a, b], 0), ex))).toEqual([1, 2, 3, 4, 5, 6, 10, 20, 30]);
  });
  it('gatherRows picks rows [3,0,3] of [4,2]', async () => {
    const root = await tgpu.init();
    const out = await toArray(
      gatherRows(materialized(matrix(4, 2), uploadF32(root, seq(8))), [3, 0, 3]),
      gpuExecutor(root),
    );
    expect(Array.from(out)).toEqual([7, 8, 1, 2, 7, 8]);
  });
});
