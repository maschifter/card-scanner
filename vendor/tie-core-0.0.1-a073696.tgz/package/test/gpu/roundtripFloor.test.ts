/** Decomposes the per-call latency floor: what one queue round-trip costs on
 *  this device/browser, independent of any model. Reported, not asserted.
 *  - submit-only: encode+submit an empty pass, no completion wait
 *  - workDone: empty submit + await onSubmittedWorkDone
 *  - mapAsync: 1.5KB copy + staging mapAsync round-trip */

import { beforeAll, describe, it } from 'vitest';
import type { TgpuRoot } from 'typegpu';
import { getRoot } from './harness.ts';

const median = (xs: number[]): number => {
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)]!;
};

describe('queue round-trip floor', () => {
  let root: TgpuRoot;
  beforeAll(async () => {
    root = await getRoot();
  });

  it('reports submit-only / workDone / mapAsync costs', async () => {
    const device = root.device;
    const REPS = 50;
    const src = device.createBuffer({ size: 1536, usage: GPUBufferUsage.COPY_SRC });
    const staging = device.createBuffer({
      size: 1536,
      usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
    });

    {
      const t0 = performance.now();
      for (let i = 0; i < REPS; i++) {
        const enc = device.createCommandEncoder();
        const pass = enc.beginComputePass();
        pass.end();
        device.queue.submit([enc.finish()]);
      }
      await device.queue.onSubmittedWorkDone();
      console.log(
        `submit-only: ${((performance.now() - t0) / REPS).toFixed(3)}ms/iter (amortized)`,
      );
    }

    for (const variant of ['workDone', 'mapAsync'] as const) {
      const times: number[] = [];
      for (let i = 0; i < REPS; i++) {
        const t0 = performance.now();
        const enc = device.createCommandEncoder();
        const pass = enc.beginComputePass();
        pass.end();
        if (variant === 'mapAsync') enc.copyBufferToBuffer(src, 0, staging, 0, 1536);
        device.queue.submit([enc.finish()]);
        if (variant === 'mapAsync') {
          await staging.mapAsync(GPUMapMode.READ);
          staging.getMappedRange();
          staging.unmap();
        } else {
          await device.queue.onSubmittedWorkDone();
        }
        times.push(performance.now() - t0);
      }
      console.log(
        `${variant}: median ${median(times).toFixed(2)}ms  min ${Math.min(...times).toFixed(2)}ms`,
      );
    }
    src.destroy();
    staging.destroy();
  }, 120_000);
});
