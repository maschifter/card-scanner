import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import type { TgpuRoot } from 'typegpu';
import { gpuExecutor, materialized, matmul, matrix, toArray } from '../../src/index.ts';
import { uploadF32 } from '../../src/gpu/buffers.ts';
import type { GpuSubmitTiming } from '../../src/gpu/perf.ts';

/** Report bench: per-shape matmul GPU time on the subgroup small-m route vs
 *  the serial routes (a plain root runs the same shapes through tiled/plain).
 *  Reported, not asserted; compare within one session only. */

let subRootPromise: Promise<TgpuRoot> | undefined;
function getSubgroupRoot(): Promise<TgpuRoot> {
  subRootPromise ??= tgpu.init({
    device: { optionalFeatures: ['subgroups', 'timestamp-query'] },
  });
  return subRootPromise;
}
let plainRootPromise: Promise<TgpuRoot> | undefined;
function getPlainRoot(): Promise<TgpuRoot> {
  plainRootPromise ??= tgpu.init({ device: { optionalFeatures: ['timestamp-query'] } });
  return plainRootPromise;
}

const median = (xs: number[]): number => {
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)]!;
};

interface Shape {
  label: string;
  m: number;
  k: number;
  n: number;
  withBias?: boolean;
  withAddend?: boolean;
  activation?: 'gelu';
}

/** Median matmul-op GPU ns over reps (timestamp-query), plus the route name. */
async function timeShape(
  root: TgpuRoot,
  s: Shape,
  reps: number,
): Promise<{ ns: number; route: string }> {
  const a = materialized(matrix(s.m, s.k), uploadF32(root, new Float32Array(s.m * s.k).fill(0.1)));
  const b = materialized(matrix(s.k, s.n), uploadF32(root, new Float32Array(s.k * s.n).fill(0.1)));
  const bias = s.withBias
    ? materialized(
        { elems: s.n, dtype: 'f32' as const, dims: [s.n] },
        uploadF32(root, new Float32Array(s.n).fill(0.01)),
      )
    : undefined;
  const addend = s.withAddend
    ? materialized(matrix(s.m, s.n), uploadF32(root, new Float32Array(s.m * s.n).fill(0.01)))
    : undefined;
  const times: number[] = [];
  let route = '?';
  for (let i = 0; i < reps; i++) {
    const timings: Promise<GpuSubmitTiming>[] = [];
    const ex = gpuExecutor(root, {
      perf: { perOp: true, onSubmit: (_n, t) => t && timings.push(t) },
    });
    const out = await toArray(matmul(a, b, { bias, addend, activation: s.activation }), ex);
    expect(out.every(Number.isFinite)).toBe(true);
    for (const t of await Promise.all(timings)) {
      for (const [name, op] of t.opNs ?? []) {
        if (name.startsWith('matmul')) {
          times.push(op.ns);
          route = name;
        }
      }
    }
  }
  return { ns: median(times), route };
}

const SHAPES: Shape[] = [
  { label: 'qkv  T=16', m: 16, k: 384, n: 1152, withBias: true },
  { label: 'out  T=16', m: 16, k: 384, n: 384, withBias: true, withAddend: true },
  { label: 'up   T=16', m: 16, k: 384, n: 1536, withBias: true, activation: 'gelu' },
  { label: 'down T=16', m: 16, k: 1536, n: 384, withBias: true, withAddend: true },
  { label: 'qkv  T=32', m: 32, k: 384, n: 1152, withBias: true },
  { label: 'up   T=32', m: 32, k: 384, n: 1536, withBias: true, activation: 'gelu' },
];

describe('small-m matmul route bench (report only)', () => {
  it('reports per-shape GPU time, subgroup route vs serial routes', async () => {
    const subRoot = await getSubgroupRoot();
    const plainRoot = await getPlainRoot();
    if (!subRoot.device.features.has('timestamp-query')) return;
    const REPS = 30;
    const lines: string[] = [];
    for (const s of SHAPES) {
      const sub = await timeShape(subRoot, s, REPS);
      const plain = await timeShape(plainRoot, s, REPS);
      lines.push(
        `${s.label} [${s.m},${s.k}]x[${s.k},${s.n}]: ` +
          `${(sub.ns / 1e3).toFixed(1)}µs (${sub.route}) vs ` +
          `${(plain.ns / 1e3).toFixed(1)}µs (${plain.route}) — ` +
          `${(plain.ns / sub.ns).toFixed(2)}x`,
      );
    }
    console.log(lines.join('\n'));
  }, 120_000);
});
