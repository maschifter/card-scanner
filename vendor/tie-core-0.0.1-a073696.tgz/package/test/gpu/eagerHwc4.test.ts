/** HWC4 kernel-family parity: each hwc4 op against the CPU reference (convs)
 *  or its CHW twin (pool/upsample/cat/chunk), plus the boundary conversions
 *  and the graph-build guards. Inputs enter through toHwc4 and results leave
 *  through toChw, so every test also exercises the conversions.
 *
 *  Tolerances are f16 ones: activations, weights AND accumulators are half
 *  precision (the measured POC configuration), so a K-deep reduction drifts
 *  by ~sqrt(K)·2^-11 relative. Inputs are scaled to keep magnitudes O(1). */
import { describe, expect, it } from 'vitest';
import tgpu from 'typegpu';
import {
  cat,
  chunk,
  conv2d,
  evalValues,
  f32ArrayToF16Bits,
  gpuExecutor,
  materialized,
  maxPool2d,
  packConvHwc4F16,
  packDwHwc4F16,
  reshape,
  tensor3d,
  toArray,
  toChw,
  toHwc4,
  upsample2d,
  uploadF16,
  uploadF32,
  type Value,
} from '../../src/index.ts';

const init = () => tgpu.init({ device: { optionalFeatures: ['shader-f16'] } });

/** f16-representable pseudo-random values in [-0.5, 0.5). */
function f16Random(n: number, seed: number): Float32Array {
  const raw = new Float32Array(n).map((_, i) => Math.sin(i * 0.7 + seed) * 0.5);
  return Float32Array.from(f32ArrayToF16Bits(raw).data, (b) => {
    const sign = b >> 15 ? -1 : 1;
    const exp = (b >> 10) & 0x1f;
    const frac = b & 0x3ff;
    if (exp === 0) return sign * frac * 2 ** -24;
    return sign * (1 + frac / 1024) * 2 ** (exp - 15);
  });
}

const silu = (v: number) => v / (1 + Math.exp(-v));

/** CPU reference conv (CHW in/out, OIHW weights, optional groups/silu). */
function cpuConv(
  x: Float32Array,
  w: Float32Array,
  bias: Float32Array | undefined,
  p: {
    cIn: number;
    cOut: number;
    h: number;
    w: number;
    kH: number;
    kW: number;
    stride: number;
    padding: number;
    groups: number;
    act: boolean;
  },
): Float32Array {
  const { cIn, cOut, h, w: wIn, kH, kW, stride, padding, groups } = p;
  const hOut = Math.floor((h + 2 * padding - kH) / stride) + 1;
  const wOut = Math.floor((wIn + 2 * padding - kW) / stride) + 1;
  const cig = cIn / groups;
  const cog = cOut / groups;
  const out = new Float32Array(cOut * hOut * wOut);
  for (let co = 0; co < cOut; co++) {
    const g = Math.floor(co / cog);
    for (let ho = 0; ho < hOut; ho++) {
      for (let wo = 0; wo < wOut; wo++) {
        let acc = bias ? bias[co]! : 0;
        for (let ci = 0; ci < cig; ci++) {
          for (let kh = 0; kh < kH; kh++) {
            for (let kw = 0; kw < kW; kw++) {
              const hi = ho * stride - padding + kh;
              const wi = wo * stride - padding + kw;
              if (hi < 0 || hi >= h || wi < 0 || wi >= wIn) continue;
              acc +=
                x[(g * cig + ci) * h * wIn + hi * wIn + wi]! *
                w[(co * cig + ci) * kH * kW + kh * kW + kw]!;
            }
          }
        }
        out[co * hOut * wOut + ho * wOut + wo] = p.act ? silu(acc) : acc;
      }
    }
  }
  return out;
}

function expectClose(got: Float32Array, want: Float32Array, rtol = 0.02, atol = 0.02): void {
  expect(got.length).toBe(want.length);
  for (let i = 0; i < got.length; i++) {
    const diff = Math.abs(got[i]! - want[i]!);
    const bound = atol + rtol * Math.abs(want[i]!);
    if (diff > bound) {
      expect.fail(`index ${i}: got ${got[i]} want ${want[i]} (|diff| ${diff} > ${bound})`);
    }
  }
}

describe('hwc4 storage', () => {
  it('toHwc4 → toChw roundtrips exactly, from f32 and f16 sources', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const [c, h, w] = [6, 5, 4]; // c padded to 8 internally
    const data = f16Random(c * h * w, 1);
    const x32 = materialized(tensor3d(c, h, w), uploadF32(root, data));
    const round32 = await toArray(toChw(toHwc4(x32), 'f32'), ex);
    expect(Array.from(round32)).toEqual(Array.from(data));

    const x16 = materialized(
      { elems: c * h * w, dtype: 'f16', dims: [c, h, w] },
      uploadF16(root, f32ArrayToF16Bits(data).data),
    );
    const round16 = await toArray(toChw(toHwc4(x16), 'f16'), ex);
    expect(Array.from(round16)).toEqual(Array.from(data));
  });

  it('generic 3×3 conv (s=1 p=1, bias+silu, padded channels) matches CPU', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const p = {
      cIn: 6,
      cOut: 10,
      h: 9,
      w: 7,
      kH: 3,
      kW: 3,
      stride: 1,
      padding: 1,
      groups: 1,
      act: true,
    };
    const x = f16Random(p.cIn * p.h * p.w, 2);
    const wData = f16Random(p.cOut * p.cIn * 9, 3);
    const bias = f16Random(p.cOut, 4);
    const ref = cpuConv(x, wData, bias, p);

    const wVal = materialized(
      { elems: p.cOut * p.cIn * 9, dtype: 'f16', dims: [p.cOut, p.cIn * 9], layout: 'hwc4' },
      uploadF16(root, packConvHwc4F16(f32ArrayToF16Bits(wData).data, p.cOut, p.cIn, 3, 3)),
    );
    const bVal = materialized(
      { elems: p.cOut, dtype: 'f16', dims: [p.cOut] },
      uploadF16(root, f32ArrayToF16Bits(bias).data),
    );
    const xVal = toHwc4(materialized(tensor3d(p.cIn, p.h, p.w), uploadF32(root, x)));
    const out = conv2d(xVal, wVal, bVal, {
      kernelSize: 3,
      stride: 1,
      padding: 1,
      groups: 1,
      act: true,
    });
    expect(out.pending!.op).toBe('conv2dHwc4');
    expectClose(await toArray(toChw(out, 'f32'), ex), ref);
  });

  it('3×3 stride-2 conv matches CPU', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const p = {
      cIn: 8,
      cOut: 8,
      h: 10,
      w: 10,
      kH: 3,
      kW: 3,
      stride: 2,
      padding: 1,
      groups: 1,
      act: false,
    };
    const x = f16Random(p.cIn * p.h * p.w, 5);
    const wData = f16Random(p.cOut * p.cIn * 9, 6);
    const ref = cpuConv(x, wData, undefined, p);

    const wVal = materialized(
      { elems: p.cOut * p.cIn * 9, dtype: 'f16', dims: [p.cOut, p.cIn * 9], layout: 'hwc4' },
      uploadF16(root, packConvHwc4F16(f32ArrayToF16Bits(wData).data, p.cOut, p.cIn, 3, 3)),
    );
    const xVal = toHwc4(materialized(tensor3d(p.cIn, p.h, p.w), uploadF32(root, x)));
    const out = conv2d(xVal, wVal, undefined, {
      kernelSize: 3,
      stride: 2,
      padding: 1,
      groups: 1,
    });
    expectClose(await toArray(toChw(out, 'f32'), ex), ref);
  });

  it('1×1 conv (register-tiled path, hw % 4 == 0) matches CPU', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const p = {
      cIn: 12,
      cOut: 8,
      h: 4,
      w: 8,
      kH: 1,
      kW: 1,
      stride: 1,
      padding: 0,
      groups: 1,
      act: true,
    };
    const x = f16Random(p.cIn * p.h * p.w, 7);
    const wData = f16Random(p.cOut * p.cIn, 8);
    const bias = f16Random(p.cOut, 9);
    const ref = cpuConv(x, wData, bias, p);

    const wVal = materialized(
      { elems: p.cOut * p.cIn, dtype: 'f16', dims: [p.cOut, p.cIn], layout: 'hwc4' },
      uploadF16(root, packConvHwc4F16(f32ArrayToF16Bits(wData).data, p.cOut, p.cIn, 1, 1)),
    );
    const bVal = materialized(
      { elems: p.cOut, dtype: 'f16', dims: [p.cOut] },
      uploadF16(root, f32ArrayToF16Bits(bias).data),
    );
    const xVal = toHwc4(materialized(tensor3d(p.cIn, p.h, p.w), uploadF32(root, x)));
    const out = conv2d(xVal, wVal, bVal, {
      kernelSize: 1,
      stride: 1,
      padding: 0,
      groups: 1,
      act: true,
    });
    expectClose(await toArray(toChw(out, 'f32'), ex), ref);
  });

  it('1×1 conv (register-tiled path, pxT=4: hw % 4 == 0, hw % 8 != 0) matches CPU', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const p = {
      cIn: 12,
      cOut: 8,
      h: 4,
      w: 3,
      kH: 1,
      kW: 1,
      stride: 1,
      padding: 0,
      groups: 1,
      act: true,
    };
    const x = f16Random(p.cIn * p.h * p.w, 20);
    const wData = f16Random(p.cOut * p.cIn, 21);
    const bias = f16Random(p.cOut, 22);
    const ref = cpuConv(x, wData, bias, p);

    const wVal = materialized(
      { elems: p.cOut * p.cIn, dtype: 'f16', dims: [p.cOut, p.cIn], layout: 'hwc4' },
      uploadF16(root, packConvHwc4F16(f32ArrayToF16Bits(wData).data, p.cOut, p.cIn, 1, 1)),
    );
    const bVal = materialized(
      { elems: p.cOut, dtype: 'f16', dims: [p.cOut] },
      uploadF16(root, f32ArrayToF16Bits(bias).data),
    );
    const xVal = toHwc4(materialized(tensor3d(p.cIn, p.h, p.w), uploadF32(root, x)));
    const out = conv2d(xVal, wVal, bVal, {
      kernelSize: 1,
      stride: 1,
      padding: 0,
      groups: 1,
      act: true,
    });
    expectClose(await toArray(toChw(out, 'f32'), ex), ref);
  });

  it('1×1 conv falls back to the generic kernel when hw % 4 != 0, still matches CPU', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const p = {
      cIn: 12,
      cOut: 8,
      h: 3,
      w: 3,
      kH: 1,
      kW: 1,
      stride: 1,
      padding: 0,
      groups: 1,
      act: true,
    };
    const x = f16Random(p.cIn * p.h * p.w, 23);
    const wData = f16Random(p.cOut * p.cIn, 24);
    const bias = f16Random(p.cOut, 25);
    const ref = cpuConv(x, wData, bias, p);

    const wVal = materialized(
      { elems: p.cOut * p.cIn, dtype: 'f16', dims: [p.cOut, p.cIn], layout: 'hwc4' },
      uploadF16(root, packConvHwc4F16(f32ArrayToF16Bits(wData).data, p.cOut, p.cIn, 1, 1)),
    );
    const bVal = materialized(
      { elems: p.cOut, dtype: 'f16', dims: [p.cOut] },
      uploadF16(root, f32ArrayToF16Bits(bias).data),
    );
    const xVal = toHwc4(materialized(tensor3d(p.cIn, p.h, p.w), uploadF32(root, x)));
    const out = conv2d(xVal, wVal, bVal, {
      kernelSize: 1,
      stride: 1,
      padding: 0,
      groups: 1,
      act: true,
    });
    expectClose(await toArray(toChw(out, 'f32'), ex), ref);
  });

  it('non-square kernel (3×5) matches CPU', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const p = {
      cIn: 6,
      cOut: 8,
      h: 7,
      w: 9,
      kH: 3,
      kW: 5,
      stride: 1,
      padding: 0,
      groups: 1,
      act: true,
    };
    const x = f16Random(p.cIn * p.h * p.w, 26);
    const wData = f16Random(p.cOut * p.cIn * p.kH * p.kW, 27);
    const bias = f16Random(p.cOut, 28);
    const ref = cpuConv(x, wData, bias, p);

    const wVal = materialized(
      {
        elems: p.cOut * p.cIn * p.kH * p.kW,
        dtype: 'f16',
        dims: [p.cOut, p.cIn * p.kH * p.kW],
        layout: 'hwc4',
      },
      uploadF16(root, packConvHwc4F16(f32ArrayToF16Bits(wData).data, p.cOut, p.cIn, p.kH, p.kW)),
    );
    const bVal = materialized(
      { elems: p.cOut, dtype: 'f16', dims: [p.cOut] },
      uploadF16(root, f32ArrayToF16Bits(bias).data),
    );
    const xVal = toHwc4(materialized(tensor3d(p.cIn, p.h, p.w), uploadF32(root, x)));
    const out = conv2d(xVal, wVal, bVal, {
      kernelSize: [p.kH, p.kW],
      stride: 1,
      padding: 0,
      groups: 1,
      act: true,
    });
    expectClose(await toArray(toChw(out, 'f32'), ex), ref);
  });

  it('depthwise 3×3 conv matches CPU', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const p = {
      cIn: 10,
      cOut: 10,
      h: 6,
      w: 6,
      kH: 3,
      kW: 3,
      stride: 1,
      padding: 1,
      groups: 10,
      act: true,
    };
    const x = f16Random(p.cIn * p.h * p.w, 10);
    const wData = f16Random(p.cOut * 9, 11);
    const bias = f16Random(p.cOut, 12);
    const ref = cpuConv(x, wData, bias, p);

    const wVal = materialized(
      { elems: p.cOut * 9, dtype: 'f16', dims: [p.cOut, 9], layout: 'hwc4' },
      uploadF16(root, packDwHwc4F16(f32ArrayToF16Bits(wData).data, p.cOut, 3, 3)),
    );
    const bVal = materialized(
      { elems: p.cOut, dtype: 'f16', dims: [p.cOut] },
      uploadF16(root, f32ArrayToF16Bits(bias).data),
    );
    const xVal = toHwc4(materialized(tensor3d(p.cIn, p.h, p.w), uploadF32(root, x)));
    const out = conv2d(xVal, wVal, bVal, {
      kernelSize: 3,
      stride: 1,
      padding: 1,
      groups: p.groups,
      act: true,
    });
    expectClose(await toArray(toChw(out, 'f32'), ex), ref);
  });

  it('maxPool2d and upsample2d route to hwc4 and match CPU', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const [c, h, w] = [8, 6, 6];
    const data = f16Random(c * h * w, 13);

    const poolNode = maxPool2d(toHwc4(materialized(tensor3d(c, h, w), uploadF32(root, data))), {
      kernelSize: 5,
      stride: 1,
      padding: 2,
    });
    expect(poolNode.pending!.op).toBe('maxPool2dHwc4');
    const gotPool = await toArray(toChw(poolNode, 'f32'), ex);
    for (let ch = 0; ch < c; ch++) {
      for (let oy = 0; oy < h; oy++) {
        for (let ox = 0; ox < w; ox++) {
          let m = -Infinity;
          for (let dy = -2; dy <= 2; dy++) {
            for (let dx = -2; dx <= 2; dx++) {
              const iy = oy + dy;
              const ix = ox + dx;
              if (iy >= 0 && iy < h && ix >= 0 && ix < w) {
                m = Math.max(m, data[ch * h * w + iy * w + ix]!);
              }
            }
          }
          const i = ch * h * w + oy * w + ox;
          expect(Math.abs(gotPool[i]! - m)).toBeLessThan(1e-3);
        }
      }
    }

    const upNode = upsample2d(toHwc4(materialized(tensor3d(c, h, w), uploadF32(root, data))), {
      scale: 2,
    });
    expect(upNode.pending!.op).toBe('upsample2dHwc4');
    const gotUp = await toArray(toChw(upNode, 'f32'), ex);
    for (let ch = 0; ch < c; ch++) {
      for (let oy = 0; oy < 2 * h; oy++) {
        for (let ox = 0; ox < 2 * w; ox++) {
          const want = data[ch * h * w + (oy >> 1) * w + (ox >> 1)]!;
          const i = ch * 4 * h * w + oy * 2 * w + ox;
          expect(Math.abs(gotUp[i]! - want)).toBeLessThan(1e-3);
        }
      }
    }
  });

  it('cat and chunk on channel blocks match their CHW twins', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const [h, w] = [3, 5];
    const a = f16Random(8 * h * w, 14);
    const b = f16Random(4 * h * w, 15);
    const chwCat = await toArray(
      cat(
        [
          materialized(tensor3d(8, h, w), uploadF32(root, a)),
          materialized(tensor3d(4, h, w), uploadF32(root, b)),
        ],
        0,
      ),
      ex,
    );
    const catNode = cat(
      [
        toHwc4(materialized(tensor3d(8, h, w), uploadF32(root, a))),
        toHwc4(materialized(tensor3d(4, h, w), uploadF32(root, b))),
      ],
      0,
    );
    expect(catNode.pending!.op).toBe('concatChannelsHwc4');
    expectClose(await toArray(toChw(catNode, 'f32'), ex), chwCat, 0.002, 0.002);

    const halves = chunk(toHwc4(materialized(tensor3d(8, h, w), uploadF32(root, a))), 2, 0);
    expect(halves[0]!.pending!.op).toBe('sliceChannelsHwc4');
    // Both halves share the toHwc4 intermediate — evaluate them in ONE batch
    // so the driver doesn't recycle it between reads.
    const chwHalves = [toChw(halves[0]!, 'f32'), toChw(halves[1]!, 'f32')];
    evalValues(chwHalves, ex);
    const first = await toArray(chwHalves[0]!, ex);
    const second = await toArray(chwHalves[1]!, ex);
    expectClose(first, a.slice(0, 4 * h * w), 0.002, 0.002);
    expectClose(second, a.slice(4 * h * w), 0.002, 0.002);
  });

  it('refuses the silent-garbage paths at graph-build time', async () => {
    const root = await init();
    const ex = gpuExecutor(root);
    const x = toHwc4(materialized(tensor3d(4, 4, 4), uploadF32(root, f16Random(64, 16))));

    // Row-major ops must reject hwc4 storage outright.
    expect(() => reshape(x, [4, 16])).toThrow(/toChw/);
    // A CHW input cannot enter a conv against an hwc4-packed weight.
    const wPacked = materialized(
      { elems: 4 * 4, dtype: 'f16', dims: [4, 4], layout: 'hwc4' },
      uploadF16(root, packConvHwc4F16(f32ArrayToF16Bits(f16Random(16, 17)).data, 4, 4, 1, 1)),
    );
    const chw = materialized(tensor3d(4, 4, 4), uploadF32(root, f16Random(64, 18)));
    expect(() =>
      conv2d(chw, wPacked, undefined, { kernelSize: 1, stride: 1, padding: 0, groups: 1 }),
    ).toThrow(/hwc4/);
    // And an hwc4 input cannot enter a conv against an unpacked weight.
    const wPlain = materialized(
      { elems: 4 * 4, dtype: 'f16', dims: [4, 4] },
      uploadF16(root, f32ArrayToF16Bits(f16Random(16, 19)).data),
    );
    expect(() =>
      conv2d(x, wPlain, undefined, { kernelSize: 1, stride: 1, padding: 0, groups: 1 }),
    ).toThrow(/hwc4/);
    // Reading hwc4 bytes back raw would hand the caller scrambled channels.
    const pool = maxPool2d(x, { kernelSize: 3, stride: 1, padding: 1 });
    await expect(toArray(pool as Value, ex)).rejects.toThrow(/toChw/);
  });
});
