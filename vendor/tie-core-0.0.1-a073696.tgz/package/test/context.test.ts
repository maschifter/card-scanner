import { afterEach, describe, expect, it } from 'vitest';
import type { TgpuRoot } from 'typegpu';
import { defaultExecutor, defaultRoot, initTie, resetTie } from '../src/index.ts';

/** Structural stand-in — context wiring never dispatches in these tests, but
 *  gpuExecutor sniffs device.features at construction, so the fake carries an
 *  empty feature set. */
const fakeRoot = (): TgpuRoot =>
  ({ device: { features: new Set() }, createBuffer: () => {} }) as unknown as TgpuRoot;

describe('initTie / default device context', () => {
  afterEach(() => resetTie());

  it('defaultRoot throws before initTie, names the fix', () => {
    expect(() => defaultRoot()).toThrow(/initTie/);
  });

  it('initTie sets the default root and returns the executor', () => {
    const root = fakeRoot();
    const ex = initTie(root);
    expect(defaultRoot()).toBe(root);
    expect(defaultExecutor()).toBe(ex);
  });

  it('memoizes one executor per root across re-init', () => {
    const a = fakeRoot();
    const b = fakeRoot();
    const exA = initTie(a);
    const exB = initTie(b);
    expect(exB).not.toBe(exA);
    expect(initTie(a)).toBe(exA); // same root — same executor, last init wins as default
    expect(defaultRoot()).toBe(a);
  });
});
