import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { packQuantColSlice } from '../src/index.ts';

describe('packQuantColSlice vs Python pack_blocked golden', () => {
  const golden = JSON.parse(
    readFileSync(
      join(import.meta.dirname, '../../../tools/testdata/pack_blocked_golden.json'),
      'utf8',
    ),
  );

  it('reproduces the exact word stream for the glu half', () => {
    const { E, K, O, bits, group } = golden;
    const qbytes = new Uint8Array(Int8Array.from(golden.qbytes as number[]).buffer);
    const scales = Float32Array.from(golden.scales as number[]);
    const { qdata } = packQuantColSlice(qbytes, scales, bits, group, E, K, O, 0, O / 2);
    expect([...qdata].map((w) => w >>> 0)).toEqual(golden.gluWords);
  });
});
