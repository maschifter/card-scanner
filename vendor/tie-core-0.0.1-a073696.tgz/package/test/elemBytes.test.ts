import { describe, expect, it } from 'vitest';
import { elemBytes } from '../src/graph/value.ts';

describe('elemBytes', () => {
  it('sizes an f32 element at 4 bytes', () => {
    expect(elemBytes('f32')).toBe(4);
  });

  it('sizes an f16 element at 2 bytes', () => {
    expect(elemBytes('f16')).toBe(2);
  });

  it('sizes a quantW element at 4 bytes (elems counts u32 words)', () => {
    expect(elemBytes('quantW')).toBe(4);
  });
});
