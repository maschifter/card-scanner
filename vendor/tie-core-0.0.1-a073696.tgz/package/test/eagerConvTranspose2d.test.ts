import { describe, expect, it } from 'vitest';
import { convTranspose2d, materialized, memoryStateDict, nn, tensor3d } from '../src/index.ts';
import * as convert from '../src/weights/convert.ts';
import type { Value, ValueMeta } from '../src/index.ts';
import { fakeGpuBuffer } from './helpers.ts';

const t3 = (c: number, h: number, w: number): Value =>
  materialized(tensor3d(c, h, w), fakeGpuBuffer({}));
const packed = (rows: number, cols: number): Value =>
  materialized(
    { elems: rows * cols, dtype: 'f16', dims: [rows, cols] } as ValueMeta,
    fakeGpuBuffer({}),
  );

describe('convTranspose2d shape rules', () => {
  it('[C,H,W] → [C_out, H·k, W·k] for k=s=2', () => {
    const y = convTranspose2d(t3(64, 80, 80), packed(64 * 4, 64), undefined, {
      kernelSize: 2,
      stride: 2,
    });
    expect(y.shape.dims).toEqual([64, 160, 160]);
    expect(y.shape.dtype).toBe('f32');
    expect(y.pending!.op).toBe('convTranspose2d');
    expect(y.pending!.attrs).toEqual([2, 0]);
  });

  it('rejects kernelSize !== stride (overlap case unimplemented)', () => {
    expect(() =>
      convTranspose2d(t3(4, 8, 8), packed(16, 4), undefined, { kernelSize: 2, stride: 1 }),
    ).toThrow('kernelSize === stride');
  });

  it('rejects weight C_in mismatch and non-k² row counts', () => {
    expect(() =>
      convTranspose2d(t3(4, 8, 8), packed(16, 8), undefined, { kernelSize: 2, stride: 2 }),
    ).toThrow('C_in');
    expect(() =>
      convTranspose2d(t3(4, 8, 8), packed(18, 4), undefined, { kernelSize: 2, stride: 2 }),
    ).toThrow('rows');
  });

  it('rejects bad bias', () => {
    const bias = materialized(
      { elems: 3, dtype: 'f32', dims: [3] } as ValueMeta,
      fakeGpuBuffer({}),
    );
    expect(() =>
      convTranspose2d(t3(4, 8, 8), packed(16, 4), bias, { kernelSize: 2, stride: 2 }),
    ).toThrow('bias');
  });
});

describe('nn.ConvTranspose2d', () => {
  it('permutes checkpoint weights from torch [cIn,cOut,k,k] to kernel rows at load', async () => {
    const { f16ToF32 } = convert;
    const m = new nn.ConvTranspose2d(3, 2, { kernelSize: 2, stride: 2, bias: false });
    // torch layout, value = ci*100 + co*10 + tap so every position is identifiable
    const torchWeights = new Float32Array(3 * 2 * 4);
    for (let ci = 0; ci < 3; ci++)
      for (let co = 0; co < 2; co++)
        for (let t = 0; t < 4; t++)
          torchWeights[ci * 8 + co * 4 + t] = ci * 100 + co * 10 + t;
    let uploaded: Uint16Array | undefined;
    await m.loadStateDict(
      memoryStateDict({ weight: { data: torchWeights, shape: [2 * 4, 3] } }),
      {
        upload: (data, shape) => {
          uploaded = data as Uint16Array;
          return materialized(shape, fakeGpuBuffer({}));
        },
      },
    );
    const out = f16ToF32(uploaded!);
    // kernel row co*4 + tap, column ci
    expect(out[(0 * 4 + 0) * 3 + 2]).toBe(200); // co=0,tap=0,ci=2
    expect(out[(1 * 4 + 3) * 3 + 0]).toBe(13); //  co=1,tap=3,ci=0
  });

  it('registers weight/bias with kernel-layout dims and forwards', async () => {
    const m = new nn.ConvTranspose2d(64, 64, { kernelSize: 2, stride: 2 });
    const params = Object.fromEntries(Array.from(m.namedParameters()));
    expect(params['weight']!.shape.dims).toEqual([64 * 4, 64]); // [C_out·k², C_in]
    expect(params['weight']!.shape.dtype).toBe('f16');
    expect(params['weight']!.shape.elems).toBe(64 * 4 * 64);
    expect(params['bias']!.shape.dims).toEqual([64]);
    await m.loadStateDict(
      memoryStateDict({
        weight: { data: new Float32Array(params['weight']!.shape.elems), shape: [64 * 4, 64] },
        bias: new Float32Array(64),
      }),
      { upload: (_, shape) => materialized(shape, fakeGpuBuffer({})) },
    );
    expect(m.forward(t3(64, 80, 80)).shape.dims).toEqual([64, 160, 160]);
  });
});
