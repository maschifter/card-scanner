import { describe, expect, it } from 'vitest';
import { materialized, matrix } from '../src/graph/value.ts';
import { add, writeRows } from '../src/graph/ops.ts';
import { evalValues, type Executor } from '../src/graph/evalCore.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number, kind = 'x') =>
  materialized(matrix(r, c), fakeGpuBuffer({ kind }));

describe('writeRows op', () => {
  it('returns the grown view of the dst buffer', () => {
    const y = writeRows(mat(6, 4, 'dst'), mat(1, 4, 'src'), 2);
    expect(y.shape.dims).toEqual([3, 4]);
    expect(y.pending!.op).toBe('writeRows');
    expect(y.pending!.attrs).toEqual([2]);
  });

  it('rejects a pending dst, col mismatch and capacity overflow', () => {
    const pendingDst = add(mat(2, 4), mat(2, 4));
    expect(() => writeRows(pendingDst, mat(1, 4), 0)).toThrow(/materialized/);
    expect(() => writeRows(mat(6, 4), mat(1, 3), 0)).toThrow(/col mismatch/);
    expect(() => writeRows(mat(6, 4), mat(2, 4), 5)).toThrow(/capacity/);
  });
});

describe('eval driver in-place handling', () => {
  function trackingExecutor() {
    const acquired: unknown[] = [];
    const released: unknown[] = [];
    const ex: Executor = {
      acquireOutput: (shape) => {
        const b = fakeGpuBuffer({ kind: 'out', shape });
        acquired.push(b);
        return b;
      },
      releaseOutput: (buffer) => {
        released.push(buffer);
      },
      dispatch: () => {},
      submit: () => {},
    };
    return { ex, acquired, released };
  }

  it('aliases the writeRows output onto dst and never pool-releases it', () => {
    const dst = mat(4, 2, 'dst');
    const src = mat(1, 2, 'src');
    const w = writeRows(dst, src, 1); // [2, 2] view
    const y = add(w, w); // consumes the view — last use would normally release it
    const { ex, acquired, released } = trackingExecutor();
    evalValues([y], ex);
    expect(w.buffer).toBe(dst.buffer); // no fresh allocation for the in-place node
    expect(acquired).toHaveLength(1); // only y's output was acquired
    expect(released).not.toContain(dst.buffer); // caller-owned buffer stays out of the pool
    expect(w.state).toBe('materialized'); // usable again next step, never 'released'
    expect(y.state).toBe('materialized');
  });
});
