import { describe, expect, it, vi } from 'vitest';
import { PipelineCache } from '../src/gpu/pipelineCache.ts';

describe('PipelineCache', () => {
  it('builds a pipeline once per (op,dtype) and reuses it', () => {
    const build = vi.fn((op: string, dtype: string) => ({ op, dtype }));
    const cache = new PipelineCache(build);
    const p1 = cache.get('add', 'f16');
    const p2 = cache.get('add', 'f16');
    expect(build).toHaveBeenCalledTimes(1);
    expect(p2).toBe(p1);
  });

  it('builds separate pipelines for different ops or dtypes', () => {
    const build = vi.fn((op: string, dtype: string) => ({ op, dtype }));
    const cache = new PipelineCache(build);
    cache.get('add', 'f16');
    cache.get('add', 'f32');
    cache.get('mul', 'f16');
    expect(build).toHaveBeenCalledTimes(3);
  });
});
