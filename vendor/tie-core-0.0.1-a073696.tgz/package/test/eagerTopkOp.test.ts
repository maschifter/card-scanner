import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { topk } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

describe('topk', () => {
  it('[T,E] -> [T,8] packed ids+weights', () => {
    const y = topk(materialized(matrix(3, 16), fakeGpuBuffer({ id: 'x' })), 4);
    expect(y.pending!.op).toBe('topk');
    expect(y.shape).toEqual({ elems: 24, dtype: 'f32', dims: [3, 8] });
  });
  it('rejects k != 4 and too-few columns', () => {
    const x = materialized(matrix(3, 16), fakeGpuBuffer({ id: 'x' }));
    expect(() => topk(x, 2)).toThrow(/topk/);
    expect(() => topk(materialized(matrix(3, 3), fakeGpuBuffer({ id: 'y' })), 4)).toThrow(/topk/);
  });
});
