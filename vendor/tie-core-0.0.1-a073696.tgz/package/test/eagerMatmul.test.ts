import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { matmul } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

describe('matrix shape helper', () => {
  it('builds an f32 matrix shape with dims and total elems', () => {
    const s = matrix(2, 3);
    expect(s).toEqual({ elems: 6, dtype: 'f32', dims: [2, 3] });
  });
});

describe('matmul op', () => {
  it('[M,K] x [K,N] -> [M,N] pending value', () => {
    const a = materialized(matrix(2, 3), fakeGpuBuffer({ id: 'a' }));
    const b = materialized(matrix(3, 4), fakeGpuBuffer({ id: 'b' }));
    const c = matmul(a, b);
    expect(c.state).toBe('pending');
    expect(c.pending!.op).toBe('matmul');
    expect(c.shape).toEqual({ elems: 8, dtype: 'f32', dims: [2, 4] });
  });

  it('throws on inner-dim mismatch', () => {
    const a = materialized(matrix(2, 3), fakeGpuBuffer({ id: 'a' }));
    const b = materialized(matrix(5, 4), fakeGpuBuffer({ id: 'b' }));
    expect(() => matmul(a, b)).toThrow(/matmul.*3.*5/);
  });
});
