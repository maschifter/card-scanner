import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { rope, swigluChunk } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));

describe('rope column window', () => {
  const tables = (t: number, hd: number) => mat(t, hd);

  it('windows a wider slab: output takes the window width', () => {
    const y = rope(mat(5, 24), tables(5, 8), tables(5, 8), {
      headDim: 8,
      srcStart: 8,
      width: 8,
    });
    expect(y.shape.dims).toEqual([5, 8]);
    expect(y.pending!.attrs).toEqual([8, 8, 8]);
  });

  it('defaults to the full width (srcStart 0)', () => {
    const y = rope(mat(5, 16), tables(5, 8), tables(5, 8), { headDim: 8 });
    expect(y.shape.dims).toEqual([5, 16]);
    expect(y.pending!.attrs).toEqual([8, 0, 16]);
  });

  it('rejects a window past the input and a non-multiple width', () => {
    expect(() =>
      rope(mat(5, 24), tables(5, 8), tables(5, 8), { headDim: 8, srcStart: 20, width: 8 }),
    ).toThrow(/window/);
    expect(() =>
      rope(mat(5, 24), tables(5, 8), tables(5, 8), { headDim: 8, srcStart: 0, width: 12 }),
    ).toThrow(/multiple/);
  });
});

describe('swigluChunk op', () => {
  it('halves the columns in one node', () => {
    const y = swigluChunk(mat(3, 16));
    expect(y.shape.dims).toEqual([3, 8]);
    expect(y.pending!.op).toBe('swigluChunk');
    expect(y.pending!.inputs).toHaveLength(1);
  });

  it('rejects odd column counts', () => {
    expect(() => swigluChunk(mat(3, 15))).toThrow(/even/);
  });
});
