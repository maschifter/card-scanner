import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { add, mul, sub } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

describe('broadcast shape rules', () => {
  it('row-broadcasts [M,N] + [N]', () => {
    const x = materialized(matrix(2, 3), fakeGpuBuffer({ id: 'x' }));
    const bias = materialized({ elems: 3, dtype: 'f32', dims: [3] }, fakeGpuBuffer({ id: 'b' }));
    const y = add(x, bias);
    expect(y.shape).toEqual({ elems: 6, dtype: 'f32', dims: [2, 3] });
    expect(y.pending!.inputs[0]).toBe(x); // full operand first
    expect(y.pending!.inputs[1]).toBe(bias);
    expect(y.pending!.attrs).toEqual([1]); // row mode
  });

  it('col-broadcasts [M,N] + [M,1]', () => {
    const x = materialized(matrix(2, 3), fakeGpuBuffer({ id: 'x' }));
    const factor = materialized(
      { elems: 2, dtype: 'f32', dims: [2, 1] },
      fakeGpuBuffer({ id: 'f' }),
    );
    const y = add(x, factor);
    expect(y.shape.dims).toEqual([2, 3]);
    expect(y.pending!.attrs).toEqual([2]); // col mode
  });

  it('col-broadcasts square [N,N] * [N,1] (ambiguous by element count alone)', () => {
    // With M === N, the [N,1] column has as many elements as a [N] row — dims,
    // not element counts, must decide, or this silently row-broadcasts.
    const x = materialized(matrix(64, 64), fakeGpuBuffer({ id: 'x' }));
    const col = materialized(matrix(64, 1), fakeGpuBuffer({ id: 'c' }));
    const y = mul(x, col);
    expect(y.shape.dims).toEqual([64, 64]);
    expect(y.pending!.attrs).toEqual([2]); // col mode, not row
  });

  it('throws when neither dim matches', () => {
    const x = materialized(matrix(2, 3), fakeGpuBuffer({ id: 'x' }));
    const bad = materialized({ elems: 5, dtype: 'f32', dims: [5] }, fakeGpuBuffer({ id: 'z' }));
    expect(() => add(x, bad)).toThrow(/incompatible/);
  });
});

describe('scalar broadcast (mode 3)', () => {
  const x = () => materialized(matrix(2, 3), fakeGpuBuffer({ id: 'x' }));
  const scalar = () => materialized(matrix(1, 1), fakeGpuBuffer({ id: 's' }));

  it('broadcasts a GPU-side [1,1] across [M,N] for add/mul/sub', () => {
    for (const op of [add, mul, sub]) {
      const y = op(x(), scalar());
      expect(y.shape.dims).toEqual([2, 3]);
      expect(y.pending!.attrs).toEqual([3]); // scalar mode
      expect(y.pending!.inputs[1]!.shape.elems).toBe(1);
    }
  });

  it('accepts a dims-less single-element operand too', () => {
    const s = materialized({ elems: 1, dtype: 'f32', dims: [1] }, fakeGpuBuffer({ id: 's' }));
    expect(add(x(), s).pending!.attrs).toEqual([3]);
  });

  it('[1,1] vs [1,1] stays plain elementwise', () => {
    expect(add(scalar(), scalar()).pending!.attrs).toEqual([0]);
  });
});

describe('sub broadcast and ordering rules', () => {
  const x = () => materialized(matrix(2, 3), fakeGpuBuffer({ id: 'x' }));

  it('col-broadcasts [M,N] − [M,1] keeping a first', () => {
    const m = materialized(matrix(2, 1), fakeGpuBuffer({ id: 'm' }));
    const y = sub(x(), m);
    expect(y.shape.dims).toEqual([2, 3]);
    expect(y.pending!.op).toBe('sub');
    expect(y.pending!.inputs[1]).toBe(m);
    expect(y.pending!.attrs).toEqual([2]); // col mode
  });

  it('row-broadcasts [M,N] − [N]', () => {
    const row = materialized({ elems: 3, dtype: 'f32', dims: [3] }, fakeGpuBuffer({ id: 'r' }));
    const y = sub(x(), row);
    expect(y.pending!.attrs).toEqual([1]); // row mode
  });

  it('rejects a smaller a — subtraction must not be silently reordered', () => {
    const m = materialized(matrix(2, 1), fakeGpuBuffer({ id: 'm' }));
    expect(() => sub(m, x())).toThrow(/full operand/);
  });
});
