import { describe, expect, it } from 'vitest';
import { matmul } from '../src/graph/ops.ts';
import { materialized, matrix, type ValueMeta } from '../src/graph/value.ts';
import { fakeGpuBuffer } from './helpers.ts';

const a = materialized(matrix(2, 8), fakeGpuBuffer({})); // [M=2, K=8]
// int8 weight logical [R=16, N=4] → 16*4/4 = 16 u32 words
const w8: ValueMeta = { elems: 16, dtype: 'quantW', dims: [16, 4] };
const scales = materialized({ elems: 8, dtype: 'f32', dims: [4, 2] }, fakeGpuBuffer({}));

describe('matmul with a quantW weight', () => {
  it('derives [M,N] and accepts a valid int8 view', () => {
    const w = materialized(w8, fakeGpuBuffer({}));
    const y = matmul(a, w, { scales, baseRow: 0, scaleBase: 0, bits: 8, groupSize: 8 });
    expect(y.shape.dims).toEqual([2, 4]);
    expect(y.shape.dtype).toBe('f32');
    expect(y.pending!.op).toBe('matmulQuantW');
  });
  it('rejects quant opts on an f32 weight', () => {
    const w = materialized(matrix(16, 4), fakeGpuBuffer({}));
    expect(() => matmul(a, w, { scales, baseRow: 0, scaleBase: 0, bits: 8, groupSize: 8 })).toThrow(
      /quantW weights only/,
    );
  });
  it('rejects a quantW weight without quant opts', () => {
    const w = materialized(w8, fakeGpuBuffer({}));
    expect(() => matmul(a, w)).toThrow(/scales, bits and groupSize/);
  });
  it('rejects baseRow+K past R', () => {
    const w = materialized(w8, fakeGpuBuffer({}));
    expect(() =>
      matmul(a, w, { scales, baseRow: 12, scaleBase: 0, bits: 8, groupSize: 8 }),
    ).toThrow(/baseRow/);
  });
});
