import { describe, expect, it, vi } from 'vitest';
import { BufferPool } from '../src/gpu/bufferPool.ts';
import type { ValueMeta } from '../src/graph/value.ts';
import { fakeGpuBuffer } from './helpers.ts';

const v4 = (elems: number): ValueMeta => ({ elems, dtype: 'f16' });

describe('BufferPool', () => {
  it('creates a new buffer on first acquire of a (dtype,size)', () => {
    const create = vi.fn((s: ValueMeta) => fakeGpuBuffer({ ...s }));
    const pool = new BufferPool(create);
    pool.acquire(v4(8));
    expect(create).toHaveBeenCalledTimes(1);
  });

  it('reuses a released buffer of the same (dtype,size)', () => {
    const create = vi.fn((s: ValueMeta) => fakeGpuBuffer({ ...s, id: create.mock.calls.length }));
    const pool = new BufferPool(create);
    const b1 = pool.acquire(v4(8));
    pool.release(b1, v4(8));
    const b2 = pool.acquire(v4(8));
    expect(create).toHaveBeenCalledTimes(1);
    expect(b2).toBe(b1);
  });

  it('separates buffers by size AND dtype', () => {
    const create = vi.fn((s: ValueMeta) => fakeGpuBuffer({ ...s }));
    const pool = new BufferPool(create);
    pool.acquire(v4(8));
    pool.acquire({ elems: 8, dtype: 'f32' }); // same elems, different dtype
    pool.acquire(v4(4));
    expect(create).toHaveBeenCalledTimes(3);
  });
});
