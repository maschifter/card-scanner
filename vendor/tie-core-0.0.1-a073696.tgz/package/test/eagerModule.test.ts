import { describe, expect, it } from 'vitest';
import { materialized, matrix, type ValueMeta, type Value } from '../src/graph/value.ts';
import { Module, ModuleList, Parameter, Buffer } from '../src/nn/module.ts';
import { memoryStateDict } from '../src/weights/safetensors.ts';
import { fakeGpuBuffer } from './helpers.ts';

class Inner extends Module {
  readonly w = new Parameter(matrix(2, 3));
  forward(x: Value): Value {
    return x;
  }
}
class Outer extends Module {
  readonly inner = new Inner();
  readonly scale = new Parameter({ elems: 3, dtype: 'f32', dims: [3] });
  readonly rope = new Buffer(new Float32Array([1, 2, 3]), { elems: 3, dtype: 'f32', dims: [3] });
  forward(x: Value): Value {
    return this.inner.forward(x);
  }
}

describe('eager Module', () => {
  it('auto-registers params/buffers/modules and assigns dotted names', () => {
    const m = new Outer();
    const names = Array.from(m.namedParameters()).map(([n]) => n);
    expect(names).toEqual(['scale', 'inner.w']); // own params first, then children
    const bufNames = Array.from(m.namedBuffers()).map(([n]) => n);
    expect(bufNames).toEqual(['rope']);
  });

  it('loadStateDict binds every Parameter and uploads Buffers via the injected upload', async () => {
    const m = new Outer();
    const uploaded: Array<{ shape: ValueMeta; len: number }> = [];
    const upload = (data: Float32Array | Uint16Array | Uint32Array, shape: ValueMeta): Value => {
      uploaded.push({ shape, len: data.length });
      return materialized(shape, fakeGpuBuffer({ data }));
    };
    await m.loadStateDict(
      memoryStateDict({ scale: new Float32Array(3), 'inner.w': new Float32Array(6) }),
      {
        upload,
      },
    );
    expect(m.scale.value.state).toBe('materialized');
    expect(m.inner.w.value.state).toBe('materialized');
    expect(m.rope.value.state).toBe('materialized'); // buffer uploaded too
    expect(uploaded).toHaveLength(3);
  });

  it('loadStateDict throws on a missing or wrong-sized weight', async () => {
    const m = new Outer();
    const upload = (_d: Float32Array | Uint16Array | Uint32Array, s: ValueMeta): Value =>
      materialized(s, fakeGpuBuffer({}));
    await expect(
      m.loadStateDict(memoryStateDict({ scale: new Float32Array(3) }), { upload }),
    ).rejects.toThrow(/inner\.w/);
    await expect(
      m.loadStateDict(
        memoryStateDict({ scale: new Float32Array(9), 'inner.w': new Float32Array(6) }),
        { upload },
      ),
    ).rejects.toThrow(/scale.*3/);
  });
});

describe('ModuleList', () => {
  it('registers items under numeric names so dotted paths come out block.N.*', () => {
    class Leaf extends Module {
      readonly w = new Parameter(matrix(2, 2));
      forward(x: Value): Value {
        return x;
      }
    }
    class Holder extends Module {
      readonly block = new ModuleList([new Leaf(), new Leaf()]);
      forward(x: Value): Value {
        return x;
      }
    }
    const h = new Holder();
    const names = Array.from(h.namedParameters()).map(([n]) => n);
    expect(names).toEqual(['block.0.w', 'block.1.w']);
    expect(h.block.items).toHaveLength(2);
  });
});
