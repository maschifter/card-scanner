import { describe, expect, it } from 'vitest';
import { hwc4Meta, materialized, tensor3d } from '../src/graph/value.ts';
import { cat, conv2d, reshape, slice } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const t3 = (c: number, h: number, w: number, id: string) =>
  materialized(tensor3d(c, h, w), fakeGpuBuffer({ id }));

/** hwc4-stored activation (what conv2d takes) with a fake buffer. */
const t3h = (c: number, h: number, w: number, id: string) =>
  materialized(hwc4Meta(c, h, w), fakeGpuBuffer({ id }));

const packedWeight = (cOut: number, kk: number, id: string) =>
  materialized(
    { elems: cOut * kk, dtype: 'f16' as const, dims: [cOut, kk], layout: 'hwc4' as const },
    fakeGpuBuffer({ id }),
  );

describe('conv2d op kernelSize', () => {
  it('declared kernelSize is cross-checked against the weight shape', () => {
    const x = t3h(4, 8, 8, 'x');
    const w3 = packedWeight(8, 4 * 9, 'w3'); // 3×3 weight
    const ok = conv2d(x, w3, undefined, { kernelSize: 3, stride: 1, padding: 1, groups: 1 });
    expect(ok.shape.dims).toEqual([8, 8, 8]);
    // 1×9 lie: kk=36 also divides as 4·(3·3) only — declaring 1 must throw
    expect(() =>
      conv2d(x, w3, undefined, { kernelSize: 1, stride: 1, padding: 0, groups: 1 }),
    ).toThrow('weight cols');
  });

  it('supports kernel sizes beyond 3 (whitelist removed)', () => {
    const x = t3h(4, 12, 12, 'x');
    const w5 = packedWeight(8, 4 * 25, 'w5'); // 5×5 weight
    const out = conv2d(x, w5, undefined, { kernelSize: 5, stride: 1, padding: 2, groups: 1 });
    expect(out.shape.dims).toEqual([8, 12, 12]);
  });
});

describe('reshape op', () => {
  it('reinterprets [3,4,4] as [3,16] preserving elems', () => {
    const out = reshape(t3(3, 4, 4, 'x'), [3, 16]);
    expect(out.shape.dims).toEqual([3, 16]);
    expect(out.shape.elems).toBe(48);
  });

  it('rejects element count change', () => {
    expect(() => reshape(t3(3, 4, 4, 'x'), [3, 10])).toThrow('reshape');
  });
});

describe('concatChannels op', () => {
  it('[2,4,4] ++ [3,4,4] → [5,4,4]', () => {
    const out = cat([t3(2, 4, 4, 'a'), t3(3, 4, 4, 'b')], 0);
    expect(out.shape.dims).toEqual([5, 4, 4]);
    expect(out.shape.elems).toBe(80);
    expect(out.pending!.op).toBe('concatChannels');
  });

  it('rejects mismatched H or W', () => {
    expect(() => cat([t3(2, 4, 4, 'a'), t3(3, 4, 5, 'b')], 0)).toThrow('spatial mismatch');
  });
});

describe('sliceChannels op', () => {
  it('[4,4,4] sliced [1:3) → [2,4,4] with attrs', () => {
    const out = slice(t3(4, 4, 4, 'x'), 0, 1, 3);
    expect(out.shape.dims).toEqual([2, 4, 4]);
    expect(out.shape.elems).toBe(32);
    expect(out.pending!.attrs).toEqual([1, 3]);
  });

  it('rejects out-of-range slice', () => {
    expect(() => slice(t3(4, 4, 4, 'x'), 0, 2, 6)).toThrow('bad range');
  });
});
