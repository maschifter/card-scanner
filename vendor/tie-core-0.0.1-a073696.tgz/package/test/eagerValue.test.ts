import { describe, expect, it } from 'vitest';
import { materialized, Value } from '../src/graph/value.ts';
import { add } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

describe('eager Value + ops', () => {
  it('materialized() is a leaf with no pending op', () => {
    const a = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'test-buffer' }));
    expect(a.state).toBe('materialized');
    expect(a.pending).toBeUndefined();
    expect(a.shape.elems).toBe(8);
  });

  it('add() builds a pending Value linked to both inputs, dispatches nothing', () => {
    const a = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'a' }));
    const b = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'b' }));
    const c = add(a, b);
    expect(c.state).toBe('pending');
    expect(c.pending!.op).toBe('add');
    expect(c.pending!.inputs).toEqual([a, b]);
    expect(c.shape).toEqual({ elems: 8, dtype: 'f16' });
  });

  it('add() throws on shape mismatch with both shapes in the message', () => {
    const a = materialized({ elems: 8, dtype: 'f16' }, fakeGpuBuffer({ kind: 'a' }));
    const b = materialized({ elems: 4, dtype: 'f16' }, fakeGpuBuffer({ kind: 'b' }));
    expect(() => add(a, b)).toThrow(/add.*8.*4/);
  });
});

describe('PendingOp attrs', () => {
  it('attrs and scalar are independent fields', () => {
    const a = materialized({ elems: 8, dtype: 'f32', dims: [2, 4] }, fakeGpuBuffer({ kind: 'a' }));
    const p = Value.pending(
      { elems: 4, dtype: 'f32', dims: [2, 2] },
      'sliceCols',
      [a],
      undefined,
      [1, 3],
    );
    expect(p.pending!.attrs).toEqual([1, 3]);
    expect(p.pending!.scalar).toBeUndefined();
  });
});
