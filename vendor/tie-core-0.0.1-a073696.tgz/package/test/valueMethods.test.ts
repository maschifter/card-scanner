import { describe, expect, it } from 'vitest';
import '../src/graph/methods.ts';
import { matrix, materialized } from '../src/graph/value.ts';
import {
  add,
  chunk,
  clamp,
  matmul,
  mean,
  reshape,
  slice,
  softmax,
  split,
  topk,
  transpose,
} from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));

describe('Value method forms', () => {
  it('unary methods produce the same pending as the functions', () => {
    const x = mat(2, 4);
    for (const name of ['softmax', 'sigmoid', 'tanh', 'asinh', 'mean', 'rsqrt'] as const) {
      const y = x[name]();
      expect(y.pending!.op).toBe(name === 'mean' ? 'mean' : name);
    }
    expect(x.softmax().shape).toEqual(softmax(x).shape);
    expect(x.mean().shape).toEqual(mean(x).shape);
  });

  it('add/sub/mul accept Value and number operands', () => {
    const x = mat(2, 3);
    expect(x.add(mat(2, 3)).pending!.op).toBe(add(x, mat(2, 3)).pending!.op);
    expect(x.add(0.5).pending!.op).toBe('addScalar');
    expect(x.add(0.5).pending!.scalar).toBe(0.5);
    expect(x.sub(2).pending!.op).toBe('addScalar'); // sub folds to add of −c
    expect(x.mul(1.702).pending!.op).toBe('mulScalar');
  });

  it('matmul forwards opts', () => {
    const a = mat(2, 3);
    const w = mat(3, 4);
    const bias = mat(1, 4);
    const viaMethod = a.matmul(w, { bias });
    const viaFn = matmul(a, w, { bias });
    expect(viaMethod.pending!.op).toBe(viaFn.pending!.op);
    expect(viaMethod.pending!.inputs.length).toBe(viaFn.pending!.inputs.length);
    expect(viaMethod.shape).toEqual(viaFn.shape);
  });

  it('shape methods match the functions', () => {
    const x = mat(2, 6);
    expect(x.reshape([3, 4]).shape).toEqual(reshape(x, [3, 4]).shape);
    expect(x.transpose().shape).toEqual(transpose(x).shape);
    expect(x.clamp(-7, 7).pending!.attrs).toEqual(clamp(x, -7, 7).pending!.attrs);
    expect(x.slice(1, 0, 2).shape).toEqual(slice(x, 1, 0, 2).shape);
  });

  it('chunk and split return the same parts as the functions', () => {
    const x = mat(2, 6);
    const viaMethod = x.chunk(3, 1);
    const viaFn = chunk(x, 3, 1);
    expect(viaMethod.length).toBe(3);
    viaMethod.forEach((part, i) => expect(part.shape).toEqual(viaFn[i]!.shape));

    const parts = x.split([2, 4], 1);
    split(x, [2, 4], 1).forEach((part, i) => expect(parts[i]!.shape).toEqual(part.shape));
  });

  it('topk matches the function', () => {
    const x = mat(2, 8);
    expect(x.topk(4).shape).toEqual(topk(x, 4).shape);
  });

  it('methods chain', () => {
    const x = mat(2, 3);
    const w = mat(3, 4);
    const y = x.matmul(w).add(0.5).softmax();
    expect(y.pending!.op).toBe('softmax');
    expect(y.shape.dims).toEqual([2, 4]);
  });
});
