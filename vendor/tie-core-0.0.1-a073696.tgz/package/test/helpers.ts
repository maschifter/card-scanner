import type { GpuBufferRef } from '../src/graph/value.ts';

/** Node tests run without a GPU, so plain objects stand in for real TypeGPU
 *  buffers. GpuBufferRef is strictly typed against TypeGPU; this is the one
 *  sanctioned escape hatch for tests that never dispatch to a device. */
export const fakeGpuBuffer = (o: object): GpuBufferRef => o as unknown as GpuBufferRef;
