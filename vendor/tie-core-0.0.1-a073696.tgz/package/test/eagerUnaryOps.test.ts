import { describe, expect, it } from 'vitest';
import { hwc4Meta, matrix, materialized } from '../src/graph/value.ts';
import { add, asinh, clamp, gelu, mul, rsqrt, sigmoid, silu, sub, tanh } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));
const hwc4 = (c: number, h: number, w: number) =>
  materialized(hwc4Meta(c, h, w), fakeGpuBuffer({ id: 'x' }));

describe('unary scalar ops', () => {
  it('sigmoid preserves shape', () => {
    const y = sigmoid(mat(2, 3));
    expect(y.pending!.op).toBe('sigmoid');
    expect(y.shape).toEqual({ elems: 6, dtype: 'f32', dims: [2, 3] });
  });
  it('mul with a number records the scalar', () => {
    const y = mul(mat(2, 3), 1.702);
    expect(y.pending!.op).toBe('mulScalar');
    expect(y.pending!.scalar).toBe(1.702);
  });
  it('add with a number records the scalar', () => {
    const y = add(mat(2, 3), 0.5);
    expect(y.pending!.op).toBe('addScalar');
    expect(y.pending!.scalar).toBe(0.5);
  });
  it('sub with a number lowers to a scalar add of the negation', () => {
    const y = sub(mat(2, 3), 3);
    expect(y.pending!.op).toBe('addScalar');
    expect(y.pending!.scalar).toBe(-3);
  });
  it('clamp records [lo, hi] attrs and validates order', () => {
    const y = clamp(mat(2, 3), -7, 7);
    expect(y.pending!.op).toBe('clampScalar');
    expect(y.pending!.attrs).toEqual([-7, 7]);
    expect(() => clamp(mat(2, 3), 7, -7)).toThrow(/clamp/);
  });
  it('clamp throws on NaN lo (!(lo <= hi) guard)', () => {
    expect(() => clamp(mat(2, 3), NaN, 7)).toThrow(/clamp/);
  });
  it('clamp(-Infinity, 7) records attrs [-Infinity, 7]', () => {
    const y = clamp(mat(2, 3), -Infinity, 7);
    expect(y.pending!.attrs).toEqual([-Infinity, 7]);
  });
  it('tanh/gelu/silu/asinh preserve shape and route by op name', () => {
    for (const [op, f] of [
      ['tanh', tanh],
      ['gelu', gelu],
      ['silu', silu],
      ['asinh', asinh],
    ] as const) {
      const y = f(mat(2, 3));
      expect(y.pending!.op).toBe(op);
      expect(y.shape).toEqual({ elems: 6, dtype: 'f32', dims: [2, 3] });
    }
  });
  it('rsqrt preserves shape on a plain (non-hwc4) value', () => {
    const y = rsqrt(mat(2, 3));
    expect(y.pending!.op).toBe('rsqrt');
    expect(y.shape).toEqual({ elems: 6, dtype: 'f32', dims: [2, 3] });
  });
  it('rsqrt refuses hwc4 input', () => {
    expect(() => rsqrt(hwc4(4, 2, 2))).toThrow(/hwc4/);
  });
  it('sigmoid refuses hwc4 input', () => {
    expect(() => sigmoid(hwc4(4, 2, 2))).toThrow(/hwc4/);
  });
});

describe('hwc4 elementwise', () => {
  it('accepts matching hwc4 shapes', () => {
    const y = add(hwc4(4, 2, 2), hwc4(4, 2, 2));
    expect(y.pending!.op).toBe('add');
  });
  it('rejects hwc4 operands whose padded elems match but dims differ', () => {
    // c4of(5) === c4of(8) === 2, so both pad to the same elems.
    expect(() => add(hwc4(5, 2, 2), hwc4(8, 2, 2))).toThrow(/incompatible/);
    expect(() => mul(hwc4(5, 2, 2), hwc4(8, 2, 2))).toThrow(/incompatible/);
  });
});
