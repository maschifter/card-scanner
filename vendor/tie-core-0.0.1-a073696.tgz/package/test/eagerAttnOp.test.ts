import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { sdpa } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));

const GEO = { qHeads: 8, kvHeads: 8, headDim: 36 }; // Moonshine-tiny head layout
const W = GEO.qHeads * GEO.headDim;

describe('sdpa op', () => {
  it('full bidirectional: output mirrors q shape', () => {
    const y = sdpa(mat(5, W), mat(5, W), mat(5, W), {
      ...GEO,
      windowLeft: Infinity,
      windowRight: Infinity,
    });
    expect(y.pending!.op).toBe('attn');
    expect(y.shape.dims).toEqual([5, W]);
  });

  it('lowers Infinity windows to the finite unbounded sentinel in attrs', () => {
    const y = sdpa(mat(5, W), mat(5, W), mat(5, W), {
      ...GEO,
      windowLeft: Infinity,
      windowRight: 0,
    });
    const [qHeads, kvHeads, headDim, wl, wr, off] = y.pending!.attrs!;
    expect([qHeads, kvHeads, headDim]).toEqual([8, 8, 36]);
    expect(Number.isFinite(wl)).toBe(true);
    expect(wl).toBe(0x3fffffff);
    expect(wr).toBe(0);
    expect(off).toBe(0);
  });

  it('cross-attention: kvLen independent of qLen under unbounded windows', () => {
    const y = sdpa(mat(15, W), mat(123, W), mat(123, W), {
      ...GEO,
      windowLeft: Infinity,
      windowRight: Infinity,
    });
    expect(y.shape.dims).toEqual([15, W]);
  });

  it('incremental causal step: qLen=1 with qPosOffset into a longer key axis', () => {
    const y = sdpa(mat(1, W), mat(8, W), mat(8, W), {
      ...GEO,
      windowLeft: Infinity,
      windowRight: 0,
      qPosOffset: 7,
    });
    expect(y.pending!.attrs![5]).toBe(7);
  });

  it('banded windows require q positions to map into the key axis', () => {
    // Causal with a forgotten offset: rows 0..4 but only 3 keys.
    expect(() =>
      sdpa(mat(5, W), mat(3, W), mat(3, W), { ...GEO, windowLeft: Infinity, windowRight: 0 }),
    ).toThrow(/qPosOffset\+qLen/);
  });

  it('validates head geometry and k/v agreement', () => {
    const opts = { ...GEO, windowLeft: Infinity, windowRight: Infinity };
    expect(() => sdpa(mat(5, W + 1), mat(5, W), mat(5, W), opts)).toThrow(/q cols/);
    expect(() => sdpa(mat(5, W), mat(5, W - 36), mat(5, W), opts)).toThrow(/k cols/);
    expect(() => sdpa(mat(5, W), mat(5, W), mat(4, W), opts)).toThrow(/v rows/);
    expect(() => sdpa(mat(5, W), mat(5, W), mat(5, W), { ...opts, kvHeads: 3 })).toThrow(
      /divisible/,
    );
    expect(() =>
      sdpa(mat(5, 8 * 130), mat(5, 8 * 130), mat(5, 8 * 130), { ...opts, headDim: 130 }),
    ).toThrow(/max \(128\)/);
  });

  it('rejects negative or fractional windows and offsets', () => {
    const g = { ...GEO };
    expect(() =>
      sdpa(mat(5, W), mat(5, W), mat(5, W), { ...g, windowLeft: -1, windowRight: 0 }),
    ).toThrow(/windowLeft/);
    expect(() =>
      sdpa(mat(5, W), mat(5, W), mat(5, W), { ...g, windowLeft: 1.5, windowRight: 0 }),
    ).toThrow(/windowLeft/);
    expect(() =>
      sdpa(mat(5, W), mat(5, W), mat(5, W), {
        ...g,
        windowLeft: Infinity,
        windowRight: Infinity,
        qPosOffset: -2,
      }),
    ).toThrow(/qPosOffset/);
  });

  it('qPosOffset changes only attrs[5] — the pipeline-key material stays identical', () => {
    // eval.ts builds the pipeline cfg from attrs[0..4]; the offset must ride in
    // the uniform, or every incremental-decode step would compile a shader.
    const at = (off: number) =>
      sdpa(mat(1, W), mat(8, W), mat(8, W), {
        ...GEO,
        windowLeft: Infinity,
        windowRight: 0,
        qPosOffset: off,
      }).pending!.attrs!;
    expect(at(3).slice(0, 5)).toEqual(at(7).slice(0, 5));
    expect(at(3)[5]).toBe(3);
    expect(at(7)[5]).toBe(7);
  });

  it('optional sinks ride as a fourth input with the hasSinks flag in attrs[6]', () => {
    const opts = { ...GEO, windowLeft: Infinity, windowRight: Infinity };
    const withSinks = sdpa(mat(5, W), mat(5, W), mat(5, W), {
      ...opts,
      sinks: mat(1, GEO.qHeads),
    });
    const without = sdpa(mat(5, W), mat(5, W), mat(5, W), opts);
    expect(withSinks.pending!.inputs.length).toBe(4);
    expect(without.pending!.inputs.length).toBe(3);
    expect(withSinks.pending!.attrs![6]).toBe(1);
    expect(without.pending!.attrs![6]).toBe(0);
    // Everything except the flag stays identical.
    expect(withSinks.pending!.attrs!.slice(0, 6)).toEqual(without.pending!.attrs!.slice(0, 6));
  });

  it('rejects sinks with the wrong size', () => {
    const opts = { ...GEO, windowLeft: Infinity, windowRight: Infinity };
    expect(() => sdpa(mat(5, W), mat(5, W), mat(5, W), { ...opts, sinks: mat(1, 3) })).toThrow(
      /sinks/,
    );
  });

  it('GQA: kvHeads dividing qHeads with narrower k/v', () => {
    const y = sdpa(mat(5, 8 * 36), mat(5, 2 * 36), mat(5, 2 * 36), {
      qHeads: 8,
      kvHeads: 2,
      headDim: 36,
      windowLeft: Infinity,
      windowRight: Infinity,
    });
    expect(y.shape.dims).toEqual([5, 288]);
  });
});
