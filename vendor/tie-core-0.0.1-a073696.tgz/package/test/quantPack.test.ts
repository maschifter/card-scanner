import { describe, expect, it } from 'vitest';
import { packQuantColSlice } from '../src/weights/quantPack.ts';

/** Blocked-unit layout rule (kernels/quantCommon.ts), as an executable spec:
 *  value (k, col) of the width-W slice lands at bit
 *  (((e·W/4 + n)·K/4 + k4)·16 + j·4 + kk)·bits, where n=col/4, j=col%4,
 *  k4=k/4, kk=k%4. */
function expectedWords(
  val: (e: number, k: number, o: number) => number,
  bits: 8 | 4,
  E: number,
  K: number,
  O: number,
  oStart: number,
  oEnd: number,
): Uint32Array {
  const width = oEnd - oStart;
  const mask = bits === 8 ? 0xff : 0xf;
  const words = new Uint32Array((E * K * width * bits) / 32);
  for (let e = 0; e < E; e++) {
    for (let k = 0; k < K; k++) {
      for (let c = 0; c < width; c++) {
        const tile = (e * (width / 4) + (c >> 2)) * (K / 4) + (k >> 2);
        const bit = (tile * 16 + (c % 4) * 4 + (k % 4)) * bits;
        words[bit >> 5] = (words[bit >> 5]! | ((val(e, k, oStart + c) & mask) << (bit & 31))) >>> 0;
      }
    }
  }
  return words;
}

describe('packQuantColSlice', () => {
  it('int8: packs a column slice into blocked-unit tiles and slices scales', () => {
    // [E1, K4, O8], value(k,o) = 10k + o (all fit signed int8)
    const val = (_e: number, k: number, o: number) => 10 * k + o;
    const qbytes = new Uint8Array(32);
    for (let k = 0; k < 4; k++) for (let o = 0; o < 8; o++) qbytes[k * 8 + o] = val(0, k, o) & 0xff;
    const scales = new Float32Array([1, 2, 3, 4, 5, 6, 7, 8]); // [E1, KG1, O8]
    // slice cols [4,8) → width 4 = one unit; K4 → one k4 chunk = one 4-word tile
    const { qdata, scales: outScales } = packQuantColSlice(qbytes, scales, 8, 4, 1, 4, 8, 4, 8);
    expect(qdata.length).toBe(4); // E·K·width/4 = 1·4·4/4
    expect(Array.from(outScales)).toEqual([5, 6, 7, 8]); // scale cols 4..7
    // Spot-check the rule: word j = col (4+j)'s values k0..3, low k low bits.
    const deq = (word: number, lane: number) => ((word >> (lane * 8)) << 24) >> 24;
    expect([0, 1, 2, 3].map((l) => deq(qdata[0]!, l))).toEqual([4, 14, 24, 34]); // col 4
    expect([0, 1, 2, 3].map((l) => deq(qdata[3]!, l))).toEqual([7, 17, 27, 37]); // col 7
    expect(Array.from(qdata)).toEqual(Array.from(expectedWords(val, 8, 1, 4, 8, 4, 8)));
  });

  it('int4: two words per tile (cols j at 16-bit halves), sign preserved', () => {
    // [E1, K4, O8] int4, value(k,o) = ((3k + o) % 15) - 7 ∈ [-7, 7]
    const val = (_e: number, k: number, o: number) => ((3 * k + o) % 15) - 7;
    const qbytes = new Uint8Array(16); // 32 nibbles, even index = low nibble
    for (let k = 0; k < 4; k++) {
      for (let o = 0; o < 8; o++) {
        const s = k * 8 + o;
        const nib = val(0, k, o) & 0xf;
        qbytes[s >> 1] = (qbytes[s >> 1]! | (nib << ((s & 1) * 4))) & 0xff;
      }
    }
    const scales = new Float32Array(8).fill(1); // [E1, KG1, O8]
    const { qdata } = packQuantColSlice(qbytes, scales, 4, 4, 1, 4, 8, 0, 8); // full width 8
    expect(qdata.length).toBe(4); // E·K·width/8 = 1·4·8/8 = 4 (2 units × 2-word tiles)
    expect(Array.from(qdata)).toEqual(Array.from(expectedWords(val, 4, 1, 4, 8, 0, 8)));
    // Spot-check sign: col 0 k0 = val(0,0,0) = -7 → low nibble of word 0.
    const nib0 = qdata[0]! & 0xf;
    expect(nib0 >= 8 ? nib0 - 16 : nib0).toBe(-7);
    // col 1's values sit in word 0's high 16 bits: k0 → nibble lane 4.
    const nib4 = (qdata[0]! >> 16) & 0xf;
    expect(nib4 >= 8 ? nib4 - 16 : nib4).toBe(val(0, 0, 1));
  });

  it('rejects bad widths, non-tiled K, and length mismatches', () => {
    // width 2 is not a multiple of 4
    expect(() =>
      packQuantColSlice(new Uint8Array(32), new Float32Array(8), 8, 4, 1, 4, 8, 0, 2),
    ).toThrow(/width/);
    // K 2 is not a multiple of 4 (blocked tiles)
    expect(() =>
      packQuantColSlice(new Uint8Array(16), new Float32Array(8), 8, 2, 1, 2, 8, 0, 8),
    ).toThrow(/multiple of 4/);
    // valid dims but wrong qbytes length
    expect(() =>
      packQuantColSlice(new Uint8Array(3), new Float32Array(8), 8, 4, 1, 4, 8, 0, 8),
    ).toThrow(/qbytes/);
  });
});
