import { describe, expect, it } from 'vitest';
import { add } from '../src/graph/ops.ts';
import { materialized, type ValueMeta } from '../src/graph/value.ts';
import { fakeGpuBuffer } from './helpers.ts';

const quantMeta: ValueMeta = { elems: 4, dtype: 'quantW', dims: [4, 4] };

describe('quantW dtype', () => {
  it('is a valid EagerDtype and elementwise ops reject it', () => {
    const w = materialized(quantMeta, fakeGpuBuffer({}));
    const x = materialized({ elems: 16, dtype: 'f32', dims: [4, 4] }, fakeGpuBuffer({}));
    expect(() => add(x, w)).toThrow(/weight-only/);
  });
});
