import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { matmul } from '../src/graph/ops.ts';
import { linear } from '../src/graph/compose.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));
const vec = (n: number) =>
  materialized({ elems: n, dtype: 'f32', dims: [n] }, fakeGpuBuffer({ id: 'v' }));

describe('matmul epilogue attrs', () => {
  it('plain matmul carries [0, 0] flags and two inputs', () => {
    const y = matmul(mat(3, 4), mat(4, 8));
    expect(y.pending!.attrs).toEqual([0, 0, 0, 0, 0]);
    expect(y.pending!.inputs).toHaveLength(2);
  });

  it('bias and addend append in (bias, addend) order with [1, 1] flags', () => {
    const y = matmul(mat(3, 4), mat(4, 8), { bias: vec(8), addend: mat(3, 8) });
    expect(y.pending!.attrs).toEqual([1, 1, 0, 0, 0]);
    expect(y.pending!.inputs).toHaveLength(4);
  });

  it('addend-only sits at inputs[2] with [0, 1] flags', () => {
    const y = matmul(mat(3, 4), mat(4, 8), { addend: mat(3, 8) });
    expect(y.pending!.attrs).toEqual([0, 1, 0, 0, 0]);
    expect(y.pending!.inputs).toHaveLength(3);
  });

  it('rejects a bias of the wrong width and an addend of the wrong shape', () => {
    expect(() => matmul(mat(3, 4), mat(4, 8), { bias: vec(7) })).toThrow(/bias/);
    expect(() => matmul(mat(3, 4), mat(4, 8), { addend: mat(3, 7) })).toThrow(/addend/);
  });

  it('linear() is ONE node — bias and residual ride the epilogue', () => {
    const y = linear(mat(3, 4), mat(4, 8), vec(8), mat(3, 8));
    expect(y.pending!.op).toBe('matmul');
    expect(y.pending!.attrs).toEqual([1, 1, 0, 0, 0]);
  });
});
