import { describe, expect, it } from 'vitest';
import { matrix, materialized } from '../src/graph/value.ts';
import { argmaxDot } from '../src/graph/ops.ts';
import { fakeGpuBuffer } from './helpers.ts';

const mat = (r: number, c: number) => materialized(matrix(r, c), fakeGpuBuffer({ id: 'x' }));

describe('argmaxDot op', () => {
  it('emits one [1,1] pending node over (w, x)', () => {
    const y = argmaxDot(mat(100, 8), mat(1, 8));
    expect(y.shape).toEqual({ elems: 1, dtype: 'f32', dims: [1, 1] });
    expect(y.pending!.op).toBe('argmaxDot');
    expect(y.pending!.inputs).toHaveLength(2);
  });

  it('rejects a multi-row x', () => {
    expect(() => argmaxDot(mat(100, 8), mat(2, 8))).toThrow(/single row/);
  });

  it('rejects mismatched widths', () => {
    expect(() => argmaxDot(mat(100, 8), mat(1, 7))).toThrow(/cols/);
  });

  it('accepts an f16 weight table with an f16 x', () => {
    const w = materialized(
      { elems: 800, dtype: 'f16', dims: [100, 8] },
      fakeGpuBuffer({ id: 'w' }),
    );
    const x = materialized({ elems: 8, dtype: 'f16', dims: [1, 8] }, fakeGpuBuffer({ id: 'x' }));
    // The result is a row index, so it stays f32 whatever the operands are.
    expect(argmaxDot(w, x).shape).toEqual({ elems: 1, dtype: 'f32', dims: [1, 1] });
  });

  it('rejects a dtype mismatch between the table and x', () => {
    const w = materialized(
      { elems: 800, dtype: 'f16', dims: [100, 8] },
      fakeGpuBuffer({ id: 'w' }),
    );
    expect(() => argmaxDot(w, mat(1, 8))).toThrow(/must match/);
  });
});
