import { describe, expect, it } from 'vitest';
import { materialized, type GpuBufferRef } from '../src/graph/value.ts';
import { add } from '../src/graph/ops.ts';
import { toArray, type Executor, type Readback } from '../src/graph/evalCore.ts';
import { fakeGpuBuffer } from './helpers.ts';

describe('toArray auto-eval', () => {
  it('evaluates a pending value then reads its buffer back', async () => {
    const a = materialized({ elems: 2, dtype: 'f16' }, fakeGpuBuffer({ id: 'a' }));
    const b = materialized({ elems: 2, dtype: 'f16' }, fakeGpuBuffer({ id: 'b' }));
    const c = add(a, b);
    const readBuffers: GpuBufferRef[] = [];
    const ex: Executor & Readback = {
      acquireOutput: (shape) => fakeGpuBuffer({ ...shape }),
      releaseOutput: () => {},
      dispatch: () => {},
      submit: () => {},
      readback: (buf, shape) => {
        readBuffers.push(buf);
        const floats = shape.dtype === 'f32' ? shape.elems : shape.elems * 4;
        return Promise.resolve(new Float32Array(floats).fill(7));
      },
    };
    const out = await toArray(c, ex);
    expect(c.state).toBe('materialized');
    expect(readBuffers).toEqual([c.buffer]);
    expect(Array.from(out)).toEqual(new Array(8).fill(7)); // vec4f elems(2)*4
  });
});
