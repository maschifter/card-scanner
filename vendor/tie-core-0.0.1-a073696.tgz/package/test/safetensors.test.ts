import { describe, expect, it } from 'vitest';
import {
  bufferSource,
  chunkedSource,
  httpRangeSource,
  parseSafetensorsHeader,
  derivedTensor,
  eagerTensor,
  fromSafetensors,
  type RangeSource,
} from '../src/weights/safetensors.ts';
import { f16ToF32 } from '../src/weights/convert.ts';
import { encodeSafetensors, f32Data, f16Data } from './safetensorsHelpers.ts';

describe('parseSafetensorsHeader', () => {
  it('parses names, dtypes, shapes, absolute offsets, and metadata', async () => {
    const file = encodeSafetensors(
      {
        'a.weight': { dtype: 'F32', shape: [2, 3], data: f32Data([1, 2, 3, 4, 5, 6]) },
        'a.bias': { dtype: 'F32', shape: [2], data: f32Data([7, 8]) },
      },
      { format: 'tie' },
    );
    const idx = await parseSafetensorsHeader(bufferSource(file));
    expect(idx.metadata).toEqual({ format: 'tie' });
    expect([...idx.tensors.keys()]).toEqual(['a.weight', 'a.bias']);
    const w = idx.tensors.get('a.weight')!;
    expect(w.dtype).toBe('F32');
    expect(w.shape).toEqual([2, 3]);
    expect(w.end - w.begin).toBe(24);
    // absolute offsets: payload starts right after the 8-byte length + JSON
    const raw = await bufferSource(file).read(w.begin, w.end);
    expect(Array.from(new Float32Array(raw.buffer, 0, 6))).toEqual([1, 2, 3, 4, 5, 6]);
  });

  it('rejects a header that is not valid JSON', async () => {
    const file = encodeSafetensors({ x: { dtype: 'F32', shape: [1], data: f32Data([1]) } });
    file[9] = 0; // corrupt the JSON
    await expect(parseSafetensorsHeader(bufferSource(file))).rejects.toThrow(/safetensors/);
  });

  it('rejects an unreasonable header length (truncated/corrupt file)', async () => {
    const file = new Uint8Array(8);
    new DataView(file.buffer).setBigUint64(0, 2n ** 40n, true);
    await expect(parseSafetensorsHeader(bufferSource(file))).rejects.toThrow(/header/);
  });

  it('reports a missing file when the payload is HTML text, not binary', async () => {
    const file = new TextEncoder().encode('<!doctype html><html><body>404</body></html>');
    await expect(parseSafetensorsHeader(bufferSource(file))).rejects.toThrow(
      /not a safetensors payload.*HTML fallback/s,
    );
  });
});

describe('bufferSource', () => {
  it('returns standalone copies (byteOffset 0) so typed-array views align', async () => {
    const buf = new Uint8Array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    const chunk = await bufferSource(buf).read(3, 7);
    expect(chunk.byteOffset).toBe(0);
    expect(Array.from(chunk)).toEqual([3, 4, 5, 6]);
  });
});

function fakeFetch(handler: (url: string, range: string | null) => Response | Promise<Response>) {
  const calls: Array<string | null> = [];
  const fn = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const range = new Headers(init?.headers).get('Range');
    calls.push(range);
    return handler(String(input), range);
  }) as typeof fetch;
  return { fn, calls };
}

describe('httpRangeSource', () => {
  const FILE = new Uint8Array(Array.from({ length: 64 }, (_, i) => i));

  it('serves ranges via 206 partial responses', async () => {
    const { fn, calls } = fakeFetch((_url, range) => {
      const [, b, e] = /bytes=(\d+)-(\d+)/.exec(range!)!;
      const body = FILE.slice(Number(b), Number(e) + 1);
      return new Response(body, { status: 206 });
    });
    const src = httpRangeSource('http://x/model.safetensors', { fetchFn: fn });
    expect(Array.from(await src.read(4, 8))).toEqual([4, 5, 6, 7]);
    expect(calls).toEqual(['bytes=4-7']);
  });

  it('falls back to one full download when the server ignores Range (200)', async () => {
    let fullFetches = 0;
    const { fn } = fakeFetch(() => {
      fullFetches++;
      return new Response(FILE.slice(0), { status: 200 });
    });
    const src = httpRangeSource('http://x/model.safetensors', { fetchFn: fn });
    expect(Array.from(await src.read(0, 2))).toEqual([0, 1]);
    expect(Array.from(await src.read(60, 64))).toEqual([60, 61, 62, 63]);
    expect(fullFetches).toBe(1); // memoized, not re-downloaded
  });

  it('retries on failure and on short bodies, then succeeds', async () => {
    let attempt = 0;
    const { fn } = fakeFetch((_url, range) => {
      attempt++;
      if (attempt === 1) throw new Error('network');
      if (attempt === 2) return new Response(FILE.slice(0, 1), { status: 206 }); // short body
      const [, b, e] = /bytes=(\d+)-(\d+)/.exec(range!)!;
      return new Response(FILE.slice(Number(b), Number(e) + 1), { status: 206 });
    });
    const src = httpRangeSource('http://x/f', { fetchFn: fn });
    expect(Array.from(await src.read(0, 4))).toEqual([0, 1, 2, 3]);
    expect(attempt).toBe(3);
  });

  it('throws after 3 failed attempts', async () => {
    const { fn, calls } = fakeFetch(() => new Response(null, { status: 500 }));
    const src = httpRangeSource('http://x/f', { fetchFn: fn });
    await expect(src.read(0, 4)).rejects.toThrow(/after retries/);
    expect(calls.length).toBe(3);
  });

  it('gates racing reads so a Range-ignoring server is downloaded once', async () => {
    let fullFetches = 0;
    const { fn } = fakeFetch(async () => {
      fullFetches++;
      await new Promise((r) => setTimeout(r, 10)); // both reads issued before any response
      return new Response(FILE.slice(0), { status: 200 });
    });
    const src = httpRangeSource('http://x/f', { fetchFn: fn });
    const [a, b] = await Promise.all([src.read(0, 2), src.read(60, 64)]);
    expect(Array.from(a)).toEqual([0, 1]);
    expect(Array.from(b)).toEqual([60, 61, 62, 63]);
    expect(fullFetches).toBe(1); // without the first-read gate this would be 2
  });

  it('reports received bytes via onBytes', async () => {
    const { fn } = fakeFetch((_url, range) => {
      const [, b, e] = /bytes=(\d+)-(\d+)/.exec(range!)!;
      return new Response(FILE.slice(Number(b), Number(e) + 1), { status: 206 });
    });
    let seen = 0;
    const src = httpRangeSource('http://x/f', { fetchFn: fn, onBytes: (n) => (seen += n) });
    await src.read(0, 10);
    expect(seen).toBe(10);
  });
});

/** bufferSource that records every inner read and can stall responses. */
function countingSource(bytes: Uint8Array) {
  const reads: Array<[number, number]> = [];
  const inner = bufferSource(bytes);
  const src: RangeSource = {
    read: (begin, end) => {
      reads.push([begin, end]);
      return inner.read(begin, end);
    },
  };
  return { src, reads };
}

describe('chunkedSource', () => {
  const FILE = new Uint8Array(Array.from({ length: 100 }, (_, i) => i));

  it('serves many small reads from one chunk fetch', async () => {
    const { src, reads } = countingSource(FILE);
    const chunked = chunkedSource(src, FILE.length, 32);
    expect(Array.from(await chunked.read(0, 4))).toEqual([0, 1, 2, 3]);
    expect(Array.from(await chunked.read(4, 8))).toEqual([4, 5, 6, 7]);
    expect(Array.from(await chunked.read(30, 32))).toEqual([30, 31]);
    expect(reads).toEqual([[0, 32]]); // one chunk fetch, three reads
  });

  it('stitches a read spanning a chunk boundary', async () => {
    const { src, reads } = countingSource(FILE);
    const chunked = chunkedSource(src, FILE.length, 32);
    expect(Array.from(await chunked.read(28, 36))).toEqual([28, 29, 30, 31, 32, 33, 34, 35]);
    expect(reads).toEqual([
      [0, 32],
      [32, 64],
    ]);
  });

  it('clamps the last chunk to totalBytes and rejects past-end reads', async () => {
    const { src, reads } = countingSource(FILE);
    const chunked = chunkedSource(src, FILE.length, 32);
    expect(Array.from(await chunked.read(96, 100))).toEqual([96, 97, 98, 99]);
    expect(reads).toEqual([[96, 100]]); // not [96, 128)
    await expect(chunked.read(96, 101)).rejects.toThrow(/past end/);
  });

  it('concurrent readers of one chunk share a single fetch', async () => {
    let fetches = 0;
    let release!: () => void;
    const stall = new Promise<void>((r) => (release = r));
    const src: RangeSource = {
      read: async (begin, end) => {
        fetches++;
        await stall;
        return FILE.slice(begin, end);
      },
    };
    const chunked = chunkedSource(src, FILE.length, 32);
    const both = Promise.all([chunked.read(0, 4), chunked.read(8, 12)]);
    release();
    const [a, b] = await both;
    expect(Array.from(a)).toEqual([0, 1, 2, 3]);
    expect(Array.from(b)).toEqual([8, 9, 10, 11]);
    expect(fetches).toBe(1);
  });

  it('evicts old chunks but re-fetches them correctly', async () => {
    const { src, reads } = countingSource(FILE);
    const chunked = chunkedSource(src, FILE.length, 16);
    await chunked.read(0, 4); // chunk 0
    await chunked.read(16, 20); // chunk 1
    await chunked.read(32, 36); // chunk 2 -> evicts chunk 0
    expect(Array.from(await chunked.read(4, 8))).toEqual([4, 5, 6, 7]); // chunk 0 again
    expect(reads).toEqual([
      [0, 16],
      [16, 32],
      [32, 48],
      [0, 16],
    ]);
  });

  it('does not memoize a failed chunk fetch', async () => {
    let calls = 0;
    const src: RangeSource = {
      read: (begin, end) => {
        calls++;
        return calls === 1
          ? Promise.reject(new Error('network'))
          : Promise.resolve(FILE.slice(begin, end));
      },
    };
    const chunked = chunkedSource(src, FILE.length, 32);
    await expect(chunked.read(0, 4)).rejects.toThrow('network');
    expect(Array.from(await chunked.read(0, 4))).toEqual([0, 1, 2, 3]);
  });
});

describe('fromSafetensors / LazyTensor', () => {
  const file = encodeSafetensors({
    w16: { dtype: 'F16', shape: [1, 3], data: f16Data([1.5, -2, 0.25]) },
    b32: { dtype: 'F32', shape: [2], data: f32Data([7, 8]) },
  });

  it('exposes lazy tensors with shapes and byte lengths, fetches on demand', async () => {
    const sd = await fromSafetensors(bufferSource(file));
    expect([...sd.tensors.keys()]).toEqual(['w16', 'b32']);
    expect(sd.totalBytes()).toBe(3 * 2 + 2 * 4);
    expect(Array.from(await sd.tensors.get('b32')!.f32())).toEqual([7, 8]);
  });

  it('decodes F16 to f32 and to padded packed halfWords', async () => {
    const sd = await fromSafetensors(bufferSource(file));
    const w = sd.tensors.get('w16')!;
    expect(Array.from(await w.f32())).toEqual([1.5, -2, 0.25]);
    const words = await w.halfWords();
    expect(words.length).toBe(2); // 3 halfs -> 2 words, high half of word 1 zero
    const halfs = new Uint16Array(words.buffer);
    expect(Array.from(f16ToF32(halfs.slice(0, 3)))).toEqual([1.5, -2, 0.25]);
    expect(halfs[3]).toBe(0);
  });

  it('halfWords() throws for non-F16 tensors', async () => {
    const sd = await fromSafetensors(bufferSource(file));
    await expect(sd.tensors.get('b32')!.halfWords()).rejects.toThrow(/F16/);
  });

  it('coalesces per-tensor reads into chunk fetches', async () => {
    const { src, reads } = countingSource(file);
    const sd = await fromSafetensors(src);
    const headerReads = reads.length; // 8-byte length + JSON header, unchunked
    await sd.tensors.get('w16')!.f32();
    await sd.tensors.get('b32')!.f32();
    expect(reads.length).toBe(headerReads + 1); // both tensors from one chunk fetch
    expect(reads[headerReads]![1]).toBe(file.length); // clamped to payload end
  });

  it('chunkBytes: 0 opts out of chunking', async () => {
    const { src, reads } = countingSource(file);
    const sd = await fromSafetensors(src, { chunkBytes: 0 });
    const headerReads = reads.length;
    await sd.tensors.get('w16')!.f32();
    await sd.tensors.get('b32')!.f32();
    expect(reads.length).toBe(headerReads + 2); // one read per tensor
  });

  it('eagerTensor wraps data; derivedTensor memoizes compute', async () => {
    const e = eagerTensor(new Float32Array([1, 2]), [2]);
    expect(Array.from(await e.f32())).toEqual([1, 2]);
    let runs = 0;
    const d = derivedTensor([2], async () => {
      runs++;
      return new Float32Array([3, 4]);
    });
    expect(Array.from(await d.f32())).toEqual([3, 4]);
    expect(Array.from(await d.f32())).toEqual([3, 4]);
    expect(runs).toBe(1);
  });

  it('derivedTensor returning packed words serves halfWords()', async () => {
    const d = derivedTensor([2], async () => new Uint32Array([0x40003c00])); // [1.0, 2.0] as f16 pair
    const halfs = new Uint16Array((await d.halfWords()).buffer);
    expect(Array.from(f16ToF32(halfs))).toEqual([1, 2]);
    await expect(d.f32()).rejects.toThrow();
  });
});

describe('U32 tensors and raw reads', () => {
  const u32Data = (values: number[]): Uint8Array =>
    new Uint8Array(new Uint32Array(values).buffer.slice(0));

  it('decodes a U32 tensor via words()', async () => {
    const file = encodeSafetensors({
      packed: { dtype: 'U32', shape: [4], data: u32Data([1, 2, 0xdeadbeef, 4]) },
    });
    const sd = await fromSafetensors(bufferSource(file));
    const words = await sd.tensors.get('packed')!.words();
    expect([...words]).toEqual([1, 2, 0xdeadbeef, 4]);
  });

  it('words() rejects non-U32 file tensors; f32() rejects U32', async () => {
    const file = encodeSafetensors({
      a: { dtype: 'F32', shape: [2], data: f32Data([1, 2]) },
      b: { dtype: 'U32', shape: [1], data: u32Data([7]) },
    });
    const sd = await fromSafetensors(bufferSource(file));
    await expect(sd.tensors.get('a')!.words()).rejects.toThrow(/U32/);
    await expect(sd.tensors.get('b')!.f32()).rejects.toThrow(/decode/);
  });

  it('u16() returns raw BF16 bits without conversion', async () => {
    const bits = new Uint16Array([0x3f80, 0xbf00]); // bf16 1.0, -0.5
    const file = encodeSafetensors({
      emb: { dtype: 'BF16', shape: [2], data: new Uint8Array(bits.buffer.slice(0)) },
    });
    const sd = await fromSafetensors(bufferSource(file));
    expect([...(await sd.tensors.get('emb')!.u16())]).toEqual([0x3f80, 0xbf00]);
  });

  it('derivedTensor holding Uint32Array serves words(); u16() throws on derived', async () => {
    const t = derivedTensor([2], () => Promise.resolve(new Uint32Array([5, 6])));
    expect([...(await t.words())]).toEqual([5, 6]);
    await expect(t.u16()).rejects.toThrow(/derived/);
  });
});
