import { describe, expect, it } from 'vitest';
import {
  bf16ToF32,
  f16ToF32,
  f32ToF16Bits,
  permuteConvTransposeF16,
  transposeF32,
} from '../src/weights/convert.ts';

// bf16 bit pattern = top 16 bits of f32.
const bf16 = (x: number) => {
  const buf = new DataView(new ArrayBuffer(4));
  buf.setFloat32(0, x, true);
  return buf.getUint16(2, true);
};

describe('bf16ToF32', () => {
  it('roundtrips exact bf16 values', () => {
    const src = new Uint16Array([bf16(1.0), bf16(-2.5), bf16(0.0), bf16(3.140625)]);
    expect([...bf16ToF32(src)]).toEqual([1.0, -2.5, 0.0, 3.140625]);
  });
});

describe('f32ToF16Bits', () => {
  it('converts exact halves', () => {
    expect(f32ToF16Bits(1.0)).toBe(0x3c00);
    expect(f32ToF16Bits(-2.0)).toBe(0xc000);
    expect(f32ToF16Bits(0.0)).toBe(0x0000);
  });
  it('clamps overflow to f16 max', () => {
    expect(f32ToF16Bits(1e6)).toBe(0x7bff); // 65504
    expect(f32ToF16Bits(-1e6)).toBe(0xfbff);
  });
  it('rounds to nearest even', () => {
    expect(f32ToF16Bits(1 + 2 ** -11)).toBe(0x3c00);
    expect(f32ToF16Bits(1 + 3 * 2 ** -11)).toBe(0x3c02);
  });
});

describe('f16ToF32', () => {
  it('expands exact f16 bit patterns, including subnormals and specials', () => {
    const src = new Uint16Array([0x3c00, 0xc000, 0x0000, 0x0001, 0x7bff]);
    const out = f16ToF32(src);
    expect(out[0]).toBe(1.0);
    expect(out[1]).toBe(-2.0);
    expect(out[2]).toBe(0.0);
    expect(out[3]).toBe(2 ** -24); // smallest subnormal
    expect(out[4]).toBe(65504); // f16 max
  });

  it('decodes normals, subnormals, zeros, infinities', () => {
    // 0x3c00=1.0, 0x4248=3.140625, 0xc000=-2.0, 0x0001=smallest subnormal,
    // 0x8000=-0, 0x7c00=+Inf, 0xfc00=-Inf, 0x7bff=65504 (f16 max)
    const out = f16ToF32(
      new Uint16Array([0x3c00, 0x4248, 0xc000, 0x0001, 0x8000, 0x7c00, 0xfc00, 0x7bff]),
    );
    expect(out[0]).toBe(1.0);
    expect(out[1]).toBeCloseTo(3.140625, 6);
    expect(out[2]).toBe(-2.0);
    expect(out[3]).toBe(2 ** -24);
    expect(Object.is(out[4], -0)).toBe(true);
    expect(out[5]).toBe(Infinity);
    expect(out[6]).toBe(-Infinity);
    expect(out[7]).toBe(65504);
  });

  it('round-trips through f32ToF16Bits for exactly-representable values', () => {
    const values = new Float32Array([0, 1, -1, 0.5, 1.5, 100, -0.25, 65504, 2 ** -14]);
    const bits = new Uint16Array(values.length);
    for (let i = 0; i < values.length; i++) bits[i] = f32ToF16Bits(values[i]!);
    expect(Array.from(f16ToF32(bits))).toEqual(Array.from(values));
  });
});

describe('transposeF32', () => {
  it('flips [out,in] to [in,out]', () => {
    const src = new Float32Array([1, 2, 3, 4, 5, 6]); // [2,3]
    expect([...transposeF32(src, 2, 3)]).toEqual([1, 4, 2, 5, 3, 6]);
    expect(() => transposeF32(src, 3, 3)).toThrow(/length/);
  });
});

describe('permuteConvTransposeF16', () => {
  it('moves torch [cIn,cOut,k,k] halfs to [cOut·k·k, cIn] rows', () => {
    const cIn = 3,
      cOut = 2,
      k = 2;
    // encode value = ci*100 + co*10 + tap so every position is identifiable
    const halfs = new Uint16Array(cIn * cOut * k * k);
    for (let ci = 0; ci < cIn; ci++)
      for (let co = 0; co < cOut; co++)
        for (let t = 0; t < k * k; t++)
          halfs[ci * cOut * k * k + co * k * k + t] = f32ToF16Bits(ci * 100 + co * 10 + t);
    const out = permuteConvTransposeF16(halfs, cIn, cOut, k);
    const decoded = f16ToF32(out);
    // row co*k*k + t, column ci
    for (let co = 0; co < cOut; co++)
      for (let t = 0; t < k * k; t++)
        for (let ci = 0; ci < cIn; ci++)
          expect(decoded[(co * k * k + t) * cIn + ci]).toBe(ci * 100 + co * 10 + t);
  });
});
