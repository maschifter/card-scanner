# tgpu-nn Architecture

**The goal: MLX for the web.** You define a model in plain TypeScript — classes, ops,
normal `if`s and loops — load weights into it, call `forward`, and read the result.
No export step, no compile step, no graph format. The runtime does whatever is needed
(buffer allocation, kernel selection, batching) behind the scenes, the way PyTorch and
MLX do. Higher-level model code (a "transformers.js"-style zoo) composes on top of
the primitives defined here.

This document is the source of truth for how that works.

---

## 1. The two stacks

The package currently contains **two execution stacks**:

|                   | Eager runtime (`src/`)                                    | Legacy trace stack (`src/graph/`, `src/nn/`, `src/kernels/`)                        |
| ----------------- | --------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| Status            | **The foundation. Everything new goes here.**             | Death row. Kept alive only as the parity oracle until the privacy filter is ported. |
| Programming model | Define-by-run: ops build a lazy DAG as your code executes | Trace once into a static graph IR, compile, then run the artifact                   |
| Kernels           | Small, shape-generic primitives (dims in uniforms)        | Fused, model-specific kernels with baked-in geometry                                |
| Covered by        | Sections 2–8                                              | Section 9 (summary only)                                                            |

Everything below describes the eager runtime unless explicitly marked legacy.

---

## 2. The big picture

The eager runtime is **eager on the surface, lazy underneath** (exactly like MLX):
calling an op returns instantly without touching the GPU; work happens in one batch
the moment you read a result.

Life of a forward pass:

```
you write                      what actually happens
─────────────────────────────  ──────────────────────────────────────────────
initTie(root)                  the default device — executor, pool, caches
const model = new Block()      tree of empty Parameter slots (no data, no GPU)
await model.loadStateDict(sd)  each slot matched by dotted name, uploaded to GPU
const y = model.forward(x)     CPU-only: a DAG of pending Values is linked up
await toArray(y)               DAG walked, kernels queued, ONE submit, readback
```

Layer stack, top to bottom (each layer only knows the one below it):

```
┌────────────────────────────────────────────────────────────┐
│  your model      class Block extends Module { forward() }  │
├────────────────────────────────────────────────────────────┤
│  nn/             Module, Parameter, Buffer, loadStateDict  │   = torch.nn
│  layers.ts       Linear, RMSNorm, ...                      │
├────────────────────────────────────────────────────────────┤
│  compose.ts      linear(), rmsNorm() — functions built     │   = torch.nn.functional
│                  purely from primitives                    │
├────────────────────────────────────────────────────────────┤
│  ops.ts          add, mul, matmul, softmax, mean, rsqrt,   │   = torch.* / mx.core
│                  addScalar — each returns a pending Value  │
├────────────────────────────────────────────────────────────┤
│  value.ts        Value (the lazy tensor), ValueMeta        │   = torch.Tensor / mx.array
├────────────────────────────────────────────────────────────┤
│  evalCore.ts     the eval driver: DFS order, liveness,     │   device-agnostic,
│                  acquire/dispatch/release loop             │   node-testable
├────────────────────────────────────────────────────────────┤
│  eval.ts         gpuExecutor: the WebGPU implementation    │   the ONLY file that
│  bufferPool.ts   of the Executor interface                 │   knows WebGPU exists
│  pipelineCache.ts                                          │
├────────────────────────────────────────────────────────────┤
│  kernels/        one WGSL compute shader per primitive op  │
└────────────────────────────────────────────────────────────┘
```

---

## 3. Value: the lazy tensor (`value.ts`)

A `Value` is what every op takes and returns — the analogue of a `torch.Tensor`.
Internally it is **one node of a computation DAG**, in one of two states:

- **materialized** — `_buffer` holds real GPU data (an uploaded weight/input, or an
  op result after evaluation).
- **pending** — no data yet; `pending: {op, inputs, scalar?}` records the _recipe_:
  which op produces it, from which input Values.

`inputs` are plain JavaScript references to other `Value` objects. There is **no
central graph object** — the graph is literally objects pointing at objects. Holding
the output Value transitively holds the whole computation; drop the reference and the
GC reclaims the nodes.

Example — `const y = add(matmul(x, W), b)` creates this in memory:

```
x  [2,4] f32   buffer: ✓ (uploaded input)     pending: —
W  [4,4] f32   buffer: ✓ (loaded weight)      pending: —
b  [4]   f32   buffer: ✓ (loaded weight)      pending: —

m  [2,4] f32   buffer: undefined              pending: {op:'matmul', inputs:[x, W]}
y  [2,4] f32   buffer: undefined              pending: {op:'add',    inputs:[m, b]}

                        y
                       ╱ ╲
                      m   b          ← the "graph": just references
                     ╱ ╲
                    x   W
```

At this point the GPU has done **nothing**. Total cost so far: two small JS objects
and some shape checks.

**`ValueMeta`** is everything known about a Value _without computing it_:

- `elems` — element count in units of `dtype`
- `dtype` — `'f32' | 'f16' | 'quantW'`
- `dims?` — logical 2D shape (`[rows, cols]`) for ops that need it (matmul, softmax)

`f32` and `f16` are the activation dtypes: a model runs entirely in one of them, and
`nn.Module.half()` flips every parameter and intermediate together (a kernel binds one
element type per buffer, so the two never mix in a single dispatch). Half precision
needs the `shader-f16` device feature; `half()` throws without it.

The third dtype, **`quantW`**, is weight-only: int8/int4 values packed per u32 word
alongside f32 scale tensors. Logical dimensions stay `[rows, cols]` while `elems`
counts u32 _words_. It is **upload-only** — no op produces a quantW Value and the
buffer pool throws if asked to acquire one — and only `matmulQuantW` /
`matmulGatherQuantW` consume it. A `baseRow` view reads rows
`[baseRow, baseRow+K)` of a fused multi-expert tensor without copying; the plain
matmul takes the same option for float weights.

A fourth dtype, **`quantW`**, is the int8/int4 analogue: signed ints packed into u32
words along the column axis (int8 = 4/word, int4 = 8/word, low col in low bits),
`elems` = the word count. Also upload-only (pool throws), consumed solely by
`matmulQuantW`, which dequantizes each int × its per-`(expert, K-group, col)` f32
scale (a separate Value) during the matmul. `bits` and `groupSize` ride in the op's
uniform, so one dtype and one pipeline serve int8, int4, and every group size. The
eager loader packs the checkpoint's quantized experts into this layout via
`packQuantColSlice` (its own flat packing, distinct from the legacy blocked one).

Ops use it to validate and derive output shapes; the executor uses it to size and
pool buffers. Because all of this is known up front, evaluation never has to ask the
GPU anything mid-graph (see §7).

**`GpuBufferRef`** is strictly a TypeGPU storage buffer (`F32Buffer | V4Buffer`),
imported type-only so the core still loads in node tests (tests stub buffers via
`test/helpers.ts`). Only the executor interprets buffers; everything else ferries
them around opaquely.

---

## 4. Ops and composition (`ops.ts`, `compose.ts`)

Every function in `ops.ts` does exactly three cheap CPU things:

1. **Validate** the inputs' ValueMeta — bad shapes throw _at the offending line_,
   synchronously, with a readable message (`matmul: inner dims disagree — a=[2,3] b=[5,4]`).
2. **Derive** the output's ValueMeta (pure shape arithmetic).
3. **Return a pending Value** wired to its inputs. The op name string
   (`'matmul'`) is the routing key the executor later matches on.

`add`/`mul` share a broadcasting helper: `[M,N] ⊕ [N]` (row broadcast, e.g. bias) and
`[M,N] ⊕ [M,1]` (column broadcast, e.g. per-row scale) are supported; the full-size
operand is always reordered to `inputs[0]` — a contract the kernel relies on.

**The primitives-only rule.** `ops.ts` contains only operations that exist in
PyTorch/MLX's core vocabulary. Anything higher-level is _composed_ in `compose.ts`:

```ts
rmsNorm(x, w, eps) = mul(mul(x, rsqrt(addScalar(mean(mul(x, x)), eps))), w);
linear(x, W, b) = add(matmul(x, W), b);
```

Same reason PyTorch doesn't define RoPE: it gives you the tools to write it.
Model-specific constructs (rope, banded attention) are built in model code / the
zoo from these primitives, not added as fused kernels here. `topk` is the one
router-shaped resident: torch defines `topk`, so it's a legitimate core primitive —
ours additionally folds the softmax-over-selected into the same kernel (a pragmatic
extension, k=4 only). The rest of MoE routing (parsing the packed output, grouping
tokens by expert) stays CPU-side in the zoo.

The accepted trade-off: composed rmsNorm is ~5 dispatches where a fused kernel is 1.
We buy a small closed kernel set and full composability; fusing hot patterns back is
a later optimization behind the same interface, not a reason to grow the vocabulary.

---

## 5. The nn layer (`nn/module.ts`, `nn/layers.ts`)

The bridge from "a bag of ops" to "a model with named weights you can load a
checkpoint into". Mirrors torch exactly:

- **`Parameter(shape)`** — a _declared slot_ for a learned weight. Not a Value:
  at construction time the data doesn't exist yet — only the expected shape. The
  checkpoint fills it later. `.value` returns the bound Value (throws if unloaded).
- **`Buffer(data, shape)`** — a model-_computed_ constant (rope cos/sin tables,
  attention masks). Ships with the code, never read from the checkpoint.
- **`Module`** — the base class. Its constructor returns a `Proxy` so plain field
  assignment (`this.proj = new Linear(4,4)`) auto-registers Parameters/Buffers/child
  Modules (what `nn.Module.__setattr__` does in Python). Two traps are required:
  `set` for runtime assignment and `defineProperty` for class-field initializers
  (ES2022 `useDefineForClassFields` uses `[[Define]]`, which bypasses `set`).
  The registry itself is stored under a **symbol key** so the traps skip it and no
  user field name can ever collide with it.
- **`namedParameters()` / `namedBuffers()`** — depth-first walk producing dotted
  paths derived from field names: `norm.scale`, `proj.weight`. Those strings ARE the
  state-dict keys (PyTorch convention). No manual bookkeeping anywhere.
- **`model.loadStateDict(sd)`** — `load_state_dict`: match every Parameter by
  dotted name (strict: missing AND unexpected keys throw), run transformStateDict
  hooks, size-check, upload onto the initTie() device (or an injected `upload`
  sink — tests, CPU-resident params), then upload all Buffers from their inline
  data. `sd` is a safetensors URL or a lazy dict.
- **`run(model, executor, x)`** — `forward()` builds the DAG, `toArray` forces it.

`layers.ts` holds the stock layers (`Linear`, `RMSNorm`); each is a thin class that
owns Parameters and calls its `compose.ts` functional form — exactly like
`torch.nn.Linear.forward` → `F.linear`. Architecture hyperparameters (feature counts,
head counts) are **required constructor args, never defaulted**; only tuning knobs
with a conventional value (`eps = 1e-6`) get defaults.

---

## 6. Evaluation (`evalCore.ts` — device-agnostic)

Nothing runs until someone reads a result. `toArray(value, ex)` (or `run`) triggers:

**Step 1 — `collectPending(targets)`.** Post-order DFS starting **from the requested
output**, walking backward along `inputs` references. Recursion stops at materialized
nodes — they're data, not work (this is also what makes evals incremental: a value
evaluated earlier is a leaf next time, never recomputed). Post-order (push a node
_after_ its inputs) means the returned list has inputs before consumers — a valid
execution order. Demand-driven for free: ops nothing depends on are never visited.

**Step 2 — liveness.** For every intermediate produced in this eval, compute
`lastUse[v]` = index of the last op that reads it.

**Step 3 — the loop.** For each node, in order:

```
out ← ex.acquireOutput(node.shape)          // buffer from the pool
ex.dispatch(node, inputBuffers, out)        // QUEUE the kernel (runs nothing)
node.setMaterialized(out)
for each input whose lastUse is now past:
    ex.releaseOutput(input.buffer)          // recycle it — unless it's a target
                                            // or a pre-existing buffer (weights)
ex.submit()                                 // once, at the end
```

The recycling is why a long chain uses ~2 intermediate buffers instead of N:

```
op0 → B1        op1 → B2        op2 → B1        op3 → B2   ...
        └─ B1 freed after op1 ──┘       └─ B2 freed after op2 ─┘
```

Never recycled: (1) the targets you asked for, (2) weights/uploaded inputs (not
produced by this eval — not ours to free), (3) anything with a consumer still ahead.

**The cross-eval buffer contract.** Because evalValues recycles each intermediate's
buffer after its last _in-batch_ consumer, a Value's buffer is only valid across an
eval boundary if it was a **target** of the eval that materialized it, or a direct
upload. Orchestrations that read back mid-model and keep building (runModel's MoE
phase A/B) must pin every Value they hold across the boundary as a co-target —
`runModel` pins each block's attention output (`evalValues([selVal, x], ex)`).
Violations fail loudly: a recycled Value's state flips to `'released'`, its `.buffer`
throws, and an eval whose DAG reaches one throws in `collectPending` — never a silent
read of recycled memory. Refcounted buffer lifetime is the eventual durable design;
the released-state guard is the contract's enforcement until then.

**Why releasing before `submit()` isn't a race:** "release" is CPU bookkeeping about
_encode order_, not GPU state. If op 2 is assigned a buffer op 1 reads, the command
list already has op 1 encoded first — and WebGPU guarantees dispatches within one
compute pass execute in encode order with writes visible to the next dispatch. The
aliasing is safe by construction; the GPU never sees an unordered plan.

`evalCore` talks to the world only through two small interfaces —

```ts
interface Executor {
  acquireOutput(shape): GpuBufferRef;
  releaseOutput(buffer, shape): void;
  dispatch(node, inputs, out): void;
  submit(): void;
}
interface Readback {
  readback(buffer, shape): Promise<Float32Array>;
}
```

— and never imports WebGPU. All of the above is unit-tested in node with stub
executors.

---

## 7. The GPU backend (`eval.ts`, `bufferPool.ts`, `pipelineCache.ts`, `kernels/`)

`gpuExecutor(root)` is the real `Executor & Readback` — **the only file in the eager
runtime that knows WebGPU exists**. Create it once and reuse it; its two caches only
pay off across calls.

- **`BufferPool`** — free-lists of storage buffers keyed `${dtype}:${elems}`
  (an f32[64] can't stand in for a vec4f[64]). Fresh allocation only on a pool miss;
  steady state is zero allocations per forward pass. Allocation is injected so the
  pool class itself stays WebGPU-free.

- **`PipelineCache`** — compiled pipelines keyed **`(op, dtype)` — shapes are
  deliberately not in the key.** This works because every kernel takes its dimensions
  as a _uniform_ (e.g. matmul's `Dims {m, k, n}` struct) instead of baking them into
  shader source. One matmul pipeline serves all shapes forever; a new sequence length
  costs a 12-byte uniform write, not a shader compile. (If shapes were baked in,
  autoregressive decode — where the attention span grows every token — would compile
  a new pipeline per token.) Each pipeline is built on the first-ever use of its op:
  this is the "on-demand compilation" half of the design.

- **`dispatch(node, inputs, out)`** — routes on `node.pending.op`, digs the
  op-specific numbers out of ValueMeta (m/k/n for matmul; rows/cols for mean/softmax)
  and attrs (elementwise broadcast mode, decided once in ops.ts), and calls the kernel's
  `*Handle()` to build a `KernelHandle` — `{pipeline, bindGroup, workgroups}`, a
  ready-to-encode dispatch. Pushed onto an internal list. **Still nothing has run.**
  This is also the one place `GpuBufferRef` is narrowed to a concrete f32/vec4f type.

- **`submit()`** — encodes the whole handle list into ONE compute pass and calls
  `queue.submit()` once. This is the moment the GPU starts computing.

- **`readback(buffer, shape)`** — copy to a mappable staging buffer, await the map,
  return a `Float32Array`. Only `toArray`/`run` call it, at the very end.

`kernels/` holds one small WGSL shader per primitive: `matmul.ts`,
`elementwiseF32.ts` (add/mul with broadcast modes), `reduce.ts` (mean),
`softmax.ts`, `unary.ts` (rsqrt, addScalar, sigmoid, mulScalar, clampScalar),
`transpose.ts`, `columns.ts` (sliceCols, concatCols), `rows.ts` (sliceRows,
concatRows, gatherRows), `topkSelect.ts` (topk + softmax-over-selected), plus
vec4f add/mul variants. All follow
the same template: a bind group layout, a `computeFn` with a bounds check, dims in a
uniform, and a `*Handle()` factory. One convention worth knowing: WGSL-side integer
division is written `d.u32(a / b)` (see `gemm.ts` and `matmul.ts`) — a bare `/` on
u32-derived values does not truncate the way you'd expect.

---

## 8. The performance model

**Why lazy-batched beats true op-by-op eager.** A `queue.submit()` has a fixed CPU
cost (command buffer creation, validation, driver handoff) of roughly hundreds of
microseconds in browsers, regardless of kernel size. A ~24-block transformer is
~240 ops per token: op-by-op that's tens of milliseconds of pure overhead per token,
more than the actual GPU math. Batched, it's one submit. Laziness is simply the
mechanism that lets us batch while the user writes sequential-looking code.

**Sync points.** A full `run()` waits on the GPU **exactly once**: the readback at
the end. Everything else — DAG walk, buffer planning, encoding, `submit()` itself —
is fire-and-forget from the CPU. Two things would add sync points, and it's important
to know which is which:

- _Reading an intermediate between evals_ (debugging) — a deliberate, local sync.
  You pay one round trip where you asked for it. This is a feature.
- _An op whose output **shape** depends on data_ (dynamic top-k, `nonzero`) — would
  force a mid-graph readback, because the driver couldn't size downstream buffers
  without asking the GPU. **We don't have such ops, and adding one is an
  architectural decision, not a routine op addition.** Everything in the target
  models is static-shaped.

**Why dynamic shapes and control flow just work.** A compiler (torch.compile, XLA)
captures the program once and serves all inputs from the frozen artifact — so
data-dependent branches cause graph breaks and new shapes cause recompiles. Here
there is no "once": **the graph is rebuilt from scratch on every forward pass by
ordinary JavaScript executing.** An `if` on shapes runs on the CPU while the DAG is
being linked; each eval's DAG simply _is_ the branch that was taken. Shapes are data
(uniforms), not program (shader source). This is the same position MLX occupies:
define-by-run feel, lazy underneath, per-call graph, kernels cached by op.

When a control decision needs a _GPU-computed value_ (generate-until-EOS, or branching
on MoE router output), you `await toArray(...)` and branch on the result — one honest
round trip that no framework can avoid (the information is physically on the device).
The difference from compiled stacks is that we degrade gracefully: one readback, then
business as usual, instead of the compiled artifact fragmenting at every such point.

For the MoE case specifically, `EagerMoeMlp` does better than a naive "read all logits"
approach: the `topk` primitive computes expert selection _entirely on the GPU_, and only
the small packed [T, 8] ids+weights tensor is read back to the CPU to shape phase B's
DAG. The sync is still there — the indices are physically on the device and must cross
the bus — but it is indices-only (a few hundred bytes per MoE block), not the full
[T, E] logit matrix.

---

## 9. The legacy trace stack (summary — do not build on this)

The privacy filter still runs on the older trace→compile engine. Its pipeline:
`Module`/`Parameter` (trace-time twins of §5, in `src/nn/`) → `trace()` runs
`forward` once against symbolic `Tensor`s, with an ambient tracer (`context.ts`)
letting ops reach the active `graphBuilder` → a JSON-serializable `Graph` IR
(`src/graph/ir.ts`) → `compileGraph` (`compile.ts`): validation, ahead-of-time
liveness buffer planning (`planBuffers`), weight binding by name → per-token-count
dispatch plans built from fused kernels (`src/kernels/`: gemm, attention, moe, …)
via the op registry (`registry.ts`) → host runs the segments and reads checkpoints
between them. Weight loading is declarative: each Parameter carries a `ParamFormat`
(`format.ts`) that `loader.ts` interprets (bf16→f32, f16-pair packing, expert
slicing, quantized variants).

Fates when the eager port reaches parity:

- **Deleted:** `src/graph/`, `src/nn/` (including `context.ts`, `format.ts`,
  `loader.ts`), the fused kernels and their packing transforms (`expertPack.ts`,
  blocked packing in `weights.ts`).
- **Kept (stack-agnostic):** `safetensors.ts`, `convert.ts` (bf16→f32),
  `buffers.ts` (upload/readback helpers).
- **Reincarnated smaller:** the _idea_ of declarative per-parameter load formats,
  regrown in the eager loader only as far as the port actually demands.

Until then the legacy engine is the **parity oracle**: the port verifies each eager
block against the legacy engine's per-block output. Don't refactor or polish
anything under `src/nn/` or `src/graph/`.

---

## 10. Current state and roadmap

**Implemented (eager):** Value/ValueMeta; add, mul (with row/col broadcast), matmul,
softmax, mean, rsqrt, addScalar, transpose, sliceCols, concatCols, sigmoid, mulScalar,
clampScalar, sliceRows, concatRows, gatherRows, topk; rmsNorm + linear composition;
Module/Parameter/Buffer/loadStateDict/run; ModuleList; Linear (optional bias-less) +
RMSNorm layers; evalCore with liveness
reuse; gpuExecutor with pool + pipeline cache + single-submit; f32, f16 and quantW
dtypes. Covered by node tests (`test/eager*.test.ts`) + GPU parity tests
(`test/gpu/eager*.test.ts`); node suites fully green (fixtures generated via
`tools/export_weights.py` + `tools/dump_fixtures.py`); the real-weights parity test
skips when `fixtures/weights` is absent.

**Done since:** the "one block first" milestone — `EagerAttnBlock`
(`packages/zoo/src/privacy-filter/`): RMSNorm → QKV → RoPE → banded GQA
attention with sinks → out-projection → residual, composed entirely from
primitives (RoPE via a constant pair-rotation matrix: `x⊙cos + (x@P)⊙sin`;
band mask and sink column as Buffers; GQA as a JS head loop). GPU-verified
against a float64 CPU reference with random weights (T=160, maxDiff ≈ 2e-7).

`EagerMoeMlp` (`packages/zoo/src/privacy-filter/moeMlp.ts`) — MoE MLP with
GPU topk routing. Phase A: `topk(gate(norm(x)))` runs on the GPU (torch.topk tie
semantics + softmax over selected); only the small packed [T,8] ids+weights tensor is
read back to shape phase B's DAG. Phase B: per-expert gatherRows → clamped-SwiGLU FFN
(composed from primitives) → pile + slot-gathers → residual. GPU parity vs f64 CPU
reference at small dims (E=8, H=64, T=24; maxDiff ≈ 2e-7). Dimension-parameterized —
real dims (E=128, H=640 → ~420MB f32 expert tensor) wait for the packed-weight loader.

Full-model assembly (`packages/zoo/src/privacy-filter/model.ts`) —
`EagerBlock` (attn + MoE MLP) stacked via `ModuleList` into `EagerModel`
(blocks → final RMSNorm → bias-less unembed), driven by the async two-phase
`runModel` (per block: attention eval + selection readback, then the expert
phase-B DAG). Position-dependent constants (rope cos/sin, band mask, sink
column) are built once and shared across all blocks. Whole-model GPU parity vs
an f64 CPU reference: maxDiff ≈ 2.2e-6 at 2 blocks, real attention dims, E=8,
T=64. Plus the cross-eval released-state guard (§6, invariant 11): stale
cross-eval buffer reads now fail loudly instead of silently reading recycled
memory.

**REAL-WEIGHTS MILESTONE (PR 4):** packedF16 dtype + `matmulPackedW` op (both since
replaced by native f16 — see §3);
real-checkpoint loader (`loader.ts`): bf16→f32 + transpose for dense weights
([out,in]→[in,out] PyTorch convention), direct bf16→f16 packing for expert tensors
(exact — bf16 mantissa ⊂ f16 mantissa), embedding kept raw bf16 CPU-side.
Parity verified against the legacy engine on the real 8-block checkpoint (T=70):

| Per-block residual maxAbsDiff | Block 0: 3.7e-4 → Block 7: 9.8e-3 (~4–14 f32 ULPs at stream magnitude; residual stream grows to absmax ~21k) |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------ |
| Logits maxAbsDiff             | 2.3e-5 (~1.5e-6 relative)                                                                                    |
| Decoded PII spans             | IDENTICAL (6/6 between engines)                                                                              |
| Eager forward                 | bit-deterministic across reruns                                                                              |

The per-block tolerance ladder is deliberately loose (~25–40× measured headroom,
absolute slack grows with stream magnitude); subtle late-block bugs are backstopped
by the tight logits gate (44× headroom) and exact-span assertion, not the ladder.

First honest perf datapoint (T=70 on the real checkpoint): eager forward ~3.1s vs
legacy ~1.6s (~2× slower — far better than the pre-measurement 10–50× estimate);
eager weight load 6.7s vs legacy 10.7s (eager faster due to no int8 quantization).

**DEMO SWAP (PR 5) — shipped.** `?engine=eager` runs the eager runtime end to end
(`createEagerDetector`, `packages/zoo/src/privacy-filter/detector.ts`): the
token-independent weights load once into a canonical model; each detect builds a model
at the _exact_ token count, rebuilding only the small position constants and reusing the
loaded weights (historically via `nn.bindShared`, since folded into the T-independent
EagerModel — rope tables are per-forward inputs). This is **dynamic exact-T, not bucketing** — the
eager runtime keys pipelines by (op, dtype), never by shape (invariant 5), so a new
length costs zero recompiles; only the O(T²) band mask is rebuilt per length (PR 6's
fused SDPA removes even that). The detector shares the legacy decode tail via the
extracted `assembleDetect`. The loader's bf16→f32 / transpose / f16-pack transforms are
OPFS-cached (versioned keys, download-once experts), so warm reloads skip both download
and transform. The demo forces the f16 manifest for eager and warns if a non-f16
`?weights=` is passed (int8 is PR 6).

**EAGER INT8/INT4 PATH — shipped.** `quantW` dtype + `matmulQuantW` (§3 above): the
eager loader packs the checkpoint's quantized experts (`source.quantized()` →
`packQuantColSlice`) and `EagerMoeMlp` dispatches to the dequantizing matmul, so eager
now reads the SAME `manifest-int8g640.json` (1.4GB) the demo ships — no f16 size
penalty. Parity verified vs the legacy quant engine on the real int8 checkpoint
(T=70): logits maxAbsDiff 3.05e-5, decoded PII spans identical 6/6 (drift is
accumulation-order only — both engines dequantize the same ints × scales). int4 shares
the kernel/packer (unit-tested); its full-checkpoint parity waits on int4 fixtures. The
detector probes the manifest format, and `?engine=eager` runs int8/int4/f16.

**PERF LADDER (PR 6) — shipped.** Measured on the real int8 checkpoint (T=70,
10 warm runs, min; legacy ~354ms), each step parity-verified before landing:

| step                                                                                                                                         | eager forward | ratio vs legacy |
| -------------------------------------------------------------------------------------------------------------------------------------------- | ------------- | --------------- |
| start of ladder                                                                                                                              | ~2740ms       | ~7.9×           |
| on-GPU MoE routing (`matmulGatherQuantW` = MLX `gather_qmm`; kills the 8 selection readbacks)                                                | 1196ms        | 3.0×            |
| fused `swiglu` op (7-dispatch elementwise chain → 1)                                                                                         | 1036ms        | 2.92×           |
| blocked-unit quantW layout (`kernels/quantCommon.ts` — THE layout contract; K-contiguous tile streams, x-reuse; packer + both quant kernels) | 841ms         | 2.40×           |
| `rope` op (mx.fast.rope analog — one dispatch per q/k slab; deletes the per-head fan-out AND the O(T²) band mask)                            | 722ms         | 2.04×           |
| vec4 base matmul (4 cols/thread, scalar tail for N%4≠0)                                                                                      | **638ms**     | **1.77×**       |

Measured dead ends, kept documented in `core/test/gpu/eagerGatherBench.test.ts`:
a fused switchGlu MoE kernel on the row layout (0.89× — fusion without the right
inner loop loses to 96 independent dispatches) and batching the 4 top-k slots
into one [280,640] gather (0.96× — M=70 already saturates; the win was
per-thread ILP, not thread count). The remaining ~1.8× is the eager tax —
per-primitive global-memory round-trips vs legacy's hand-fused blocks — which
only a compile/fusion layer deletes.

**EAGER ONLY (PR 7) — legacy deleted.** The demo runs the eager engine,
unconditionally. The fixture-based e2e suites (`e2e.test.ts`,
`e2e-quant.test.ts`) run the EAGER detector — the recorded reference spans are
engine-independent ground truth, so correctness never depended on keeping
legacy alive (mixed_long's knife-edge deviation reproduces identically on
eager, re-verified before the cut). With that oracle in place, the legacy
trace→compile engine is GONE: `graph/`, the legacy kernels (`gemm`, `moe`,
`moeQuant`, `ropeApply`, …), the trace-time `nn/` stack, zoo's legacy
model/pipeline/expertPack, and the live-parity + benchmark tests whose job is
done — the perf table above is the permanent record of the baseline they
measured. `kernels/common.ts` survives, trimmed to the shared plumbing
(KernelHandle/makeHandle, buffer types, WORKGROUP_SIZE/HIDDEN_V4). Everything
in §1–§9 now describes the only engine in the tree.

**Deferred:** a compile/fusion layer (would capture the eager DAG behind the same
interfaces — nothing in the current design blocks it, and nothing depends on it);
the remaining ~1.8× vs the recorded legacy baseline is its target.

---

## 11. Invariants — the rules that keep this correct

If you touch the runtime, don't break these:

1. **Ops never touch the GPU.** An op call validates, derives meta, links a node.
   All device work happens inside an eval.
2. **Dispatch order = `collectPending`'s post-order.** Inputs always encode before
   consumers; in-pass ordering does the synchronization.
3. **Buffer recycling relies on invariant 2.** Releasing before submit is safe only
   because encode order is execution order within one pass.
4. **Output shapes are computable from input ValueMeta alone.** No op may need GPU
   data to determine its output size (would force mid-graph sync).
5. **Pipelines are keyed (op, dtype), never shape.** New shapes must never compile
   shaders; dims travel in uniforms.
6. **`ops.ts` stays primitives-only** (PyTorch/MLX core vocabulary). Higher-level
   constructs compose in `compose.ts` / model code.
7. **Weights are never released to the pool.** Only buffers produced by the current
   eval are recycled, and never the requested targets.
8. **evalCore never imports WebGPU.** Everything device-specific lives behind
   `Executor`/`Readback` in `eval.ts`.
9. **Dotted field paths are the state-dict contract.** `namedParameters()` names
   must match checkpoint keys; changing field names is a breaking change to loading.
10. **Architecture hyperparameters have no defaults.** Required constructor args;
    only conventional tuning knobs (`eps`) may default.
11. **A buffer only survives an eval boundary if its Value was a target of the eval
    that materialized it** (or a direct upload). Anything held across a
    readback-then-keep-building boundary must be pinned as a co-target; recycled
    Values report state `'released'` and every later use throws (see §6).
